# BiteMap NOVA Evidence Review: Brown trout

- **BiteMap speciesId:** `brown-trout`
- **BiteMap status:** current
- **Supplied scientific name:** *Salmo trutta*
- **Accepted scientific name:** *Salmo trutta*
- **Research status:** PARTIAL

Machine-readable JSON supplied separately in the research archive.

## Taxonomy Check

Salmo trutta is accepted, but brown trout comprise deeply differentiated lineages and numerous hatchery stocks. Historical form names such as Salmo fario and Salmo lacustris do not define universally transferable activity thresholds.

**Relevant aliases:** *Salmo fario*, *Salmo lacustris*

**Taxonomy source IDs:** S2

## Targetability Assessment

Not applicable to a current or proposed BiteMap species status.

## 1. Executive Conclusion

### Strongest supported predictors

- No numerical activity predictor met the standard for safe scoring in the reviewed evidence. (model use: unavailable; evidence: none)

### Context only

- Use habitat, depth, cover, prey, and movement evidence to guide location and presentation rather than as automatic feeding bonuses. (model use: context-only; evidence: E1)
- Display reproductive phase as migration, aggregation, nesting, defense, or recovery with the mechanism clearly identified. (model use: context-only; evidence: E2)
- Display the reviewed diel classification as context only; do not apply a universal hourly multiplier. (model use: context-only; evidence: E3)

### Unsupported popular beliefs

- Do not assign barometric-pressure, generic front, cloud-cover, ordinary-rain, wind, or moon-phase weight without direct species-specific evidence.
- Do not use FishBase environmental ranges as active-feeding or catchability optima.
- Do not convert habitat occupancy, movement, growth, survival, electrofishing catch, or nest defense into feeding rate.

### Most important evidence gaps

- Direct hook-and-line catchability studies for Brown trout in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.

## 2. Evidence Ledger

| Evidence ID | Variable | Exact condition or range | Observed effect | What was measured | Population/location | Life stage | Evidence type | NOVA applicability | Confidence | Source ID | Source locator | Recommended model use | Limitations |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E1 | Habitat and feeding mode | Regional habitat and diet description | Virginia DWR describes brown trout in cold, clean, oxygenated streams and some impoundments, often using undercut banks, woody cover, pools, and overhead shade. Brown trout feed on aquatic and terrestrial invertebrates and increasingly on fish as they grow; large fish can be strongly cover-oriented. | expert/agency synthesis | Virginia or adjoining Mid-Atlantic region | Mixed | government species account | High regional relevance; describes location and feeding mode rather than per-fish catchability | medium | S1 | section Habitat; Diet; Reproduction; Recreational Opportunities | context-only | Habitat occupancy and diet do not by themselves demonstrate increased feeding motivation or angling catchability. |
| E2 | Broad biology and life history | Range-wide species account | Brown trout spawn during the fall and early winter in gravel redds. Reproductive movement and territorial behavior should be kept separate from feeding. | expert/agency synthesis | Range-wide; exact population depends on cited underlying studies | Mixed; reproduction concerns adults | metadata record | Useful for species-specific mechanism, but numerical transfer to Northern Virginia is not assumed | low | S2 | section Classification / Names; Biology; Life cycle and mating behavior; Human uses | context-only | FishBase is a synthesis. Underlying studies can involve other regions, stocks, or life stages. |
| E3 | Time and underwater light | Species-specific diel description | flexible; larger fish may feed heavily in low light or at night | movement/activity | Range-wide synthesis and regional account where available | Mixed | metadata record | General behavioral context; direct Northern Virginia angling evidence is absent | low | S2 | section Biology; Human uses | context-only | Diel classification does not establish a universal hourly catchability multiplier and may vary with season, size, clarity, and prey. |

## 3. Variable Synthesis

### Water temperature - context-only
No portable active-feeding optimum was identified. Population, season, acclimation, size, and rate of change remain important unresolved modifiers.

- Virginia DWR describes brown trout in cold, clean, oxygenated streams and some impoundments, often using undercut banks, woody cover, pools, and overhead shade.

### Dissolved oxygen - context-only
The reviewed evidence supports habitat context for oxygen-sensitive coldwater species but no portable feeding or catchability concentration.

### Time and underwater light - context-only
Classification: flexible. Season, size, temperature, clarity, prey, and cover may change the observed pattern. Treat water clarity and underwater light as presentation and habitat context unless a direct catchability study supports scoring.

### Flow and water level - unavailable
Flow can relocate fish, change access to habitat, alter current seams, and change presentation efficiency, but no portable species-specific hook-and-line modifier was identified.

### Turbidity and visibility - context-only
Visibility can affect prey and lure detection, but no defensible numerical Northern Virginia catchability range was identified.

### Tidal/current/salinity - not-applicable
Not a primary tidal species in the reviewed Northern Virginia context.

### Weather

All reviewed direct-weather fields are zero-weight unless a future species-specific study isolates an effect after aquatic mediators are controlled.

## 4. Reproductive Phase

| Phase | Regional months | Catchability effect | Mechanism | Model use | Evidence IDs | Notes |
|---|---|---|---|---|---|---|
| pre-spawn | 10, 11 | unknown | migration | context-only | E2 | Movement or staging may change location; feeding and catchability were not directly measured. |
| spawning | 10, 11, 12 | unknown | migration | context-only | E2 | Any nest or territorial response must be labeled defense rather than feeding. |
| nesting | unknown | unknown | unknown | context-only | E2 | Applies only where parental care occurs and must not be generalized to females or non-guarding fish. |
| post-spawn | 11, 12 | unknown | recovery | context-only | E2 | No supported universal post-spawn feeding bonus was identified. |
| recovery | unknown | unknown | recovery | unavailable | none | No direct catchability evidence. |

## 5. Monthly Regional Activity

| Month | Level | Mechanisms | Recommended model use | Evidence IDs |
|---|---|---|---|---|
| January | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| February | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| March | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| April | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| May | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| June | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| July | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| August | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| September | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| October | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| November | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| December | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |

## 6. Candidate Model Rules

| Input | Condition | Direction | Strength | Confidence | Recommended model use | Mechanism | Evidence IDs | Double-counting risk |
|---|---|---|---|---|---|---|---|---|
| habitatContext | Virginia DWR describes brown trout in cold, clean, oxygenated streams and some impoundments, often using undercut banks, woody cover, pools, and overhead shade. | context-only | weak | medium | context-only | Conditions alter fish location and presentation opportunities more clearly than intrinsic feeding motivation. | E1 | Do not stack habitat, season, temperature, flow, and depth modifiers when they describe the same relocation. |
| reproductivePhase | Brown trout spawn during the fall and early winter in gravel redds. Reproductive movement and territorial behavior should be kept separate from feeding. | context-only | weak | low | context-only | Nest defense, migration, or aggregation can change vulnerability without proving increased feeding. | E2 | Do not stack a spawn rule with a generic spring bonus or label defensive strikes as feeding. |
| timeOfDay | flexible; larger fish may feed heavily in low light or at night | context-only | weak | low | context-only | Diel behavior can alter movement and visual or chemical foraging opportunities. | E3 | Do not independently stack clock time, cloud cover, moonlight, turbidity, and underwater light. |

## 7. Conflict and Uncertainty Report

- Direct hook-and-line catchability studies for Brown trout in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.

## 8. Sources

### S1 - Brown Trout
- **Type:** government species account
- **Authors/agency:** Virginia Department of Wildlife Resources
- **Year:** 2024
- **Publisher:** Virginia Department of Wildlife Resources
- **DOI:** none
- **URL:** https://dwr.virginia.gov/wildlife/information/brown-trout/
- **Geographic scope:** Virginia or adjoining Mid-Atlantic region
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

### S2 - Salmo trutta, Brown trout species summary
- **Type:** metadata record
- **Authors/agency:** FishBase Consortium
- **Year:** 2026
- **Publisher:** FishBase
- **DOI:** none
- **URL:** https://www.fishbase.se/summary/Salmo-trutta.html
- **Geographic scope:** Range-wide synthesis; geographic applicability varies
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

## 9. Final Verdict

**RESEARCH STATUS: PARTIAL**

### SAFE TO IMPLEMENT

- None identified from the reviewed evidence.

### CONTEXT ONLY

- Use habitat, depth, cover, prey, and movement evidence to guide location and presentation rather than as automatic feeding bonuses. (model use: context-only; evidence: E1)
- Display reproductive phase as migration, aggregation, nesting, defense, or recovery with the mechanism clearly identified. (model use: context-only; evidence: E2)
- Display the reviewed diel classification as context only; do not apply a universal hourly multiplier. (model use: context-only; evidence: E3)

### DO NOT IMPLEMENT

- Do not assign barometric-pressure, generic front, cloud-cover, ordinary-rain, wind, or moon-phase weight without direct species-specific evidence. (model use: zero-weight; evidence: none)
- Do not use FishBase environmental ranges as active-feeding or catchability optima. (model use: zero-weight; evidence: E2)
- Do not convert habitat occupancy, movement, growth, survival, electrofishing catch, or nest defense into feeding rate. (model use: zero-weight; evidence: E1, E2, E3)

### MISSING

- Direct hook-and-line catchability studies for Brown trout in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.
