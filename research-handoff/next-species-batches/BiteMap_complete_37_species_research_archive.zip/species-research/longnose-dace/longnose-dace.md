# BiteMap NOVA Evidence Review: Longnose dace

- **BiteMap speciesId:** `longnose-dace`
- **BiteMap status:** guide-only
- **Supplied scientific name:** *Rhinichthys cataractae*
- **Accepted scientific name:** *Rhinichthys cataractae*
- **Research status:** PARTIAL

Machine-readable JSON supplied separately in the research archive.

## Taxonomy Check

Rhinichthys cataractae remains the accepted name in the reviewed taxonomic and agency sources. No geographic split was identified that clearly changes application to Northern Virginia, but population and hatchery differences may still limit transfer.

**Taxonomy source IDs:** S2

## Targetability Assessment

- **Intentionally targeted in Mid-Atlantic:** False
- **Hook-and-line practicality:** low
- **Promotion recommendation:** remain-guide-only
- **Reason:** The species is primarily forage, bait, and ecological-survey material; its size and riffle-holding behavior make deliberate hook-and-line targeting uncommon and impractical.
- **Evidence IDs:** E4

## 1. Executive Conclusion

### Strongest supported predictors

- No numerical activity predictor met the standard for safe scoring in the reviewed evidence. (model use: unavailable; evidence: none)

### Context only

- Use habitat, depth, cover, prey, and movement evidence to guide location and presentation rather than as automatic feeding bonuses. (model use: context-only; evidence: E1)
- Display reproductive phase as migration, aggregation, nesting, defense, or recovery with the mechanism clearly identified. (model use: context-only; evidence: E2)
- Display the reviewed diel classification as context only; do not apply a universal hourly multiplier. (model use: context-only; evidence: E3)

### Unsupported popular beliefs

- Do not assign barometric-pressure, generic front, cloud-cover, ordinary-rain, wind, or moon-phase weight without direct species-specific evidence.
- Do not use FishBase environmental ranges as active-feeding or catchability optima.
- Do not convert habitat occupancy, movement, growth, survival, electrofishing catch, or nest defense into feeding rate.

### Most important evidence gaps

- Direct hook-and-line catchability studies for Longnose dace in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.

## 2. Evidence Ledger

| Evidence ID | Variable | Exact condition or range | Observed effect | What was measured | Population/location | Life stage | Evidence type | NOVA applicability | Confidence | Source ID | Source locator | Recommended model use | Limitations |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E1 | Habitat and feeding mode | Regional habitat and diet description | FishBase describes longnose dace in rocky riffles and runs of streams and rivers where they hold close to the bottom in current. They feed mainly on benthic aquatic insects and other small invertebrates. | expert/agency synthesis | Virginia or adjoining Mid-Atlantic region | Mixed | government species account | High regional relevance; describes location and feeding mode rather than per-fish catchability | medium | S1 | section Overview; Geography | context-only | Habitat occupancy and diet do not by themselves demonstrate increased feeding motivation or angling catchability. |
| E2 | Broad biology and life history | Range-wide species account | Spawning biology is relevant to stream ecology, but no intentional Mid-Atlantic hook-and-line fishery or activity forecast evidence was found. | expert/agency synthesis | Range-wide; exact population depends on cited underlying studies | Mixed; reproduction concerns adults | metadata record | Useful for species-specific mechanism, but numerical transfer to Northern Virginia is not assumed | low | S2 | section Classification / Names; Biology; Life cycle and mating behavior; Human uses | context-only | FishBase is a synthesis. Underlying studies can involve other regions, stocks, or life stages. |
| E3 | Time and underwater light | Species-specific diel description | primarily diurnal to crepuscular | movement/activity | Range-wide synthesis and regional account where available | Mixed | metadata record | General behavioral context; direct Northern Virginia angling evidence is absent | low | S2 | section Biology; Human uses | context-only | Diel classification does not establish a universal hourly catchability multiplier and may vary with season, size, clarity, and prey. |
| E4 | Hook-and-line targetability | FishBase human-use classification plus species morphology and feeding ecology | No qualifying Mid-Atlantic source demonstrating a common intentional hook-and-line fishery was found in the reviewed evidence. | expert/agency synthesis | Mid-Atlantic applicability evaluated from range-wide and agency accounts | Mixed | metadata record | Directly addresses guide-only classification but remains an absence-of-evidence assessment | low | S2 | section Human uses; Biology | context-only | A niche fishery may exist without being documented in the reviewed sources. |

## 3. Variable Synthesis

### Water temperature - unavailable
No portable active-feeding optimum was identified. Population, season, acclimation, size, and rate of change remain important unresolved modifiers.

### Dissolved oxygen - unavailable
No species-specific Northern Virginia feeding or catchability threshold was identified.

### Time and underwater light - context-only
Classification: diurnal. Season, size, temperature, clarity, prey, and cover may change the observed pattern. Treat water clarity and underwater light as presentation and habitat context unless a direct catchability study supports scoring.

### Flow and water level - context-only
Flow can relocate fish, change access to habitat, alter current seams, and change presentation efficiency, but no portable species-specific hook-and-line modifier was identified.

### Turbidity and visibility - context-only
Visibility can affect prey and lure detection, but no defensible numerical Northern Virginia catchability range was identified.

### Tidal/current/salinity - not-applicable
Not a primary tidal species in the reviewed Northern Virginia context.

### Weather

All reviewed direct-weather fields are zero-weight unless a future species-specific study isolates an effect after aquatic mediators are controlled.

## 4. Reproductive Phase

| Phase | Regional months | Catchability effect | Mechanism | Model use | Evidence IDs | Notes |
|---|---|---|---|---|---|---|
| pre-spawn | 5, 6 | unknown | migration | context-only | E2 | Movement or staging may change location; feeding and catchability were not directly measured. |
| spawning | 5, 6, 7 | unknown | aggregation | context-only | E2 | Any nest or territorial response must be labeled defense rather than feeding. |
| nesting | unknown | unknown | unknown | context-only | E2 | Applies only where parental care occurs and must not be generalized to females or non-guarding fish. |
| post-spawn | 6, 7 | unknown | recovery | context-only | E2 | No supported universal post-spawn feeding bonus was identified. |
| recovery | unknown | unknown | recovery | unavailable | none | No direct catchability evidence. |

## 5. Monthly Regional Activity

| Month | Level | Mechanisms | Recommended model use | Evidence IDs |
|---|---|---|---|---|
| January | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| February | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| March | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| April | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| May | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| June | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| July | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| August | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| September | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| October | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| November | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |
| December | unknown | Guide-only ecological record; hook-and-line activity evidence is insufficient. | unavailable | E1, E2 |

## 6. Candidate Model Rules

| Input | Condition | Direction | Strength | Confidence | Recommended model use | Mechanism | Evidence IDs | Double-counting risk |
|---|---|---|---|---|---|---|---|---|
| habitatContext | FishBase describes longnose dace in rocky riffles and runs of streams and rivers where they hold close to the bottom in current. | context-only | weak | medium | context-only | Conditions alter fish location and presentation opportunities more clearly than intrinsic feeding motivation. | E1 | Do not stack habitat, season, temperature, flow, and depth modifiers when they describe the same relocation. |
| reproductivePhase | Spawning biology is relevant to stream ecology, but no intentional Mid-Atlantic hook-and-line fishery or activity forecast evidence was found. | context-only | weak | low | context-only | Nest defense, migration, or aggregation can change vulnerability without proving increased feeding. | E2 | Do not stack a spawn rule with a generic spring bonus or label defensive strikes as feeding. |
| timeOfDay | primarily diurnal to crepuscular | context-only | weak | low | context-only | Diel behavior can alter movement and visual or chemical foraging opportunities. | E3 | Do not independently stack clock time, cloud cover, moonlight, turbidity, and underwater light. |
| targetability | Intentional Mid-Atlantic hook-and-line targeting assessment | context-only | weak | low | context-only | Determines whether a bite-scored forecast is a practical product feature; it is not an environmental activity multiplier. | E4 | Do not convert general recreational interest into a biological bite bonus. |

## 7. Conflict and Uncertainty Report

- Direct hook-and-line catchability studies for Longnose dace in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.

## 8. Sources

### S1 - Longnose Dace
- **Type:** government species account
- **Authors/agency:** U.S. Fish and Wildlife Service
- **Year:** 2026
- **Publisher:** U.S. Fish and Wildlife Service
- **DOI:** none
- **URL:** https://www.fws.gov/species/longnose-dace-rhinichthys-cataractae
- **Geographic scope:** Virginia or adjoining Mid-Atlantic region
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

### S2 - Rhinichthys cataractae, Longnose dace species summary
- **Type:** metadata record
- **Authors/agency:** FishBase Consortium
- **Year:** 2026
- **Publisher:** FishBase
- **DOI:** none
- **URL:** https://www.fishbase.se/summary/Rhinichthys-cataractae.html
- **Geographic scope:** Range-wide synthesis; geographic applicability varies
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

## 9. Final Verdict

**RESEARCH STATUS: PARTIAL**

### SAFE TO IMPLEMENT

- None identified from the reviewed evidence.

### CONTEXT ONLY

- Use habitat, depth, cover, prey, and movement evidence to guide location and presentation rather than as automatic feeding bonuses. (model use: context-only; evidence: E1)
- Display reproductive phase as migration, aggregation, nesting, defense, or recovery with the mechanism clearly identified. (model use: context-only; evidence: E2)
- Display the reviewed diel classification as context only; do not apply a universal hourly multiplier. (model use: context-only; evidence: E3)

### DO NOT IMPLEMENT

- Do not assign barometric-pressure, generic front, cloud-cover, ordinary-rain, wind, or moon-phase weight without direct species-specific evidence. (model use: zero-weight; evidence: none)
- Do not use FishBase environmental ranges as active-feeding or catchability optima. (model use: zero-weight; evidence: E2)
- Do not convert habitat occupancy, movement, growth, survival, electrofishing catch, or nest defense into feeding rate. (model use: zero-weight; evidence: E1, E2, E3, E4)

### MISSING

- Direct hook-and-line catchability studies for Longnose dace in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.
