# BiteMap NOVA Evidence Review: Muskellunge

- **BiteMap speciesId:** `muskellunge`
- **BiteMap status:** current
- **Supplied scientific name:** *Esox masquinongy*
- **Accepted scientific name:** *Esox masquinongy*
- **Research status:** PARTIAL

Machine-readable JSON supplied separately in the research archive.

## Taxonomy Check

Esox masquinongy remains the accepted name in the reviewed taxonomic and agency sources. No geographic split was identified that clearly changes application to Northern Virginia, but population and hatchery differences may still limit transfer.

**Taxonomy source IDs:** S2

## Targetability Assessment

Not applicable to a current or proposed BiteMap species status.

## 1. Executive Conclusion

### Strongest supported predictors

- Apply a conservative high-temperature negative near 84 degrees F as an agency-supported feeding-cessation context; do not infer a precise optimum. (model use: score; evidence: E5)

### Context only

- Use habitat, depth, cover, prey, and movement evidence to guide location and presentation rather than as automatic feeding bonuses. (model use: context-only; evidence: E1)
- Display reproductive phase as migration, aggregation, nesting, defense, or recovery with the mechanism clearly identified. (model use: context-only; evidence: E2)
- Display the reviewed diel classification as context only; do not apply a universal hourly multiplier. (model use: context-only; evidence: E3)

### Unsupported popular beliefs

- Do not assign barometric-pressure, generic front, cloud-cover, ordinary-rain, wind, or moon-phase weight without direct species-specific evidence.
- Do not use FishBase environmental ranges as active-feeding or catchability optima.
- Do not convert habitat occupancy, movement, growth, survival, electrofishing catch, or nest defense into feeding rate.

### Most important evidence gaps

- Direct hook-and-line catchability studies for Muskellunge in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.

## 2. Evidence Ledger

| Evidence ID | Variable | Exact condition or range | Observed effect | What was measured | Population/location | Life stage | Evidence type | NOVA applicability | Confidence | Source ID | Source locator | Recommended model use | Limitations |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E1 | Habitat and feeding mode | Regional habitat and diet description | Virginia DWR describes muskellunge using large rivers and reservoirs with cover, current breaks, weed edges, and open-water prey. The account gives a preferred range of 62 to 75 degrees F, states feeding stops near 84 degrees F, and describes severe stress near 89 degrees F. Muskellunge are ambush piscivores whose encounter rate depends strongly on prey location, cover, and seasonal movement. | expert/agency synthesis | Virginia or adjoining Mid-Atlantic region | Mixed | government species account | High regional relevance; describes location and feeding mode rather than per-fish catchability | medium | S1 | section Habitat; Reproduction; Management and Research; Recreational Opportunities | context-only | Habitat occupancy and diet do not by themselves demonstrate increased feeding motivation or angling catchability. |
| E2 | Broad biology and life history | Range-wide species account | Virginia spawning occurs in late March and April around 50 to 60 degrees F. Spawning movement is an aggregation mechanism, not a feeding optimum. | expert/agency synthesis | Range-wide; exact population depends on cited underlying studies | Mixed; reproduction concerns adults | metadata record | Useful for species-specific mechanism, but numerical transfer to Northern Virginia is not assumed | low | S2 | section Classification / Names; Biology; Life cycle and mating behavior; Human uses | context-only | FishBase is a synthesis. Underlying studies can involve other regions, stocks, or life stages. |
| E3 | Time and underwater light | Species-specific diel description | flexible | movement/activity | Range-wide synthesis and regional account where available | Mixed | metadata record | General behavioral context; direct Northern Virginia angling evidence is absent | low | S2 | section Biology; Human uses | context-only | Diel classification does not establish a universal hourly catchability multiplier and may vary with season, size, clarity, and prey. |
| E4 | Hook-and-line targetability | Explicit regional fishing guidance or management context | Virginia DWR reports directed angler use and exploitation research, confirming intentional targeting. The same account warns about warm-water stress and handling mortality. | expert/agency synthesis | Mid-Atlantic region | Catchable juveniles and adults | government species account | Directly relevant to intentional regional angling | high | S3 | section Management and Research; Recreational Opportunities | context-only | Targetability evidence does not establish an environmental activity threshold. |
| E5 | Water temperature | Preferred 62-75 degrees F; feeding reported to stop near 84 degrees F; severe stress near 89 degrees F | Virginia DWR identifies a coolwater preference and a high-temperature feeding cessation and stress context. | expert/agency synthesis | Virginia managed muskellunge waters | Adult | government species account | Direct regional agency synthesis | medium | S1 | section Habitat | score | Agency account does not provide the underlying study design in the webpage. Treat 84 degrees F as a conservative agency threshold, not a precise universal switch. |

## 3. Variable Synthesis

### Water temperature - score
No portable active-feeding optimum was identified. Population, season, acclimation, size, and rate of change remain important unresolved modifiers.

- Virginia DWR describes muskellunge using large rivers and reservoirs with cover, current breaks, weed edges, and open-water prey. The account gives a preferred range of 62 to 75 degrees F, states feeding stops near 84 degrees F, and describes severe stress near 89 degrees F.

### Dissolved oxygen - unavailable
No species-specific Northern Virginia feeding or catchability threshold was identified.

### Time and underwater light - context-only
Classification: flexible. Season, size, temperature, clarity, prey, and cover may change the observed pattern. Treat water clarity and underwater light as presentation and habitat context unless a direct catchability study supports scoring.

### Flow and water level - unavailable
Flow can relocate fish, change access to habitat, alter current seams, and change presentation efficiency, but no portable species-specific hook-and-line modifier was identified.

### Turbidity and visibility - context-only
Visibility can affect prey and lure detection, but no defensible numerical Northern Virginia catchability range was identified.

### Tidal/current/salinity - not-applicable
Not a primary tidal species in the reviewed Northern Virginia context.

### Weather

All reviewed direct-weather fields are zero-weight unless a future species-specific study isolates an effect after aquatic mediators are controlled.

## 4. Reproductive Phase

| Phase | Regional months | Catchability effect | Mechanism | Model use | Evidence IDs | Notes |
|---|---|---|---|---|---|---|
| pre-spawn | 3, 4 | unknown | migration | context-only | E2 | Movement or staging may change location; feeding and catchability were not directly measured. |
| spawning | 3, 4 | unknown | migration | context-only | E2 | Any nest or territorial response must be labeled defense rather than feeding. |
| nesting | unknown | unknown | unknown | context-only | E2 | Applies only where parental care occurs and must not be generalized to females or non-guarding fish. |
| post-spawn | 3, 4 | unknown | recovery | context-only | E2 | No supported universal post-spawn feeding bonus was identified. |
| recovery | unknown | unknown | recovery | unavailable | none | No direct catchability evidence. |

## 5. Monthly Regional Activity

| Month | Level | Mechanisms | Recommended model use | Evidence IDs |
|---|---|---|---|---|
| January | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| February | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| March | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| April | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| May | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| June | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| July | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| August | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| September | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| October | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| November | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| December | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |

## 6. Candidate Model Rules

| Input | Condition | Direction | Strength | Confidence | Recommended model use | Mechanism | Evidence IDs | Double-counting risk |
|---|---|---|---|---|---|---|---|---|
| habitatContext | Virginia DWR describes muskellunge using large rivers and reservoirs with cover, current breaks, weed edges, and open-water prey. The account gives a preferred range of 62 to 75 degrees F, states feeding stops near 84 degrees F, and describes severe stress near 89 degrees F. | context-only | weak | medium | context-only | Conditions alter fish location and presentation opportunities more clearly than intrinsic feeding motivation. | E1 | Do not stack habitat, season, temperature, flow, and depth modifiers when they describe the same relocation. |
| reproductivePhase | Virginia spawning occurs in late March and April around 50 to 60 degrees F. Spawning movement is an aggregation mechanism, not a feeding optimum. | context-only | weak | low | context-only | Nest defense, migration, or aggregation can change vulnerability without proving increased feeding. | E2 | Do not stack a spawn rule with a generic spring bonus or label defensive strikes as feeding. |
| timeOfDay | flexible | context-only | weak | low | context-only | Diel behavior can alter movement and visual or chemical foraging opportunities. | E3 | Do not independently stack clock time, cloud cover, moonlight, turbidity, and underwater light. |
| waterTemperatureF | At or above approximately 84 degrees F | decrease | strong | medium | score | Virginia DWR reports feeding cessation near this temperature and severe stress at still higher temperature. | E5 | Do not stack a separate generic summer penalty or survival threshold with the same thermal mechanism. |
| targetability | Intentional Mid-Atlantic hook-and-line targeting assessment | context-only | weak | high | context-only | Determines whether a bite-scored forecast is a practical product feature; it is not an environmental activity multiplier. | E4 | Do not convert general recreational interest into a biological bite bonus. |

## 7. Conflict and Uncertainty Report

- Direct hook-and-line catchability studies for Muskellunge in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.

## 8. Sources

### S1 - Muskellunge
- **Type:** government species account
- **Authors/agency:** Virginia Department of Wildlife Resources
- **Year:** 2025
- **Publisher:** Virginia Department of Wildlife Resources
- **DOI:** none
- **URL:** https://dwr.virginia.gov/wildlife/information/muskellunge/
- **Geographic scope:** Virginia or adjoining Mid-Atlantic region
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

### S2 - Esox masquinongy, Muskellunge species summary
- **Type:** metadata record
- **Authors/agency:** FishBase Consortium
- **Year:** 2026
- **Publisher:** FishBase
- **DOI:** none
- **URL:** https://www.fishbase.se/summary/Esox-masquinongy.html
- **Geographic scope:** Range-wide synthesis; geographic applicability varies
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

### S3 - Muskellunge
- **Type:** government species account
- **Authors/agency:** Virginia Department of Wildlife Resources
- **Year:** 2025
- **Publisher:** Virginia DWR
- **DOI:** none
- **URL:** https://dwr.virginia.gov/wildlife/information/muskellunge/
- **Geographic scope:** Mid-Atlantic region
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

## 9. Final Verdict

**RESEARCH STATUS: PARTIAL**

### SAFE TO IMPLEMENT

- Apply a conservative high-temperature negative near 84 degrees F as an agency-supported feeding-cessation context; do not infer a precise optimum. (model use: score; evidence: E5)

### CONTEXT ONLY

- Use habitat, depth, cover, prey, and movement evidence to guide location and presentation rather than as automatic feeding bonuses. (model use: context-only; evidence: E1)
- Display reproductive phase as migration, aggregation, nesting, defense, or recovery with the mechanism clearly identified. (model use: context-only; evidence: E2)
- Display the reviewed diel classification as context only; do not apply a universal hourly multiplier. (model use: context-only; evidence: E3)

### DO NOT IMPLEMENT

- Do not assign barometric-pressure, generic front, cloud-cover, ordinary-rain, wind, or moon-phase weight without direct species-specific evidence. (model use: zero-weight; evidence: none)
- Do not use FishBase environmental ranges as active-feeding or catchability optima. (model use: zero-weight; evidence: E2)
- Do not convert habitat occupancy, movement, growth, survival, electrofishing catch, or nest defense into feeding rate. (model use: zero-weight; evidence: E1, E2, E3, E4)

### MISSING

- Direct hook-and-line catchability studies for Muskellunge in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.
