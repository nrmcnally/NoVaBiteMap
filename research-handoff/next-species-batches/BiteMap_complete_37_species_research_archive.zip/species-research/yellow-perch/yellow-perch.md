# BiteMap NOVA Evidence Review: Yellow perch

- **BiteMap speciesId:** `yellow-perch`
- **BiteMap status:** current
- **Supplied scientific name:** *Perca flavescens*
- **Accepted scientific name:** *Perca flavescens*
- **Research status:** PARTIAL

Machine-readable JSON supplied separately in the research archive.

## Taxonomy Check

Perca flavescens remains the accepted name in the reviewed taxonomic and agency sources. No geographic split was identified that clearly changes application to Northern Virginia, but population and hatchery differences may still limit transfer.

**Taxonomy source IDs:** S2

## Targetability Assessment

Not applicable to a current or proposed BiteMap species status.

## 1. Executive Conclusion

### Strongest supported predictors

- No numerical activity predictor met the standard for safe scoring in the reviewed evidence. (model use: unavailable; evidence: none)

### Context only

- Use habitat, depth, cover, prey, and movement evidence to guide location and presentation rather than as automatic feeding bonuses. (model use: context-only; evidence: E1)
- Display reproductive phase as migration, aggregation, nesting, defense, or recovery with the mechanism clearly identified. (model use: context-only; evidence: E2)
- Display the reviewed diel classification as context only; do not apply a universal hourly multiplier. (model use: context-only; evidence: E3)
- Display tidal/current/salinity context without a fixed tide-stage multiplier. (model use: context-only; evidence: E1)

### Unsupported popular beliefs

- Do not assign barometric-pressure, generic front, cloud-cover, ordinary-rain, wind, or moon-phase weight without direct species-specific evidence.
- Do not use FishBase environmental ranges as active-feeding or catchability optima.
- Do not convert habitat occupancy, movement, growth, survival, electrofishing catch, or nest defense into feeding rate.

### Most important evidence gaps

- Direct hook-and-line catchability studies for Yellow perch in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.

## 2. Evidence Ledger

| Evidence ID | Variable | Exact condition or range | Observed effect | What was measured | Population/location | Life stage | Evidence type | NOVA applicability | Confidence | Source ID | Source locator | Recommended model use | Limitations |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E1 | Habitat and feeding mode | Regional habitat and diet description | Virginia DWR describes schooling fish using reservoirs, tidal tributaries, vegetation, flats, and deeper channels depending on season. Yellow perch are visual predators on invertebrates and fish; schooling can strongly affect local encounter rates. | expert/agency synthesis | Virginia or adjoining Mid-Atlantic region | Mixed | government species account | High regional relevance; describes location and feeding mode rather than per-fish catchability | medium | S1 | section Diet; Habitat; Reproduction | context-only | Habitat occupancy and diet do not by themselves demonstrate increased feeding motivation or angling catchability. |
| E2 | Broad biology and life history | Range-wide species account | Regional fish make winter-to-early-spring movements into shallow tributaries and vegetation or woody structure to deposit gelatinous egg strands. Aggregation is not automatically increased feeding. | expert/agency synthesis | Range-wide; exact population depends on cited underlying studies | Mixed; reproduction concerns adults | metadata record | Useful for species-specific mechanism, but numerical transfer to Northern Virginia is not assumed | low | S2 | section Classification / Names; Biology; Life cycle and mating behavior; Human uses | context-only | FishBase is a synthesis. Underlying studies can involve other regions, stocks, or life stages. |
| E3 | Time and underwater light | Species-specific diel description | primarily diurnal in reviewed synthesis, with seasonal flexibility | movement/activity | Range-wide synthesis and regional account where available | Mixed | metadata record | General behavioral context; direct Northern Virginia angling evidence is absent | low | S2 | section Biology; Human uses | context-only | Diel classification does not establish a universal hourly catchability multiplier and may vary with season, size, clarity, and prey. |

## 3. Variable Synthesis

### Water temperature - unavailable
No portable active-feeding optimum was identified. Population, season, acclimation, size, and rate of change remain important unresolved modifiers.

### Dissolved oxygen - unavailable
No species-specific Northern Virginia feeding or catchability threshold was identified.

### Time and underwater light - context-only
Classification: diurnal. Season, size, temperature, clarity, prey, and cover may change the observed pattern. Treat water clarity and underwater light as presentation and habitat context unless a direct catchability study supports scoring.

### Flow and water level - unavailable
Flow can relocate fish, change access to habitat, alter current seams, and change presentation efficiency, but no portable species-specific hook-and-line modifier was identified.

### Turbidity and visibility - context-only
Visibility can affect prey and lure detection, but no defensible numerical Northern Virginia catchability range was identified.

### Tidal/current/salinity - context-only
Tide stage should be interpreted through actual current, depth, salinity, prey, and access to cover. No universal ebb, flood, or slack multiplier was identified.

### Weather

All reviewed direct-weather fields are zero-weight unless a future species-specific study isolates an effect after aquatic mediators are controlled.

## 4. Reproductive Phase

| Phase | Regional months | Catchability effect | Mechanism | Model use | Evidence IDs | Notes |
|---|---|---|---|---|---|---|
| pre-spawn | 1, 2 | unknown | migration | context-only | E2 | Movement or staging may change location; feeding and catchability were not directly measured. |
| spawning | 1, 2, 3, 4 | unknown | migration | context-only | E2 | Any nest or territorial response must be labeled defense rather than feeding. |
| nesting | unknown | unknown | unknown | context-only | E2 | Applies only where parental care occurs and must not be generalized to females or non-guarding fish. |
| post-spawn | 3, 4 | unknown | recovery | context-only | E2 | No supported universal post-spawn feeding bonus was identified. |
| recovery | unknown | unknown | recovery | unavailable | none | No direct catchability evidence. |

## 5. Monthly Regional Activity

| Month | Level | Mechanisms | Recommended model use | Evidence IDs |
|---|---|---|---|---|
| January | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| February | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| March | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| April | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| May | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| June | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| July | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| August | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| September | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| October | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| November | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| December | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |

## 6. Candidate Model Rules

| Input | Condition | Direction | Strength | Confidence | Recommended model use | Mechanism | Evidence IDs | Double-counting risk |
|---|---|---|---|---|---|---|---|---|
| habitatContext | Virginia DWR describes schooling fish using reservoirs, tidal tributaries, vegetation, flats, and deeper channels depending on season. | context-only | weak | medium | context-only | Conditions alter fish location and presentation opportunities more clearly than intrinsic feeding motivation. | E1 | Do not stack habitat, season, temperature, flow, and depth modifiers when they describe the same relocation. |
| reproductivePhase | Regional fish make winter-to-early-spring movements into shallow tributaries and vegetation or woody structure to deposit gelatinous egg strands. Aggregation is not automatically increased feeding. | context-only | weak | low | context-only | Nest defense, migration, or aggregation can change vulnerability without proving increased feeding. | E2 | Do not stack a spawn rule with a generic spring bonus or label defensive strikes as feeding. |
| timeOfDay | primarily diurnal in reviewed synthesis, with seasonal flexibility | context-only | weak | low | context-only | Diel behavior can alter movement and visual or chemical foraging opportunities. | E3 | Do not independently stack clock time, cloud cover, moonlight, turbidity, and underwater light. |

## 7. Conflict and Uncertainty Report

- Direct hook-and-line catchability studies for Yellow perch in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.

## 8. Sources

### S1 - Yellow Perch
- **Type:** government species account
- **Authors/agency:** Virginia Department of Wildlife Resources
- **Year:** 2024
- **Publisher:** Virginia Department of Wildlife Resources
- **DOI:** none
- **URL:** https://dwr.virginia.gov/wildlife/information/yellow-perch/
- **Geographic scope:** Virginia or adjoining Mid-Atlantic region
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

### S2 - Perca flavescens, Yellow perch species summary
- **Type:** metadata record
- **Authors/agency:** FishBase Consortium
- **Year:** 2026
- **Publisher:** FishBase
- **DOI:** none
- **URL:** https://www.fishbase.se/summary/Perca-flavescens.html
- **Geographic scope:** Range-wide synthesis; geographic applicability varies
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

## 9. Final Verdict

**RESEARCH STATUS: PARTIAL**

### SAFE TO IMPLEMENT

- None identified from the reviewed evidence.

### CONTEXT ONLY

- Use habitat, depth, cover, prey, and movement evidence to guide location and presentation rather than as automatic feeding bonuses. (model use: context-only; evidence: E1)
- Display reproductive phase as migration, aggregation, nesting, defense, or recovery with the mechanism clearly identified. (model use: context-only; evidence: E2)
- Display the reviewed diel classification as context only; do not apply a universal hourly multiplier. (model use: context-only; evidence: E3)
- Display tidal/current/salinity context without a fixed tide-stage multiplier. (model use: context-only; evidence: E1)

### DO NOT IMPLEMENT

- Do not assign barometric-pressure, generic front, cloud-cover, ordinary-rain, wind, or moon-phase weight without direct species-specific evidence. (model use: zero-weight; evidence: none)
- Do not use FishBase environmental ranges as active-feeding or catchability optima. (model use: zero-weight; evidence: E2)
- Do not convert habitat occupancy, movement, growth, survival, electrofishing catch, or nest defense into feeding rate. (model use: zero-weight; evidence: E1, E2, E3)

### MISSING

- Direct hook-and-line catchability studies for Yellow perch in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.
