# BiteMap NOVA Evidence Review: Blue catfish

- **BiteMap speciesId:** `blue-catfish`
- **BiteMap status:** current
- **Supplied scientific name:** *Ictalurus furcatus*
- **Accepted scientific name:** *Ictalurus furcatus*
- **Research status:** PARTIAL

Machine-readable JSON supplied separately in the research archive.

## Taxonomy Check

Ictalurus furcatus remains the accepted name in the reviewed taxonomic and agency sources. No geographic split was identified that clearly changes application to Northern Virginia, but population and hatchery differences may still limit transfer.

**Taxonomy source IDs:** S2

## Targetability Assessment

Not applicable to a current or proposed BiteMap species status.

## 1. Executive Conclusion

### Strongest supported predictors

- No numerical activity predictor met the standard for safe scoring in the reviewed evidence. (model use: unavailable; evidence: none)

### Context only

- Use habitat, depth, cover, prey, and movement evidence to guide location and presentation rather than as automatic feeding bonuses. (model use: context-only; evidence: E1)
- Display reproductive phase as migration, aggregation, nesting, defense, or recovery with the mechanism clearly identified. (model use: context-only; evidence: E2)
- Display the reviewed diel classification as context only; do not apply a universal hourly multiplier. (model use: context-only; evidence: E3)
- Display tidal/current/salinity context without a fixed tide-stage multiplier. (model use: context-only; evidence: E1)

### Unsupported popular beliefs

- Do not assign barometric-pressure, generic front, cloud-cover, ordinary-rain, wind, or moon-phase weight without direct species-specific evidence.
- Do not use FishBase environmental ranges as active-feeding or catchability optima.
- Do not convert habitat occupancy, movement, growth, survival, electrofishing catch, or nest defense into feeding rate.

### Most important evidence gaps

- Direct hook-and-line catchability studies for Blue catfish in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.

## 2. Evidence Ledger

| Evidence ID | Variable | Exact condition or range | Observed effect | What was measured | Population/location | Life stage | Evidence type | NOVA applicability | Confidence | Source ID | Source locator | Recommended model use | Limitations |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E1 | Habitat and feeding mode | Regional habitat and diet description | Virginia DWR describes adults using deep channels and structural cover by day and moving shallower during low-light feeding periods, especially in tidal rivers and reservoirs. Blue catfish use chemical and tactile senses as benthic predators and scavengers and may become strongly piscivorous with size. | expert/agency synthesis | Virginia or adjoining Mid-Atlantic region | Mixed | government species account | High regional relevance; describes location and feeding mode rather than per-fish catchability | medium | S1 | section Diet; Habitat; Reproduction; Recreational Opportunities | context-only | Habitat occupancy and diet do not by themselves demonstrate increased feeding motivation or angling catchability. |
| E2 | Broad biology and life history | Range-wide species account | Spawning occurs in late spring and early summer, with the DWR account identifying approximately 70 to 75 degrees F and movement toward cavity-forming structure or smaller connected waters. | expert/agency synthesis | Range-wide; exact population depends on cited underlying studies | Mixed; reproduction concerns adults | metadata record | Useful for species-specific mechanism, but numerical transfer to Northern Virginia is not assumed | low | S2 | section Classification / Names; Biology; Life cycle and mating behavior; Human uses | context-only | FishBase is a synthesis. Underlying studies can involve other regions, stocks, or life stages. |
| E3 | Time and underwater light | Species-specific diel description | predominantly low-light or nocturnal foraging with flexible behavior | movement/activity | Range-wide synthesis and regional account where available | Mixed | metadata record | General behavioral context; direct Northern Virginia angling evidence is absent | low | S2 | section Biology; Human uses | context-only | Diel classification does not establish a universal hourly catchability multiplier and may vary with season, size, clarity, and prey. |
| E4 | Hook-and-line targetability | Explicit regional fishing guidance or management context | Maryland provides specific Potomac and Chesapeake fishing locations and bottom-rig methods, confirming intentional Mid-Atlantic targeting. | expert/agency synthesis | Mid-Atlantic region | Catchable juveniles and adults | government species account | Directly relevant to intentional regional angling | high | S3 | section Fishing locations and methods | context-only | Targetability evidence does not establish an environmental activity threshold. |

## 3. Variable Synthesis

### Water temperature - unavailable
No portable active-feeding optimum was identified. Population, season, acclimation, size, and rate of change remain important unresolved modifiers.

### Dissolved oxygen - unavailable
No species-specific Northern Virginia feeding or catchability threshold was identified.

### Time and underwater light - context-only
Classification: nocturnal. Season, size, temperature, clarity, prey, and cover may change the observed pattern. Treat water clarity and underwater light as presentation and habitat context unless a direct catchability study supports scoring.

### Flow and water level - context-only
Flow can relocate fish, change access to habitat, alter current seams, and change presentation efficiency, but no portable species-specific hook-and-line modifier was identified.

### Turbidity and visibility - context-only
Visibility can affect prey and lure detection, but no defensible numerical Northern Virginia catchability range was identified.

### Tidal/current/salinity - context-only
Tide stage should be interpreted through actual current, depth, salinity, prey, and access to cover. No universal ebb, flood, or slack multiplier was identified.

### Weather

All reviewed direct-weather fields are zero-weight unless a future species-specific study isolates an effect after aquatic mediators are controlled.

## 4. Reproductive Phase

| Phase | Regional months | Catchability effect | Mechanism | Model use | Evidence IDs | Notes |
|---|---|---|---|---|---|---|
| pre-spawn | 5, 6 | unknown | migration | context-only | E2 | Movement or staging may change location; feeding and catchability were not directly measured. |
| spawning | 5, 6, 7 | unknown | migration | context-only | E2 | Any nest or territorial response must be labeled defense rather than feeding. |
| nesting | unknown | unknown | unknown | context-only | E2 | Applies only where parental care occurs and must not be generalized to females or non-guarding fish. |
| post-spawn | 6, 7 | unknown | recovery | context-only | E2 | No supported universal post-spawn feeding bonus was identified. |
| recovery | unknown | unknown | recovery | unavailable | none | No direct catchability evidence. |

## 5. Monthly Regional Activity

| Month | Level | Mechanisms | Recommended model use | Evidence IDs |
|---|---|---|---|---|
| January | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| February | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| March | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| April | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| May | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| June | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| July | variable | Reproductive movement, aggregation, nesting, or parental behavior may alter location and vulnerability.; Do not interpret reproductive vulnerability as feeding unless directly measured. | context-only | E2 |
| August | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| September | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| October | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| November | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |
| December | variable | Temperature, prey, habitat, and waterbody conditions vary; no precise monthly score is supported. | context-only | E1 |

## 6. Candidate Model Rules

| Input | Condition | Direction | Strength | Confidence | Recommended model use | Mechanism | Evidence IDs | Double-counting risk |
|---|---|---|---|---|---|---|---|---|
| habitatContext | Virginia DWR describes adults using deep channels and structural cover by day and moving shallower during low-light feeding periods, especially in tidal rivers and reservoirs. | context-only | weak | medium | context-only | Conditions alter fish location and presentation opportunities more clearly than intrinsic feeding motivation. | E1 | Do not stack habitat, season, temperature, flow, and depth modifiers when they describe the same relocation. |
| reproductivePhase | Spawning occurs in late spring and early summer, with the DWR account identifying approximately 70 to 75 degrees F and movement toward cavity-forming structure or smaller connected waters. | context-only | weak | low | context-only | Nest defense, migration, or aggregation can change vulnerability without proving increased feeding. | E2 | Do not stack a spawn rule with a generic spring bonus or label defensive strikes as feeding. |
| timeOfDay | predominantly low-light or nocturnal foraging with flexible behavior | context-only | weak | low | context-only | Diel behavior can alter movement and visual or chemical foraging opportunities. | E3 | Do not independently stack clock time, cloud cover, moonlight, turbidity, and underwater light. |
| targetability | Intentional Mid-Atlantic hook-and-line targeting assessment | context-only | weak | high | context-only | Determines whether a bite-scored forecast is a practical product feature; it is not an environmental activity multiplier. | E4 | Do not convert general recreational interest into a biological bite bonus. |

## 7. Conflict and Uncertainty Report

- Direct hook-and-line catchability studies for Blue catfish in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.

## 8. Sources

### S1 - Blue Catfish
- **Type:** government species account
- **Authors/agency:** Virginia Department of Wildlife Resources
- **Year:** 2025
- **Publisher:** Virginia Department of Wildlife Resources
- **DOI:** none
- **URL:** https://dwr.virginia.gov/wildlife/information/blue-catfish/
- **Geographic scope:** Virginia or adjoining Mid-Atlantic region
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

### S2 - Ictalurus furcatus, Blue catfish species summary
- **Type:** metadata record
- **Authors/agency:** FishBase Consortium
- **Year:** 2026
- **Publisher:** FishBase
- **DOI:** none
- **URL:** https://www.fishbase.se/summary/Ictalurus-furcatus.html
- **Geographic scope:** Range-wide synthesis; geographic applicability varies
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

### S3 - Blue Catfish Fishing
- **Type:** government species account
- **Authors/agency:** Maryland Department of Natural Resources
- **Year:** 2026
- **Publisher:** Maryland DNR
- **DOI:** none
- **URL:** https://dnr.maryland.gov/fisheries/Pages/blue-catfish/bcat_fishing.aspx
- **Geographic scope:** Mid-Atlantic region
- **Access mode:** full-text
- **Verification status:** AI-reviewed-unverified

## 9. Final Verdict

**RESEARCH STATUS: PARTIAL**

### SAFE TO IMPLEMENT

- None identified from the reviewed evidence.

### CONTEXT ONLY

- Use habitat, depth, cover, prey, and movement evidence to guide location and presentation rather than as automatic feeding bonuses. (model use: context-only; evidence: E1)
- Display reproductive phase as migration, aggregation, nesting, defense, or recovery with the mechanism clearly identified. (model use: context-only; evidence: E2)
- Display the reviewed diel classification as context only; do not apply a universal hourly multiplier. (model use: context-only; evidence: E3)
- Display tidal/current/salinity context without a fixed tide-stage multiplier. (model use: context-only; evidence: E1)

### DO NOT IMPLEMENT

- Do not assign barometric-pressure, generic front, cloud-cover, ordinary-rain, wind, or moon-phase weight without direct species-specific evidence. (model use: zero-weight; evidence: none)
- Do not use FishBase environmental ranges as active-feeding or catchability optima. (model use: zero-weight; evidence: E2)
- Do not convert habitat occupancy, movement, growth, survival, electrofishing catch, or nest defense into feeding rate. (model use: zero-weight; evidence: E1, E2, E3, E4)

### MISSING

- Direct hook-and-line catchability studies for Blue catfish in Northern Virginia or the adjoining Mid-Atlantic.
- Validated active-feeding and feeding-decline temperature ranges for the relevant regional population.
- Species-specific dissolved-oxygen, turbidity, flow-rate-of-change, and weather effects on per-fish catchability.
- Field studies separating abundance, fishing effort, movement, spawning behavior, and presentation efficiency.
