# Blacknose dace (*Rhinichthys atratulus*)

**Species ID:** `blacknose-dace`  
**Schema:** 1.1  
**Research status:** partial  
**Targetability recommendation:** fish-guide-only  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Fish Guide only. A conditional summer crepuscular feeding rule is scientifically supported in one Lake Ontario tributary, but low targetability and lack of regional replication make production bite scoring inappropriate.

### Model-ready findings

- **time of day - Summer conditions comparable to the reviewed Lake Ontario tributary:** Increase expected feeding near crepuscular periods; main observed peak 1600-2000 h and smaller peak 0400-0800 h (medium). Evidence: E1.

### Context-only findings

- **benthic prey availability:** Guide presentation and prey matching; no calibrated bonus. Diet and benthos association. Evidence: E2, E3.
- **winter habitat:** Shift location context toward rubble crevices and winter focal habitat. Observed seasonal habitat shift. Evidence: E4, E5.
- **population/current adaptation:** Use as transfer and habitat context only. Swimming performance and plasticity vary among populations. Evidence: E6, E7.
- **taxonomic/ecotype gate:** Require taxonomic review before transfer to NOVA R. atratulus. Modern molecular evidence separates R. atratulus and R. obtusus. Evidence: E8.

### Rejected or zero-weight assumptions

- **barometric pressure and weather fronts:** No qualifying direct species-specific feeding, foraging, or hook-and-line catchability experiment isolated pressure or fronts.
- **moon phase:** No qualifying direct species-specific feeding or catchability evidence was found.
- **wind and cloud cover:** No direct species-specific endpoint evidence isolated these atmospheric variables.
- **ordinary rainfall:** Rainfall was not isolated from discharge, turbidity, habitat access, or prey delivery in a direct feeding or catchability study.
- **recent stocking:** No species-specific post-stocking hook-and-line accessibility or depletion experiment was found.
- **angling pressure, hook avoidance, and learning:** No species-specific vulnerability, learning, or depletion experiment was found.
- **monthly activity curve:** No direct evidence supports a smooth monthly feeding or catchability curve; season, temperature, spawn, effort, and abundance cannot be collapsed safely.
- **growth, thermal preference, or survival as bite optimum:** Growth, preferred temperature, lethal limits, and physiological performance are not feeding or hook-and-line catchability unless directly linked.
- **photoperiod-dependent lethal limits as bite thresholds:** 29.9 C and 28.8 C were survival/tolerance endpoints after laboratory acclimation, not feeding optima.
- **predator avoidance behavior as a bite modifier:** The juvenile artificial-stream study measured anti-predator space use, not feeding or angling catchability.

## Endpoint separation and adversarial review

- Hook-and-line catchability, feeding/consumption, and direct foraging/attack/prey selection were the only score-eligible endpoint classes.
- Movement, habitat occupancy, growth, physiology, stress, survival, and reproduction remained context unless directly linked to feeding or catchability.
- Contradictory, null, inaccessible, and transfer-limited evidence was preserved. No smooth response curve or production multiplier was invented.

## Targetability assessment

A direct summer feeding-period result exists, but blacknose dace is not a practical mainstream hook-and-line target. The feeding rule is retained scientifically as a conditional candidate but should not be activated in production unless the species is deliberately promoted for microfishing or ecological-guide use.

## Evidence ledger

### E1 - time of day / feeding periodicity
- **Condition/range:** Summer sampling, Lake Ontario tributary
- **Observed effect:** Blacknose dace fed most heavily during crepuscular periods, with a main peak from 1600-2000 h and a smaller peak from 0400-0800 h.
- **Measured:** Stomach fullness/diet through the diel cycle
- **Population:** Lake Ontario tributary, New York; mixed small stream fish
- **Evidence / NOVA / confidence:** field feeding study / medium-high / medium
- **Source:** S1 (page: 282-286, section: Author abstract)
- **Model use:** score
- **Limitations:** Single tributary and summer season; original full article was not independently inspected, so the rule must remain conditional rather than universal.

### E2 - seasonal diet composition
- **Condition/range:** June through September
- **Observed effect:** Chironomid larvae were the major prey, but their contribution generally declined from June to September.
- **Measured:** Stomach-content composition
- **Population:** Lake Ontario tributary, New York; mixed
- **Evidence / NOVA / confidence:** field diet study / medium-high / medium
- **Source:** S1 (page: 282-286, section: Author abstract)
- **Model use:** context-only
- **Limitations:** Changing diet share may reflect prey phenology and does not quantify total feeding rate.

### E3 - prey availability and source
- **Condition/range:** Diel samples in Trucka Brook
- **Observed effect:** Blacknose dace diets were closely associated with benthic prey; a mayfly nymph was a major prey item in the fish community.
- **Measured:** Fish diets compared with benthos and drift
- **Population:** Adirondack Mountains, New York; mixed
- **Evidence / NOVA / confidence:** field community trophic study / medium-high / medium
- **Source:** S2 (page: 97-104, section: Abstract)
- **Model use:** context-only
- **Limitations:** Multi-species study; no portable blacknose-dace effect size for a BiteMap score was extracted.

### E4 - winter temperature and habitat shift
- **Condition/range:** Late November as water temperature declined below 5.0 C
- **Observed effect:** Dace moved into crevices beneath rubble; mean maximum rubble diameter was 15.9 cm.
- **Measured:** Underwater habitat observations
- **Population:** Southern Ontario stream; mixed
- **Evidence / NOVA / confidence:** winter field study / medium / high
- **Source:** S3 (page: 53-60, section: Abstract)
- **Model use:** context-only
- **Limitations:** Habitat occupancy and movement were measured, not feeding or catchability.

### E5 - winter depth and velocity
- **Condition/range:** Winter versus summer observations
- **Observed effect:** Winter focal depth was greater and mid-depth water velocity was faster than in summer.
- **Measured:** Focal depth and current velocity
- **Population:** Southern Ontario stream; mixed
- **Evidence / NOVA / confidence:** winter field study / medium / high
- **Source:** S3 (page: 53-60, section: Abstract)
- **Model use:** context-only
- **Limitations:** Location context only; cannot infer a winter bite increase or decrease.

### E6 - current adaptation
- **Condition/range:** Populations from streams with different current velocities
- **Observed effect:** Swimming performance mirrored home-stream current velocity.
- **Measured:** Swimming performance
- **Population:** Eastern U.S. stream populations; mixed
- **Evidence / NOVA / confidence:** comparative physiology / high regional / high
- **Source:** S4 (page: 301-308, section: Abstract)
- **Model use:** context-only
- **Limitations:** Performance adaptation is not feeding rate, and population effects limit transfer.

### E7 - population/urbanization modifier
- **Condition/range:** Populations across an urbanization gradient
- **Observed effect:** Performance differences showed environmental correlates, plasticity, and repeatability among populations.
- **Measured:** Physiological/performance traits
- **Population:** Eastern U.S. streams; mixed
- **Evidence / NOVA / confidence:** comparative physiology / high regional / medium
- **Source:** S5 (page: 25-42, section: Abstract)
- **Model use:** context-only
- **Limitations:** Population performance does not directly predict feeding or hook-and-line catchability.

### E8 - taxonomic transfer
- **Condition/range:** Eastern half of North America
- **Observed effect:** Large genetic differences support separation of eastern R. atratulus and western R. obtusus; R. atratulus occurs east of the Appalachians from Nova Scotia to Virginia and in part of the eastern Great Lakes.
- **Measured:** Mitochondrial genes and microsatellites
- **Population:** Eastern North America; mixed
- **Evidence / NOVA / confidence:** molecular phylogenetics / very high / high
- **Source:** S6 (page: 325-338, section: Abstract / original paper)
- **Model use:** context-only
- **Limitations:** Older western blacknose-dace studies may involve R. obtusus or a broad species concept and must not be transferred silently to NOVA.

### E9 - predator-risk behavior
- **Condition/range:** Juvenile dace exposed to varying creek-chub density and habitat structure
- **Observed effect:** When structure at predator locations was low, dace avoided predators at night but not during the day; response did not scale with predator density in that treatment.
- **Measured:** Space use under predation risk
- **Population:** Artificial field stream; juvenile
- **Evidence / NOVA / confidence:** controlled behavioral study / low-medium / medium
- **Source:** S7 (page: 364-370, section: Abstract)
- **Model use:** context-only
- **Limitations:** Predation avoidance is not feeding; juvenile artificial-stream behavior should not become an angling rule.

### E10 - photoperiod and upper thermal tolerance
- **Condition/range:** 20 C acclimation; 16L:8D versus 8L:16D
- **Observed effect:** Long-day fish had incipient upper lethal temperature 29.9 C versus 28.8 C under short days, and generally longer resistance times.
- **Measured:** Thermal lethality/resistance
- **Population:** Laboratory population; mixed
- **Evidence / NOVA / confidence:** laboratory physiology / low-medium / high
- **Source:** S8 (page: 241-244, section: Abstract)
- **Model use:** context-only
- **Limitations:** Survival and lethal tolerance are not feeding optima; do not use these values as bite thresholds.

### E11 - early-life development
- **Condition/range:** Susquehanna River tributary stock
- **Observed effect:** Embryo-to-juvenile development was described for blacknose and longnose dace.
- **Measured:** Larval morphology and development
- **Population:** Pennsylvania Susquehanna tributary; embryo to juvenile
- **Evidence / NOVA / confidence:** proceedings early-life study / high regional / medium
- **Source:** S9 (page: 56-60, section: Paper scope)
- **Model use:** context-only
- **Limitations:** Early-life development does not support adult feeding or catchability rules.

### E12 - hook-and-line targetability
- **Condition/range:** Broad targeted search
- **Observed effect:** No qualifying intentional hook-and-line fishery or catchability experiment was located; the species is small and normally functions as a forage/minnow species.
- **Measured:** Evidence-gap and practicality assessment
- **Population:** Northern Virginia / Mid-Atlantic; adult
- **Evidence / NOVA / confidence:** evidence synthesis / high / medium
- **Source:** S1 (section: Search-breadth audit)
- **Model use:** unavailable
- **Limitations:** Microfishing can intentionally target dace, but production BiteMap prioritization is weak.

### E13 - dissolved oxygen, turbidity, pressure, fronts, moon, stocking, angling pressure
- **Condition/range:** Broad variable-specific searches
- **Observed effect:** No direct species-specific feeding or catchability response adequate for scoring was found.
- **Measured:** Evidence-gap assessment
- **Population:** Range-wide with Mid-Atlantic priority; mixed
- **Evidence / NOVA / confidence:** systematic review / high / medium
- **Source:** S1 (section: Search-breadth audit)
- **Model use:** unavailable
- **Limitations:** Absence of evidence is not evidence of no biological effect.

## Candidate model rules

### R1 - time of day
- **Condition:** Summer conditions comparable to the reviewed Lake Ontario tributary
- **Direction:** Increase expected feeding near crepuscular periods; main observed peak 1600-2000 h and smaller peak 0400-0800 h
- **Strength / confidence:** moderate within-study; weak transfer / medium
- **Use:** score
- **Mechanism:** Direct diel feeding periodicity from stomach-content evidence.
- **Evidence:** E1
- **Double-counting risk:** High risk of double counting light, season, temperature, and local prey timing. Do not apply outside summer or as a universal hourly curve.

### R2 - benthic prey availability
- **Condition:** Where benthic chironomids/mayflies are locally available
- **Direction:** Guide presentation and prey matching; no calibrated bonus
- **Strength / confidence:** weak / medium
- **Use:** context-only
- **Mechanism:** Diet and benthos association.
- **Evidence:** E2, E3
- **Double-counting risk:** Avoid double counting substrate and stream productivity.

### R3 - winter habitat
- **Condition:** Water declining below 5.0 C in a comparable stream
- **Direction:** Shift location context toward rubble crevices and winter focal habitat
- **Strength / confidence:** moderate / high
- **Use:** context-only
- **Mechanism:** Observed seasonal habitat shift.
- **Evidence:** E4, E5
- **Double-counting risk:** Do not translate habitat shift into lower or higher feeding.

### R4 - population/current adaptation
- **Condition:** Population-specific home-stream current regime
- **Direction:** Use as transfer and habitat context only
- **Strength / confidence:** moderate / high
- **Use:** context-only
- **Mechanism:** Swimming performance and plasticity vary among populations.
- **Evidence:** E6, E7
- **Double-counting risk:** Do not treat high swimming performance as high bite activity.

### R5 - taxonomic/ecotype gate
- **Condition:** Studies west of Appalachians or labeled western blacknose dace
- **Direction:** Require taxonomic review before transfer to NOVA R. atratulus
- **Strength / confidence:** strong / high
- **Use:** context-only
- **Mechanism:** Modern molecular evidence separates R. atratulus and R. obtusus.
- **Evidence:** E8
- **Double-counting risk:** Prevents mixing species/population effects.

### R6 - photoperiod thermal threshold
- **Condition:** 29.9 C versus 28.8 C lethal-tolerance result
- **Direction:** No feeding or bite threshold
- **Strength / confidence:** strong rejection / high
- **Use:** zero-weight
- **Mechanism:** The experiment measured lethality/resistance, not ingestion.
- **Evidence:** E10
- **Double-counting risk:** Avoid double counting temperature and photoperiod as feeding.

### R7 - predator density/day-night response
- **Condition:** Juvenile artificial-stream predator experiment
- **Direction:** No bite modifier
- **Strength / confidence:** strong rejection / medium
- **Use:** zero-weight
- **Mechanism:** Anti-predator space use is not feeding.
- **Evidence:** E9
- **Double-counting risk:** Avoid converting avoidance behavior to catchability.

## Complete bibliography

- **S1** James H. Johnson (1982). *Summer feeding ecology of the Blacknose Dace, Rhinichthys atratulus, in a tributary of Lake Ontario*. The Canadian Field-Naturalist 96(3):282-286. https://www.biodiversitylibrary.org/item/89040 Access: bibliographic-full-volume-plus-author-abstract; verification: AI-reviewed-unverified.
- **S2** James H. Johnson; Emily Z. Johnson (1982). *Diel foraging in relation to available prey in an Adirondack Mountain stream fish community*. Hydrobiologia 96:97-104. DOI: 10.1007/BF00006282. https://link.springer.com/article/10.1007/BF00006282 Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S3** Richard A. Cunjak; Geoffrey Power (1986). *Winter biology of the blacknose dace, Rhinichthys atratulus, in a southern Ontario stream*. Environmental Biology of Fishes 17(1):53-60. DOI: 10.1007/BF00000401. https://link.springer.com/article/10.1007/BF00000401 Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S4** Jay A. Nelson; Portia S. Gotwalt; Joel W. Snodgrass (2003). *Swimming performance of blacknose dace (Rhinichthys atratulus) mirrors home-stream current velocity*. Canadian Journal of Fisheries and Aquatic Sciences 60(3):301-308. DOI: 10.1139/f03-023. https://cdnsciencepub.com/doi/10.1139/f03-023 Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S5** Jay A. Nelson; P. S. Gotwalt; C. A. Simonetti; J. W. Snodgrass (2008). *Environmental correlates, plasticity, and repeatability of differences in performance among blacknose dace (Rhinichthys atratulus) populations across a gradient of urbanization*. Physiological and Biochemical Zoology 81(1):25-42. DOI: 10.1086/523304. https://pubmed.ncbi.nlm.nih.gov/18040970/ Access: abstract-and-metadata; verification: AI-reviewed-unverified.
- **S6** Michelle L. Kraczkowski; Barry Chernoff (2014). *Molecular Phylogenetics of the Eastern and Western Blacknose Dace, Rhinichthys atratulus and R. obtusus (Teleostei: Cyprinidae)*. Copeia 2014(2):325-338. DOI: 10.1643/CG-14-002. https://bioone.org/journals/ichthyology-and-herpetology/volume-2014/issue-2/CG-14-002/Molecular-Phylogenetics-of-the-Eastern-and-Western-Blacknose-Dace-iRhinichthys/10.1643/CG-14-002.pdf Access: author-uploaded-full-text-and-publisher-metadata; verification: AI-reviewed-unverified.
- **S7** Douglas F. Fraser; Edward E. Emmons (1984). *Behavioral Response of Blacknose Dace (Rhinichthys atratulus) to Varying Densities of Predatory Creek Chub (Semotilus atromaculatus)*. Canadian Journal of Fisheries and Aquatic Sciences 41(2):364-370. DOI: 10.1139/f84-039. https://cdnsciencepub.com/doi/full/10.1139/f84-039 Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S8** Kenneth M. Terpin; James R. Spotila; Robert R. Koons (1976). *Effect of photoperiod on the temperature tolerance of the blacknose dace, Rhinichthys atratulus*. Comparative Biochemistry and Physiology Part A 53(3):241-244. DOI: 10.1016/S0300-9629(76)80028-X. https://www.sciencedirect.com/science/article/abs/pii/S030096297680028X Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S9** Gerard L. Buynak; Harold W. Mohr, Jr. (1979). *Larval Development of the Blacknose Dace (Rhinichthys atratulus) and Longnose Dace (Rhinichthys cataractae) from a Susquehanna River Tributary*. Proceedings of the Pennsylvania Academy of Science 53(1):56-60. https://www.jstor.org/stable/44112593 Access: metadata-and-summary; verification: AI-reviewed-unverified.

## Remaining research gaps

- Full-text replication and exact methods review of the 1982 diel-feeding study.
- Virginia/Mid-Atlantic feeding periodicity studies.
- Hook-and-line/microfishing vulnerability studies.
- Direct environmental feeding responses for temperature, oxygen, discharge, turbidity, and weather.
