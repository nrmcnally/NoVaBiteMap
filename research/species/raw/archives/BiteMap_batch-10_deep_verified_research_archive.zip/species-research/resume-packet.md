# BiteMap NOVA research resume packet

## Completed species

- largemouth-bass
- smallmouth-bass
- channel-catfish
- Batches 1-8 (provided by user)
- Batch 9: yellow-bullhead, brown-bullhead, northern-hogsucker
- Batch 10: shorthead-redhorse, blacknose-dace, longnose-dace

## Pending species

- Batch 11: mottled-sculpin, tessellated-darter, gizzard-shad

## Next recommended batch

Batch 11 - Primarily Fish Guide species. Do not manufacture score rules or a source quota.

## Schema version

1.1

## Batch 10 result

- Shorthead redhorse: Fish Guide only; plausible intentional target, but no score-ready environmental feeding/catchability evidence.
- Blacknose dace: Fish Guide only; one conditional summer crepuscular feeding candidate, not recommended for production because targetability and regional replication are weak.
- Longnose dace: Fish Guide only; a constrained prey-patch foraging candidate exists, while universal diel scoring is rejected because populations conflict.

## Known corrections

See `correction-and-conflict-log.json`. Preserve Harold W. Mohr, Jr.; all nine Hatry et al. authors; the eastern/western blacknose-dace taxonomic split; and the longnose-dace diel contradiction.

## Unresolved questions

- No direct hook-and-line catchability experiment was found for any Batch 10 species.
- Blacknose-dace diel feeding needs full-text and Mid-Atlantic replication.
- Longnose-dace prey-patch selection needs local replication and a real prey-availability input.
- Shorthead-redhorse evidence remains dominated by diet, reproduction, movement, fishway, habitat, and demographics.

## Files a new chat must receive

1. BiteMap_complete_37_species_research_archive.zip
2. BiteMap_channel-catfish_deep_verified_research_archive.zip
3. The immediately preceding completed-batch archive(s), including Batch 9 and this Batch 10 ZIP
4. COPY_PASTE_MASTER_PROMPT.txt, changed to ACTIVE BATCH = BATCH 11
