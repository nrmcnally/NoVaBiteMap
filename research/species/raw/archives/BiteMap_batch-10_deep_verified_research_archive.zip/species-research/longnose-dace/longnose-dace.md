# Longnose dace (*Rhinichthys cataractae*)

**Species ID:** `longnose-dace`  
**Schema:** 1.1  
**Research status:** partial  
**Targetability recommendation:** fish-guide-only  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Fish Guide only. Direct foraging evidence supports a constrained local prey-patch rule, but low targetability and contradictory population-level diel behavior preclude a general production bite score.

### Model-ready findings

- **local prey patchiness - Summer, physically suitable patches under 5 m where benthic prey are demonstrably patchy:** Prioritize high-prey patches; avoid a continuous prey-density curve (high). Evidence: E2.

### Context-only findings

- **reach-scale prey and habitat:** Location context: higher prey reaches may hold more dace. Reach-scale abundance correlated with prey, but habitat constrained occupancy. Evidence: E3, E4.
- **substrate and current:** Use for location guidance only. Physical habitat constrained use even when food was abundant. Evidence: E4, E10, E11, E12.
- **benthic prey/presentation:** Fish Guide bait/presentation context only. Diet studies establish prey type but not environmental response. Evidence: E8, E9.
- **fish size/life stage:** Context-only modifier for location. Size-specific habitat use. Evidence: E10, E13.

### Rejected or zero-weight assumptions

- **barometric pressure and weather fronts:** No qualifying direct species-specific feeding, foraging, or hook-and-line catchability experiment isolated pressure or fronts.
- **moon phase:** No qualifying direct species-specific feeding or catchability evidence was found.
- **wind and cloud cover:** No direct species-specific endpoint evidence isolated these atmospheric variables.
- **ordinary rainfall:** Rainfall was not isolated from discharge, turbidity, habitat access, or prey delivery in a direct feeding or catchability study.
- **recent stocking:** No species-specific post-stocking hook-and-line accessibility or depletion experiment was found.
- **angling pressure, hook avoidance, and learning:** No species-specific vulnerability, learning, or depletion experiment was found.
- **monthly activity curve:** No direct evidence supports a smooth monthly feeding or catchability curve; season, temperature, spawn, effort, and abundance cannot be collapsed safely.
- **growth, thermal preference, or survival as bite optimum:** Growth, preferred temperature, lethal limits, and physiological performance are not feeding or hook-and-line catchability unless directly linked.
- **universal night or day bite bonus:** Direct observations conflict between Alberta and Coweeta populations.
- **single-cobble prey biomass bonus:** Foraging intensity was not correlated with prey biomass at the primary cobble scale.

## Endpoint separation and adversarial review

- Hook-and-line catchability, feeding/consumption, and direct foraging/attack/prey selection were the only score-eligible endpoint classes.
- Movement, habitat occupancy, growth, physiology, stress, survival, and reproduction remained context unless directly linked to feeding or catchability.
- Contradictory, null, inaccessible, and transfer-limited evidence was preserved. No smooth response curve or production multiplier was invented.

## Targetability assessment

Longnose dace has valuable direct foraging science, including a transferable concept of prey-patch selection, but it is not a practical mainstream hook-and-line target. Retain the rule for ecological/location intelligence and possible microfishing use rather than production bite scoring.

## Evidence ledger

### E1 - prey patchiness at primary scale
- **Condition/range:** Four to five cobbles separated by less than 1 m; summer, autumn, spring
- **Observed effect:** Foraging intensity was not correlated with benthic macroinvertebrate biomass per cobble in any season.
- **Measured:** Observed bites per cobble and macroinvertebrate biomass
- **Population:** Ball Creek, Coweeta, North Carolina; adults over 45 mm standard length
- **Evidence / NOVA / confidence:** natural-stream foraging experiment / very high regional / high
- **Source:** S1 (page: 145, section: Summary item 2)
- **Model use:** score
- **Limitations:** Important null finding: prey density on a single cobble did not predict bite intensity.

### E2 - prey patchiness at secondary scale
- **Condition/range:** Foraging patches less than 5 m diameter
- **Observed effect:** In summer, when prey were patchily distributed, dace used cobbles with significantly higher macroinvertebrate biomass than nearby physically similar random cobbles; no such selection occurred in autumn or spring when prey were homogeneous.
- **Measured:** Direct foraging-patch selection and prey biomass
- **Population:** Ball Creek, Coweeta, North Carolina; adult
- **Evidence / NOVA / confidence:** natural-stream foraging experiment / very high regional / high
- **Source:** S1 (page: 145, section: Summary item 3)
- **Model use:** score
- **Limitations:** Conditional on local summer prey patchiness and comparable stream habitat; not a smooth prey-response curve.

### E3 - prey biomass at reach scale
- **Condition/range:** Erosional reaches 11-19 m long
- **Observed effect:** Among physically suitable reaches, prey biomass correlated positively with dace density in all seasons; prey patchiness explained most among-reach abundance variation.
- **Measured:** Fish density and prey biomass by reach
- **Population:** Ball Creek, Coweeta, North Carolina; adult
- **Evidence / NOVA / confidence:** field habitat/abundance study / very high regional / high
- **Source:** S1 (page: 145;155, section: Summary item 4; Discussion)
- **Model use:** context-only
- **Limitations:** Fish abundance/habitat occupancy, not per-fish feeding rate or catchability.

### E4 - physical habitat constraint
- **Condition/range:** Depositional low-current sand/silt/debris versus erosional cobble/boulder high-current reaches
- **Observed effect:** Dace avoided depositional habitats even where food was abundant; no adult dace were observed in one high-food depositional reach.
- **Measured:** Habitat selection with food availability measured
- **Population:** Ball Creek, Coweeta, North Carolina; adult
- **Evidence / NOVA / confidence:** field habitat study / very high regional / high
- **Source:** S1 (page: 155, section: Discussion)
- **Model use:** context-only
- **Limitations:** Strong location context but still not a direct catchability multiplier.

### E5 - diel behavior - Coweeta
- **Condition/range:** Daylight snorkeling in summer/autumn 1996 and spring 1997
- **Observed effect:** Coweeta longnose dace were regularly observed as active daytime foragers; dietary work in that system supported diurnal feeding.
- **Measured:** Direct daytime foraging observations
- **Population:** Ball Creek, Coweeta, North Carolina; adult
- **Evidence / NOVA / confidence:** field behavioral observation / very high regional / high
- **Source:** S1 (page: 146-147, section: Introduction / Sampling regime)
- **Model use:** context-only
- **Limitations:** System-specific; conflicts with Alberta nocturnal evidence.

### E6 - diel behavior - Alberta
- **Condition/range:** Southern Alberta stream population
- **Observed effect:** Foraging was constrained to nighttime in the reviewed Alberta population.
- **Measured:** Foraging periodicity
- **Population:** Southern Alberta stream; mixed
- **Evidence / NOVA / confidence:** field behavioral study / low-medium / medium
- **Source:** S2 (page: 2008-2012, section: Title/abstract)
- **Model use:** context-only
- **Limitations:** Geographically distant and contradicted by Coweeta observations; no universal night bonus is defensible.

### E7 - light-response plasticity
- **Condition/range:** Different light intensities
- **Observed effect:** Foraging behavior changed with light intensity, demonstrating plasticity.
- **Measured:** Foraging behavior under light treatments
- **Population:** Alberta; mixed
- **Evidence / NOVA / confidence:** behavioral experiment / low-medium / low
- **Source:** S3 (page: 101-105, section: Title and bibliographic scope)
- **Model use:** unavailable
- **Limitations:** Exact light levels and response magnitudes were not extracted from full text; unavailable for scoring.

### E8 - diet composition
- **Condition/range:** Stream stomach-content study
- **Observed effect:** Longnose dace consumed benthic prey; diet composition supports benthic presentation.
- **Measured:** Stomach contents
- **Population:** North American stream; mixed
- **Evidence / NOVA / confidence:** field diet study / medium / medium
- **Source:** S4 (page: 478-485, section: Article scope)
- **Model use:** context-only
- **Limitations:** No environmental feeding-rate response extracted.

### E9 - comparative diet
- **Condition/range:** Blacknose versus longnose dace
- **Observed effect:** The two dace species differed in food habits, reinforcing species-specific prey/presentation context.
- **Measured:** Stomach contents
- **Population:** North American stream; mixed
- **Evidence / NOVA / confidence:** comparative diet study / medium / low
- **Source:** S5 (page: 361-364, section: Article scope)
- **Model use:** context-only
- **Limitations:** No portable predictor extracted without full text.

### E10 - fish size and habitat
- **Condition/range:** 783 juveniles and 857 adults in a Michigan stream
- **Observed effect:** Juveniles and adults used habitat differently.
- **Measured:** Size-specific habitat use
- **Population:** Michigan stream; juvenile and adult
- **Evidence / NOVA / confidence:** field habitat study / medium / medium
- **Source:** S6 (page: 177-183, section: Abstract)
- **Model use:** context-only
- **Limitations:** Habitat occupancy is not feeding/catchability; exact size-habitat effects require full text.

### E11 - species habitat segregation
- **Condition/range:** Mink River sympatry
- **Observed effect:** Longnose and blacknose dace segregated ecologically in stream habitat.
- **Measured:** Distribution and habitat use
- **Population:** Mink River, Manitoba; mixed
- **Evidence / NOVA / confidence:** field habitat study / low-medium / medium
- **Source:** S7 (page: 1245-1252, section: Article scope)
- **Model use:** context-only
- **Limitations:** Distant geography and habitat endpoint only.

### E12 - habitat suitability synthesis
- **Condition/range:** Riverine and lacustrine habitat variables
- **Observed effect:** The agency report models physical habitat suitability for longnose dace.
- **Measured:** Literature-derived habitat suitability
- **Population:** Continental U.S. synthesis; mixed
- **Evidence / NOVA / confidence:** federal technical synthesis / high regional / medium
- **Source:** S8 (page: 1-13, section: Model documentation)
- **Model use:** context-only
- **Limitations:** HSI values predict habitat suitability, not feeding motivation or angler catchability.

### E13 - early-life development
- **Condition/range:** Susquehanna tributary stock
- **Observed effect:** Embryo-to-juvenile development was described for longnose and blacknose dace.
- **Measured:** Larval morphology and development
- **Population:** Pennsylvania Susquehanna tributary; embryo to juvenile
- **Evidence / NOVA / confidence:** proceedings early-life study / high regional / medium
- **Source:** S9 (page: 56-60, section: Paper scope)
- **Model use:** context-only
- **Limitations:** Early-life development is not an adult feeding/catchability endpoint.

### E14 - hook-and-line targetability and missing variables
- **Condition/range:** Broad variable-specific search
- **Observed effect:** No direct hook-and-line catchability experiment and no defensible oxygen, pressure, front, moon, stocking, or angling-pressure score were found.
- **Measured:** Evidence-gap assessment
- **Population:** Mid-Atlantic priority plus range-wide; adult
- **Evidence / NOVA / confidence:** systematic review / high / medium
- **Source:** S1 (section: Search-breadth audit)
- **Model use:** unavailable
- **Limitations:** Niche microfishing exists conceptually, but the species is not a mainstream target and absence of research is not proof of no effect.

## Candidate model rules

### R1 - local prey patchiness
- **Condition:** Summer, physically suitable patches under 5 m where benthic prey are demonstrably patchy
- **Direction:** Prioritize high-prey patches; avoid a continuous prey-density curve
- **Strength / confidence:** moderate / high
- **Use:** score
- **Mechanism:** Direct foraging-patch selection in a southern Appalachian stream.
- **Evidence:** E2
- **Double-counting risk:** Double-counting risk with season, substrate, current, and reach productivity. Requires a real prey-availability input.

### R2 - single-cobble prey biomass
- **Condition:** Individual cobbles within less than 1 m primary-scale groups
- **Direction:** Do not increase expected feeding solely from prey biomass on one cobble
- **Strength / confidence:** null / rejection / high
- **Use:** zero-weight
- **Mechanism:** Direct null relationship between bite intensity and prey biomass at this scale.
- **Evidence:** E1
- **Double-counting risk:** Prevents extrapolating the secondary-scale result to every micro-patch.

### R3 - time of day
- **Condition:** Any universal day or night classification
- **Direction:** Zero-weight universal diel bonus; display population conflict instead
- **Strength / confidence:** strong rejection / high
- **Use:** zero-weight
- **Mechanism:** Alberta nocturnal foraging conflicts with Coweeta daytime foraging.
- **Evidence:** E5, E6, E7
- **Double-counting risk:** Avoid double counting light, geography, predators, competitors, and season.

### R4 - reach-scale prey and habitat
- **Condition:** Physically suitable erosional reaches
- **Direction:** Location context: higher prey reaches may hold more dace
- **Strength / confidence:** moderate / high
- **Use:** context-only
- **Mechanism:** Reach-scale abundance correlated with prey, but habitat constrained occupancy.
- **Evidence:** E3, E4
- **Double-counting risk:** Abundance is not per-fish feeding or catchability; avoid scoring both prey and habitat.

### R5 - substrate and current
- **Condition:** Cobble/boulder erosional habitat versus depositional sand/silt/debris
- **Direction:** Use for location guidance only
- **Strength / confidence:** moderate / high
- **Use:** context-only
- **Mechanism:** Physical habitat constrained use even when food was abundant.
- **Evidence:** E4, E10, E11, E12
- **Double-counting risk:** Habitat presence must not become a bite multiplier.

### R6 - benthic prey/presentation
- **Condition:** Known benthic-invertebrate diet
- **Direction:** Fish Guide bait/presentation context only
- **Strength / confidence:** weak / medium
- **Use:** context-only
- **Mechanism:** Diet studies establish prey type but not environmental response.
- **Evidence:** E8, E9
- **Double-counting risk:** Avoid double counting diet and measured prey-patch rule.

### R7 - fish size/life stage
- **Condition:** Juvenile versus adult habitat
- **Direction:** Context-only modifier for location
- **Strength / confidence:** weak / medium
- **Use:** context-only
- **Mechanism:** Size-specific habitat use.
- **Evidence:** E10, E13
- **Double-counting risk:** Do not transfer larval/juvenile habitat to adult catchability.

## Complete bibliography

- **S1** Andrew R. Thompson; J. Todd Petty; Gary D. Grossman (2001). *Multi-scale effects of resource patchiness on foraging behaviour and habitat use by longnose dace, Rhinichthys cataractae*. Freshwater Biology 46:145-160. DOI: 10.1046/j.1365-2427.2001.00654.x. https://research.fs.usda.gov/download/treesearch/9427.pdf Access: full-text-original-pdf; verification: AI-reviewed-unverified.
- **S2** Joseph M. Culp (1989). *Nocturnally constrained foraging of a lotic minnow (Rhinichthys cataractae)*. Canadian Journal of Zoology 67(8):2008-2012. DOI: 10.1139/z89-285. https://cdnsciencepub.com/doi/10.1139/z89-285 Access: publisher-pdf-metadata; verification: AI-reviewed-unverified.
- **S3** C. E. Beers; Joseph M. Culp (1990). *Plasticity in foraging behaviour of a lotic minnow (Rhinichthys cataractae) in response to different light intensities*. Canadian Journal of Zoology 68(1):101-105. DOI: 10.1139/z90-014. https://cdnsciencepub.com/doi/10.1139/z90-014 Access: publisher-metadata; verification: AI-reviewed-unverified.
- **S4** Jerry W. Gerald (1966). *Food Habits of the Longnose Dace, Rhinichthys cataractae*. Copeia 1966(3):478-485. DOI: 10.2307/1441069. https://www.jstor.org/stable/1441069 Access: publisher-metadata; verification: AI-reviewed-unverified.
- **S5** Antonios Pappantoniou; G. Dale (1982). *Comparative Food Habits of Two Minnow Species: Blacknose Dace, Rhinichthys atratulus and Longnose Dace, Rhinichthys cataractae*. Journal of Freshwater Ecology 1(4):361-364. DOI: 10.1080/02705060.1982.9664054. https://www.tandfonline.com/doi/abs/10.1080/02705060.1982.9664054 Access: publisher-metadata; verification: AI-reviewed-unverified.
- **S6** D. M. Mullen; T. M. Burton (1995). *Size-Related Habitat Use by Longnose Dace (Rhinichthys cataractae)*. The American Midland Naturalist 133(1):177-183. DOI: 10.2307/2426359. https://www.jstor.org/stable/2426359 Access: publisher-metadata-and-abstract; verification: AI-reviewed-unverified.
- **S7** J. R. H. Gibbons; J. H. Gee (1972). *Ecological Segregation Between Longnose and Blacknose Dace (Genus Rhinichthys) in the Mink River, Manitoba*. Journal of the Fisheries Research Board of Canada 29(9):1245-1252. DOI: 10.1139/f72-190. https://cdnsciencepub.com/doi/10.1139/f72-190 Access: publisher-metadata; verification: AI-reviewed-unverified.
- **S8** Elizabeth A. Edwards; Hiram Li; Carl B. Schreck (1983). *Habitat Suitability Index Models: Longnose Dace*. U.S. Fish and Wildlife Service FWS/OBS-82/10.33. https://waves-vagues.dfo-mpo.gc.ca/library-bibliotheque/219828.pdf Access: full-text-agency-report; verification: AI-reviewed-unverified.
- **S9** Gerard L. Buynak; Harold W. Mohr, Jr. (1979). *Larval Development of the Blacknose Dace (Rhinichthys atratulus) and Longnose Dace (Rhinichthys cataractae) from a Susquehanna River Tributary*. Proceedings of the Pennsylvania Academy of Science 53(1):56-60. https://www.jstor.org/stable/44112593 Access: metadata-and-summary; verification: AI-reviewed-unverified.

## Remaining research gaps

- Direct hook-and-line or microfishing catchability experiments.
- Mid-Atlantic replication of the Coweeta prey-patch study.
- Full-text quantitative light-response extraction and local diel validation.
- Direct feeding responses to temperature, oxygen, discharge, turbidity, and short-term trends.
