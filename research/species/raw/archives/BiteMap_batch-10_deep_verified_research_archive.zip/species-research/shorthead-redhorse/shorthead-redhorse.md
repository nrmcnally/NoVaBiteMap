# Shorthead redhorse (*Moxostoma macrolepidotum*)

**Species ID:** `shorthead-redhorse`  
**Schema:** 1.1  
**Research status:** partial  
**Targetability recommendation:** fish-guide-only  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Fish Guide only. Shorthead redhorse is a plausible niche sport target, but the reviewed evidence supports habitat, benthic presentation, reproduction, connectivity, and physiology context rather than an environmental bite score.

### Model-ready findings

- No score-ready rule was identified.

### Context-only findings

- **benthic prey/presentation:** Use for bottom-oriented Fish Guide presentation only; no numerical activity bonus. Diet composition supports presentation, not feeding intensity. Evidence: E1, E2.
- **spawning stage and temperature:** Display reproductive aggregation/migration context; do not increase bite score. Direct spawning and run monitoring measured reproduction. Evidence: E3, E5.
- **flow and fishway access:** Location/connectivity context only. Passage and fragmentation influence movement and access. Evidence: E7, E8.
- **physiological performance:** Context only; no bite optimum. Swimming and metabolic capacity were measured. Evidence: E6.
- **growth and age:** Context only. Population growth/mortality differs by system. Evidence: E9.

### Rejected or zero-weight assumptions

- **barometric pressure and weather fronts:** No qualifying direct species-specific feeding, foraging, or hook-and-line catchability experiment isolated pressure or fronts.
- **moon phase:** No qualifying direct species-specific feeding or catchability evidence was found.
- **wind and cloud cover:** No direct species-specific endpoint evidence isolated these atmospheric variables.
- **ordinary rainfall:** Rainfall was not isolated from discharge, turbidity, habitat access, or prey delivery in a direct feeding or catchability study.
- **recent stocking:** No species-specific post-stocking hook-and-line accessibility or depletion experiment was found.
- **angling pressure, hook avoidance, and learning:** No species-specific vulnerability, learning, or depletion experiment was found.
- **monthly activity curve:** No direct evidence supports a smooth monthly feeding or catchability curve; season, temperature, spawn, effort, and abundance cannot be collapsed safely.
- **growth, thermal preference, or survival as bite optimum:** Growth, preferred temperature, lethal limits, and physiological performance are not feeding or hook-and-line catchability unless directly linked.
- **spawning aggregation or a 16 C observation as a bite bonus:** One spawning observation and seasonal run studies measured reproduction, not feeding or catchability.

## Endpoint separation and adversarial review

- Hook-and-line catchability, feeding/consumption, and direct foraging/attack/prey selection were the only score-eligible endpoint classes.
- Movement, habitat occupancy, growth, physiology, stress, survival, and reproduction remained context unless directly linked to feeding or catchability.
- Contradictory, null, inaccessible, and transfer-limited evidence was preserved. No smooth response curve or production multiplier was invented.

## Targetability assessment

Shorthead redhorse is a plausible intentional rod-and-line target, but this review found no direct hook-and-line vulnerability experiment and no portable environmental feeding-response rule. Diet, spawning, migration, fishway, habitat, and growth evidence belongs in the Fish Guide or location context.

## Evidence ledger

### E1 - diet and feeding mode
- **Condition/range:** Kankakee River life-history sampling
- **Observed effect:** Shorthead redhorse consumed a broad range of mainly benthic invertebrate prey categories; the study characterizes trophic mode but does not quantify an environmental feeding response.
- **Measured:** Stomach contents and life history
- **Population:** Kankakee River drainage, Illinois; mixed
- **Evidence / NOVA / confidence:** field life-history study / medium / medium
- **Source:** S1 (page: 1-16, section: Food habits / life history)
- **Model use:** context-only
- **Limitations:** Exact diet percentages were not promoted because the relevant original table/page was not independently reproduced during this run. Diet composition is not a bite multiplier.

### E2 - prey overlap
- **Condition/range:** Summer collections in four Iowa rivers
- **Observed effect:** Shorthead and silver redhorse diets showed substantial overlap (Morisita index C=0.67), confirming benthic-resource overlap rather than an environmental feeding optimum.
- **Measured:** Stomach contents, diet overlap, gill-raker morphology
- **Population:** Iowa rivers; mixed
- **Evidence / NOVA / confidence:** graduate field study / low-medium / medium
- **Source:** S4 (section: Abstract and thesis results)
- **Model use:** context-only
- **Limitations:** Multi-species Iowa study; overlap does not indicate feeding intensity or hook-and-line catchability.

### E3 - spawning temperature and stage
- **Condition/range:** 17-18 May 1976 at 16 C
- **Observed effect:** Adults were observed spawning at 16 C in Big Rock Creek.
- **Measured:** Direct spawning observations
- **Population:** Big Rock Creek, Illinois; spawning adults
- **Evidence / NOVA / confidence:** field behavioral observation / medium / high
- **Source:** S2 (page: 80-82, section: Abstract)
- **Model use:** context-only
- **Limitations:** Single spawning event; reproductive activity was measured, not feeding or catchability.

### E4 - embryonic development temperature
- **Condition/range:** Eggs incubated at mean 15.6 C
- **Observed effect:** Eggs hatched 8 days after fertilization; newly hatched larvae averaged 10.0 mm total length.
- **Measured:** Egg incubation and larval morphology
- **Population:** Susquehanna River stock, Pennsylvania; embryo and larva
- **Evidence / NOVA / confidence:** laboratory early-life study / high regional / high
- **Source:** S3 (page: 161-165, section: Abstract)
- **Model use:** context-only
- **Limitations:** Early-life development and survival are not adult feeding or angling endpoints.

### E5 - seasonal spawning run
- **Condition/range:** Early May to mid-June across three Great Lakes basin rivers
- **Observed effect:** Shorthead and silver redhorse runs occurred earlier and at lower water temperatures than black and river redhorse runs.
- **Measured:** Electrofishing/fishway run timing and demographics
- **Population:** Ontario Great Lakes basin rivers; spawning adults
- **Evidence / NOVA / confidence:** field run monitoring / medium / medium
- **Source:** S6 (page: 249-258, section: Abstract)
- **Model use:** context-only
- **Limitations:** Run timing is confounded with reproduction, river-specific temperatures, flows, and sampling; no feeding endpoint.

### E6 - physiology and swimming performance
- **Condition/range:** Species-specific peak migration temperatures used in swim/physiology tests
- **Observed effect:** Shorthead redhorse exhibited higher maximum metabolic rate and faster swimming than the two comparison redhorse species.
- **Measured:** Respirometry and swimming performance
- **Population:** Richelieu River, Quebec; migrating adults
- **Evidence / NOVA / confidence:** comparative physiological study / medium / high
- **Source:** S5 (page: 148-159, section: Abstract)
- **Model use:** context-only
- **Limitations:** Physiological capacity and fishway performance do not establish feeding motivation or catchability.

### E7 - fishway passage
- **Condition/range:** Fishway passage monitored across years
- **Observed effect:** Passage success and passage duration varied among species and years, with temperature and flow considered as modulators.
- **Measured:** Fishway approach/passage and physiology
- **Population:** Richelieu River, Quebec; migrating adults
- **Evidence / NOVA / confidence:** field and laboratory study / medium / medium
- **Source:** S5 (page: 148-159, section: Abstract)
- **Model use:** context-only
- **Limitations:** Movement endpoint; no ingestion, attack, or hook-and-line outcome.

### E8 - river fragmentation
- **Condition/range:** Populations separated by barriers in Great Lakes basin rivers
- **Observed effect:** Species traits mediated genetic consequences of fragmentation in shorthead and river redhorse.
- **Measured:** Population genetics and fragmentation
- **Population:** Great Lakes basin; mixed
- **Evidence / NOVA / confidence:** population genetics / low-medium / high
- **Source:** S7 (page: 1892-1904, section: Abstract / USGS record)
- **Model use:** context-only
- **Limitations:** Connectivity and genetics are location/conservation context, not feeding.

### E9 - age, growth, mortality
- **Condition/range:** Grand River population
- **Observed effect:** Age, growth, and mortality were estimated for shorthead redhorse.
- **Measured:** Age structure, growth, mortality
- **Population:** Grand River, Ontario; mixed
- **Evidence / NOVA / confidence:** field demographics / medium / medium
- **Source:** S8 (page: 178-183, section: Abstract)
- **Model use:** context-only
- **Limitations:** Growth and mortality cannot be converted to bite optima.

### E10 - habitat occupancy
- **Condition/range:** Agency profile
- **Observed effect:** The species is associated with shallow, swift water over clean sand or gravel.
- **Measured:** Agency habitat synthesis
- **Population:** United States; mixed
- **Evidence / NOVA / confidence:** federal species profile / high regional / medium
- **Source:** S9 (section: Overview / geography)
- **Model use:** context-only
- **Limitations:** Habitat presence is not catchability or feeding rate.

### E11 - hook-and-line catchability
- **Condition/range:** Broad targeted search
- **Observed effect:** No qualifying experiment linked temperature, flow, oxygen, diel period, turbidity, prey level, weather, or angling pressure to shorthead-redhorse hook-and-line capture probability.
- **Measured:** Evidence-gap assessment
- **Population:** Mid-Atlantic priority plus range-wide; adult target size
- **Evidence / NOVA / confidence:** systematic evidence review / high / medium
- **Source:** S1 (section: Search-breadth audit)
- **Model use:** unavailable
- **Limitations:** Absence of qualifying research is not proof the fish cannot be intentionally targeted.

### E12 - targetability
- **Condition/range:** Species size, benthic feeding ecology, and documented human use
- **Observed effect:** Intentional rod-and-line targeting is plausible, but predictive evidence is too sparse for an environmental BiteMap score.
- **Measured:** Independent targetability assessment
- **Population:** Northern Virginia / Mid-Atlantic transfer assessment; adult
- **Evidence / NOVA / confidence:** evidence synthesis / high / medium
- **Source:** S9 (section: Species profile plus reviewed primary literature)
- **Model use:** context-only
- **Limitations:** Niche targeting may be underrepresented in formal research.

## Candidate model rules

### R1 - benthic prey/presentation
- **Condition:** Where local surveys or guide information indicate benthic macroinvertebrates
- **Direction:** Use for bottom-oriented Fish Guide presentation only; no numerical activity bonus
- **Strength / confidence:** weak / medium
- **Use:** context-only
- **Mechanism:** Diet composition supports presentation, not feeding intensity.
- **Evidence:** E1, E2
- **Double-counting risk:** Do not double count substrate, habitat occupancy, and prey availability.

### R2 - spawning stage and temperature
- **Condition:** Observed run/spawn conditions, including one event at 16 C
- **Direction:** Display reproductive aggregation/migration context; do not increase bite score
- **Strength / confidence:** moderate / high
- **Use:** context-only
- **Mechanism:** Direct spawning and run monitoring measured reproduction.
- **Evidence:** E3, E5
- **Double-counting risk:** High risk of converting aggregation or reproductive behavior to feeding.

### R3 - flow and fishway access
- **Condition:** Migration corridors, barriers, and changing hydraulic conditions
- **Direction:** Location/connectivity context only
- **Strength / confidence:** moderate / medium
- **Use:** context-only
- **Mechanism:** Passage and fragmentation influence movement and access.
- **Evidence:** E7, E8
- **Double-counting risk:** Do not treat movement opportunity as catchability.

### R4 - physiological performance
- **Condition:** Species-specific migration-temperature tests
- **Direction:** Context only; no bite optimum
- **Strength / confidence:** moderate / high
- **Use:** context-only
- **Mechanism:** Swimming and metabolic capacity were measured.
- **Evidence:** E6
- **Double-counting risk:** Avoid double counting temperature, migration stage, and flow.

### R5 - growth and age
- **Condition:** Grand River demographic conditions
- **Direction:** Context only
- **Strength / confidence:** weak / medium
- **Use:** context-only
- **Mechanism:** Population growth/mortality differs by system.
- **Evidence:** E9
- **Double-counting risk:** Growth optimum is not feeding optimum.

### R6 - spawn aggregation as bite bonus
- **Condition:** Any spawning run or observed spawning temperature
- **Direction:** No automatic increase
- **Strength / confidence:** strong rejection / high
- **Use:** zero-weight
- **Mechanism:** Reproduction was measured without feeding or hook-and-line capture.
- **Evidence:** E3, E5
- **Double-counting risk:** Prevents spawn, temperature, and movement double counting.

## Complete bibliography

- **S1** Michael J. Sule; Thomas M. Skelly (1985). *The life history of the shorthead redhorse, Moxostoma macrolepidotum, in the Kankakee River drainage, Illinois*. Illinois Natural History Survey Biological Notes 123:1-16. DOI: 10.5962/bhl.title.15169. https://www.biodiversitylibrary.org/item/51930 Access: digitized-full-text-repository; verification: AI-reviewed-unverified.
- **S2** Brooks M. Burr; Michael A. Morris (1977). *Spawning Behavior of the Shorthead Redhorse, Moxostoma macrolepidotum, in Big Rock Creek, Illinois*. Transactions of the American Fisheries Society 106(1):80-82. DOI: 10.1577/1548-8659(1977)106<80:SBOTSR>2.0.CO;2. https://academic.oup.com/tafs/article/106/1/80/7895052 Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S3** Gerard L. Buynak; Harold W. Mohr, Jr. (1979). *Larval Development of the Shorthead Redhorse (Moxostoma macrolepidotum) from the Susquehanna River*. Transactions of the American Fisheries Society 108(2):161-165. DOI: 10.1577/1548-8659(1979)108<161:LDOTSR>2.0.CO;2. https://academic.oup.com/tafs/article/108/2/161/7894652 Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S4** Jason Robert Spiegel (2010). *Summer food habits and gill raker morphology of seven Catostomid species in Iowa rivers*. Iowa State University M.S. thesis. https://dr.lib.iastate.edu/entities/publication/cef1ee97-502b-4684-84ac-da3b35b788e4 Access: repository-full-text; verification: AI-reviewed-unverified.
- **S5** Charles Hatry; Jason D. Thiem; Thomas R. Binder; Daniel Hatin; Pierre Dumont; Keith M. Stamplecoskie; Juan M. Molina; Karen E. Smokorowski; Steven J. Cooke (2014). *Comparative Physiology and Relative Swimming Performance of Three Redhorse (Moxostoma spp.) Species: Associations with Fishway Passage Success*. Physiological and Biochemical Zoology 87(1):148-159. DOI: 10.1086/671900. https://pubmed.ncbi.nlm.nih.gov/24457929/ Access: title-page-and-abstract; verification: AI-reviewed-unverified.
- **S6** S. M. Reid (2006). *Timing and Demographic Characteristics of Redhorse Spawning Runs in Three Great Lakes Basin Rivers*. Journal of Freshwater Ecology 21(2):249-258. DOI: 10.1080/02705060.2006.9664993. https://www.tandfonline.com/doi/abs/10.1080/02705060.2006.9664993 Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S7** S. M. Reid; C. C. Wilson; L. M. Carl; T. G. Zorn (2008). *Species traits influence the genetic consequences of river fragmentation on two co-occurring redhorse (Moxostoma) species*. Canadian Journal of Fisheries and Aquatic Sciences 65(9):1892-1904. DOI: 10.1139/F08-093. https://pubs.usgs.gov/publication/70000134 Access: agency-metadata-and-abstract; verification: AI-reviewed-unverified.
- **S8** S. M. Reid (2009). *Age, growth and mortality of black redhorse (Moxostoma duquesnei) and shorthead redhorse (M. macrolepidotum) in the Grand River, Ontario*. Journal of Applied Ichthyology 25(2):178-183. DOI: 10.1111/j.1439-0426.2009.01214.x. https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1439-0426.2009.01214.x Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S9** U.S. Fish and Wildlife Service (n.d.). *Shorthead Redhorse (Moxostoma macrolepidotum)*. U.S. Fish and Wildlife Service. https://www.fws.gov/species/shorthead-redhorse-moxostoma-macrolepidotum Access: agency-webpage; verification: AI-reviewed-unverified.

## Remaining research gaps

- Direct hook-and-line catchability or vulnerability experiments.
- Temperature-, oxygen-, flow-, light-, and turbidity-linked feeding-rate studies.
- Mid-Atlantic stomach-content or foraging studies paired with environmental covariates.
- Angling-pressure, depletion, learning, and gear-comparison studies.
