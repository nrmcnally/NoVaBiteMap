# Mottled sculpin (*Cottus bairdii*)

**Species ID:** `mottled-sculpin`  
**Schema:** 1.1  
**Research status:** complete-for-batch  
**Targetability recommendation:** Fish Guide only  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Fish Guide only. Preserve the non-visual feeding mechanism and benthic habitat/trophic context, but do not deploy an environmental bite score.

### Model-ready findings

- No score-ready rule was identified.

### Context-only findings

- **local prey availability:** lower expected feeding intensity / more empty stomachs. Direct stomach-content evidence linked autumn resource limitation with poorer feeding metrics, but the portable causal input is prey availability, not month. Evidence: E2.
- **presentation vibration/movement:** supports detectability, not a bite multiplier. Non-visual prey detection provides a mechanistic presentation note. Evidence: E1.
- **stream microhabitat:** higher habitat occupancy likelihood. Field observations separated sculpin location from darter habitat. Evidence: E4.
- **fish size / territoriality:** adults more spatially restricted; juveniles more overlapping/marginal. Size-dependent territoriality alters where fish may be found. Evidence: E5.

### Rejected or zero-weight assumptions

- **barometric pressure and weather fronts:** No qualifying direct species-specific feeding, foraging, or hook-and-line catchability experiment isolated pressure or fronts.
- **moon phase:** No qualifying direct species-specific feeding or catchability evidence was found.
- **wind and cloud cover:** No direct species-specific endpoint evidence isolated these atmospheric variables.
- **ordinary rainfall:** Rainfall was not isolated from discharge, turbidity, habitat access, or prey delivery in a direct feeding or catchability study.
- **recent stocking:** No species-specific post-stocking hook-and-line accessibility or depletion experiment was found.
- **angling pressure, hook avoidance, and learning:** No species-specific vulnerability, learning, or depletion experiment was found.
- **monthly activity curve:** No direct evidence supports a smooth monthly feeding or catchability curve; season, temperature, spawn, effort, and abundance cannot be collapsed safely.
- **growth, thermal preference, or survival as bite optimum:** Growth, preferred temperature, lethal limits, and physiological performance are not feeding or hook-and-line catchability unless directly linked.
- **universal nighttime bonus:** Ability to detect prey in darkness does not show that feeding rate or catchability is higher at night.
- **fixed current-speed bite optimum:** Current and depth studies measured occupancy, not feeding or catchability.
- **territoriality bonus:** Adult space exclusivity is a movement/behavior endpoint and cannot be treated as feeding aggression toward hooks.

## Endpoint separation and adversarial review

- Hook-and-line catchability, feeding/consumption, and direct foraging/attack/prey selection were the only score-eligible endpoint classes.
- Movement, habitat occupancy, growth, physiology, stress, survival, and reproduction remained context unless directly linked to feeding or catchability.
- Contradictory, null, inaccessible, and transfer-limited evidence was preserved. No smooth response curve or production multiplier was invented.

## Targetability assessment

Mottled sculpin has direct feeding-behavior and trophic evidence, but it lacks a credible intentional NOVA hook-and-line target pathway and direct angling-catchability research. Habitat and sensory findings are useful to the guide, not a production bite score.

## Evidence ledger

### E1 - underwater light and sensory mode
- **Condition/range:** Moving prey presented under darkness/non-visual conditions
- **Observed effect:** Mottled sculpin could detect and attack moving prey without relying on vision.
- **Measured:** Prey-location and attack behavior under non-visual conditions
- **Population:** Lake Michigan study system; unspecified/experimental fish
- **Evidence / NOVA / confidence:** controlled behavioral experiment / moderate: sensory mechanism is relevant, but exact transfer to NOVA streams is uncertain / medium
- **Source:** S1 (page: 111-117, section: Abstract and experimental results)
- **Model use:** context-only
- **Limitations:** The accessible record supports non-visual prey detection, not a higher nocturnal feeding rate or hook-and-line catchability. Exact trial conditions require full-text reinspection.

### E2 - season and prey availability
- **Condition/range:** Spring, summer, and autumn samples during 2021-2022 in a regulated oligotrophic high-elevation river
- **Observed effect:** Autumn had the highest frequency of empty stomachs and lower stomach fullness when benthic prey biomass was lowest.
- **Measured:** Stomach contents, stomach fullness index, empty-stomach frequency, benthic prey biomass, and stable isotopes
- **Population:** Blue River, Colorado; mixed sizes of wild mottled sculpin
- **Evidence / NOVA / confidence:** field stomach-content and trophic study / low-to-moderate: direct feeding endpoint but distant regulated high-elevation system / medium-high
- **Source:** S4 (page: 6-7 of article, section: Results 3.2.1 and Discussion, table: Table 1)
- **Model use:** context-only
- **Limitations:** Season, prey biomass, regulated flow, temperature, and competition covary. This cannot justify a universal autumn or monthly penalty.

### E3 - prey selection
- **Condition/range:** Season-specific electivity estimates in 2021-2022
- **Observed effect:** Electivity varied by season and prey taxon; some amphipod, dipteran, and ephemeropteran prey were positively selected in particular samples.
- **Measured:** Stomach prey composition relative to benthic availability
- **Population:** Blue River, Colorado; wild mottled sculpin
- **Evidence / NOVA / confidence:** field prey-selection study / low-to-moderate: useful Fish Guide context; prey community differs from NOVA / medium
- **Source:** S4 (page: 6-8 of article, section: Results 3.2.2, figure: Figure 2)
- **Model use:** context-only
- **Limitations:** Selection was not stable across all seasons/years and does not establish lure-specific or universal prey rules.

### E4 - current velocity, depth, and substrate position
- **Condition/range:** Underwater observations in Pennsylvania streams
- **Observed effect:** Mottled sculpin occurred in shallower, faster habitats than available and were most often beneath substrate.
- **Measured:** Focal depth, water velocity, substrate size, and position
- **Population:** Nescopeck Creek, Pennsylvania; wild juveniles and adults combined
- **Evidence / NOVA / confidence:** field microhabitat observation / moderate-to-high geographic relevance for Mid-Atlantic streams / high
- **Source:** S3 (page: 443-453, section: Synopsis and Results)
- **Model use:** context-only
- **Limitations:** Habitat occupancy was measured, not feeding or angling catchability.

### E5 - fish size and territoriality
- **Condition/range:** Three-year mark-recapture and snorkeling study; juveniles <48 mm SL, adults 49-64 and >65 mm SL
- **Observed effect:** Adults had restricted, strongly territorial home ranges with <10% overlap; juveniles overlapped more and occupied less-stable margins.
- **Measured:** Movement, home range, overlap, territory abandonment, substrate stability
- **Population:** Shope Fork, North Carolina; juveniles and adults
- **Evidence / NOVA / confidence:** field movement/space-use study / moderate: southern Appalachian stream is regionally closer than western studies / high
- **Source:** S2 (page: 1750-1761, section: Abstract, Methods, Results)
- **Model use:** context-only
- **Limitations:** Territoriality and space use may affect location, but feeding rate and catchability were not measured.

### E6 - streamflow variability
- **Condition/range:** Seasonal flow metrics and territory abandonment in the same stream study
- **Observed effect:** Adult territorial behavior was more closely related to density of large adults than to flow variability or microhabitat stability.
- **Measured:** Home-range behavior, abandonment, flow metrics, population age structure
- **Population:** Shope Fork, North Carolina; juveniles and adults
- **Evidence / NOVA / confidence:** field movement study with null/relative findings / moderate regional relevance / medium-high
- **Source:** S2 (page: 1750 and Results pages, section: Abstract and environmental variability analysis)
- **Model use:** zero-weight
- **Limitations:** Null/relative movement finding cannot be converted to a flow-bite rule.

### E7 - movement and home-range restriction
- **Condition/range:** Mark-recapture evaluation in a Michigan stream
- **Observed effect:** Most fish were relatively sedentary, but a nontrivial minority moved farther than a strict restricted-movement assumption would predict.
- **Measured:** Longitudinal movement and recapture distributions
- **Population:** Michigan stream; wild mottled sculpin
- **Evidence / NOVA / confidence:** field movement study / low-to-moderate geographic transfer / medium
- **Source:** S5 (section: Abstract)
- **Model use:** context-only
- **Limitations:** Movement is not feeding; abstract-only access limits exact distance transcription here.

### E8 - diet composition
- **Condition/range:** Comparative stomach-content observations with salmonids
- **Observed effect:** Mottled sculpin consumed benthic animal prey and overlapped with salmonid prey resources.
- **Measured:** Stomach-content composition
- **Population:** North American coldwater stream; wild fish
- **Evidence / NOVA / confidence:** field diet study / moderate natural-history relevance / low-medium
- **Source:** S6 (page: 640-645)
- **Model use:** context-only
- **Limitations:** Historical full text was not inspected; diet identity is presentation context, not an environmental response.

### E9 - physiology and contaminant stress
- **Condition/range:** High-hardness-water zinc exposures
- **Observed effect:** Zinc toxicity thresholds were evaluated for mottled sculpin.
- **Measured:** Survival/toxicological response
- **Population:** Colorado laboratory; experimental fish
- **Evidence / NOVA / confidence:** laboratory toxicology / low for bite scoring / medium
- **Source:** S7 (section: Abstract)
- **Model use:** zero-weight
- **Limitations:** Stress and survival are not feeding or catchability; contaminant-specific results are outside routine BiteMap inputs.

### E10 - hook-and-line catchability
- **Condition/range:** Broad search across angling, vulnerability, gear, pressure, depletion, and learning themes
- **Observed effect:** No qualifying direct hook-and-line catchability experiment was located.
- **Measured:** Evidence absence after documented search
- **Population:** NOVA-priority and broader North American literature; all
- **Evidence / NOVA / confidence:** search-breadth finding / high relevance as a limitation / high
- **Source:** S8 (section: Agency profile plus documented search audit)
- **Model use:** unavailable
- **Limitations:** Absence of evidence is not evidence that the species cannot be caught intentionally.

### E11 - dissolved oxygen and temperature interaction
- **Condition/range:** Species-specific direct feeding/catchability search
- **Observed effect:** No portable DO threshold or temperature-oxygen feeding interaction was found.
- **Measured:** Evidence absence after targeted search
- **Population:** North America; all
- **Evidence / NOVA / confidence:** search-breadth finding / high relevance as a model gap / high
- **Source:** S8 (section: Documented search audit)
- **Model use:** unavailable
- **Limitations:** Physiological tolerance literature must not be substituted for feeding response.

### E12 - targetability
- **Condition/range:** Species is a small benthic stream fish and not a common intentional hook-and-line target in the NOVA product context
- **Observed effect:** Scientific feeding studies exist, but recreational targeting and catchability evidence are inadequate for a production bite score.
- **Measured:** Independent targetability and endpoint assessment
- **Population:** Northern Virginia application context; all
- **Evidence / NOVA / confidence:** adversarial synthesis / high / high
- **Source:** S8 (section: Synthesis)
- **Model use:** zero-weight
- **Limitations:** Guide-only status does not imply ecological unimportance or absolute uncatchability.

## Candidate model rules

### R1 - local prey availability
- **Condition:** Only when a local benthic-resource indicator documents severe seasonal depletion comparable to the Blue River study
- **Direction:** lower expected feeding intensity / more empty stomachs
- **Strength / confidence:** weak-to-moderate / medium
- **Use:** context-only
- **Mechanism:** Direct stomach-content evidence linked autumn resource limitation with poorer feeding metrics, but the portable causal input is prey availability, not month.
- **Evidence:** E2
- **Double-counting risk:** High risk of double-counting season, temperature, flow regulation, and prey biomass.

### R2 - underwater light
- **Condition:** Do not apply an automatic darkness penalty when moving prey cues remain available
- **Direction:** no universal negative effect
- **Strength / confidence:** weak / medium
- **Use:** zero-weight
- **Mechanism:** Mottled sculpin can use mechanosensory/non-visual cues to locate moving prey.
- **Evidence:** E1
- **Double-counting risk:** Could double-count diel and turbidity; evidence does not establish a night bonus.

### R3 - presentation vibration/movement
- **Condition:** Fish Guide only: moving benthic prey or lures may remain detectable in very low light
- **Direction:** supports detectability, not a bite multiplier
- **Strength / confidence:** qualitative / medium
- **Use:** context-only
- **Mechanism:** Non-visual prey detection provides a mechanistic presentation note.
- **Evidence:** E1
- **Double-counting risk:** Do not treat tackle presentation as an environmental score or infer lure superiority.

### R4 - stream microhabitat
- **Condition:** Shallow faster water with cover beneath substrate in comparable Mid-Atlantic streams
- **Direction:** higher habitat occupancy likelihood
- **Strength / confidence:** qualitative / high
- **Use:** context-only
- **Mechanism:** Field observations separated sculpin location from darter habitat.
- **Evidence:** E4
- **Double-counting risk:** Habitat presence is not feeding; avoid double-counting current, depth, and substrate.

### R5 - fish size / territoriality
- **Condition:** Adults versus juveniles in small Appalachian streams
- **Direction:** adults more spatially restricted; juveniles more overlapping/marginal
- **Strength / confidence:** qualitative / high
- **Use:** context-only
- **Mechanism:** Size-dependent territoriality alters where fish may be found.
- **Evidence:** E5
- **Double-counting risk:** Do not infer higher feeding or catchability from territoriality.

### R6 - season/month
- **Condition:** Calendar autumn or any smooth monthly curve without local prey data
- **Direction:** no production effect
- **Strength / confidence:** none / high
- **Use:** zero-weight
- **Mechanism:** Observed autumn feeding depression was system-specific and resource-linked.
- **Evidence:** E2, E3
- **Double-counting risk:** Very high double-counting risk with prey, temperature, flow, and competition.

### R7 - flow change
- **Condition:** Ordinary flow variability in a comparable stream
- **Direction:** no supported feeding/catchability direction
- **Strength / confidence:** none / medium-high
- **Use:** zero-weight
- **Mechanism:** The territoriality study did not show a direct feeding response and found density more influential than flow for the measured behavior.
- **Evidence:** E6
- **Double-counting risk:** Movement endpoint only.

## Complete bibliography

- **S1** Denise Hoekstra; John Janssen (1985). *Non-visual feeding behavior of the mottled sculpin, Cottus bairdi, in Lake Michigan*. Environmental Biology of Fishes 12:111-117. DOI: 10.1007/BF00002763. https://link.springer.com/article/10.1007/BF00002763 Access: publisher-metadata-and-abstract; verification: AI-reviewed-unverified.
- **S2** J. Todd Petty; Gary D. Grossman (2007). *Size-Dependent Territoriality of Mottled Sculpin in a Southern Appalachian Stream*. Transactions of the American Fisheries Society 136:1750-1761. DOI: 10.1577/T06-034.1. https://research.fs.usda.gov/download/treesearch/33862.pdf Access: full-text-pdf; verification: AI-reviewed-unverified.
- **S3** Ellen van Snik Gray; Jay R. Stauffer, Jr. (1999). *Comparative microhabitat use of ecologically similar benthic fishes*. Environmental Biology of Fishes 56:443-453. DOI: 10.1023/A:1007536019444. https://ecosystems.psu.edu/research/labs/stauffer/publications/1990s/graystauffer1999.pdf Access: full-text-pdf; verification: AI-reviewed-unverified.
- **S4** Nitsa M. Platis; Yoichiro Kanno; Brett M. Johnson; Brien P. Rose (2024). *Seasonal trophic niche width and overlap of mottled sculpin and brown trout in a regulated high-elevation river*. Ecology of Freshwater Fish 33:e12793. DOI: 10.1111/eff.12793. https://sites.warnercnr.colostate.edu/wp-content/uploads/sites/112/2024/10/Platis-et-al.-2024-brown-trout-and-sculpin-seasonal-trophic-niche-width-and-overlap.pdf Access: full-text-open-access-pdf; verification: AI-reviewed-unverified.
- **S5** Matthew J. Breen; Carl R. Ruetz III; Kurt J. Thompson; Steven L. Kohler (2009). *Movements of mottled sculpins (Cottus bairdii) in a Michigan stream: how restricted are they?*. Canadian Journal of Fisheries and Aquatic Sciences 66(1):31-41. DOI: 10.1139/F08-189. https://cdnsciencepub.com/doi/10.1139/F08-189 Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S6** C. F. Dineen (1951). *A comparative study of the food habits of Cottus bairdii and associated species of Salmonidae*. American Midland Naturalist 46:640-645. https://www.jstor.org/stable/2421980 Access: bibliographic-record; verification: AI-reviewed-unverified.
- **S7** Stephen Brinkman; John Woodling (2005). *Zinc toxicity to the mottled sculpin (Cottus bairdi) in high-hardness water*. Environmental Toxicology and Chemistry 24(6):1515-1517. DOI: 10.1897/04-235R.1. https://onlinelibrary.wiley.com/doi/10.1897/04-235R.1 Access: publisher-abstract; verification: AI-reviewed-unverified.
- **S8** U.S. Fish and Wildlife Service (n.d.). *Mottled Sculpin (Cottus bairdii)*. U.S. Fish and Wildlife Service Species Profile. https://www.fws.gov/species/mottled-sculpin-cottus-bairdii Access: agency-web-page; verification: AI-reviewed-unverified.

## Remaining research gaps

- Direct hook-and-line vulnerability or intentional angling studies.
- Replicated Mid-Atlantic feeding-rate studies across temperature, DO, diel period, turbidity, and flow.
- Portable local prey-availability measurements tied to feeding intensity.
- Controlled tests separating light level from prey motion, turbidity, and time of day.
