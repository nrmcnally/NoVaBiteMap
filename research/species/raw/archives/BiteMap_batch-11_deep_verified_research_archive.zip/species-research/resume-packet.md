# BiteMap NOVA research resume packet

## Completed species

- largemouth-bass
- smallmouth-bass
- channel-catfish
- Batches 1-8 (provided by user)
- Batch 9: yellow-bullhead, brown-bullhead, northern-hogsucker
- Batch 10: shorthead-redhorse, blacknose-dace, longnose-dace
- Batch 11: mottled-sculpin, tessellated-darter, gizzard-shad

## Pending species

- No species remain in the 11-batch queue supplied for this research sequence.
- Largemouth bass and smallmouth bass remain pending for the separately planned verification audit.

## Next recommended work

Conduct the separate verification audit of largemouth bass and smallmouth bass against the approved deep-research standard, preserving the original and revised archives for differential review.

## Schema version

1.1

## Batch 11 result

- Mottled sculpin: Fish Guide only. Non-visual prey detection and system-specific seasonal trophic evidence are useful context, not a night or monthly bite rule.
- Tessellated darter: Fish Guide only. Diet and competitor-conditioned habitat shifts are useful location context; reproductive behaviors are zero-weight for bite scoring.
- Gizzard shad: Fish Guide/forage layer only. Direct age-0 thermal feeding rules exist, but intentional hook-and-line targetability is absent.

## Known corrections

See `correction-and-conflict-log.json`. Preserve Cottus bairdii versus historical C. bairdi spelling, Jay R. Stauffer, Jr., S. David Wilkins, and the distinction between gizzard-shad feeding temperatures and cold-survival thresholds.

## Unresolved questions

- No direct hook-and-line catchability experiment was found for any Batch 11 species.
- Mottled-sculpin seasonal feeding evidence needs Mid-Atlantic replication and a portable prey-availability input.
- Tessellated-darter environmental feeding responses remain almost entirely unstudied.
- Gizzard-shad direct thermal feeding evidence is age-0 laboratory evidence and should not be transferred to adults.

## Files a new chat must receive

1. BiteMap_complete_37_species_research_archive.zip
2. BiteMap_channel-catfish_deep_verified_research_archive.zip
3. The completed Batch 9, Batch 10, and Batch 11 archives
4. The audit-specific master prompt for largemouth bass and smallmouth bass
