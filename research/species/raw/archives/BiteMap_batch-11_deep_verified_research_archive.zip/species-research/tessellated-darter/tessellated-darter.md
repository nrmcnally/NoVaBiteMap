# Tessellated darter (*Etheostoma olmstedi*)

**Species ID:** `tessellated-darter`  
**Schema:** 1.1  
**Research status:** complete-for-batch  
**Targetability recommendation:** Fish Guide only  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Fish Guide only. Use diet, depth/substrate, and competitor-conditioned habitat information for location/context, with zero environmental bite score.

### Model-ready findings

- No score-ready rule was identified.

### Context-only findings

- **benthic prey availability:** supports likely forage context. Diet evidence identifies common prey but does not quantify feeding-rate response. Evidence: E1.
- **depth and substrate position:** deeper water and top-of-substrate occupancy may improve location probability. Direct underwater observation describes occupancy. Evidence: E2.
- **competitor presence:** shift expected toward shallower, slower, smaller-substrate margins. A comparative field study documented conditional habitat displacement. Evidence: E3, E4.

### Rejected or zero-weight assumptions

- **barometric pressure and weather fronts:** No qualifying direct species-specific feeding, foraging, or hook-and-line catchability experiment isolated pressure or fronts.
- **moon phase:** No qualifying direct species-specific feeding or catchability evidence was found.
- **wind and cloud cover:** No direct species-specific endpoint evidence isolated these atmospheric variables.
- **ordinary rainfall:** Rainfall was not isolated from discharge, turbidity, habitat access, or prey delivery in a direct feeding or catchability study.
- **recent stocking:** No species-specific post-stocking hook-and-line accessibility or depletion experiment was found.
- **angling pressure, hook avoidance, and learning:** No species-specific vulnerability, learning, or depletion experiment was found.
- **monthly activity curve:** No direct evidence supports a smooth monthly feeding or catchability curve; season, temperature, spawn, effort, and abundance cannot be collapsed safely.
- **growth, thermal preference, or survival as bite optimum:** Growth, preferred temperature, lethal limits, and physiological performance are not feeding or hook-and-line catchability unless directly linked.
- **spawn-season aggression bonus:** The available studies measured mating, parental care, and egg cannibalism rather than hook strikes or generalized feeding.
- **fixed 0.13 m/s current threshold:** This value described competitor-conditioned habitat occupancy, not a feeding or catchability threshold.
- **diet item as environmental multiplier:** Chironomid-dominated diet identifies prey context but does not quantify the effect of prey abundance on feeding or catchability.

## Endpoint separation and adversarial review

- Hook-and-line catchability, feeding/consumption, and direct foraging/attack/prey selection were the only score-eligible endpoint classes.
- Movement, habitat occupancy, growth, physiology, stress, survival, and reproduction remained context unless directly linked to feeding or catchability.
- Contradictory, null, inaccessible, and transfer-limited evidence was preserved. No smooth response curve or production multiplier was invented.

## Targetability assessment

The evidence base is useful for diet, microhabitat, competition, and reproductive behavior, but there is no direct environmental feeding-rate or hook-and-line catchability research adequate for a BiteMap score.

## Evidence ledger

### E1 - diet and prey type
- **Condition/range:** Massachusetts collections across size/age classes
- **Observed effect:** Diet was dominated by aquatic insect prey, especially chironomid/tendipedid larvae in reported seasonal samples.
- **Measured:** Stomach contents, age, and growth
- **Population:** Massachusetts; multiple ages/sizes
- **Evidence / NOVA / confidence:** field diet study / moderate natural-history transfer to Mid-Atlantic streams / medium
- **Source:** S1 (page: 459-462, section: Abstract/results summary)
- **Model use:** context-only
- **Limitations:** Diet composition is Fish Guide context and does not quantify response to weather, temperature, light, flow, or angling.

### E2 - depth, current, and substrate position
- **Condition/range:** Underwater observations in Pennsylvania streams
- **Observed effect:** Tessellated darters occupied significantly deeper water than available and were most often on top of the substrate; current/substrate niche breadth differed from sculpins.
- **Measured:** Focal depth, current velocity, substrate size, and position
- **Population:** Nescopeck Creek, Pennsylvania; wild fish
- **Evidence / NOVA / confidence:** field microhabitat observation / high geographic relevance for Mid-Atlantic streams / high
- **Source:** S2 (page: 443-453, section: Synopsis and Results)
- **Model use:** context-only
- **Limitations:** Habitat occupancy was measured, not feeding or hook-and-line catchability.

### E3 - biotic interaction and habitat shift
- **Condition/range:** Sites with versus without introduced banded darter Etheostoma zonale
- **Observed effect:** In sympatry, tessellated darters used shallower water (mean depth <27 cm), smaller substrate (mean index <32), and slower velocity (mean <0.13 m/s), shifting toward shallow pools and margins.
- **Measured:** Microhabitat depth, substrate, velocity, and niche breadth
- **Population:** Susquehanna drainage, Pennsylvania; wild fish
- **Evidence / NOVA / confidence:** comparative field habitat study / high geographic relevance but conditional on competitor presence / high
- **Source:** S3 (page: 166-177, section: Abstract and Results)
- **Model use:** context-only
- **Limitations:** Thresholds describe conditional habitat use, not feeding optima or bite thresholds.

### E4 - population/community modifier
- **Condition/range:** Presence of Etheostoma zonale versus allopatry
- **Observed effect:** The same native species changed habitat use substantially in response to a non-native competitor.
- **Measured:** Between-site habitat-use comparison
- **Population:** Susquehanna drainage, Pennsylvania; wild fish
- **Evidence / NOVA / confidence:** field natural experiment / high conceptual relevance / high
- **Source:** S3 (page: 166 and discussion pages, section: Abstract and Discussion)
- **Model use:** context-only
- **Limitations:** Local fish community can invalidate a fixed depth/current rule; no feeding rate was measured.

### E5 - reproduction and nest behavior
- **Condition/range:** Historical observations of eastern johnny/tessellated darter reproductive behavior
- **Observed effect:** Male nest-associated reproductive behavior was documented.
- **Measured:** Courtship, spawning, and nest behavior
- **Population:** Eastern North America; breeding adults
- **Evidence / NOVA / confidence:** behavioral natural-history study / moderate life-history transfer / low-medium
- **Source:** S5 (page: 100-106)
- **Model use:** zero-weight
- **Limitations:** Spawning aggregation, defense, and courtship are not feeding or catchability.

### E6 - alloparental care
- **Condition/range:** Males caring for eggs not genetically their own
- **Observed effect:** Alloparental care increased mating success.
- **Measured:** Parental care and subsequent mating success
- **Population:** tessellated-darter study system; breeding males
- **Evidence / NOVA / confidence:** behavioral ecology experiment/field study / moderate biological transfer / high
- **Source:** S6 (page: 206-211, section: Abstract)
- **Model use:** zero-weight
- **Limitations:** This is reproduction, not feeding; it cannot support a spawn-season bite bonus.

### E7 - filial cannibalism
- **Condition/range:** Genetic assignment of embryos/eggs and guarding males in natural nests
- **Observed effect:** Genetic evidence documented consumption of a male's own offspring in nature.
- **Measured:** Parentage and cannibalism in guarded nests
- **Population:** natural tessellated-darter nests; breeding males and eggs
- **Evidence / NOVA / confidence:** field molecular behavioral study / moderate biological transfer / high
- **Source:** S7 (page: 5090-5092, section: Results and Discussion)
- **Model use:** zero-weight
- **Limitations:** Egg consumption during parental care is not evidence of generalized feeding activity or hook vulnerability.

### E8 - age and growth
- **Condition/range:** Historical Atlantic-slope life-history observations
- **Observed effect:** Age, growth, reproduction, and natural history were described for tessellated darter populations.
- **Measured:** Life-history traits
- **Population:** Atlantic-slope populations; multiple ages
- **Evidence / NOVA / confidence:** field life-history study / moderate regional transfer / low-medium
- **Source:** S4 (page: 28-51)
- **Model use:** context-only
- **Limitations:** Growth and life history are context, not bite optima; full text was not inspected.

### E9 - water temperature and feeding
- **Condition/range:** Targeted search for temperature-specific feeding rate, attack rate, or catchability
- **Observed effect:** No qualifying direct temperature-feeding or angling experiment was found.
- **Measured:** Evidence absence after targeted search
- **Population:** Mid-Atlantic and broader range; all
- **Evidence / NOVA / confidence:** search-breadth finding / high as a model gap / high
- **Source:** S8 (section: Documented search audit)
- **Model use:** unavailable
- **Limitations:** Do not substitute spawning temperature, growth, or distribution limits.

### E10 - diel, light, and turbidity
- **Condition/range:** Targeted search for diel feeding, photoperiod, light, cloud, or turbidity endpoints
- **Observed effect:** No portable species-specific direct feeding/catchability response was identified.
- **Measured:** Evidence absence after targeted search
- **Population:** Mid-Atlantic and broader range; all
- **Evidence / NOVA / confidence:** search-breadth finding / high as a limitation / high
- **Source:** S8 (section: Documented search audit)
- **Model use:** unavailable
- **Limitations:** Habitat observations and general darter behavior cannot fill this gap.

### E11 - hook-and-line catchability
- **Condition/range:** Targeted angling, gear, pressure, learning, depletion, and catchability search
- **Observed effect:** No qualifying direct hook-and-line study was located.
- **Measured:** Evidence absence after documented search
- **Population:** Northern Virginia application context; all
- **Evidence / NOVA / confidence:** search-breadth finding / high / high
- **Source:** S8 (section: Documented search audit)
- **Model use:** unavailable
- **Limitations:** Lack of study does not prove absolute uncatchability.

### E12 - targetability
- **Condition/range:** Small benthic darter with diet and reproductive research but no intentional angling evidence
- **Observed effect:** Guide placement is scientifically defensible; bite scoring is not.
- **Measured:** Independent targetability and endpoint assessment
- **Population:** Northern Virginia application context; all
- **Evidence / NOVA / confidence:** adversarial synthesis / high / high
- **Source:** S8 (section: Synthesis)
- **Model use:** zero-weight
- **Limitations:** Guide-only classification reflects product use, not conservation value.

## Candidate model rules

### R1 - benthic prey availability
- **Condition:** Fish Guide only when local chironomid/aquatic-insect abundance is known
- **Direction:** supports likely forage context
- **Strength / confidence:** qualitative / medium
- **Use:** context-only
- **Mechanism:** Diet evidence identifies common prey but does not quantify feeding-rate response.
- **Evidence:** E1
- **Double-counting risk:** Do not double-count generic prey abundance and substrate habitat.

### R2 - depth and substrate position
- **Condition:** Comparable Mid-Atlantic streams without strong competitor displacement
- **Direction:** deeper water and top-of-substrate occupancy may improve location probability
- **Strength / confidence:** qualitative / high
- **Use:** context-only
- **Mechanism:** Direct underwater observation describes occupancy.
- **Evidence:** E2
- **Double-counting risk:** Habitat presence is not feeding; depth and current are correlated.

### R3 - competitor presence
- **Condition:** Where banded darter E. zonale is established
- **Direction:** shift expected toward shallower, slower, smaller-substrate margins
- **Strength / confidence:** qualitative / high
- **Use:** context-only
- **Mechanism:** A comparative field study documented conditional habitat displacement.
- **Evidence:** E3, E4
- **Double-counting risk:** Do not apply both a fixed habitat rule and competitor modifier; this would double count the same displacement.

### R4 - current velocity
- **Condition:** Mean velocity below 0.13 m/s reported in sympatric sites
- **Direction:** no bite-score effect
- **Strength / confidence:** none / high
- **Use:** zero-weight
- **Mechanism:** The number was a conditional habitat-use summary, not a feeding threshold.
- **Evidence:** E3
- **Double-counting risk:** High risk of false precision and transfer error.

### R5 - spawning/nest stage
- **Condition:** Courtship, guarding, alloparental care, or filial cannibalism
- **Direction:** no automatic feeding/catchability bonus
- **Strength / confidence:** none / high
- **Use:** zero-weight
- **Mechanism:** These studies measured reproductive behavior and egg consumption, not ordinary foraging or hooks.
- **Evidence:** E5, E6, E7
- **Double-counting risk:** Very high double-counting risk with season and aggregation.

### R6 - temperature, diel, light, turbidity, weather
- **Condition:** Any condition without new direct species-specific endpoint evidence
- **Direction:** unavailable / zero production weight
- **Strength / confidence:** none / high
- **Use:** zero-weight
- **Mechanism:** Broad searches did not locate portable direct feeding/catchability effects.
- **Evidence:** E9, E10, E11
- **Double-counting risk:** Avoid borrowing from related darters.

## Complete bibliography

- **S1** J. B. Layzer; R. J. Reed (1978). *Food, Age and Growth of the Tessellated Darter, Etheostoma olmstedi, in Massachusetts*. American Midland Naturalist 100(2):459-462. https://www.jstor.org/stable/2424847 Access: publisher-bibliographic-record-and-abstract; verification: AI-reviewed-unverified.
- **S2** Ellen van Snik Gray; Jay R. Stauffer, Jr. (1999). *Comparative microhabitat use of ecologically similar benthic fishes*. Environmental Biology of Fishes 56:443-453. DOI: 10.1023/A:1007536019444. https://ecosystems.psu.edu/research/labs/stauffer/publications/1990s/graystauffer1999.pdf Access: full-text-pdf; verification: AI-reviewed-unverified.
- **S3** Ellen van Snik Gray; Karen A. Kellogg; Jay R. Stauffer, Jr. (2005). *Habitat Shift of a Native Darter Etheostoma olmstedi (Teleostei: Percidae) in Sympatry with a Non-native Darter Etheostoma zonale*. American Midland Naturalist 154:166-177. https://ecosystems.psu.edu/research/labs/stauffer/publications/2000s/2005-habitat-shift-of-a-native-darter-etheostoma-olmstedi-teleostei-percidae-in-sympatry-with-a-non-native-darter-etheostoma-zonale/@@download/file/Gray_etal_2005.pdf Access: full-text-pdf; verification: AI-reviewed-unverified.
- **S4** C. F. Cole (1967). *A study of the eastern johnny darter, Etheostoma olmstedi (Storer)*. Chesapeake Science 8(1):28-51. https://www.jstor.org/stable/1350359 Access: bibliographic-record; verification: AI-reviewed-unverified.
- **S5** J. W. Atz (1940). *Reproductive behavior in the eastern johnny darter, Etheostoma nigrum olmstedi (Storer)*. Copeia 1940(2):100-106. https://www.jstor.org/stable/1439034 Access: bibliographic-record; verification: AI-reviewed-unverified.
- **S6** Kelly A. Stiver; Suzanne H. Alonzo (2011). *Alloparental care increases mating success*. Behavioral Ecology 22(1):206-211. DOI: 10.1093/beheco/arq186. https://academic.oup.com/beheco/article-abstract/22/1/206/232218 Access: publisher-abstract-and-title-page-html; verification: AI-reviewed-unverified.
- **S7** J. Andrew DeWoody; Dean E. Fletcher; S. David Wilkins; John C. Avise (2001). *Genetic documentation of filial cannibalism in nature*. Proceedings of the National Academy of Sciences 98(9):5090-5092. DOI: 10.1073/pnas.091102598. https://www.pnas.org/doi/10.1073/pnas.091102598 Access: publisher-full-text-html-and-pdf; verification: AI-reviewed-unverified.
- **S8** U.S. Fish and Wildlife Service (n.d.). *Tessellated Darter (Etheostoma olmstedi)*. U.S. Fish and Wildlife Service Species Profile. https://www.fws.gov/species/tessellated-darter-etheostoma-olmstedi Access: agency-web-page; verification: AI-reviewed-unverified.

## Remaining research gaps

- Any direct hook-and-line catchability/vulnerability research.
- Temperature-, oxygen-, light-, turbidity-, flow-, and diel-specific feeding experiments.
- Mid-Atlantic prey-abundance studies linked to attack rate or stomach fullness.
- Replication of habitat shifts across streams with and without banded darter.
