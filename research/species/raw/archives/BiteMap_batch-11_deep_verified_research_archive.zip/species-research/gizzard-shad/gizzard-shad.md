# Gizzard shad (*Dorosoma cepedianum*)

**Species ID:** `gizzard-shad`  
**Schema:** 1.1  
**Research status:** complete-for-batch  
**Targetability recommendation:** Fish Guide only  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Fish Guide only. Retain age-0 thermal feeding rules as research/forage-context candidates, but do not publish a target-species bite score.

### Model-ready findings

- **absolute water temperature - Age-0 gizzard shad under conditions comparable to the experiment: approximately 5 deg C versus 10-20 deg C:** lower feeding activity at 5 deg C; increasing feeding acts across the warmer treatments (high for experiment / low-to-moderate transfer). Evidence: E1, E2.
- **gastric evacuation / temperature - Age-0 fish at 10, 15, and 20 deg C:** faster evacuation from 10 to 15 deg C, little additional change from 15 to 20 deg C (high for experiment). Evidence: E2.

### Context-only findings

- **local food abundance:** weak positive tendency in feeding incidence/gut fullness. Field feeding success usually rose with food abundance, but correlations were weak and site-dependent. Evidence: E4.
- **fish size / life stage:** larger age-0 fish showed greater feeding success and diet shifts. Ontogenetic development changed feeding efficiency and prey use. Evidence: E6.

### Rejected or zero-weight assumptions

- **barometric pressure and weather fronts:** No qualifying direct species-specific feeding, foraging, or hook-and-line catchability experiment isolated pressure or fronts.
- **moon phase:** No qualifying direct species-specific feeding or catchability evidence was found.
- **wind and cloud cover:** No direct species-specific endpoint evidence isolated these atmospheric variables.
- **ordinary rainfall:** Rainfall was not isolated from discharge, turbidity, habitat access, or prey delivery in a direct feeding or catchability study.
- **recent stocking:** No species-specific post-stocking hook-and-line accessibility or depletion experiment was found.
- **angling pressure, hook avoidance, and learning:** No species-specific vulnerability, learning, or depletion experiment was found.
- **monthly activity curve:** No direct evidence supports a smooth monthly feeding or catchability curve; season, temperature, spawn, effort, and abundance cannot be collapsed safely.
- **growth, thermal preference, or survival as bite optimum:** Growth, preferred temperature, lethal limits, and physiological performance are not feeding or hook-and-line catchability unless directly linked.
- **8 deg C bite cutoff:** The reported threshold concerned overwinter mortality/cold stress, not feeding cessation or catchability.
- **adult or universal thermal optimum:** The direct study used age-0 fish and discrete treatments; it did not estimate an adult optimum or smooth curve.
- **user-facing target score:** The species lacks an intentional hook-and-line targetability pathway despite useful feeding ecology.

## Endpoint separation and adversarial review

- Hook-and-line catchability, feeding/consumption, and direct foraging/attack/prey selection were the only score-eligible endpoint classes.
- Movement, habitat occupancy, growth, physiology, stress, survival, and reproduction remained context unless directly linked to feeding or catchability.
- Contradictory, null, inaccessible, and transfer-limited evidence was preserved. No smooth response curve or production multiplier was invented.

## Targetability assessment

Gizzard shad has direct and useful age-0 feeding-temperature science, but it is principally a forage species and lacks credible intentional hook-and-line catchability evidence for a user-facing NOVA target score.

## Evidence ledger

### E1 - absolute water temperature
- **Condition/range:** Age-0 fish observed at 5 deg C versus 10, 15, and 20 deg C
- **Observed effect:** Little feeding activity occurred at 5 deg C; feeding acts increased significantly with temperature at warmer treatments.
- **Measured:** Observed feeding acts in controlled temperature treatments
- **Population:** Ohio laboratory study; age-0 fish, approximately 6 g in consumption estimate
- **Evidence / NOVA / confidence:** controlled feeding experiment / low-to-moderate for NOVA adult/field transfer; direct endpoint is strong / high
- **Source:** S1 (page: 67-70, section: Abstract and experimental results)
- **Model use:** score
- **Limitations:** Age-0 laboratory fish and artificial/controlled feeding conditions; not an adult catchability threshold and not a universal cessation point.

### E2 - temperature and gastric evacuation
- **Condition/range:** 10, 15, and 20 deg C
- **Observed effect:** Estimated food evacuation times were 8.5, 4.9, and 4.4 h, respectively.
- **Measured:** Gastric evacuation rate
- **Population:** Ohio laboratory study; age-0 fish
- **Evidence / NOVA / confidence:** controlled physiology/feeding experiment / low-to-moderate transfer / high
- **Source:** S1 (page: 67-70, section: Abstract)
- **Model use:** score
- **Limitations:** Only three warmer treatment points; does not establish an optimum or smooth response curve.

### E3 - feeding/consumption rate
- **Condition/range:** Natural detritus diet modeled for a 6-g age-0 fish under study conditions
- **Observed effect:** Estimated consumption was 3.2-7.7% of wet body weight per day.
- **Measured:** Daily ration estimate derived from evacuation and field diet assumptions
- **Population:** Ohio age-0 fish; age-0, approximately 6 g
- **Evidence / NOVA / confidence:** laboratory/field-calibration estimate / low transfer to adult fish or NOVA waterbodies / medium
- **Source:** S1 (page: 67-70, section: Abstract)
- **Model use:** context-only
- **Limitations:** Size-, diet-, and study-specific calibration candidate only; not a universal daily intake value.

### E4 - prey/food abundance
- **Condition/range:** Small (5-9 mm), medium (10-19 mm), and large (20-29 mm) larvae/early juveniles in two Missouri reservoirs
- **Observed effect:** Feeding incidence and, to a lesser degree, gut fullness of small and medium fish usually increased with food abundance, but correlations were weak.
- **Measured:** Feeding incidence, gut fullness, zooplankton/phytoplankton abundance
- **Population:** Two large Missouri reservoirs; larval and early juvenile age-0 fish
- **Evidence / NOVA / confidence:** field diet and feeding-success study / low-to-moderate: reservoir age-0 forage ecology, not adult NOVA catchability / medium-high
- **Source:** S2 (page: 182-191, section: Abstract and Results)
- **Model use:** context-only
- **Limitations:** Weak and inconsistent relationships; site effects differed between reservoirs.

### E5 - water clarity and field temperature
- **Condition/range:** Secchi depth and water temperature across reservoir samples and three size groups
- **Observed effect:** Feeding incidence and mean gut fullness were not usually correlated with Secchi depth or temperature for any length group.
- **Measured:** Field feeding incidence and gut fullness correlations
- **Population:** Two large Missouri reservoirs; age-0 larvae/early juveniles
- **Evidence / NOVA / confidence:** field observational study with null findings / moderate for rejecting simplistic field clarity/temperature rules / high
- **Source:** S2 (page: 182-191, section: Abstract and Results)
- **Model use:** zero-weight
- **Limitations:** Observational ranges and sampling design may lack power; does not contradict the controlled laboratory temperature experiment because endpoints/conditions differ.

### E6 - fish size / life stage
- **Condition/range:** 5-9, 10-19, and 20-29 mm total length groups
- **Observed effect:** Feeding success increased with fish size; diets shifted from copepod nauplii/cyclopoids toward rotifers and phytoplankton as fish grew.
- **Measured:** Feeding incidence, gut fullness, diet, and prey size
- **Population:** Two large Missouri reservoirs; larval and early juvenile age-0 fish
- **Evidence / NOVA / confidence:** field ontogenetic diet study / moderate forage-ecology relevance / high
- **Source:** S2 (page: 182-191, section: Abstract)
- **Model use:** context-only
- **Limitations:** Ontogenetic effect is not an adult bite modifier and should not be extrapolated beyond age-0 sizes.

### E7 - cold stress and survival
- **Condition/range:** Cage temperatures above and below 8 deg C; laboratory treatments of 1, 2, and 4 deg C
- **Observed effect:** Cage mortality was low above 8 deg C and exceeded 75% as temperature fell below 8 deg C; laboratory mortality rose after 4 deg C and was greatest at 1-2 deg C.
- **Measured:** Survival, dry weight, visceral-somatic index, size-dependent mortality
- **Population:** Oneida Lake, New York, and laboratory; age-0 fish
- **Evidence / NOVA / confidence:** field cage plus laboratory stress experiment / moderate cold-climate physiological transfer / high
- **Source:** S3 (page: 1460-1471, section: Abstract and Results)
- **Model use:** zero-weight
- **Limitations:** Survival/cold acclimation endpoint, not feeding or hook-and-line catchability. Do not use 8 deg C as a bite threshold.

### E8 - fish size and overwinter mortality
- **Condition/range:** Within the cold-temperature experiments and winter field collections
- **Observed effect:** Smaller fish died faster in a winter-temperature treatment; field mean size increased through winter.
- **Measured:** Length-dependent mortality and field size distribution
- **Population:** Oneida Lake/laboratory; age-0 fish
- **Evidence / NOVA / confidence:** stress/survival study / moderate population-context relevance / high
- **Source:** S3 (page: 1460-1471, section: Abstract)
- **Model use:** context-only
- **Limitations:** Survival selection is not feeding activity.

### E9 - density-dependent diet
- **Condition/range:** Variation in gizzard-shad biomass in an Ohio reservoir
- **Observed effect:** Diet contribution and ecosystem effects shifted with population biomass, indicating density-dependent reliance on zooplankton versus detrital resources.
- **Measured:** Diet composition, growth, and food-web response
- **Population:** Acton Lake, Ohio; population including multiple sizes
- **Evidence / NOVA / confidence:** field trophic study / moderate reservoir transfer / medium-high
- **Source:** S5 (page: 40-54, section: Abstract)
- **Model use:** context-only
- **Limitations:** Biomass is not a real-time BiteMap weather input; diet shift does not directly predict hook-and-line catchability.

### E10 - range-edge recruitment and survival
- **Condition/range:** Populations near the northwestern native-range edge
- **Observed effect:** Survival, reproduction, and recruitment were evaluated under cold-climate conditions.
- **Measured:** Population demography
- **Population:** South Dakota; population level
- **Evidence / NOVA / confidence:** field population study / low NOVA transfer; context only / medium
- **Source:** S6 (page: 41-53, section: Abstract)
- **Model use:** context-only
- **Limitations:** Demography and range persistence are not feeding/catchability.

### E11 - hook-and-line targetability
- **Condition/range:** Broad search of intentional angling, vulnerability, bait/lure, pressure, and depletion
- **Observed effect:** No qualifying intentional hook-and-line catchability experiment was found; gizzard shad functions primarily as forage rather than a NOVA rod-and-reel target.
- **Measured:** Evidence absence and independent targetability assessment
- **Population:** Northern Virginia application context; all
- **Evidence / NOVA / confidence:** search-breadth/adversarial synthesis / high / high
- **Source:** S8 (section: Synthesis and search audit)
- **Model use:** zero-weight
- **Limitations:** Other capture methods and rare incidental catches do not establish targetable recreational catchability.

### E12 - feeding mechanics
- **Condition/range:** Filter-feeding and particle-capture mechanics investigated in controlled work
- **Observed effect:** Specialized feeding mechanics support plankton/detritus ecology.
- **Measured:** Feeding mechanics and particle capture
- **Population:** laboratory study; gizzard shad
- **Evidence / NOVA / confidence:** graduate experimental research / low for environmental scoring; useful guide context / low-medium
- **Source:** S7 (section: Repository scope/title)
- **Model use:** context-only
- **Limitations:** Full dissertation and exact result pages were not inspected; no quantitative score claim is taken from it.

## Candidate model rules

### R1 - absolute water temperature
- **Condition:** Age-0 gizzard shad under conditions comparable to the experiment: approximately 5 deg C versus 10-20 deg C
- **Direction:** lower feeding activity at 5 deg C; increasing feeding acts across the warmer treatments
- **Strength / confidence:** moderate / high for experiment / low-to-moderate transfer
- **Use:** score
- **Mechanism:** Controlled feeding observations directly measured temperature effects.
- **Evidence:** E1, E2
- **Double-counting risk:** High risk of double-counting cold stress, season, size, and survival; discrete evidence only, not a smooth curve.

### R2 - gastric evacuation / temperature
- **Condition:** Age-0 fish at 10, 15, and 20 deg C
- **Direction:** faster evacuation from 10 to 15 deg C, little additional change from 15 to 20 deg C
- **Strength / confidence:** moderate / high for experiment
- **Use:** score
- **Mechanism:** Measured evacuation times constrain the direction without proving an optimum.
- **Evidence:** E2
- **Double-counting risk:** Do not infer adult feeding, hook vulnerability, or values between/beyond tested temperatures.

### R3 - local food abundance
- **Condition:** Larval/early juvenile fish where plankton abundance is measured
- **Direction:** weak positive tendency in feeding incidence/gut fullness
- **Strength / confidence:** weak / medium
- **Use:** context-only
- **Mechanism:** Field feeding success usually rose with food abundance, but correlations were weak and site-dependent.
- **Evidence:** E4
- **Double-counting risk:** Food abundance, site position, fish size, and reservoir productivity covary.

### R4 - Secchi depth / water clarity
- **Condition:** Routine field ranges represented in two Missouri reservoirs
- **Direction:** no supported production effect
- **Strength / confidence:** none / high for null study
- **Use:** zero-weight
- **Mechanism:** Feeding incidence and gut fullness were not usually correlated with Secchi depth.
- **Evidence:** E5
- **Double-counting risk:** Do not treat one null study as proof of no effect under all turbidity extremes.

### R5 - field temperature correlation
- **Condition:** Routine field ranges in the Missouri reservoir study
- **Direction:** no additional score beyond the controlled age-0 temperature evidence
- **Strength / confidence:** none / medium-high
- **Use:** zero-weight
- **Mechanism:** Field temperature was not usually correlated with feeding success, showing that uncontrolled seasonal field correlations can differ from lab causality.
- **Evidence:** E1, E5
- **Double-counting risk:** Avoid double counting temperature via season, prey, and size.

### R6 - fish size / life stage
- **Condition:** Age-0 size classes 5-29 mm TL
- **Direction:** larger age-0 fish showed greater feeding success and diet shifts
- **Strength / confidence:** qualitative / high
- **Use:** context-only
- **Mechanism:** Ontogenetic development changed feeding efficiency and prey use.
- **Evidence:** E6
- **Double-counting risk:** Only apply as forage-ecology context, never as an adult bite modifier.

### R7 - extreme cold
- **Condition:** Below approximately 8 deg C in cages or 1-4 deg C laboratory exposures
- **Direction:** no bite-score effect; flag population stress/survival context only
- **Strength / confidence:** none / high
- **Use:** zero-weight
- **Mechanism:** The study measured mortality and acclimation failure rather than feeding.
- **Evidence:** E7, E8
- **Double-counting risk:** Very high risk of converting a survival threshold into a feeding threshold.

### R8 - production targetability
- **Condition:** Any environmental condition
- **Direction:** do not expose a user-facing hook-and-line bite score
- **Strength / confidence:** none / high
- **Use:** zero-weight
- **Mechanism:** Direct feeding science exists, but intentional recreational targetability and catchability evidence do not.
- **Evidence:** E11
- **Double-counting risk:** Keep forage-availability implications separate from scoring gizzard shad as a target species.

## Complete bibliography

- **S1** Scott R. Salvatore; Thomas E. Wissing; Neal D. Mundahl (1987). *Effect of Water Temperature on Food Evacuation Rate and Feeding Activity of Age-0 Gizzard Shad*. Transactions of the American Fisheries Society 116(1):67-70. DOI: 10.1577/1548-8659(1987)116<67:EOWTOF>2.0.CO;2. https://academic.oup.com/tafs/article/116/1/67/7891987 Access: publisher-abstract-and-metadata; verification: AI-reviewed-unverified.
- **S2** Paul H. Michaletz (1996). *Diets and Factors Affecting Feeding Success of Age-0 Gizzard Shad*. Proceedings of the Annual Conference Southeastern Association of Fish and Wildlife Agencies 50:182-191. https://seafwa.org/sites/default/files/journal-articles/MICHALETZ-182-191.pdf Access: full-text-pdf; verification: AI-reviewed-unverified.
- **S3** William W. Fetzer; Thomas E. Brooking; James R. Jackson; Lars G. Rudstam (2011). *Overwinter Mortality of Gizzard Shad: Evaluation of Starvation and Cold Temperature Stress*. Transactions of the American Fisheries Society 140:1460-1471. DOI: 10.1080/00028487.2011.630281. https://wwfetzer.weebly.com/uploads/4/9/8/7/49879383/fetzer_tafs2011.pdf Access: full-text-pdf; verification: AI-reviewed-unverified.
- **S4** Robert Rush Miller (1960). *Systematics and biology of the gizzard shad (Dorosoma cepedianum) and related fishes*. U.S. Fish and Wildlife Service Fishery Bulletin 60. https://spo.nmfs.noaa.gov/content/systematics-and-biology-gizzard-shad-dorosoma-cepedianum-and-related-fishes Access: federal-repository-record; verification: AI-reviewed-unverified.
- **S5** Maynard H. Schaus; Michael J. Vanni; Thomas E. Wissing (2002). *Biomass-Dependent Diet Shifts in Omnivorous Gizzard Shad: Implications for Growth, Food Web, and Ecosystem Effects*. Transactions of the American Fisheries Society 131(1):40-54. DOI: 10.1577/1548-8659(2002)131<0040:BDDSIO>2.0.CO;2. https://www.tandfonline.com/doi/abs/10.1577/1548-8659%282002%29131%3C0040%3ABDDSIO%3E2.0.CO%3B2 Access: publisher-abstract-and-metadata; verification: AI-reviewed-unverified.
- **S6** Justin A. VanDeHey; David W. Willis; Brian G. Blackwell (2012). *Survival, reproduction, and recruitment of gizzard shad (Dorosoma cepedianum) at the northwestern edge of its native range*. Journal of Freshwater Ecology 27(1):41-53. DOI: 10.1080/02705060.2011.603210. https://openprairie.sdstate.edu/nrm_pubs/149/ Access: university-repository-and-publisher-record; verification: AI-reviewed-unverified.
- **S7** Richard W. Drenner (1977). *The Feeding Mechanics of the Gizzard Shad (Dorosoma cepedianum)*. Texas Tech University dissertation. https://ttu-ir.tdl.org/items/89e40dc9-a7ca-4b06-a4ca-5f216117fdd4 Access: university-repository-record; verification: AI-reviewed-unverified.
- **S8** U.S. Fish and Wildlife Service (n.d.). *Gizzard Shad (Dorosoma cepedianum)*. U.S. Fish and Wildlife Service Species Profile. https://www.fws.gov/species/gizzard-shad-dorosoma-cepedianum Access: agency-web-page; verification: AI-reviewed-unverified.

## Remaining research gaps

- Direct adult feeding-rate studies across temperature, DO, diel period, turbidity, and prey fields.
- Any intentional hook-and-line catchability or vulnerability research.
- Mid-Atlantic/Chesapeake-region age-0 feeding replication.
- Short-term temperature-trend and rate-of-change feeding experiments.
- Clear separation of temperature from prey, size, and seasonal cohort effects in natural waters.
