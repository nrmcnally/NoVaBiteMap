# Northern hogsucker (*Hypentelium nigricans*)

**Species ID:** `northern-hogsucker`  
**Schema:** 1.1  
**Research status:** partial  
**Targetability recommendation:** fish-guide-only  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Fish Guide only. Telemetry and habitat findings may improve location guidance, but no environmental BiteMap score is scientifically defensible from the reviewed evidence.

### Model-ready findings

- No score-ready rule was identified.

### Context-only findings

- **seasonal movement display:** context: greater mean daily movement in summer. Observed movement difference. Evidence: E2.
- **diel display:** context: more movement by day; habitat shifts day/night. Telemetry, not feeding. Evidence: E4, E5.
- **high flow:** context: relocate toward lower-velocity refuge. Velocity refuge/habitat occupancy. Evidence: E6.
- **spawning stage:** context: spawning-related movement. Reproductive migration. Evidence: E7, E10.
- **barrier/connectivity:** context: movement constraint. Physical connectivity influences access to habitat. Evidence: E8.
- **microhabitat:** context only. Regional habitat studies may guide where the species occurs. Evidence: E11, E12.

### Rejected or zero-weight assumptions

- **barometric pressure and weather fronts:** No qualifying direct species-specific feeding, foraging, or hook-and-line catchability experiment was found.
- **moon phase:** No qualifying direct species-specific feeding or catchability evidence was found.
- **wind and cloud cover:** No direct species-specific endpoint evidence isolated these atmospheric variables.
- **ordinary rainfall:** Rainfall was not isolated from flow, turbidity, habitat access, or prey delivery in a direct feeding or catchability study.
- **recent stocking:** No species-specific post-stocking hook-and-line depletion or accessibility experiment was found.
- **angling pressure, hook avoidance, and learning:** No species-specific vulnerability or learning experiment was found.
- **monthly activity curve:** No direct evidence supports a smooth monthly feeding or catchability curve; season, temperature, spawn, effort, and abundance cannot be collapsed safely.
- **growth or thermal preference as a bite optimum:** Growth, preferred temperature, and physiological performance are not feeding or hook-and-line catchability unless directly linked in the study.

## Endpoint separation and adversarial review

- Hook-and-line catchability, feeding/consumption, and foraging/attack/prey selection were treated as score-eligible endpoint classes.
- Movement, habitat occupancy, growth, physiology, stress, survival, and reproduction were retained as context unless directly linked to feeding or catchability.
- Contradictory, null, inaccessible, and transfer-limited evidence was preserved. No smooth response curve or production multiplier was invented.

## Targetability assessment

The species can be caught on hook and line, but this review found no direct Mid-Atlantic catchability study and no environmental feeding-response evidence adequate for a bite score. Regional conservation rules may also matter.

## Evidence ledger

### E1 - taxonomy
- **Condition/range:** Federal species profile
- **Observed effect:** Accepted name Hypentelium nigricans; common name Northern Hog Sucker.
- **Measured:** Taxonomic identity
- **Population:** United States; all
- **Evidence / NOVA / confidence:** federal agency profile / high / high
- **Source:** S1 (section: Overview and taxonomic tree)
- **Model use:** context-only
- **Limitations:** No predictive endpoint.

### E2 - seasonal movement
- **Condition/range:** 25 radio-tagged fish followed for one year
- **Observed effect:** Mean daily distance was 425 m in summer versus 276 m in winter.
- **Measured:** Movement distance
- **Population:** Current River, Missouri; adult-sized tagged fish
- **Evidence / NOVA / confidence:** field telemetry / medium / high
- **Source:** S2 (page: 886-897, section: Abstract)
- **Model use:** context-only
- **Limitations:** Movement is not feeding or hook-and-line catchability.

### E3 - seasonal home range
- **Condition/range:** Winter/spring versus summer/fall
- **Observed effect:** Mean home range was 812 m in winter/spring versus 426 m in summer/fall.
- **Measured:** Home-range extent
- **Population:** Current River, Missouri; adult-sized tagged fish
- **Evidence / NOVA / confidence:** field telemetry / medium / high
- **Source:** S2 (page: 886-897, section: Abstract)
- **Model use:** context-only
- **Limitations:** Home-range size cannot be converted to a bite score.

### E4 - diel movement
- **Condition/range:** Hourly records for 17 winter days and 12 summer days
- **Observed effect:** Fish moved more during the day than at night.
- **Measured:** Movement distance and position
- **Population:** Current River, Missouri; adult-sized tagged fish
- **Evidence / NOVA / confidence:** field telemetry / medium / high
- **Source:** S2 (page: 886-897, section: Abstract)
- **Model use:** context-only
- **Limitations:** The study did not directly measure ingestion, attack rate, or angling catchability.

### E5 - diel habitat use
- **Condition/range:** Winter day: pools/moderate flow; winter night: riffle edges; summer day: runs; summer night: riffle edges
- **Observed effect:** Habitat shifted by season and diel period.
- **Measured:** Depth, velocity, substrate, mesohabitat
- **Population:** Current River, Missouri; adult-sized tagged fish
- **Evidence / NOVA / confidence:** field telemetry / medium / high
- **Source:** S2 (page: 886-897, section: Abstract)
- **Model use:** context-only
- **Limitations:** Authors interpreted some daytime use as feeding, but feeding was not measured. Retain only as habitat context.

### E6 - high-flow refuge
- **Condition/range:** High-flow events
- **Observed effect:** Fish remained in home areas but used flooded riparian areas with lower velocities.
- **Measured:** Telemetry location during high flow
- **Population:** Current River, Missouri; adult-sized tagged fish
- **Evidence / NOVA / confidence:** field telemetry / medium / high
- **Source:** S2 (page: 886-897, section: Abstract)
- **Model use:** context-only
- **Limitations:** Floodplain use is location/refuge behavior, not evidence of increased feeding.

### E7 - spawning movement
- **Condition/range:** Late February to early March; seven fish
- **Observed effect:** Mean spawning-related movement was 497 m.
- **Measured:** Movement associated with spawning season
- **Population:** Current River, Missouri; adult
- **Evidence / NOVA / confidence:** field telemetry / medium / medium
- **Source:** S2 (page: 886-897, section: Abstract)
- **Model use:** context-only
- **Limitations:** Aggregation/migration does not establish feeding or catchability and may reflect reproduction.

### E8 - barrier passage / connectivity
- **Condition/range:** Low-water road crossing in an Ozark stream
- **Observed effect:** Movement was affected by the crossing, demonstrating a connectivity constraint.
- **Measured:** Tagged-fish movement across/near crossing
- **Population:** Ozark stream, Missouri; adult-sized
- **Evidence / NOVA / confidence:** field movement study / medium / medium
- **Source:** S3 (page: 157-171, section: Abstract and Results)
- **Model use:** context-only
- **Limitations:** Barrier movement study; no feeding endpoint and no direct NOVA calibration.

### E9 - trophic ecology research scope
- **Condition/range:** Seven catostomid species sampled in four Iowa rivers in 2009
- **Observed effect:** Northern hogsucker was included in a stomach-content/gill-raker study, but the accessible abstract did not provide a portable species-specific environmental feeding response.
- **Measured:** Diet and morphology
- **Population:** Iowa rivers; mixed
- **Evidence / NOVA / confidence:** field trophic study / low-medium / medium
- **Source:** S4 (section: USGS abstract)
- **Model use:** unavailable
- **Limitations:** No numerical hogsucker-specific rule extracted from the abstract.

### E10 - spawning demographics
- **Condition/range:** Spring 2004-2005 Savannah River spawning aggregations
- **Observed effect:** Northern hogsucker was the smallest of the four species and reached sexual maturity at age 3.
- **Measured:** Age, growth, sexual maturity
- **Population:** Savannah River, GA/SC; spawning adults
- **Evidence / NOVA / confidence:** field demographics / medium / high
- **Source:** S5 (page: 318, section: Abstract)
- **Model use:** context-only
- **Limitations:** Demography is not feeding or catchability.

### E11 - long-term microhabitat context
- **Condition/range:** 1983-1992 southern Appalachian stream study
- **Observed effect:** Hydrologic period, season, and fish length were evaluated as microhabitat correlates.
- **Measured:** Microhabitat use
- **Population:** Southern Appalachians; mixed sizes
- **Evidence / NOVA / confidence:** long-term field habitat study / medium / low
- **Source:** S6 (page: 108-131, section: Bibliographic/abstract scope)
- **Model use:** unavailable
- **Limitations:** Exact hogsucker response not extracted; no feeding endpoint.

### E12 - regional occurrence and conservation context
- **Condition/range:** New Jersey Mid-Atlantic species account
- **Observed effect:** The species occurs in the Mid-Atlantic and is associated with clean, flowing stream habitat; regional conservation status may constrain targeting.
- **Measured:** Agency distribution/habitat synthesis
- **Population:** New Jersey; all
- **Evidence / NOVA / confidence:** state agency account / high / medium
- **Source:** S8 (section: Species account)
- **Model use:** context-only
- **Limitations:** Agency synthesis; habitat presence is not feeding or catchability.

## Candidate model rules

### R1 - seasonal movement display
- **Condition:** Summer versus winter in the reviewed Ozark telemetry study
- **Direction:** context: greater mean daily movement in summer
- **Strength / confidence:** moderate / high
- **Use:** context-only
- **Mechanism:** Observed movement difference.
- **Evidence:** E2
- **Double-counting risk:** High risk of converting movement to feeding or double counting temperature/season.

### R2 - diel display
- **Condition:** Reviewed Ozark telemetry conditions
- **Direction:** context: more movement by day; habitat shifts day/night
- **Strength / confidence:** moderate / high
- **Use:** context-only
- **Mechanism:** Telemetry, not feeding.
- **Evidence:** E4, E5
- **Double-counting risk:** Do not infer a daytime bite bonus.

### R3 - high flow
- **Condition:** Flooded riparian access during high-flow events
- **Direction:** context: relocate toward lower-velocity refuge
- **Strength / confidence:** moderate / high
- **Use:** context-only
- **Mechanism:** Velocity refuge/habitat occupancy.
- **Evidence:** E6
- **Double-counting risk:** Do not double count flow, floodplain access, and habitat availability.

### R4 - spawning stage
- **Condition:** Late winter/early spring migration in the reviewed population
- **Direction:** context: spawning-related movement
- **Strength / confidence:** weak / medium
- **Use:** context-only
- **Mechanism:** Reproductive migration.
- **Evidence:** E7, E10
- **Double-counting risk:** No feeding or catchability endpoint; avoid spawn aggression assumptions.

### R5 - barrier/connectivity
- **Condition:** Low-water crossings or similar barriers
- **Direction:** context: movement constraint
- **Strength / confidence:** moderate / medium
- **Use:** context-only
- **Mechanism:** Physical connectivity influences access to habitat.
- **Evidence:** E8
- **Double-counting risk:** Location feature only; not a bite modifier.

### R6 - microhabitat
- **Condition:** Season, hydrologic period, fish length
- **Direction:** context only
- **Strength / confidence:** weak / low
- **Use:** context-only
- **Mechanism:** Regional habitat studies may guide where the species occurs.
- **Evidence:** E11, E12
- **Double-counting risk:** Habitat presence must not become catchability.

## Complete bibliography

- **S1** U.S. Fish and Wildlife Service (n.d.). *Northern Hog Sucker (Hypentelium nigricans)*. U.S. Fish and Wildlife Service. https://www.fws.gov/species/northern-hog-sucker-hypentelium-nigricans Access: full-text; verification: AI-reviewed-unverified.
- **S2** Matthew P. Matheney IV; Charles F. Rabeni (1995). *Patterns of Movement and Habitat Use by Northern Hog Suckers in an Ozark Stream*. Transactions of the American Fisheries Society 124(6):886-897. DOI: 10.1577/1548-8659(1995)124<0886:POMAHU>2.3.CO;2. https://academic.oup.com/tafs/article-abstract/124/6/886/7892870 Access: abstract-only; verification: AI-reviewed-unverified.
- **S3** Jeffrey M. Williams; Hope R. Dodd; Debra S. Finn (2020). *A low-water crossing impacts Northern Hog Sucker Hypentelium nigricans movement in an Ozark stream*. Journal of Freshwater Ecology 35(1):157-171. DOI: 10.1080/02705060.2020.1754302. https://www.tandfonline.com/doi/full/10.1080/02705060.2020.1754302 Access: full-text; verification: AI-reviewed-unverified.
- **S4** J. R. Spiegel; M. C. Quist; J. E. Morris (2011). *Trophic ecology and gill raker morphology of seven catostomid species in Iowa rivers*. Journal of Applied Ichthyology. DOI: 10.1111/j.1439-0426.2011.01779.x. https://www.usgs.gov/publications/trophic-ecology-and-gill-raker-morphology-seven-catostomid-species-iowa-rivers Access: abstract-only; verification: AI-reviewed-unverified.
- **S5** T. B. Grabowski; N. L. Ratterman; J. J. Isely (2008). *Demographics of the spawning aggregations of four catostomid species in the Savannah River, South Carolina and Georgia, USA*. Ecology of Freshwater Fish 17(2):318-327. DOI: 10.1111/j.1600-0633.2007.00284.x. https://robustredhorse.com/wp-content/uploads/2025/06/Grabowski-2008-Demographics-of-the-Spawning-Aggregations-of-Four-Catostomid-Species-in-the-Savanah-River.pdf Access: full-text; verification: AI-reviewed-unverified.
- **S6** Gary D. Grossman; Robert E. Ratajczak Jr. (1998). *Long-term patterns of microhabitat use by fish in a southern Appalachian stream from 1983 to 1992: effects of hydrologic period, season and fish length*. Ecology of Freshwater Fish 7(3):108-131. DOI: 10.1111/j.1600-0633.1998.tb00178.x. https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1600-0633.1998.tb00178.x Access: abstract-only; verification: AI-reviewed-unverified.
- **S7** E. C. Raney; E. A. Lachner (1946). *Age, Growth, and Habits of the Hog Sucker, Hypentelium nigricans (LeSueur), in New York*. The American Midland Naturalist 36(1):76-86. DOI: 10.2307/2421622. https://www.jstor.org/stable/2421622 Access: metadata-only; verification: AI-reviewed-unverified.
- **S8** New Jersey Division of Fish and Wildlife (n.d.). *Northern Hog Sucker (Hypentelium nigricans)*. New Jersey Department of Environmental Protection. https://dep.nj.gov/njfw/wp-content/uploads/njfw/Northern-Hog-Sucker.pdf Access: full-text; verification: AI-reviewed-unverified.

## Remaining research gaps

- No direct catchability evidence.
- No direct environmental feeding response.
- No pressure/front/moon/weather evidence.
- No dissolved-oxygen feeding threshold.
