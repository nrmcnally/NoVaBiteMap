# Brown bullhead (*Ameiurus nebulosus*)

**Species ID:** `brown-bullhead`  
**Schema:** 1.1  
**Research status:** partial  
**Targetability recommendation:** proposed-for-bite-scoring  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Proposed for bite scoring as a limited research-backed pilot. Only four cautious score candidates are supported; no universal temperature curve or hourly multiplier is justified.

### Model-ready findings

- **water temperature - After sustained acclimation: compare approximately 25 C with 18 C:** decrease feeding performance at 25 C (high internal / medium transfer). Evidence: E2, E3, E4, E5, E6.
- **short winter temperature change - Within the studied cold range, 3 C to 4.5 C:** increase modeled predation potential (low). Evidence: E8, E9.
- **time of day / underwater light - Winter lab conditions comparable to the reviewed experiment:** increase at night (low-medium). Evidence: E10.
- **very cold water guardrail - Approximately 2-3 C:** suppress expected feeding but never force a universal zero (low). Evidence: E8, E11.

### Context-only findings

- **flow/current:** location/presentation context only. Flow altered odor-source localization in a flume. Evidence: E12.
- **prey availability and habitat:** diet/presentation context. Field diets were opportunistic and habitat dependent. Evidence: E13, E14.
- **body condition:** context only. Condition and feeding efficiency did not move identically. Evidence: E7.

### Rejected or zero-weight assumptions

- **barometric pressure and weather fronts:** No qualifying direct species-specific feeding, foraging, or hook-and-line catchability experiment was found.
- **moon phase:** No qualifying direct species-specific feeding or catchability evidence was found.
- **wind and cloud cover:** No direct species-specific endpoint evidence isolated these atmospheric variables.
- **ordinary rainfall:** Rainfall was not isolated from flow, turbidity, habitat access, or prey delivery in a direct feeding or catchability study.
- **recent stocking:** No species-specific post-stocking hook-and-line depletion or accessibility experiment was found.
- **angling pressure, hook avoidance, and learning:** No species-specific vulnerability or learning experiment was found.
- **monthly activity curve:** No direct evidence supports a smooth monthly feeding or catchability curve; season, temperature, spawn, effort, and abundance cannot be collapsed safely.
- **growth or thermal preference as a bite optimum:** Growth, preferred temperature, and physiological performance are not feeding or hook-and-line catchability unless directly linked in the study.

## Endpoint separation and adversarial review

- Hook-and-line catchability, feeding/consumption, and foraging/attack/prey selection were treated as score-eligible endpoint classes.
- Movement, habitat occupancy, growth, physiology, stress, survival, and reproduction were retained as context unless directly linked to feeding or catchability.
- Contradictory, null, inaccessible, and transfer-limited evidence was preserved. No smooth response curve or production multiplier was invented.

## Targetability assessment

The species is regionally available and has direct feeding-response evidence, but all score candidates need cautious transfer and should remain a research-backed pilot rather than a production curve.

## Evidence ledger

### E1 - taxonomy
- **Condition/range:** Current catalog status
- **Observed effect:** Accepted as Ameiurus nebulosus (Lesueur, 1819); original type locality was the Delaware River near Philadelphia.
- **Measured:** Taxonomic identity
- **Population:** North America / Mid-Atlantic type locality; all
- **Evidence / NOVA / confidence:** taxonomic catalog / high / high
- **Source:** S1 (section: Current status and original description)
- **Model use:** context-only
- **Limitations:** Not a predictive study.

### E2 - temperature acclimation and feeding design
- **Condition/range:** At least 28 days captivity; 18 C or 25 C treatment; 25 C fish ramped 1 C/day for 7 days then held 14 days; 3 ppt salinity; 3-h chironomid trials at prey densities 2-500
- **Observed effect:** The design represents sustained acclimation rather than an acute temperature shock.
- **Measured:** Prey consumption functional response
- **Population:** Canada laboratory; adult-sized experimental fish
- **Evidence / NOVA / confidence:** controlled feeding experiment / medium / high
- **Source:** S2 (page: 4-5, section: Methods)
- **Model use:** score
- **Limitations:** Artificial salinity and captivity; one prey type; Canadian population; not hook-and-line catchability.

### E3 - temperature and attack rate
- **Condition/range:** 18 C versus 25 C after sustained acclimation
- **Observed effect:** Attack rate was 1.27 +/- 0.05 at 18 C and 0.59 +/- 0.05 at 25 C; the model comparison was significant (p < 0.001).
- **Measured:** Functional-response attack rate
- **Population:** Canada laboratory; adult-sized
- **Evidence / NOVA / confidence:** controlled feeding experiment / medium / high
- **Source:** S2 (page: 8-9, section: Results, table: Tables 2-3)
- **Model use:** score
- **Limitations:** Do not infer a smooth curve or universal optimum from two treatments.

### E4 - temperature and handling time
- **Condition/range:** 18 C versus 25 C after sustained acclimation
- **Observed effect:** Handling time was 0.005 +/- 0.000 h at 18 C and 0.013 +/- 0.001 h at 25 C; the model comparison was significant (p < 0.001).
- **Measured:** Functional-response handling time
- **Population:** Canada laboratory; adult-sized
- **Evidence / NOVA / confidence:** controlled feeding experiment / medium / high
- **Source:** S2 (page: 8-9, section: Results, table: Tables 2-3)
- **Model use:** score
- **Limitations:** Units and fitted-model context must be preserved; not a lure-handling result.

### E5 - temperature and maximum feeding performance
- **Condition/range:** 18 C versus 25 C
- **Observed effect:** Estimated maximum feeding rate declined from 209 prey/h to 75 prey/h; FRR declined from 265 (244-288) to 44 (37-53).
- **Measured:** Model-estimated chironomid consumption
- **Population:** Canada laboratory; adult-sized
- **Evidence / NOVA / confidence:** controlled feeding experiment / medium / high
- **Source:** S2 (page: 8-10, section: Results, table: Table 2)
- **Model use:** score
- **Limitations:** Calibration candidate only; single prey type, two temperatures, laboratory conditions.

### E6 - temperature and observed consumption
- **Condition/range:** 18 C versus 25 C across prey-density treatments
- **Observed effect:** Consumption at 25 C was significantly lower across nearly the entire prey-density range tested.
- **Measured:** Observed prey consumption across densities
- **Population:** Canada laboratory; adult-sized
- **Evidence / NOVA / confidence:** controlled feeding experiment / medium / high
- **Source:** S2 (page: 11, section: Discussion of Fig. 2, figure: Figure 2)
- **Model use:** score
- **Limitations:** Does not prove that all natural populations feed best at 18 C.

### E7 - body condition
- **Condition/range:** Seven-week feeding-trial span; 18 C and 25 C
- **Observed effect:** Brown bullhead condition increased at 18 C but did not change significantly at 25 C; HSI did not differ by temperature.
- **Measured:** Condition factors and organ indices
- **Population:** Canada laboratory; adult-sized
- **Evidence / NOVA / confidence:** growth/physiology endpoint / low-medium / high
- **Source:** S2 (page: 10-12, section: Body condition factors, table: Table 4)
- **Model use:** context-only
- **Limitations:** Condition is not feeding rate or catchability; use only as context and adversarial check.

### E8 - extreme cold and feeding
- **Condition/range:** Controlled winter test at 3 C
- **Observed effect:** Predation occurred at temperatures as low as 3 C.
- **Measured:** Prey consumption / functional response
- **Population:** European non-native population; young; conference abstract reported mean 123 +/- 4 mm TL
- **Evidence / NOVA / confidence:** controlled feeding experiment / low / medium
- **Source:** S3 (section: Abstract)
- **Model use:** score
- **Limitations:** Small European non-native fish and winter lab conditions; no basis for a universal field threshold.

### E9 - short cold-temperature increase
- **Condition/range:** 3 C versus 4.5 C
- **Observed effect:** Modeled potential predation impact showed a strong increase in resource consumption from 3 C to 4.5 C.
- **Measured:** Functional response and potential consumption
- **Population:** European non-native population; young
- **Evidence / NOVA / confidence:** controlled feeding experiment / low / medium
- **Source:** S3 (section: Abstract)
- **Model use:** score
- **Limitations:** Narrow 1.5 C contrast and non-native juvenile population; direction may not transfer quantitatively.

### E10 - diel feeding periodicity
- **Condition/range:** Day versus night under winter experimental conditions
- **Observed effect:** Predation occurred almost exclusively at night; hunting periodicity was classified as nocturnal.
- **Measured:** Actual prey consumption by period
- **Population:** European non-native population; young
- **Evidence / NOVA / confidence:** controlled feeding experiment / low-medium / medium
- **Source:** S3 (section: Abstract and results summary)
- **Model use:** score
- **Limitations:** Winter-specific laboratory evidence; do not universalize to all seasons, clarity levels, or sizes.

### E11 - winter field feeding and heated effluent
- **Condition/range:** Heated power-plant discharge versus a reference pond near 2 C
- **Observed effect:** Fish in the heated discharge fed, whereas fish from the approximately 2 C reference water did not in sampled stomachs.
- **Measured:** Stomach contents and body condition
- **Population:** Connecticut; adult/unspecified
- **Evidence / NOVA / confidence:** field comparative study / medium / medium
- **Source:** S4 (page: 138-141, section: Abstract)
- **Model use:** score
- **Limitations:** Separate sites confound temperature with habitat and effluent; sample-specific absence is not universal cessation.

### E12 - flow and chemical orientation
- **Condition/range:** No-flow versus flowing flume with a gelatin odor source
- **Observed effect:** 100% located the odor source without flow versus 57% under flow; swimming paths differed.
- **Measured:** Odor-source localization
- **Population:** Laboratory flume; unspecified
- **Evidence / NOVA / confidence:** controlled behavior experiment / low-medium / medium
- **Source:** S5 (page: 2301-2318, section: Abstract)
- **Model use:** context-only
- **Limitations:** Orientation is not ingestion or hook-and-line catchability; no natural-flow threshold.

### E13 - prey selection and opportunism
- **Condition/range:** Lake Opinicon, monthly May-November stomach sampling relative to food availability
- **Observed effect:** Brown bullheads were broadly opportunistic; chironomids were consistently consumed and amphipods were emphasized when abundant.
- **Measured:** Stomach contents and food availability
- **Population:** Ontario lake; multiple ages
- **Evidence / NOVA / confidence:** field diet study / medium / medium
- **Source:** S6 (section: Repository project results)
- **Model use:** context-only
- **Limitations:** Diet composition does not quantify a weather or temperature bite response.

### E14 - habitat trophic status and diet
- **Condition/range:** 278 fish from seven Central-Eastern European lakes
- **Observed effect:** Twenty food categories were found; detritus, Chironomidae, plants, and macrofauna were frequent; diet varied with lake trophic status.
- **Measured:** Stomach contents
- **Population:** Central-Eastern Europe; mixed sizes
- **Evidence / NOVA / confidence:** field diet study / low-medium / high
- **Source:** S7 (page: 59-69, section: Abstract and Results)
- **Model use:** context-only
- **Limitations:** European invasive populations; habitat and prey availability are intertwined.

### E15 - growth-temperature evidence
- **Condition/range:** Temperature experiment documented in primary literature
- **Observed effect:** No growth optimum was converted into a bite optimum.
- **Measured:** Growth response
- **Population:** Laboratory; year-0 and older fish reported in metadata/secondary citations
- **Evidence / NOVA / confidence:** growth endpoint / low / low
- **Source:** S8 (page: 1510-1515, section: Bibliographic record only)
- **Model use:** unavailable
- **Limitations:** Exact full text not inspected; growth is score-ineligible here.

### E16 - regional occurrence and targetability
- **Condition/range:** Maryland freshwater hotspot accounts list brown bullhead in regional waters
- **Observed effect:** The species is available to Mid-Atlantic anglers and is a plausible intentional target.
- **Measured:** Agency occurrence
- **Population:** Maryland; all
- **Evidence / NOVA / confidence:** state agency account / high / low-medium
- **Source:** S9 (section: Freshwater Fishing Hotspots)
- **Model use:** context-only
- **Limitations:** Not effort-standardized and not a catchability predictor.

## Candidate model rules

### R1 - water temperature
- **Condition:** After sustained acclimation: compare approximately 25 C with 18 C
- **Direction:** decrease feeding performance at 25 C
- **Strength / confidence:** strong within study; do not calibrate universally / high internal / medium transfer
- **Use:** score
- **Mechanism:** Attack rate fell, handling time rose, and modeled maximum consumption declined after long acclimation.
- **Evidence:** E2, E3, E4, E5, E6
- **Double-counting risk:** High risk of double-counting season, warm-water stress, and prey availability. Use categorical evidence gate, not a smooth curve.

### R2 - short winter temperature change
- **Condition:** Within the studied cold range, 3 C to 4.5 C
- **Direction:** increase modeled predation potential
- **Strength / confidence:** weak portable rule / low
- **Use:** score
- **Mechanism:** Small warming increased modeled consumption in a juvenile European winter experiment.
- **Evidence:** E8, E9
- **Double-counting risk:** Do not combine with a general temperature curve or treat 4.5 C as an optimum.

### R3 - time of day / underwater light
- **Condition:** Winter lab conditions comparable to the reviewed experiment
- **Direction:** increase at night
- **Strength / confidence:** weak and seasonal / low-medium
- **Use:** score
- **Mechanism:** Actual prey consumption was overwhelmingly nocturnal in the winter experiment.
- **Evidence:** E10
- **Double-counting risk:** Double-counting risk with cover, clarity, season, and temperature; do not universalize to summer.

### R4 - very cold water guardrail
- **Condition:** Approximately 2-3 C
- **Direction:** suppress expected feeding but never force a universal zero
- **Strength / confidence:** weak / low
- **Use:** score
- **Mechanism:** A field comparison found no stomach feeding near 2 C, but a controlled experiment documented predation at 3 C.
- **Evidence:** E8, E11
- **Double-counting risk:** Contradictory designs and populations; use only to prevent a false hard cessation threshold.

### R5 - flow/current
- **Condition:** Any uncalibrated natural flow condition
- **Direction:** location/presentation context only
- **Strength / confidence:** weak / medium
- **Use:** context-only
- **Mechanism:** Flow altered odor-source localization in a flume.
- **Evidence:** E12
- **Double-counting risk:** Do not double count flow with turbidity or prey delivery; no ingestion endpoint.

### R6 - prey availability and habitat
- **Condition:** When chironomids, amphipods, detritus, or fish prey availability changes
- **Direction:** diet/presentation context
- **Strength / confidence:** moderate / medium
- **Use:** context-only
- **Mechanism:** Field diets were opportunistic and habitat dependent.
- **Evidence:** E13, E14
- **Double-counting risk:** Do not make prey abundance an automatic feeding-rate bonus without local prey data.

### R7 - body condition
- **Condition:** 18 C versus 25 C experimental treatments
- **Direction:** context only
- **Strength / confidence:** none / high
- **Use:** context-only
- **Mechanism:** Condition and feeding efficiency did not move identically.
- **Evidence:** E7
- **Double-counting risk:** Prevents double counting physiology as bite score.

### R8 - growth temperature
- **Condition:** Any growth-optimum estimate
- **Direction:** no score
- **Strength / confidence:** none / high
- **Use:** zero-weight
- **Mechanism:** Growth endpoint is not feeding or catchability.
- **Evidence:** E15
- **Double-counting risk:** Avoid double counting temperature and life stage.

## Complete bibliography

- **S1** California Academy of Sciences (2026). *Eschmeyer's Catalog of Fishes: Ameiurus nebulosus*. Eschmeyer's Catalog of Fishes. https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatget.asp?spid=54196 Access: full-text; verification: AI-reviewed-unverified.
- **S2** Christophe Benjamin; Jaclyn Hill; Anthony Ricciardi (2026). *Thermal effects on feeding efficiency and body condition in invasive and native benthivorous freshwater fishes*. Biological Invasions 28:51. DOI: 10.1007/s10530-026-03767-w. https://link.springer.com/article/10.1007/s10530-026-03767-w Access: full-text; verification: AI-reviewed-unverified.
- **S3** Alan Fritsch; Pavel Staněk; Miloš Buřič; Antonín Kouba; Lukáš Veselý; Paride Balzani (2025). *Winter predatory efficiency and periodicity of the non-native brown bullhead Ameiurus nebulosus*. Journal of Fish Biology 107(6):1889-1897. DOI: 10.1111/jfb.70189. https://onlinelibrary.wiley.com/doi/10.1111/jfb.70189 Access: full-text; verification: AI-reviewed-unverified.
- **S4** Ronald R. Massengill (1973). *Change in feeding and body condition of brown bullheads overwintering in the heated effluent of a power plant*. Chesapeake Science 14(2):138-141. DOI: 10.2307/1350881. https://link.springer.com/article/10.2307/1350881 Access: abstract-only; verification: AI-reviewed-unverified.
- **S5** Marilyn L. Sherman; Paul A. Moore (2001). *Chemical Orientation of Brown Bullheads, Ameiurus nebulosus, Under Different Flow Conditions*. Journal of Chemical Ecology 27(11):2301-2318. DOI: 10.1023/A:1012239222761. https://pubmed.ncbi.nlm.nih.gov/11817083/ Access: abstract-only; verification: AI-reviewed-unverified.
- **S6** Allen Keast (1985). *Implications of chemosensory feeding in catfishes: an analysis of the diets of Ictalurus nebulosus and I. natalis*. Canadian Journal of Zoology 63(3):590-602. DOI: 10.1139/z85-086. https://research.qubs.ca/projects/implications-of-chemosensory-feeding-in-catfishes-an-analysis-of-the-diets-of-ictalurus-nebulosus-and-i-natalis Access: repository-summary; verification: AI-reviewed-unverified.
- **S7** Jacek Rechulicz; Wojciech Płaska (2019). *Inter-Population Variability of Diet of the Alien Species Brown Bullhead (Ameiurus nebulosus) from Lakes with Different Trophic Status*. Turkish Journal of Fisheries and Aquatic Sciences 19(1):59-69. DOI: 10.4194/1303-2712-v19_1_07. https://www.trjfas.org/pdf.php?id=1297 Access: full-text; verification: AI-reviewed-unverified.
- **S8** Allen Keast (1985). *Growth responses of the brown bullhead (Ictalurus nebulosus) to temperature*. Canadian Journal of Zoology 63(7):1510-1515. DOI: 10.1139/z85-224. https://cdnsciencepub.com/doi/10.1139/z85-224 Access: metadata-only; verification: AI-reviewed-unverified.
- **S9** Maryland Department of Natural Resources (n.d.). *Freshwater Fishing Hotspots and regional species occurrence*. Maryland DNR Fisheries. https://dnr.maryland.gov/fisheries/pages/hotspots/index.aspx Access: full-text; verification: AI-reviewed-unverified.

## Remaining research gaps

- No direct hook-and-line study found.
- No validated Mid-Atlantic temperature response.
- No direct dissolved-oxygen consumption threshold.
- No species-specific weather folklore support.
