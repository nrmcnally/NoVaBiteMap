# Yellow bullhead (*Ameiurus natalis*)

**Species ID:** `yellow-bullhead`  
**Schema:** 1.1  
**Research status:** partial  
**Targetability recommendation:** proposed-for-bite-scoring  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Proposed for future bite scoring, but current evidence supports Fish Guide and context features only. Do not deploy a yellow-bullhead environmental bite score from this batch.

### Model-ready findings

- No score-ready rule was identified.

### Context-only findings

- **diel display:** context: greater locomotor activity. Observed movement pattern only. Evidence: E2, E3.
- **prey/presentation context:** context: broader juvenile diet; more fish/crayfish specialization in adults. Ontogenetic diet shift. Evidence: E7.
- **chemosensory presentation:** context: strong gustatory localization mechanism. Taste functions in distance food finding and intake control. Evidence: E5, E6.

### Rejected or zero-weight assumptions

- **barometric pressure and weather fronts:** No qualifying direct species-specific feeding, foraging, or hook-and-line catchability experiment was found.
- **moon phase:** No qualifying direct species-specific feeding or catchability evidence was found.
- **wind and cloud cover:** No direct species-specific endpoint evidence isolated these atmospheric variables.
- **ordinary rainfall:** Rainfall was not isolated from flow, turbidity, habitat access, or prey delivery in a direct feeding or catchability study.
- **recent stocking:** No species-specific post-stocking hook-and-line depletion or accessibility experiment was found.
- **angling pressure, hook avoidance, and learning:** No species-specific vulnerability or learning experiment was found.
- **monthly activity curve:** No direct evidence supports a smooth monthly feeding or catchability curve; season, temperature, spawn, effort, and abundance cannot be collapsed safely.
- **growth or thermal preference as a bite optimum:** Growth, preferred temperature, and physiological performance are not feeding or hook-and-line catchability unless directly linked in the study.

## Endpoint separation and adversarial review

- Hook-and-line catchability, feeding/consumption, and foraging/attack/prey selection were treated as score-eligible endpoint classes.
- Movement, habitat occupancy, growth, physiology, stress, survival, and reproduction were retained as context unless directly linked to feeding or catchability.
- Contradictory, null, inaccessible, and transfer-limited evidence was preserved. No smooth response curve or production multiplier was invented.

## Targetability assessment

Regional angler encounter and direct feeding ecology support a useful Fish Guide, but no qualifying environmental feeding or hook-and-line predictor is yet validated.

## Evidence ledger

### E1 - taxonomy
- **Condition/range:** Current catalog status
- **Observed effect:** Accepted as Ameiurus natalis (Lesueur, 1819).
- **Measured:** Taxonomic identity and distribution
- **Population:** North America; all
- **Evidence / NOVA / confidence:** taxonomic catalog / high / high
- **Source:** S1 (section: Current status)
- **Model use:** context-only
- **Limitations:** Taxonomic source does not measure feeding or catchability.

### E2 - diel locomotor activity
- **Condition/range:** Twelve adults; individual 3-day shuttlebox trials; 12 h light / 12 h dark
- **Observed effect:** About 80% of recorded locomotor activity occurred during the dark phase.
- **Measured:** Locomotor activity, not feeding
- **Population:** Pennsylvania laboratory; adult
- **Evidence / NOVA / confidence:** controlled laboratory behavior / medium / high
- **Source:** S2 (page: 132-133, section: Abstract/results summary)
- **Model use:** context-only
- **Limitations:** Small laboratory sample; movement cannot be converted to feeding or angling catchability.

### E3 - study design
- **Condition/range:** 12 adult fish; 3-day tests; 12L:12D photoperiod
- **Observed effect:** The design supports a diel movement classification only.
- **Measured:** Electronic shuttlebox movement
- **Population:** Pennsylvania laboratory; adult
- **Evidence / NOVA / confidence:** controlled laboratory behavior / medium / high
- **Source:** S2 (page: 132-133, section: Methods summary)
- **Model use:** context-only
- **Limitations:** No prey, ingestion, strikes, or hooks were measured.

### E4 - temperature preference and ontogeny
- **Condition/range:** Study title and bibliographic scope confirmed; exact treatment values and results unavailable
- **Observed effect:** No numerical threshold was extracted or scored.
- **Measured:** Preferred temperature and diel activity
- **Population:** Laboratory; origin unresolved; multiple ontogenetic stages
- **Evidence / NOVA / confidence:** metadata-only primary study / low / low
- **Source:** S3 (page: 409-411, section: Bibliographic record only)
- **Model use:** unavailable
- **Limitations:** Full text and exact result locators unavailable; no inference from title alone.

### E5 - chemosensory food finding
- **Condition/range:** Peripheral olfactory destruction versus gustatory-area ablations
- **Observed effect:** Olfactory destruction did not prevent food finding; taste acted as a distance receptor and helped control food intake.
- **Measured:** Food finding and intake behavior
- **Population:** Laboratory; unspecified
- **Evidence / NOVA / confidence:** experimental neurobehavior / low-medium / medium
- **Source:** S4 (page: 273-294, section: Abstract)
- **Model use:** context-only
- **Limitations:** Mechanism study; no environmental predictor or angling endpoint.

### E6 - chemosensory localization and swallowing
- **Condition/range:** Facial taste-area ablation versus vagal taste-area ablation
- **Observed effect:** Facial-area damage impaired localization/pickup; vagal-area damage impaired swallowing without preventing localization/pickup.
- **Measured:** Localization, pickup, and swallowing
- **Population:** Laboratory; unspecified
- **Evidence / NOVA / confidence:** experimental neurobehavior / low-medium / medium
- **Source:** S4 (page: 273-294, section: Abstract)
- **Model use:** context-only
- **Limitations:** Not a field feeding-rate or catchability study.

### E7 - prey selection and life stage
- **Condition/range:** Lake Opinicon stomach samples during monthly 14-day windows, May-November 1974
- **Observed effect:** Young yellow bullheads were broader generalists; adults were more specialized on fish and crayfish.
- **Measured:** Stomach contents relative to food availability
- **Population:** Lake Opinicon, Ontario; juvenile and adult
- **Evidence / NOVA / confidence:** field diet study / medium / medium
- **Source:** S5 (section: Repository project methods and results)
- **Model use:** context-only
- **Limitations:** One Canadian lake and historic sampling; does not estimate catchability.

### E8 - sampling time and diet evidence
- **Condition/range:** Most netting 2100-2400 and 0500-0800; inshore seine and offshore gill nets
- **Observed effect:** Diet conclusions came from stomach contents, not a controlled test of diel feeding rate.
- **Measured:** Stomach contents and prey availability
- **Population:** Lake Opinicon, Ontario; juvenile and adult
- **Evidence / NOVA / confidence:** field diet study / medium / medium
- **Source:** S5 (section: Repository project methods)
- **Model use:** context-only
- **Limitations:** Sampling windows confound time, habitat, gear, and prey availability; do not create a night multiplier.

### E9 - growth and longevity
- **Condition/range:** 144 fish, 97-312 mm total length, ages 1-12
- **Observed effect:** Growth was rapid during the first three years and slowed later; the study documented longevity to age 12.
- **Measured:** Age and growth
- **Population:** Everglades, Florida; ages 1-12
- **Evidence / NOVA / confidence:** field age-growth study / low / high
- **Source:** S6 (section: USGS abstract and citation)
- **Model use:** context-only
- **Limitations:** Growth and longevity do not establish feeding or bite optima; southern Florida transfer is weak.

### E10 - regional targetability and occurrence
- **Condition/range:** Maryland Chesapeake Bay tributaries; anglers commonly encounter fish <=10 in and some exceed 15 in
- **Observed effect:** The species is regionally encountered by anglers and plausibly intentional as a small catfish target.
- **Measured:** Agency occurrence and angler-size account
- **Population:** Maryland; juvenile and adult
- **Evidence / NOVA / confidence:** state agency account / high / medium
- **Source:** S7 (section: Yellow Bullhead)
- **Model use:** context-only
- **Limitations:** Not an effort-standardized creel study and not a predictor.

## Candidate model rules

### R1 - diel display
- **Condition:** Dark phase under the reviewed 12L:12D adult laboratory design
- **Direction:** context: greater locomotor activity
- **Strength / confidence:** moderate / high
- **Use:** context-only
- **Mechanism:** Observed movement pattern only.
- **Evidence:** E2, E3
- **Double-counting risk:** High risk of double-counting light with cover and incorrectly converting movement into feeding.

### R2 - prey/presentation context
- **Condition:** Juvenile versus adult life stage
- **Direction:** context: broader juvenile diet; more fish/crayfish specialization in adults
- **Strength / confidence:** moderate / medium
- **Use:** context-only
- **Mechanism:** Ontogenetic diet shift.
- **Evidence:** E7
- **Double-counting risk:** Do not double count body size and prey availability.

### R3 - chemosensory presentation
- **Condition:** Odor/taste-accessible natural baits or prey cues
- **Direction:** context: strong gustatory localization mechanism
- **Strength / confidence:** weak / medium
- **Use:** context-only
- **Mechanism:** Taste functions in distance food finding and intake control.
- **Evidence:** E5, E6
- **Double-counting risk:** Fish Guide information; not an environmental score.

### R4 - temperature
- **Condition:** Any exact preferred-temperature or growth value
- **Direction:** no score
- **Strength / confidence:** none / high
- **Use:** zero-weight
- **Mechanism:** Preference/growth does not establish feeding or catchability.
- **Evidence:** E4, E9
- **Double-counting risk:** Avoid double counting temperature with season and growth.

## Complete bibliography

- **S1** California Academy of Sciences (2026). *Eschmeyer's Catalog of Fishes: Ameiurus natalis*. Eschmeyer's Catalog of Fishes. https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatget.asp?spid=54189 Access: full-text; verification: AI-reviewed-unverified.
- **S2** W. W. Reynolds; M. E. Casterlin (1977). *Diel Activity in the Yellow Bullhead*. The Progressive Fish-Culturist 39(3):132-133. DOI: 10.1577/1548-8659(1977)39[132:DAITYB]2.0.CO;2. https://academic.oup.com/naja/article-abstract/39/3/132/7878902 Access: abstract-only; verification: AI-reviewed-unverified.
- **S3** William W. Reynolds; Martha E. Casterlin (1978). *Ontogenetic change in preferred temperature and diel activity of the yellow bullhead, Ictalurus natalis*. Comparative Biochemistry and Physiology Part A: Physiology 59(4):409-411. DOI: 10.1016/0300-9629(78)90188-3. https://www.sciencedirect.com/science/article/pii/0300962978901883 Access: metadata-only; verification: AI-reviewed-unverified.
- **S4** Jelle Atema (1971). *Structures and Functions of the Sense of Taste in the Catfish (Ictalurus natalis)*. Brain, Behavior and Evolution 4(4):273-294. DOI: 10.1159/000125438. https://karger.com/bbe/article/4/4/273/45776/Structures-and-Functions-of-the-Sense-of-Taste-in Access: abstract-only; verification: AI-reviewed-unverified.
- **S5** Allen Keast (1985). *Implications of chemosensory feeding in catfishes: an analysis of the diets of Ictalurus nebulosus and I. natalis*. Canadian Journal of Zoology 63(3):590-602. DOI: 10.1139/z85-086. https://research.qubs.ca/projects/implications-of-chemosensory-feeding-in-catfishes-an-analysis-of-the-diets-of-ictalurus-nebulosus-and-i-natalis Access: repository-summary; verification: AI-reviewed-unverified.
- **S6** D. J. Murie; D. C. Parkyn; W. F. Loftus; L. G. Nico (2009). *Variable growth and longevity of yellow bullhead (Ameiurus natalis) in the Everglades of south Florida, USA*. Journal of Applied Ichthyology 25(6):740-745. DOI: 10.1111/j.1439-0426.2009.01300.x. https://pubs.usgs.gov/publication/70037419 Access: abstract-only; verification: AI-reviewed-unverified.
- **S7** Maryland Department of Natural Resources (n.d.). *Catfish Identification: Yellow Bullhead*. Maryland DNR Fisheries. https://dnr.maryland.gov/fisheries/Pages/flat_cat/flathead_id.aspx Access: full-text; verification: AI-reviewed-unverified.
- **S8** U.S. Fish and Wildlife Service (n.d.). *Yellow Bullhead (Ameiurus natalis)*. U.S. Fish and Wildlife Service. https://www.fws.gov/species/yellow-bullhead-ameiurus-natalis Access: full-text; verification: AI-reviewed-unverified.

## Remaining research gaps

- No qualifying pressure/front/moon/wind/cloud/rain evidence.
- No direct dissolved-oxygen feeding threshold.
- No direct temperature-feeding response curve.
- No angling-pressure or stocking vulnerability experiment.
