# BiteMap NOVA research resume packet

## Completed species

- largemouth-bass
- smallmouth-bass
- channel-catfish
- Batches 1-8 (provided by user)
- yellow-bullhead
- brown-bullhead
- northern-hogsucker

## Pending species

- Batch 10: shorthead-redhorse, blacknose-dace, longnose-dace
- Batch 11: mottled-sculpin, tessellated-darter, gizzard-shad

## Next recommended batch

Batch 10 - Redhorse and daces. Do not silently promote movement or habitat evidence to feeding/catchability.

## Schema version

1.1

## Batch 9 result

- Brown bullhead: proposed for a limited, research-backed bite-scoring pilot; four cautious score candidates.
- Yellow bullhead: proposed for future scoring, but current output remains Fish Guide/context only.
- Northern hogsucker: Fish Guide only; telemetry and habitat evidence is not score-ready.

## Known corrections

See `correction-and-conflict-log.json`. Preserve complete original bylines, including Matheney IV and the six-author Fritsch paper. Dynamic agency pages remain undated unless they supply a publication date.

## Unresolved questions

- No direct hook-and-line catchability experiment was found for any Batch 9 species.
- Brown-bullhead score candidates lack Mid-Atlantic natural-water replication.
- Yellow-bullhead environmental feeding modifiers remain untested.
- Northern-hogsucker research is dominated by movement, habitat, and demographics rather than feeding.

## Files a new chat must receive

1. BiteMap_complete_37_species_research_archive.zip
2. BiteMap_channel-catfish_deep_verified_research_archive.zip
3. The immediately preceding completed-batch archive(s), including this Batch 9 ZIP
4. COPY_PASTE_MASTER_PROMPT.txt, changed to ACTIVE BATCH = BATCH 10
