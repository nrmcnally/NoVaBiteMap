# Brook Trout
*Salvelinus fontinalis*

- Species ID: `brook-trout`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Brook trout are a flagship native Mid-Atlantic target. Direct competitor-dependent feeding evidence and strain vulnerability support Bite-scored status, with substantial transfer limits.

### Model-ready findings
- **score**: At 18, 20 and 22 C, warming reduced brook-trout feeding and aggression specifically when creek chub were present; model only as a temperature-by-competitor interaction. Evidence: E5, E6.
- **score**: Wild brook-trout strains differed in angling vulnerability in a Michigan exploitation experiment; this is a low-portability population/strain candidate. Evidence: E10.

### Context-only findings
- From less than 3 to more than 40 NTU, juvenile daily consumption was unchanged while growth declined and active searching increased. Evidence: E7, E8.
- West Virginia telemetry shows strong temperature/refuge movement context, not feeding. Evidence: E9.
- Maryland hook-type results belong in the Fish Guide rather than an environmental bite score. Evidence: E11.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- wind or ordinary rainfall as an independent direct multiplier
- cloud cover without measured underwater light
- moon phase or solunar tables
- growth optimum used as bite optimum
- movement used as feeding
- habitat occupancy used as catchability
- spawning movement used as feeding
- monthly curves derived from seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The strongest thermal feeding effect requires creek-chub presence; temperature alone is not supported.
- Turbidity reduced growth but not consumption, showing why growth cannot substitute for feeding.
- Warm-water refuge concentration can increase encounter rate while fish remain physiologically stressed.

## Targetability assessment
Brook trout are a flagship native Mid-Atlantic target. Direct competitor-dependent feeding evidence and strain vulnerability support Bite-scored status, with substantial transfer limits.

## Candidate model rules
### R1. waterTemperatureC_x_creekChubPresence - score
- Condition: 18-22 C with creek chub present in the Colby flow-through-tank design
- Direction: decrease
- Strength: moderate
- Confidence: medium
- Mechanism: Warming weakened brook-trout feeding and aggression under interspecific competition.
- Evidence: E5, E6
- Double-counting risk: Requires competitor presence; avoid double counting temperature, species composition, aggression and habitat displacement; no smooth curve.
### R2. populationOrStrain - score
- Condition: East Branch Fox versus Au Sable strains in the Michigan exploitation experiment
- Direction: increase for the faster-growing strain
- Strength: weak
- Confidence: low-medium
- Mechanism: Inherited or learned strain differences in growth/behavior affected angling vulnerability.
- Evidence: E10
- Double-counting risk: Do not map to Virginia lineages without genetic/stocking provenance; growth and behavior are confounded.
### R3. turbidityNtu - zero-weight
- Condition: <3 to >40 NTU at 12 C, 49 lx and 0.06 m/s for juvenile hatchery fish
- Direction: none for daily consumption
- Strength: zero
- Confidence: high
- Mechanism: Fish maintained intake by increasing activity and changing search strategy.
- Evidence: E7, E8
- Double-counting risk: Do not infer no effect on adult catchability, energy balance, higher turbidity or different light/current.
### R4. daysSinceStocking - zero-weight
- Condition: 1-30 days after stocking in Virginia pooled trout data
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: Catch did not show a simple monotonic post-stocking decline.
- Evidence: E3
- Double-counting risk: Pooled species and overlapping stocking/harvest.
### R5. isStockingDay - context-only
- Condition: Actual stocking day
- Direction: increase in observed catch
- Strength: moderate
- Confidence: medium-low
- Mechanism: Immediate concentration and accessibility.
- Evidence: E2
- Double-counting risk: May be access rather than feeding; pooled species.
### R6. thermalRefugeAvailability - context-only
- Condition: Warm mainstem with accessible cold-water refuge
- Direction: increase in local encounter/catch concentration, not appetite
- Strength: moderate
- Confidence: medium-low
- Mechanism: Fish aggregate in refuge patches under heat.
- Evidence: E4, E9
- Double-counting risk: Do not score warm water as beneficial or double count occupancy and ethical heat stress.
### R7. dissolvedOxygenMgL - zero-weight
- Condition: Any universal bite threshold derived from activity or occupancy
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Available brook-trout oxygen studies measured distribution or activity, not feeding/catchability.
- Evidence: E14, E15
- Double-counting risk: Do not substitute habitat choice for bite probability.
### R8. dielPeriod - zero-weight
- Condition: Day/night/light category from lake telemetry
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Movement and depth changed, but feeding and hook-and-line capture were not measured.
- Evidence: E13
- Double-counting risk: Do not transfer an ice-covered lake schedule to Appalachian streams.
### R9. barometricPressureFrontsMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No direct species-specific feeding or catchability evidence.
- Evidence: none
- Double-counting risk: Do not proxy temperature, light or flow with folklore.
### R10. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Native versus stocked populations, spawning, access and temperature differ too much for a universal curve.
- Evidence: E1, E2, E13
- Double-counting risk: Avoid double counting season, stocking and effort.

## Evidence ledger
### E1. regional targetability, native status and ecology - context-only
- Exact condition/range: Virginia brook-trout resources, including native southern Appalachian populations.
- Observed effect: Confirms high intentional targetability and the importance of wild-versus-stocked and genetic context.
- Measured: Distribution, management status, genetics and life history
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency synthesis
- NOVA applicability: very high for regional context
- Confidence: high
- Source: S1 (page: 8-10; section: Brook Trout)
- Limitations: Habitat and thermal preference are not feeding or catchability optima.
- Surrogate evidence: false
### E2. recent stocking and catchability - context-only
- Exact condition/range: Virginia put-and-take waters with trout species pooled.
- Observed effect: Observed catch was fastest on stocking day, while catch and effort depended on site, month and time since stocking.
- Measured: Catch per angler-hour and effort
- Population/location: Western Virginia
- Life stage: stocked catchable trout
- Evidence type: field creel/thesis
- NOVA applicability: high regional relevance, species pooled
- Confidence: medium
- Source: S2 (page: 33-45; section: Chapter 2)
- Limitations: May reflect accessibility and angler concentration rather than feeding.
- Surrogate evidence: false
### E3. days since stocking - zero-weight
- Exact condition/range: Post-stocking intervals through 30 days in pooled Virginia trout data.
- Observed effect: Catch rates after the initial pulse remained near 1 trout per angler-hour instead of declining monotonically.
- Measured: Catch per angler-hour
- Population/location: Western Virginia
- Life stage: stocked catchable trout
- Evidence type: field creel/thesis
- NOVA applicability: high for rejecting simple decay
- Confidence: medium
- Source: S2 (page: 44; section: Discussion; figure: Figure 2-3)
- Limitations: Species pooled; overlapping stocking and harvest may mask local patterns.
- Surrogate evidence: false
### E4. species catchability and thermal-refuge concentration - context-only
- Exact condition/range: Stocked brook, rainbow and brown trout in an Adirondack river; summer exceeded 20 C with cold refuges.
- Observed effect: Estimated angler catch was highest for brook trout (72%); warm conditions did not lower catch because refuges concentrated fish.
- Measured: Angler recoveries
- Population/location: Adirondack river, New York
- Life stage: stocked trout
- Evidence type: field tagging and recovery
- NOVA applicability: important warning for stocked/refuge fisheries
- Confidence: medium
- Source: S3 (section: Abstract)
- Limitations: Catch concentration is not feeding; species differed in survival and movement.
- Surrogate evidence: false
### E5. temperature by competitor interaction on feeding - score
- Exact condition/range: Brook trout alone, paired with brook trout, or paired with creek chub at 18, 20 and 22 C in flow-through tanks.
- Observed effect: As temperature increased, brook-trout feeding and aggression declined significantly when paired with creek chub.
- Measured: Pellets consumed, feeding latency, aggression and space use
- Population/location: Experimental Appalachian species assemblage
- Life stage: juvenile/subadult
- Evidence type: controlled experiment
- NOVA applicability: mechanistically relevant to warm lower-elevation streams with creek chub
- Confidence: medium-high
- Source: S4 (section: Results; table: Table 1; figure: Figures 2-4)
- Limitations: Artificial pellets and dyads; temperature effect depended on competitor identity and cannot be a universal brook-trout curve.
- Surrogate evidence: false
### E6. competition, temperature and habitat use - context-only
- Exact condition/range: Same 18, 20 and 22 C treatments across solitary and paired combinations.
- Observed effect: Space use and dominance shifted by pairing treatment; solitary and conspecific responses differed from brook-trout/creek-chub pairs.
- Measured: Feeding latency, aggression and position
- Population/location: Experimental flow-through tanks
- Life stage: juvenile/subadult
- Evidence type: controlled experiment
- NOVA applicability: context for competitor-aware modeling
- Confidence: medium-high
- Source: S4 (section: Results and Discussion; figure: Figures 2-5)
- Limitations: Requires local competitor presence/abundance; movement and aggression should not be double-counted as feeding.
- Surrogate evidence: false
### E7. turbidity and prey consumption - zero-weight
- Exact condition/range: Artificial stream at 12.0 +/- 0.5 C, about 49 lx, 0.06 m/s; turbidity from <3 to >40 NTU; hatchery fish mean length about 126 mm.
- Observed effect: Turbidity had no significant effect on mean daily prey consumption.
- Measured: Daily prey consumption
- Population/location: Artificial stream, West Virginia research context
- Life stage: juvenile hatchery
- Evidence type: controlled experiment
- NOVA applicability: good Appalachian mechanistic relevance, limited life stage
- Confidence: high
- Source: S5 (page: 386-393; section: Methods and Results; figure: Figures 1-2)
- Limitations: Does not cover adult angling, higher turbidity, natural prey drift, or different light/current.
- Surrogate evidence: false
### E8. turbidity, activity and growth - context-only
- Exact condition/range: Same <3 to >40 NTU artificial-stream experiment.
- Observed effect: Growth declined as turbidity increased while activity and foraging strategy shifted from drift feeding toward active searching.
- Measured: Specific growth, activity and strategy
- Population/location: Artificial stream
- Life stage: juvenile hatchery
- Evidence type: controlled experiment
- NOVA applicability: context only
- Confidence: high
- Source: S5 (page: 386-393; section: Results and Discussion)
- Limitations: Growth cost occurred without reduced consumption; converting growth to bite would reverse the actual feeding endpoint.
- Surrogate evidence: false
### E9. temperature, flow, refugia and movement - context-only
- Exact condition/range: Radio-tagged brook trout in a complex West Virginia riverscape.
- Observed effect: Movement and location were associated with maximum temperature and distance to cold-water sources; fish used thermal refugia and no tracked fish were observed above the reported high-temperature envelope.
- Measured: Movement and habitat occupancy
- Population/location: West Virginia Appalachians
- Life stage: wild adult
- Evidence type: field telemetry
- NOVA applicability: high regional ecological relevance
- Confidence: high
- Source: S6 (section: Results and Discussion)
- Limitations: Movement and occupancy are not feeding or catchability; telemetry detection and system geometry matter.
- Surrogate evidence: false
### E10. population/strain and angling vulnerability - score
- Exact condition/range: Three wild brook-trout strains exposed to different exploitation levels in Michigan.
- Observed effect: The faster-growing East Branch Fox strain was caught more readily than the compared Au Sable strains.
- Measured: Hook-and-line vulnerability, growth and survival
- Population/location: Michigan streams
- Life stage: wild trout strains
- Evidence type: field exploitation experiment, abstract-level
- NOVA applicability: supports strain/population context
- Confidence: medium
- Source: S7 (section: Abstract)
- Limitations: Founder effects, growth, behavior and prior selection were not cleanly separated; not portable to Virginia genetics without validation.
- Surrogate evidence: false
### E11. hook type, active/passive presentation and catchability - context-only
- Exact condition/range: 201 stream-dwelling brook trout captured with circle and J hooks under active/passive methods.
- Observed effect: Hooking method and hook type affected capture and injury outcomes.
- Measured: Catchability, hooking location and mortality
- Population/location: Maryland streams
- Life stage: wild stream trout
- Evidence type: field angling experiment
- NOVA applicability: high Fish Guide relevance
- Confidence: high
- Source: S8 (section: Methods and Results)
- Limitations: Gear/presentation belongs in Fish Guide; it does not establish an environmental bite score.
- Surrogate evidence: false
### E12. temperature, growth and stress physiology - context-only
- Exact condition/range: Brook trout acclimated across warm temperatures in a controlled experiment.
- Observed effect: Upper growth performance and stress responses changed with temperature.
- Measured: Growth, endocrine and physiological stress endpoints
- Population/location: Controlled laboratory experiment
- Life stage: brook trout
- Evidence type: controlled physiology study
- NOVA applicability: important heat-risk context
- Confidence: high
- Source: S9 (section: Results and Discussion)
- Limitations: Growth and stress are not feeding or catchability; do not treat the growth limit as a bite optimum.
- Surrogate evidence: false
### E13. season, diel period, light and activity - context-only
- Exact condition/range: 17-month telemetry in an ice-covered Newfoundland lake.
- Observed effect: Depth, movement and range varied with season, temperature, light and time of day.
- Measured: Movement and habitat use
- Population/location: Newfoundland lake
- Life stage: wild lake brook trout
- Evidence type: field telemetry
- NOVA applicability: low-to-moderate transfer to NOVA streams
- Confidence: medium-high
- Source: S10 (section: Results and Discussion)
- Limitations: Lake/ice environment and movement endpoint prevent a bite-time rule.
- Surrogate evidence: false
### E14. dissolved oxygen and habitat choice - context-only
- Exact condition/range: Fingerling brook trout given laboratory dissolved-oxygen gradients.
- Observed effect: Fish distribution shifted across oxygen gradients, demonstrating avoidance/selection behavior.
- Measured: Position in oxygen gradient
- Population/location: Laboratory
- Life stage: fingerling
- Evidence type: controlled habitat-choice experiment, abstract-level
- NOVA applicability: physiological/habitat context only
- Confidence: medium
- Source: S12 (section: Abstract)
- Limitations: Occupancy is not feed intake or catchability; acclimation and temperature interactions limit transfer.
- Surrogate evidence: false
### E15. dissolved oxygen and activity - context-only
- Exact condition/range: Brook trout exposed to oxygen treatments in a laboratory experiment.
- Observed effect: Activity responded to oxygen concentration.
- Measured: Locomotor activity
- Population/location: Laboratory
- Life stage: brook trout
- Evidence type: controlled activity experiment, abstract-level
- NOVA applicability: context only
- Confidence: medium
- Source: S11 (section: Abstract)
- Limitations: Activity is not feeding, and direction cannot be converted to catchability without direct linkage.
- Surrogate evidence: false

## Remaining research gaps
- Wild adult Appalachian feeding and hook-and-line trials across temperature, flow, oxygen, light and turbidity.
- Local competitor-abundance data needed before applying the creek-chub interaction.
- Virginia lineage/stocking provenance needed before any strain vulnerability adjustment.
- Short-term hook-avoidance and depletion studies.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained, exact values remain bounded to study conditions, and no final production multiplier or invented smooth curve is supplied.

## Complete bibliography
### S1. Stephen J. Reeser (2019)
**Virginia Wild Trout Management Plan 2019-2028**. Virginia Department of Game and Inland Fisheries.
https://dwr.virginia.gov/wp-content/uploads/media/Virginia-Wild-Trout-Management-Plan-2019-2028.pdf
Scope: Virginia. Access: original-agency-pdf-full-text. Verification: AI-reviewed-unverified.
### S2. Amanda A. Hyman (2015)
**The Virginia Stocked-Trout Program: An Evaluation of Anglers and Their Catch**. Virginia Polytechnic Institute and State University.
https://vtechworks.lib.vt.edu/bitstream/handle/10919/78333/Hyman_AA_T_2016.pdf
Scope: Fourteen put-and-take waters in western Virginia. Access: university-repository-pdf-full-text. Verification: AI-reviewed-unverified.
### S3. Owen E. Baird, Charles C. Krueger, and Daniel C. Josephson (2006)
**Growth, Movement, and Catch of Brook, Rainbow, and Brown Trout after Stocking into a Large, Marginally Suitable Adirondack River**. North American Journal of Fisheries Management 26(1):180-189. DOI: 10.1577/M04-183.1.
https://academic.oup.com/najfm/article/26/1/180/7847743
Scope: West Branch Sacandaga River, Adirondack Mountains, New York. Access: publisher-abstract-and-pdf-preview. Verification: AI-reviewed-unverified.
### S4. Bryan R. Colby, Jonathan M. Niles, and Matthew Persons (2022)
**Shifting thermal regimes influence competitive feeding and aggression dynamics of brook trout (Salvelinus fontinalis) and creek chub (Semotilus atromaculatus)**. Ecology and Evolution 12:e9056. DOI: 10.1002/ece3.9056.
https://pmc.ncbi.nlm.nih.gov/articles/PMC9251879/
Scope: Experimental flow-through tanks, Appalachian species. Access: publisher-open-full-text. Verification: AI-reviewed-unverified.
### S5. John A. Sweka and Kyle J. Hartman (2001)
**Effects of turbidity on prey consumption and growth in brook trout and implications for bioenergetics modeling**. Canadian Journal of Fisheries and Aquatic Sciences 58(2):386-393. DOI: 10.1139/f00-260.
https://cdnsciencepub.com/doi/pdf/10.1139/f00-260
Scope: Artificial stream, West Virginia research context. Access: publisher-pdf-full-text. Verification: AI-reviewed-unverified.
### S6. J. Todd Petty, Jeff L. Hansbarger, Benjamin M. Huntsman, and Patricia M. Mazik (2012)
**Brook Trout Movement in Response to Temperature, Flow, and Thermal Refugia within a Complex Appalachian Riverscape**. Transactions of the American Fisheries Society 141(4):1060-1073. DOI: 10.1080/00028487.2012.681102.
https://www.tandfonline.com/doi/full/10.1080/00028487.2012.681102
Scope: West Virginia Appalachian riverscape. Access: publisher-full-text. Verification: AI-reviewed-unverified.
### S7. Andrew J. Nuhfer and Gaylord R. Alexander (1994)
**Growth, Survival, and Vulnerability to Angling of Three Wild Brook Trout Strains Exposed to Different Levels of Angler Exploitation**. North American Journal of Fisheries Management 14(2):423-434. DOI: 10.1577/1548-8675(1994)014<0423:GSAVTA>2.3.CO;2.
https://www.tandfonline.com/doi/abs/10.1577/1548-8675(1994)014%3C0423:GSAVTA%3E2.3.CO%3B2
Scope: Michigan streams. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S8. David C. Kazyak, Matthew T. Sell, Robert H. Hilderbrand, Robert E. Heft, and David M. Cooper (2016)
**A Comparison of Catchability and Mortality with Circle and J Hooks for Stream-Dwelling Brook Trout**. North American Journal of Fisheries Management 36(2):259-266. DOI: 10.1080/02755947.2015.1120833.
https://www.tandfonline.com/doi/full/10.1080/02755947.2015.1120833
Scope: Maryland streams. Access: publisher-full-text. Verification: AI-reviewed-unverified.
### S9. Joseph G. Chadwick and Stephen D. McCormick (2017)
**Upper thermal limits of growth in brook trout and their relationship to stress physiology**. Journal of Experimental Biology 220(21):3976-3987. DOI: 10.1242/jeb.161224.
https://journals.biologists.com/jeb/article/220/21/3976/18805/Upper-thermal-limits-of-growth-in-brook-trout-and
Scope: Controlled acclimation experiment. Access: publisher-full-text. Verification: AI-reviewed-unverified.
### S10. David Cote, B. Tibble, R. Allen Curry, S. Peake, B. K. Adams, K. D. Clarke, and R. Perry (2020)
**Seasonal and diel patterns in activity and habitat use by brook trout (Salvelinus fontinalis) in a small Newfoundland lake**. Environmental Biology of Fishes 103:31-47. DOI: 10.1007/s10641-019-00931-1.
https://link.springer.com/article/10.1007/s10641-019-00931-1
Scope: Small lake, Newfoundland, Canada. Access: publisher-open-full-text. Verification: AI-reviewed-unverified.
### S11. J. W. T. Dandy (1970)
**Activity response to oxygen in the brook trout, Salvelinus fontinalis (Mitchill)**. Canadian Journal of Zoology 48(5):1067-1072. DOI: 10.1139/z70-189.
https://doi.org/10.1139/z70-189
Scope: Laboratory oxygen experiment. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S12. W. A. Spoor (1990)
**Distribution of fingerling brook trout, Salvelinus fontinalis (Mitchill), in dissolved oxygen concentration gradients**. Journal of Fish Biology 36(3):363-373. DOI: 10.1111/j.1095-8649.1990.tb05616.x.
https://onlinelibrary.wiley.com/doi/10.1111/j.1095-8649.1990.tb05616.x
Scope: Laboratory oxygen-gradient experiment. Access: publisher-abstract. Verification: AI-reviewed-unverified.
