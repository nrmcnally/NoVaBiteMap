# Rainbow Trout
*Oncorhynchus mykiss*

- Species ID: `rainbow-trout`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Rainbow trout are a major Virginia target with direct feeding and catchability evidence, but implementation should remain limited to bounded oxygen and size candidates rather than broad seasonal folklore.

### Model-ready findings
- **score**: Chronic exposure to approximately 4.5 mg/L dissolved oxygen at 14 C reduced voluntary feed intake in a controlled rainbow-trout trial; use only as a bounded chronic-hypoxia candidate. Evidence: E6.
- **score**: Stocked rainbow trout over 300 mm were caught more readily than fish under 260 mm in one Adirondack river; retain as a population-limited size candidate. Evidence: E4.

### Context-only findings
- Turbidity affected reactive distance and prey selection, but juvenile feeding quantity was maintained through 160 NTU and field piscivory did not follow a generic penalty. Evidence: E9, E10, E11, E12.
- Virginia pooled-trout creel data reject a simple 1-30 day post-stocking catch-rate collapse. Evidence: E2, E3.
- Heat can concentrate stocked trout in cool refuges and preserve catches without implying increased appetite. Evidence: E5.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- wind or ordinary rainfall as an independent direct multiplier
- cloud cover without measured underwater light
- moon phase or solunar tables
- growth optimum used as bite optimum
- movement used as feeding
- habitat occupancy used as catchability
- spawning movement used as feeding
- monthly curves derived from seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- Aquaculture hypoxia effects may not match short natural oxygen events.
- Turbidity studies disagree by endpoint: visual range can decline while total consumption persists or field piscivory rises.
- Stocking-day catches and refuge concentration can reflect accessibility rather than feeding.

## Targetability assessment
Rainbow trout are a major Virginia target with direct feeding and catchability evidence, but implementation should remain limited to bounded oxygen and size candidates rather than broad seasonal folklore.

## Candidate model rules
### R1. dissolvedOxygenMgL - score
- Condition: Approximately 4.5 mg/L versus 7.9 mg/L for 42 days at 14 C in cultured fish
- Direction: decrease
- Strength: weak
- Confidence: medium
- Mechanism: Chronic hypoxia constrained voluntary intake and metabolism.
- Evidence: E6
- Double-counting risk: Do not double count with heat stress, refuge occupancy, or a generic physiological-stress score; no smooth curve.
### R2. fishLengthMm - score
- Condition: Stocked rainbow trout >300 mm versus <260 mm in the studied Adirondack river
- Direction: increase
- Strength: moderate
- Confidence: medium-low
- Mechanism: Size may alter lure visibility, behavior, and angler selection.
- Evidence: E4
- Double-counting risk: Do not extrapolate to intermediate lengths, wild fish, or all gear; size also correlates with age and stocking cohort.
### R3. daysSinceStocking - zero-weight
- Condition: 1-30 days after stocking, excluding the stocking-day pulse
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: Virginia pooled-trout catch rate stayed near the managerial target rather than decaying monotonically.
- Evidence: E3
- Double-counting risk: Do not double count overlapping stockings, effort, access, or harvest.
### R4. isStockingDay - context-only
- Condition: Actual stocking day on Virginia put-and-take waters
- Direction: increase in observed catch rate
- Strength: moderate
- Confidence: medium-low
- Mechanism: Immediate accessibility and concentrated fish increased angler success.
- Evidence: E2
- Double-counting risk: Species were pooled; this may measure access and effort rather than feeding.
### R5. turbidityNtu - zero-weight
- Condition: 0-160 NTU for juvenile feeding quantity in the Rowe laboratory design
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: Juveniles maintained prey consumption by shifting foraging mode or prey use.
- Evidence: E9
- Double-counting risk: Do not infer no effect on adult lures, reactive distance, or conditions above 160 NTU.
### R6. turbidityAndPreyField - context-only
- Condition: Turbidity with known prey type, density, and fish size
- Direction: variable
- Strength: weak
- Confidence: medium-low
- Mechanism: Visual range, prey selection, and piscivory can move in different directions.
- Evidence: E10, E11, E12
- Double-counting risk: Avoid double counting clarity, light, prey availability, and habitat concentration.
### R7. recentCatchAndRelease - unavailable
- Condition: Any generic short-term suppression period
- Direction: unknown
- Strength: unknown
- Confidence: medium
- Mechanism: Available rainbow study emphasized growth and survival, not a portable recapture curve.
- Evidence: E15
- Double-counting risk: Do not borrow brown-trout learning duration.
### R8. temperature - context-only
- Condition: High temperature without measured refuge availability
- Direction: unknown
- Strength: unknown
- Confidence: medium
- Mechanism: Thermal stress and catch concentration can oppose each other.
- Evidence: E5
- Double-counting risk: Do not score warm water positively; physiology and ethical fish handling remain separate.
### R9. barometricPressureFrontsMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No direct species-specific feeding or catchability evidence survived review.
- Evidence: none
- Double-counting risk: Do not proxy underwater light or temperature trend with folklore.
### R10. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Management schedules, access, regulations, and angler effort confound seasonal catch.
- Evidence: E1, E2
- Double-counting risk: Do not manufacture a continuous monthly curve.

## Evidence ledger
### E1. regional targetability and ecology - context-only
- Exact condition/range: Virginia wild rainbow-trout populations and fisheries described in the state management plan.
- Observed effect: Confirms intentional regional targeting and distinguishes wild from stocked management.
- Measured: Distribution, management status, habitat and life history
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency synthesis
- NOVA applicability: high for targetability; low for bite prediction
- Confidence: high
- Source: S1 (page: 11; section: Rainbow Trout)
- Limitations: Natural-history statements do not establish bite optima.
- Surrogate evidence: false
### E2. recent stocking and catchability - context-only
- Exact condition/range: 5,689 interviews on 14 Virginia put-and-take waters; species were pooled.
- Observed effect: Catch was fastest on stocking day; both catch rate and effort varied with time after stocking, site, and month.
- Measured: Angler catch per hour and effort
- Population/location: Western Virginia stocked waters
- Life stage: catchable stocked trout, pooled species
- Evidence type: field creel/thesis
- NOVA applicability: high for stocked Virginia waters but not species-specific
- Confidence: medium
- Source: S2 (page: 33-45; section: Chapter 2; abstract, results, discussion; table: Table 2-2; figure: Figure 2-3)
- Limitations: Rainbow, brown, and brook trout were not separated; effort, access, harvest, and site are confounders.
- Surrogate evidence: false
### E3. days since stocking - zero-weight
- Exact condition/range: Day after through 16-30 days after stocking on Virginia put-and-take waters.
- Observed effect: After the initial stocking-day peak, average catch rates stayed near 1 trout per angler-hour and were statistically similar across post-stocking intervals for up to a month.
- Measured: Catch per angler-hour
- Population/location: Western Virginia stocked waters
- Life stage: catchable stocked trout, pooled species
- Evidence type: field creel/thesis
- NOVA applicability: high for rejecting a simple decay rule; species transfer limited
- Confidence: medium
- Source: S2 (page: 44; section: Discussion; figure: Figure 2-3)
- Limitations: Does not prove no local depletion; species were pooled and stockings sometimes overlapped.
- Surrogate evidence: false
### E4. fish size and angler catchability - score
- Exact condition/range: Stocked rainbow trout >300 mm compared with fish <260 mm in one Adirondack river.
- Observed effect: Larger rainbow trout were caught at higher rates.
- Measured: Tag recoveries from anglers
- Population/location: West Branch Sacandaga River, New York
- Life stage: stocked subadult/adult
- Evidence type: field tagging and angler recovery
- NOVA applicability: moderate ecological similarity but not Mid-Atlantic
- Confidence: medium
- Source: S3 (section: Abstract)
- Limitations: Only two reported size groups; stocking, visibility, gear, and refuge use may contribute.
- Surrogate evidence: false
### E5. extreme heat, thermal refuge and catchability - context-only
- Exact condition/range: Summer water temperatures exceeded 20 C in a thermally marginal stocked river with cool refuges.
- Observed effect: High temperature did not reduce observed catch rates because fish concentrated in cool refuges; this was especially noted for brook trout.
- Measured: Angler recoveries and fish location
- Population/location: Adirondack river, New York
- Life stage: stocked trout
- Evidence type: field tagging and angler recovery
- NOVA applicability: contextual; warns against treating thermal stress as automatic low catchability
- Confidence: medium
- Source: S3 (section: Abstract)
- Limitations: Catch concentration is not increased feeding; exact refuge geometry and stocked status limit transfer.
- Surrogate evidence: false
### E6. dissolved oxygen and feed intake - score
- Exact condition/range: 42 days at 14 C; approximately 7.9 versus 4.5 mg O2/L; isogenic cultured rainbow trout fed ad libitum.
- Observed effect: Hypoxia reduced feed intake by about 6% and growth by about 8%.
- Measured: Voluntary feed intake and growth
- Population/location: Controlled aquaculture system
- Life stage: juvenile/cultured
- Evidence type: controlled experiment
- NOVA applicability: mechanistically relevant, but chronic aquaculture exposure is not a field bite curve
- Confidence: medium-high
- Source: S4 (section: Results and Discussion; figure: Figure 1)
- Limitations: One line, diet treatments, chronic exposure, and constant temperature; do not interpolate a universal oxygen curve.
- Surrogate evidence: false
### E7. dissolved oxygen and physiology - context-only
- Exact condition/range: Same 42-day 14 C comparison of 7.9 and 4.5 mg O2/L.
- Observed effect: Hypoxia reduced oxygen consumption and altered metabolic/osmoregulatory responses.
- Measured: Oxygen consumption and physiological endpoints
- Population/location: Controlled aquaculture system
- Life stage: juvenile/cultured
- Evidence type: controlled experiment
- NOVA applicability: context only
- Confidence: medium-high
- Source: S4 (section: Results and Discussion)
- Limitations: Physiology is not catchability and may overlap the feed-intake rule.
- Surrogate evidence: false
### E8. dissolved oxygen and maximal feed intake - context-only
- Exact condition/range: Normoxic versus reduced-oxygen cultured rainbow trout in a feeding trial.
- Observed effect: Lower oxygen reduced maximal voluntary feed intake, while utilization efficiency was not the primary limiting response.
- Measured: Maximum feed intake and nutrient utilization
- Population/location: Controlled aquaculture system
- Life stage: cultured rainbow trout
- Evidence type: controlled experiment, abstract-level
- NOVA applicability: mechanistic replication of oxygen-intake direction
- Confidence: medium
- Source: S5 (section: Abstract)
- Limitations: Abstract-level evidence; exact transfer to wild fish, acclimation state, and short exposures is unresolved.
- Surrogate evidence: false
### E9. turbidity and feeding rate - zero-weight
- Exact condition/range: Juveniles offered Daphnia and benthic prey at turbidity up to 160 NTU in laboratory tanks.
- Observed effect: Overall feeding rate was not reduced across the tested turbidity range.
- Measured: Number of prey consumed
- Population/location: Laboratory tanks, New Zealand
- Life stage: juvenile
- Evidence type: controlled experiment, abstract-level
- NOVA applicability: limited by life stage and artificial prey field
- Confidence: medium
- Source: S6 (section: Abstract)
- Limitations: Cannot establish adult angling response or conditions beyond 160 NTU.
- Surrogate evidence: false
### E10. turbidity, darkness and prey selection - context-only
- Exact condition/range: Turbidity up to 160 NTU; benthic chironomids and mayfly prey; total darkness included.
- Observed effect: Turbidity altered size selection for some prey, and chironomids were consumed in darkness.
- Measured: Prey-size selection and consumption
- Population/location: Laboratory tanks, New Zealand
- Life stage: juvenile
- Evidence type: controlled experiment, abstract-level
- NOVA applicability: mechanistic context only
- Confidence: medium
- Source: S6 (section: Abstract)
- Limitations: Prey-specific and juvenile; natural light and lure detection were not measured.
- Surrogate evidence: false
### E11. turbidity and visual attack process - context-only
- Exact condition/range: Wild rainbow trout 87-185 mm exposed to suspended sediment in artificial channels.
- Observed effect: Reactive distance and pursuit behavior changed with turbidity.
- Measured: Reactive distance and pursuit speed
- Population/location: Artificial stream channels
- Life stage: juvenile/subadult
- Evidence type: controlled behavioral experiment, abstract-level
- NOVA applicability: contextual mechanism, not consumption or angling
- Confidence: medium
- Source: S7 (section: Abstract)
- Limitations: A shorter reactive distance does not uniquely predict catch rate; prey density and encounter distance matter.
- Surrogate evidence: false
### E12. turbidity, temperature, prey availability and piscivory - context-only
- Exact condition/range: Colorado River field observations spanning broad suspended-sediment conditions.
- Observed effect: Piscivory varied with turbidity, temperature, and fish-prey availability; higher turbidity did not imply a simple feeding penalty.
- Measured: Piscivory index from diet observations
- Population/location: Colorado River, Grand Canyon
- Life stage: mostly adult piscivorous trout
- Evidence type: field observational study
- NOVA applicability: low-to-moderate transfer due ecosystem and diet differences
- Confidence: medium
- Source: S8 (section: Abstract)
- Limitations: Correlated covariates, extreme sediment regime, and piscivorous subset prevent a portable single-variable rule.
- Surrogate evidence: false
### E13. prey availability, hunger and prey size - context-only
- Exact condition/range: Controlled encounters varying hunger, prey density, and prey size.
- Observed effect: Attack and consumption depended on energetic state and prey field.
- Measured: Predation behavior and consumption
- Population/location: Controlled experiment
- Life stage: rainbow trout
- Evidence type: controlled experiment, abstract-level
- NOVA applicability: general mechanism only
- Confidence: medium
- Source: S9 (section: Abstract)
- Limitations: Does not yield a public environmental API threshold; prey abundance is rarely observed directly.
- Surrogate evidence: false
### E14. species, size and angling vulnerability - context-only
- Exact condition/range: Bait angling of sympatric salmonids in natural Japanese streams.
- Observed effect: Vulnerability and size selectivity differed among salmonid species.
- Measured: Hook-and-line captures by species and size
- Population/location: Japan
- Life stage: stream salmonids
- Evidence type: field angling experiment, abstract-level
- NOVA applicability: supports population/species context but limited geographic transfer
- Confidence: medium
- Source: S10 (section: Abstract)
- Limitations: Different fish community, fishing style, and population histories; exact ranking should not be generalized without local validation.
- Surrogate evidence: false
### E15. catch-and-release exposure - context-only
- Exact condition/range: Repeated catch-and-release angling in an experimental rainbow-trout fishery.
- Observed effect: Study evaluated growth and survival consequences rather than a short-term bite-probability function.
- Measured: Growth and survival after capture
- Population/location: Texas experimental pond
- Life stage: stocked rainbow trout
- Evidence type: field experiment, abstract-level
- NOVA applicability: Fish Guide and welfare context
- Confidence: medium
- Source: S11 (section: Abstract)
- Limitations: No direct same-day or next-day recapture rule was isolated for NOVA waters.
- Surrogate evidence: false

## Remaining research gaps
- Adult Mid-Atlantic field tests linking dissolved oxygen and temperature trend directly to feeding or standardized catchability.
- Species-separated Virginia stocking and catch-rate data.
- Local turbidity/light experiments with adult fish, natural prey and hook-and-line endpoints.
- Short-term rainbow-trout learning and hook-avoidance experiments.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained, exact values remain bounded to study conditions, and no final production multiplier or invented smooth curve is supplied.

## Complete bibliography
### S1. Stephen J. Reeser (2019)
**Virginia Wild Trout Management Plan 2019-2028**. Virginia Department of Game and Inland Fisheries.
https://dwr.virginia.gov/wp-content/uploads/media/Virginia-Wild-Trout-Management-Plan-2019-2028.pdf
Scope: Virginia. Access: original-agency-pdf-full-text. Verification: AI-reviewed-unverified.
### S2. Amanda A. Hyman (2015)
**The Virginia Stocked-Trout Program: An Evaluation of Anglers and Their Catch**. Virginia Polytechnic Institute and State University.
https://vtechworks.lib.vt.edu/bitstream/handle/10919/78333/Hyman_AA_T_2016.pdf
Scope: Fourteen put-and-take waters in western Virginia. Access: university-repository-pdf-full-text. Verification: AI-reviewed-unverified.
### S3. Owen E. Baird, Charles C. Krueger, and Daniel C. Josephson (2006)
**Growth, Movement, and Catch of Brook, Rainbow, and Brown Trout after Stocking into a Large, Marginally Suitable Adirondack River**. North American Journal of Fisheries Management 26(1):180-189. DOI: 10.1577/M04-183.1.
https://academic.oup.com/najfm/article/26/1/180/7847743
Scope: West Branch Sacandaga River, Adirondack Mountains, New York. Access: publisher-abstract-and-pdf-preview. Verification: AI-reviewed-unverified.
### S4. Leonardo J. Magnoni, Ep Eding, Isabelle Leguen, Patrick Prunet, Inge Geurden, Rodrigo O. A. Ozório, and Johan W. Schrama (2018)
**Hypoxia, but not an electrolyte-imbalanced diet, reduces feed intake, growth and oxygen consumption in rainbow trout (Oncorhynchus mykiss)**. Scientific Reports 8:4965. DOI: 10.1038/s41598-018-23352-z.
https://www.nature.com/articles/s41598-018-23352-z
Scope: Controlled aquaculture experiment, Europe. Access: publisher-open-full-text. Verification: AI-reviewed-unverified.
### S5. Brett D. Glencross (2009)
**Reduced water oxygen levels affect maximal feed intake, but not protein or energy utilization efficiency of rainbow trout (Oncorhynchus mykiss)**. Aquaculture Nutrition 15(1):1-8. DOI: 10.1111/j.1365-2095.2007.00562.x.
https://doi.org/10.1111/j.1365-2095.2007.00562.x
Scope: Controlled aquaculture experiment. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S6. David K. Rowe, T. L. Dean, E. Williams, and J. P. Smith (2003)
**Effects of turbidity on the ability of juvenile rainbow trout, Oncorhynchus mykiss, to feed on limnetic and benthic prey in laboratory tanks**. New Zealand Journal of Marine and Freshwater Research 37(1):45-52. DOI: 10.1080/00288330.2003.9517145.
https://doi.org/10.1080/00288330.2003.9517145
Scope: Laboratory tanks, New Zealand. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S7. Peter M. Barrett, Gary D. Grossman, and James Rosenfeld (1992)
**Turbidity-induced changes in reactive distance of rainbow trout**. Transactions of the American Fisheries Society 121(4):437-443. DOI: 10.1577/1548-8659(1992)121<0437:TICIRD>2.3.CO;2.
https://doi.org/10.1577/1548-8659(1992)121%3C0437:TICIRD%3E2.3.CO;2
Scope: Experimental stream channels. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S8. Michael D. Yard, Lewis G. Coggins Jr., Colden V. Baxter, Geoffrey E. Bennett, and Josh Korman (2011)
**Trout piscivory in the Colorado River, Grand Canyon: Effects of turbidity, temperature, and fish prey availability**. Transactions of the American Fisheries Society 140(2):471-486. DOI: 10.1080/00028487.2011.572011.
https://pubs.usgs.gov/publication/70033772
Scope: Colorado River, Grand Canyon, Arizona. Access: agency-bibliographic-record-and-abstract. Verification: AI-reviewed-unverified.
### S9. Daniel M. Ware (1972)
**Predation by Rainbow Trout (Salmo gairdneri): The Influence of Hunger, Prey Density, and Prey Size**. Journal of the Fisheries Research Board of Canada 29(8):1193-1201. DOI: 10.1139/f72-175.
https://doi.org/10.1139/f72-175
Scope: Controlled predation experiment. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S10. Jun-ichi Tsuboi, Kentaro Morita, Genki Sahashi, Mari Kuroki, S. Baba, and Robert Arlinghaus (2021)
**Species-specific vulnerability to angling and its size-selectivity in sympatric stream salmonids**. Canadian Journal of Fisheries and Aquatic Sciences 78(10):1470-1478. DOI: 10.1139/cjfas-2020-0428.
https://doi.org/10.1139/cjfas-2020-0428
Scope: Natural streams, Japan. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S11. Kevin L. Pope, Gene R. Wilde, and Dennis Knabe (2007)
**Effect of catch-and-release angling on growth and survival of rainbow trout, Oncorhynchus mykiss**. Fisheries Management and Ecology 14(2):115-120. DOI: 10.1111/j.1365-2400.2007.00531.x.
https://pubs.usgs.gov/publication/70029482
Scope: Experimental pond fishery, Texas. Access: agency-bibliographic-record-and-abstract. Verification: AI-reviewed-unverified.
