# BiteMap NOVA research resume packet

- Completed species before this batch: largemouth-bass, smallmouth-bass, channel-catfish, black-crappie, white-crappie, bluegill, redbreast-sunfish, pumpkinseed, green-sunfish, rock-bass.
- Completed in Batch 3: rainbow-trout, brown-trout, brook-trout.
- Pending species: blue-catfish, flathead-catfish, white-catfish, striped-bass, white-perch, yellow-perch, walleye, muskellunge, northern-snakehead, spotted-bass, common-carp, american-eel, fallfish, creek-chub, white-sucker, yellow-bullhead, brown-bullhead, northern-hogsucker, shorthead-redhorse, blacknose-dace, longnose-dace, mottled-sculpin, tessellated-darter, gizzard-shad.
- Next recommended batch: Batch 4 - blue catfish, flathead catfish, and white catfish.
- Schema version: 1.1.
- Verification status: AI-reviewed-unverified.
- Known corrections: Hyman accepted as 2015 from the original title page; Sweka and Hartman DOI accepted as 10.1139/f00-260; channel-catfish S13 must include James W. Avault Jr.
- Batch 3 outcome: all three trout remain Bite-scored, but only bounded oxygen/size, recent-pressure/extreme-sediment, and temperature-by-competitor/strain candidates survived.
- Unresolved questions: see validation-report.json and correction-and-conflict-log.json.
- Files a new chat should receive: the two baseline archives, Batch 1, Batch 2, BiteMap_batch-3_deep_verified_research_archive.zip, and the master prompt with ACTIVE BATCH changed to BATCH 4.
