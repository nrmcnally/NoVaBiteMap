# Brown Trout
*Salmo trutta*

- Species ID: `brown-trout`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Brown trout are a deliberate regional target and have direct pressure and extreme-sediment feeding evidence. They remain Bite-scored, but only narrow rules survive adversarial review.

### Model-ready findings
- **score**: Recent capture or close disturbance reduced brown-trout approachability and repeat vulnerability over following days in clear New Zealand backcountry rivers. Evidence: E5.
- **score**: Extreme suspended sediment of 450-600 mg/L reduced feeding by roughly 22-31% in a controlled experiment. Evidence: E8.

### Context-only findings
- Temperature controls feeding capacity jointly with body size and ration, but no portable field bite optimum was verified. Evidence: E10, E11.
- Southern Appalachian diel and seasonal movements are high-value location context, not evidence of feeding. Evidence: E12, E13.
- Winter feeding continued in a groundwater stream, rejecting a blanket winter feeding-cessation assumption. Evidence: E14.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- wind or ordinary rainfall as an independent direct multiplier
- cloud cover without measured underwater light
- moon phase or solunar tables
- growth optimum used as bite optimum
- movement used as feeding
- habitat occupancy used as catchability
- spawning movement used as feeding
- monthly curves derived from seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The pressure study used unusually clear, remote sight-fishing rivers and does not support a universal recovery duration.
- The sediment result applies to mg/L suspended solids at extreme levels, not ordinary stained water or NTU.
- Movement peaks, winter growth and laboratory energetic optima do not equal angling probability.

## Targetability assessment
Brown trout are a deliberate regional target and have direct pressure and extreme-sediment feeding evidence. They remain Bite-scored, but only narrow rules survive adversarial review.

## Candidate model rules
### R1. recentAnglingDisturbance - score
- Condition: Fish caught/released or closely disturbed during the previous several days in clear, sight-fished backcountry rivers
- Direction: decrease
- Strength: moderate
- Confidence: medium
- Mechanism: Learning, displacement and increased wariness reduce approachability and repeat vulnerability.
- Evidence: E5
- Double-counting risk: Do not assume a universal duration; avoid double counting effort, fish depletion, access and visibility.
### R2. suspendedSedimentMgL - score
- Condition: Approximately 450-600 mg/L in the Greer experimental design
- Direction: decrease
- Strength: moderate
- Confidence: medium
- Mechanism: Extreme suspended sediment interfered with prey acquisition even though respiration was not similarly reduced.
- Evidence: E8, E9
- Double-counting risk: Do not convert mg/L to NTU or extrapolate a smooth curve to ordinary stain.
### R3. daysSinceStocking - zero-weight
- Condition: 1-30 days after stocking in Virginia pooled put-and-take data
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: Catch stayed near the managerial target after the initial pulse.
- Evidence: E3
- Double-counting risk: Species were pooled; local stocking overlap and harvest remain confounders.
### R4. isStockingDay - context-only
- Condition: Actual stocking day
- Direction: increase in observed catch
- Strength: moderate
- Confidence: medium-low
- Mechanism: Immediate accessibility and concentrated fish.
- Evidence: E2
- Double-counting risk: May reflect access and effort rather than feeding; pooled species.
### R5. exploratoryPhenotype - context-only
- Condition: High exploratory behavior in hatchery-reared fish
- Direction: increase
- Strength: weak
- Confidence: medium-low
- Mechanism: Behavioral phenotype affected capture vulnerability.
- Evidence: E7
- Double-counting risk: Personality is usually unobserved and may be altered by stocking history.
### R6. waterTemperatureC - context-only
- Condition: Absolute temperature with body size and ration known
- Direction: nonlinear/interactive
- Strength: unknown
- Confidence: medium
- Mechanism: Feeding capacity is jointly controlled by temperature, body mass and ration.
- Evidence: E10, E11
- Double-counting risk: Do not convert a growth or lab feeding equation into catchability or double count season.
### R7. dielPeriod - zero-weight
- Condition: Sunrise, sunset or night based only on telemetry movement
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Seasonal movement timing was measured, not feeding or hook-and-line capture.
- Evidence: E12
- Double-counting risk: Do not equate movement with biting.
### R8. winterSeason - zero-weight
- Condition: Winter month alone
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: Field evidence shows continued winter feeding in a stable groundwater stream.
- Evidence: E14
- Double-counting risk: Does not imply high catchability; local temperature and prey remain important.
### R9. barometricPressureFrontsMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct species-specific evidence.
- Evidence: none
- Double-counting risk: Do not infer from movement or angler folklore.
### R10. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Telemetry, spawning and stocking schedules do not establish intrinsic monthly bite probability.
- Evidence: E1, E2, E13
- Double-counting risk: Avoid double counting temperature, access, regulations and effort.

## Evidence ledger
### E1. regional targetability and ecology - context-only
- Exact condition/range: Virginia wild brown-trout populations and major tailwater fisheries.
- Observed effect: Confirms intentional regional targeting and broad waterbody contexts.
- Measured: Distribution, management status and life history
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency synthesis
- NOVA applicability: high for targetability
- Confidence: high
- Source: S1 (page: 12; section: Brown Trout)
- Limitations: Not a feeding or catchability curve.
- Surrogate evidence: false
### E2. recent stocking and catchability - context-only
- Exact condition/range: Virginia put-and-take waters, pooled trout species.
- Observed effect: Catch was fastest on stocking day, with site, month and time since stocking affecting observed catch and effort.
- Measured: Catch per angler-hour and effort
- Population/location: Western Virginia
- Life stage: stocked catchable trout, pooled species
- Evidence type: field creel/thesis
- NOVA applicability: high regional relevance but species pooled
- Confidence: medium
- Source: S2 (page: 33-45; section: Chapter 2)
- Limitations: Access and effort can explain part of the pattern.
- Surrogate evidence: false
### E3. days since stocking - zero-weight
- Exact condition/range: Post-stocking intervals through 30 days, pooled trout species.
- Observed effect: Catch rates remained near 1 trout per angler-hour after the initial pulse rather than showing a simple monotonic collapse.
- Measured: Catch per angler-hour
- Population/location: Western Virginia
- Life stage: stocked catchable trout
- Evidence type: field creel/thesis
- NOVA applicability: high for rejecting a generic decay rule
- Confidence: medium
- Source: S2 (page: 44; section: Discussion; figure: Figure 2-3)
- Limitations: Pooled species and overlapping stockings.
- Surrogate evidence: false
### E4. species-specific catch and thermal refuge - context-only
- Exact condition/range: Stocked brook, rainbow and brown trout in a thermally marginal Adirondack river.
- Observed effect: Estimated angler catch differed strongly among species; brown trout had the lowest estimated fraction caught, and heat did not uniformly reduce catch where refuges concentrated fish.
- Measured: Angler recoveries
- Population/location: Adirondack river, New York
- Life stage: stocked trout
- Evidence type: field tagging
- NOVA applicability: context only
- Confidence: medium
- Source: S3 (section: Abstract)
- Limitations: Recovery fraction is not intrinsic catchability without equal abundance, survival and behavior.
- Surrogate evidence: false
### E5. recent angling pressure and disturbance - score
- Exact condition/range: Four 3-day trips in a lightly fished and a more regularly fished New Zealand backcountry river.
- Observed effect: After fish were caught/released or merely disturbed, trout were less likely to remain visible or readily approachable on following days; naive fish were more catchable.
- Measured: Sightings, behavioral responses and hook-and-line captures
- Population/location: Owen and Ugly rivers, New Zealand
- Life stage: adult wild brown trout
- Evidence type: field behavioral and angling study
- NOVA applicability: mechanistically strong but specialized fishery
- Confidence: medium-high
- Source: S4 (section: Results and Discussion)
- Limitations: Remote clear-water sight-fishing, low fish density and skilled anglers limit transfer; disturbance and actual hooking were partly combined.
- Surrogate evidence: false
### E6. presentation under angling pressure - context-only
- Exact condition/range: Previously fished trout in the New Zealand rivers.
- Observed effect: More pressured trout were more likely to require smaller or lower-profile flies and were more easily scared.
- Measured: Angler observations and captures
- Population/location: New Zealand backcountry rivers
- Life stage: adult wild
- Evidence type: field behavioral study
- NOVA applicability: Fish Guide relevance
- Confidence: medium
- Source: S4 (section: Results and Discussion)
- Limitations: Presentation finding is gear-specific and should not become an environmental score.
- Surrogate evidence: false
### E7. behavioral phenotype and angling vulnerability - context-only
- Exact condition/range: Hatchery-reared brown trout measured for exploratory behavior before angling.
- Observed effect: More explorative individuals were more vulnerable to capture.
- Measured: Individual behavior and hook-and-line capture
- Population/location: Finland
- Life stage: hatchery-reared juvenile/subadult
- Evidence type: controlled/field angling experiment, abstract-level
- NOVA applicability: population context, not an API weather input
- Confidence: medium
- Source: S5 (section: Abstract)
- Limitations: Hatchery origin and individual personality are rarely observed; selection can change populations.
- Surrogate evidence: false
### E8. suspended sediment and feeding - score
- Exact condition/range: 0, 150, 300, 450 and 600 mg/L suspended sediment after macrophyte-control disturbance.
- Observed effect: Feeding was reduced by about 22% at 450 mg/L and 31% at 600 mg/L relative to control.
- Measured: Prey consumption
- Population/location: Controlled experiment, New Zealand
- Life stage: brown trout
- Evidence type: controlled experiment, abstract-level
- NOVA applicability: supports only an extreme-sediment candidate
- Confidence: medium-high
- Source: S6 (section: Abstract)
- Limitations: Units are mg/L suspended sediment, not NTU; extreme pulse and experimental prey conditions limit transfer.
- Surrogate evidence: false
### E9. suspended sediment and respiration - context-only
- Exact condition/range: Up to 600 mg/L suspended sediment in the same experiment.
- Observed effect: Oxygen consumption did not show the same decline as feeding.
- Measured: Respiration/oxygen consumption
- Population/location: Controlled experiment, New Zealand
- Life stage: brown trout
- Evidence type: controlled experiment, abstract-level
- NOVA applicability: context only
- Confidence: medium
- Source: S6 (section: Abstract)
- Limitations: Physiological null result does not negate feeding reduction.
- Surrogate evidence: false
### E10. absolute temperature, body size and feeding capacity - context-only
- Exact condition/range: Brown trout 9-302 g tested from approximately 3.8 to 18.1 C.
- Observed effect: Maximum daily ration and feeding rate depended on temperature and body mass.
- Measured: Meal number, maximum food consumed and feeding rate
- Population/location: Controlled experiments, United Kingdom
- Life stage: juvenile to adult-size
- Evidence type: controlled feeding study, abstract-level
- NOVA applicability: useful calibration context but not a simple field optimum
- Confidence: medium
- Source: S7 (section: Abstract)
- Limitations: Equations, acclimation and ration design must be reviewed before implementation; no short-term trend or catchability endpoint.
- Surrogate evidence: false
### E11. temperature, ration, metabolism and growth - context-only
- Exact condition/range: Laboratory combinations of body weight, water temperature and ration.
- Observed effect: Energetic allocation changed jointly with temperature, body size and ration.
- Measured: Feeding, metabolism and growth
- Population/location: Controlled experiments, United Kingdom
- Life stage: multiple sizes
- Evidence type: controlled bioenergetics study
- NOVA applicability: context only
- Confidence: medium
- Source: S8 (section: Article summary)
- Limitations: Growth and metabolism are not hook-and-line catchability; exact equations were not fully verified in this run.
- Surrogate evidence: false
### E12. time of day and movement - context-only
- Exact condition/range: 22 radio-tagged trout, 268-446 mm, across 47 24-hour tracking periods in a southern Appalachian river.
- Observed effect: Most movement was short and pool-centered; timing varied by season, with sunrise, sunset and night movements depending on season.
- Measured: Movement distance and timing
- Population/location: Chattooga River watershed
- Life stage: adult wild
- Evidence type: field telemetry
- NOVA applicability: high geographic relevance, wrong endpoint for bite
- Confidence: medium-high
- Source: S9 (section: Abstract)
- Limitations: Movement is not feeding; detection and sample size limit hourly inference.
- Surrogate evidence: false
### E13. seasonal movement - context-only
- Exact condition/range: Telemetry in a southern Appalachian river.
- Observed effect: Seasonal movements and habitat shifts occurred, including spawning-related movement.
- Measured: Movement and habitat use
- Population/location: Chattooga River watershed
- Life stage: adult wild
- Evidence type: field telemetry, abstract-level
- NOVA applicability: high geographic relevance, context only
- Confidence: medium
- Source: S10 (section: Abstract)
- Limitations: Cannot become a monthly bite curve or flow effect without feeding/catch data.
- Surrogate evidence: false
### E14. winter feeding - zero-weight
- Exact condition/range: November-March in a groundwater-dominated Minnesota stream; fish size classes sampled.
- Observed effect: Brown trout continued feeding and smaller fish showed measurable winter growth.
- Measured: Diet, ration proxies, growth and condition
- Population/location: Minnesota
- Life stage: juvenile/subadult/adult
- Evidence type: field diet and mark-recapture study
- NOVA applicability: supports rejecting winter feeding cessation
- Confidence: medium-high
- Source: S11 (section: Abstract and Results)
- Limitations: Groundwater temperature stability and prey community differ from NOVA; feeding does not equal angler catch.
- Surrogate evidence: false
### E15. wild versus hatchery foraging - context-only
- Exact condition/range: Free-ranging wild and hatchery brown trout observed in a Pennsylvania stream.
- Observed effect: Foraging tactics and efficiency differed with origin and experience.
- Measured: Foraging behavior
- Population/location: Pennsylvania
- Life stage: wild and hatchery trout
- Evidence type: field behavioral study, abstract-level
- NOVA applicability: Mid-Atlantic contextual relevance
- Confidence: medium
- Source: S12 (section: Abstract)
- Limitations: Older study and site-specific prey drift; does not yield a single environment multiplier.
- Surrogate evidence: false

## Remaining research gaps
- Replication of recent-pressure effects in Mid-Atlantic stocked, tailwater and freestone fisheries.
- Adult field feeding/catchability data across ordinary turbidity and measured underwater light.
- Direct dissolved-oxygen feeding thresholds and temperature-rate-of-change studies.
- Species-separated Virginia stocked-trout creel data.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained, exact values remain bounded to study conditions, and no final production multiplier or invented smooth curve is supplied.

## Complete bibliography
### S1. Stephen J. Reeser (2019)
**Virginia Wild Trout Management Plan 2019-2028**. Virginia Department of Game and Inland Fisheries.
https://dwr.virginia.gov/wp-content/uploads/media/Virginia-Wild-Trout-Management-Plan-2019-2028.pdf
Scope: Virginia. Access: original-agency-pdf-full-text. Verification: AI-reviewed-unverified.
### S2. Amanda A. Hyman (2015)
**The Virginia Stocked-Trout Program: An Evaluation of Anglers and Their Catch**. Virginia Polytechnic Institute and State University.
https://vtechworks.lib.vt.edu/bitstream/handle/10919/78333/Hyman_AA_T_2016.pdf
Scope: Fourteen put-and-take waters in western Virginia. Access: university-repository-pdf-full-text. Verification: AI-reviewed-unverified.
### S3. Owen E. Baird, Charles C. Krueger, and Daniel C. Josephson (2006)
**Growth, Movement, and Catch of Brook, Rainbow, and Brown Trout after Stocking into a Large, Marginally Suitable Adirondack River**. North American Journal of Fisheries Management 26(1):180-189. DOI: 10.1577/M04-183.1.
https://academic.oup.com/najfm/article/26/1/180/7847743
Scope: West Branch Sacandaga River, Adirondack Mountains, New York. Access: publisher-abstract-and-pdf-preview. Verification: AI-reviewed-unverified.
### S4. Roger G. Young and John W. Hayes (2004)
**Angling Pressure and Trout Catchability: Behavioral Observations of Brown Trout in Two New Zealand Backcountry Rivers**. North American Journal of Fisheries Management 24(4):1203-1213. DOI: 10.1577/M03-177.1.
https://www.tandfonline.com/doi/full/10.1577/M03-177.1
Scope: Owen and Ugly rivers, New Zealand. Access: publisher-full-text. Verification: AI-reviewed-unverified.
### S5. Laura Härkönen, Pekka Hyvärinen, Jussi Paappanen, and Anssi Vainikka (2014)
**Explorative behavior increases vulnerability to angling in hatchery-reared brown trout (Salmo trutta)**. Canadian Journal of Fisheries and Aquatic Sciences 71(12):1900-1909. DOI: 10.1139/cjfas-2014-0221.
https://cdnsciencepub.com/doi/10.1139/cjfas-2014-0221
Scope: Finland, hatchery-reared brown trout. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S6. Melanie J. C. Greer, Simone K. Crow, Brendan J. Hicks, and Gerard P. Closs (2015)
**The effects of suspended sediment on brown trout (Salmo trutta) feeding and respiration after macrophyte control**. New Zealand Journal of Marine and Freshwater Research 49(2):278-285. DOI: 10.1080/00288330.2015.1013140.
https://doi.org/10.1080/00288330.2015.1013140
Scope: Controlled experiment, New Zealand. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S7. J. Malcolm Elliott (1975)
**The number of meals in a day, maximum weight of food consumed in a day and maximum rate of feeding for brown trout, Salmo trutta L.**. Freshwater Biology 5(3):287-303. DOI: 10.1111/j.1365-2427.1975.tb00142.x.
https://doi.org/10.1111/j.1365-2427.1975.tb00142.x
Scope: Controlled feeding experiments, United Kingdom. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S8. J. Malcolm Elliott (1976)
**The energetics of feeding, metabolism and growth of brown trout (Salmo trutta L.) in relation to body weight, water temperature and ration size**. Journal of Animal Ecology 45(3):923-948. DOI: 10.2307/3590.
https://doi.org/10.2307/3590
Scope: Controlled feeding experiments, United Kingdom. Access: bibliographic-record. Verification: AI-reviewed-unverified.
### S9. David B. Bunnell Jr., J. Jeffery Isely, Kyle H. Burrell, and David H. Van Lear (1998)
**Diel Movement of Brown Trout in a Southern Appalachian River**. Transactions of the American Fisheries Society 127(4):630-636. DOI: 10.1577/1548-8659(1998)127<0630:DMOBTI>2.0.CO;2.
https://pubs.usgs.gov/publication/70020805
Scope: Chattooga River watershed, Georgia-South Carolina. Access: agency-bibliographic-record-and-abstract. Verification: AI-reviewed-unverified.
### S10. Kyle H. Burrell, J. Jeffery Isely, David B. Bunnell Jr., David H. Van Lear, and C. Andrew Dolloff (2000)
**Seasonal Movement of Brown Trout in a Southern Appalachian River**. Transactions of the American Fisheries Society 129(6):1373-1379. DOI: 10.1577/1548-8659(2000)129<1373:SMOBTI>2.0.CO;2.
https://doi.org/10.1577/1548-8659(2000)129%3C1373:SMOBTI%3E2.0.CO;2
Scope: Chattooga River watershed, Georgia-South Carolina. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S11. William E. French, Bruce Vondracek, Leonard C. Ferrington Jr., Jacques C. Finlay, and Douglas J. Dieterman (2014)
**Winter feeding, growth and condition of brown trout Salmo trutta in a groundwater-dominated stream**. Journal of Freshwater Ecology 29(2):187-200. DOI: 10.1080/02705060.2013.847868.
https://doi.org/10.1080/02705060.2013.847868
Scope: Groundwater-dominated stream, Minnesota. Access: author-manuscript-full-text. Verification: AI-reviewed-unverified.
### S12. Roger A. Bachman (1984)
**Foraging behavior of free-ranging wild and hatchery brown trout in a stream**. Transactions of the American Fisheries Society 113(1):1-32. DOI: 10.1577/1548-8659(1984)113<1:FBOFWA>2.0.CO;2.
https://doi.org/10.1577/1548-8659(1984)113%3C1:FBOFWA%3E2.0.CO;2
Scope: Pennsylvania stream. Access: publisher-abstract. Verification: AI-reviewed-unverified.
