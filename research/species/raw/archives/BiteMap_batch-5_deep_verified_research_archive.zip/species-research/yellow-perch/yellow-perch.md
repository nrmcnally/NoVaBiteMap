# Yellow Perch
*Perca flavescens*

- Species ID: `yellow-perch`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Yellow perch are an intentional recreational target and have direct feeding evidence. Bite-scored status is defensible, but only a bounded summer diel candidate survives; oxygen, turbidity and weather require context-specific handling.

### Model-ready findings
- **score**: In two summer 24-hour field cycles, stomach fullness rose through daylight, peaked in late evening, and feeding nearly ceased after sunset. Evidence: E2.

### Context-only findings
- Age-0 visual foraging declined more under phytoplankton turbidity than sediment turbidity, and higher prey density did not fully compensate; adult transfer is unverified. Evidence: E4, E5, E6.
- Juvenile feeding at about 15 C was not reduced by approximately 4 or 2.5 mg/L oxygen in one study, while Lake Erie work shows context-dependent hypoxic forays and prey compression. Evidence: E7, E8, E9, E10.
- A small direct experiment found no barometric-pressure effect on consumption, supporting zero weight rather than folklore. Evidence: E12.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- moon phase or solunar tables
- wind or ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The direct diel study covered only two summer days in an Alberta lake.
- Turbidity experiments used larvae and juveniles, not adult hook-and-line targets.
- Moderate-hypoxia findings conflict across temperature, duration and field prey distributions.
- The barometric-pressure null study was small and does not prove universal invariance.

## Targetability assessment
Yellow perch are an intentional recreational target and have direct feeding evidence. Bite-scored status is defensible, but only a bounded summer diel candidate survives; oxygen, turbidity and weather require context-specific handling.

## Candidate model rules
### R1. timeOfDay - score
- Condition: Summer daylight through late evening in a clear/northern lake; after-sunset period
- Direction: feeding rises through day, peaks late evening, then declines after sunset
- Strength: bounded low-medium
- Confidence: medium
- Mechanism: Direct stomach-fullness chronology linked feeding to daylight and late evening.
- Evidence: E2
- Double-counting risk: Do not turn into a universal clock; season, latitude, water clarity, prey and temperature must be measured.
### R2. movementOrLittoralOccupancy - context-only
- Condition: Littoral movement during feeding periods
- Direction: context only
- Strength: unknown
- Confidence: medium
- Mechanism: Movement correlated with foraging but is not independently causal.
- Evidence: E3
- Double-counting risk: Do not double count time of day, habitat and prey.
### R3. turbidityType - context-only
- Condition: Age-0 phytoplankton versus sediment turbidity across <5-100 NTU
- Direction: phytoplankton turbidity can reduce consumption more than sediment
- Strength: unquantified
- Confidence: medium-high
- Mechanism: Algal particles/light attenuation altered visual foraging functional response.
- Evidence: E4, E5
- Double-counting risk: Life-stage limitation; never use a generic NTU penalty without turbidity type and adult validation.
### R4. preyDensity - context-only
- Condition: Age-0 zooplankton density
- Direction: higher prey increases consumption but does not erase algal-turbidity cost
- Strength: unquantified
- Confidence: medium
- Mechanism: Functional response to prey abundance.
- Evidence: E4, E6
- Double-counting risk: Requires actual forage data and adult validation.
### R5. dissolvedOxygenMgL - zero-weight
- Condition: ~2.5-4 mg/L for up to 10 days near 15 C in juveniles
- Direction: no measured feeding penalty in tested experiment
- Strength: zero within narrow condition
- Confidence: high
- Mechanism: Moderate cool-water hypoxia did not change consumption in two hatchery populations.
- Evidence: E7
- Double-counting risk: Do not extrapolate to warm water, longer exposures, adults or lower oxygen.
### R6. oxygenXtemperaturePrey - context-only
- Condition: Warm-season stratified lakes with hypolimnetic hypoxia
- Direction: context-dependent
- Strength: unknown
- Confidence: medium
- Mechanism: Hypoxia changes prey overlap and can induce short foraging forays.
- Evidence: E8, E9, E10
- Double-counting risk: Avoid double counting oxygen, temperature, depth and prey concentration.
### R7. photoperiodOrCloudCover - zero-weight
- Condition: Artificial 8/16 h photoperiod or ordinary cloud categories
- Direction: none as bite rule
- Strength: zero
- Confidence: high
- Mechanism: Growth and age-0 sensory studies do not establish adult catchability.
- Evidence: E11, E13
- Double-counting risk: Photoperiod, instantaneous underwater light and diel period are different inputs.
### R8. barometricPressureTrend - zero-weight
- Condition: Rising, falling or steady across tested trials
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: Direct small experiment found no significant consumption effect.
- Evidence: E12
- Double-counting risk: Limited power means absence of evidence outside tested range, not proof of universal no effect.
### R9. spawningStage - context-only
- Condition: Spring migration/spawn
- Direction: unknown
- Strength: unknown
- Confidence: low
- Mechanism: Seasonal concentration and reproduction alter location.
- Evidence: E1
- Double-counting risk: Do not infer feeding or aggression without direct measurements.
### R10. recentAnglingPressure - unavailable
- Condition: Any duration
- Direction: none
- Strength: unavailable
- Confidence: high
- Mechanism: No qualifying hook-learning experiment was verified.
- Evidence: E1
- Double-counting risk: Do not infer from fishing effort or harvest.
### R11. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Diel and diet studies do not create monthly catchability curves.
- Evidence: E2, E15
- Double-counting risk: Avoid double counting temperature, spawn, prey, access and effort.

## Evidence ledger
### E1. regional recreational targetability - context-only
- Exact condition/range: Virginia DWR documents native/established populations and angling value.
- Observed effect: Confirms intentional targetability in Virginia.
- Measured: Fishery status
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency account
- NOVA applicability: high for targetability
- Confidence: high
- Source: S1 (section: Species account)
- Limitations: No score thresholds.
- Surrogate evidence: false
### E2. time of day - score
- Exact condition/range: Fish sampled every three hours over two summer 24-hour periods.
- Observed effect: Stomach fullness increased through daylight, peaked in late evening, and feeding nearly ceased after sunset.
- Measured: Stomach fullness, consumption and movement
- Population/location: Baptiste Lake, Alberta
- Life stage: wild multiple sizes
- Evidence type: field diel feeding study
- NOVA applicability: direct endpoint but low geographic/seasonal replication
- Confidence: medium-high
- Source: S2 (page: 287-303; section: Results; figure: diel plots)
- Limitations: Only two summer 24-hour periods in a northern lake; light, prey and temperature covaried.
- Surrogate evidence: false
### E3. movement versus feeding - context-only
- Exact condition/range: Same diel study.
- Observed effect: Littoral movements correlated with foraging periods.
- Measured: Movement and feeding chronology
- Population/location: Baptiste Lake, Alberta
- Life stage: wild multiple sizes
- Evidence type: field observation
- NOVA applicability: useful as a linkage but not standalone movement rule
- Confidence: medium
- Source: S2 (page: 287-303; section: Results and Discussion)
- Limitations: Correlation does not justify scoring movement or habitat occupancy independently.
- Surrogate evidence: false
### E4. turbidity type and prey density - context-only
- Exact condition/range: Age-0 larvae/juveniles; turbidity <5, 20, 50 and 100 NTU; sediment versus phytoplankton; multiple prey densities.
- Observed effect: Consumption increased with prey density, but the consumption-prey slope was lower in phytoplankton than sediment turbidity; high prey density did not fully compensate.
- Measured: Zooplankton consumed
- Population/location: laboratory; Lake Erie stock
- Life stage: larvae and juveniles
- Evidence type: controlled factorial feeding experiment
- NOVA applicability: mechanistically strong but early-life only
- Confidence: high
- Source: S3 (page: 11-18, 24-32; section: Results and Discussion; table: Table 1; figure: Figures 3-8)
- Limitations: Cannot transfer directly to adult hook-and-line fishing; turbidity type matters more than a generic NTU value.
- Surrogate evidence: false
### E5. phytoplankton turbidity - context-only
- Exact condition/range: Across <5-100 NTU treatments.
- Observed effect: Age-0 consumption was lower at higher phytoplankton turbidity, whereas sediment turbidity effects were inconsistent or weaker.
- Measured: Prey consumption
- Population/location: laboratory
- Life stage: age-0
- Evidence type: controlled experiment
- NOVA applicability: early-life context only
- Confidence: high
- Source: S3 (page: 15-18; section: Discussion; figure: Figures 3-6)
- Limitations: No adult data; algal and sediment turbidity are not interchangeable.
- Surrogate evidence: false
### E6. prey availability - context-only
- Exact condition/range: Multiple zooplankton densities crossed with turbidity.
- Observed effect: Consumption rose with prey density in all conditions, but prey abundance did not eliminate phytoplankton-turbidity impairment.
- Measured: Functional response
- Population/location: laboratory
- Life stage: age-0
- Evidence type: controlled experiment
- NOVA applicability: context
- Confidence: high
- Source: S4 (page: 1729-1741; section: Abstract/Results)
- Limitations: Prey density cannot be observed reliably without a forage data source; adult transfer uncertain.
- Surrogate evidence: false
### E7. moderate hypoxia - zero-weight
- Exact condition/range: About 15 C; control >5 mg/L, moderate ~4.0 mg/L, low ~2.5 mg/L for acute/chronic trials up to 10 days; two hatchery populations.
- Observed effect: No marked/significant differences in feeding rate, movement, growth or several physiological measures among treatments.
- Measured: Food consumption, movement, growth and physiology
- Population/location: laboratory
- Life stage: juvenile
- Evidence type: controlled experiment
- NOVA applicability: valuable null within tested cool conditions
- Confidence: high
- Source: S5 (page: 47-55; section: Results and Discussion; figure: behavior/physiology figures)
- Limitations: Occasional lower excursions and cool temperature; does not prove safety or no effect at warmer temperatures.
- Surrogate evidence: false
### E8. temperature and oxygen interaction - context-only
- Exact condition/range: Comparison with prior work at warmer temperatures and Lake Erie field conditions.
- Observed effect: Published evidence is condition-dependent: moderate hypoxia at ~15 C was neutral in one experiment, while warmer/severe conditions and field habitat compression affected foraging.
- Measured: Feeding, distribution and habitat
- Population/location: laboratory and Lake Erie
- Life stage: juvenile/adult
- Evidence type: cross-study contradiction
- NOVA applicability: contextual
- Confidence: medium-high
- Source: S5 (page: 52-54; section: Discussion)
- Limitations: Cannot construct one monotonic oxygen curve without temperature and exposure duration.
- Surrogate evidence: false
### E9. hypolimnetic hypoxia and prey distribution - context-only
- Exact condition/range: Lake Erie vertical profiles, prey and yellow-perch distributions.
- Observed effect: Hypoxia altered spatial overlap and foraging habitat; fish could exploit prey near or within low-oxygen layers.
- Measured: Distribution, prey overlap and modeled foraging
- Population/location: Lake Erie
- Life stage: wild juvenile/adult
- Evidence type: field/model study
- NOVA applicability: context only
- Confidence: medium-high
- Source: S6 (page: S132-S142; section: Results and Discussion; figure: vertical distribution figures)
- Limitations: Habitat compression and prey concentration can offset or reverse simple oxygen effects; not direct hook catchability.
- Surrogate evidence: false
### E10. hypoxic foraging forays - context-only
- Exact condition/range: Field evidence of temporary excursions into hypoxic water.
- Observed effect: Yellow perch made hypoxic forays potentially to access prey, showing that occupancy below a threshold does not equal feeding cessation.
- Measured: Telemetry/distribution and prey-consumption inference
- Population/location: Lake Erie
- Life stage: wild
- Evidence type: field study
- NOVA applicability: important contradiction
- Confidence: medium
- Source: S7 (page: 922-937; section: Abstract and Results)
- Limitations: Foray behavior is not a general bite bonus and may incur physiological costs.
- Surrogate evidence: false
### E11. photoperiod and temperature - zero-weight
- Exact condition/range: Age-0 fish for 14 weeks at 16 versus 22 C and 8 versus 16-hour photoperiod.
- Observed effect: Yellow-perch growth was influenced by photoperiod; best growth occurred at 22 C and 16 h light.
- Measured: Growth on formulated feed
- Population/location: laboratory
- Life stage: age-0
- Evidence type: controlled growth study
- NOVA applicability: wrong endpoint
- Confidence: medium-high
- Source: S8 (page: 254-258; section: Results)
- Limitations: Growth is not feeding activity or catchability; artificial photoperiod and formulated feed.
- Surrogate evidence: false
### E12. barometric pressure - zero-weight
- Exact condition/range: 12 laboratory trials: five rising, five falling and two steady; fish 75-125 mm; 16-20 C; DO 4.00-8.69 mg/L.
- Observed effect: Barometric pressure category was not significantly related to food consumption (overall P=.55; falling P=.98; rising P=.63).
- Measured: Prey consumed
- Population/location: laboratory fish from Lake Bemidji
- Life stage: juvenile/small
- Evidence type: small controlled observational experiment
- NOVA applicability: direct null; limited power
- Confidence: medium
- Source: S9 (page: 1-8; section: Results; table: statistical table; figure: pressure/consumption figures)
- Limitations: Small undergraduate study, only 12 trials, acclimation/time trend and narrow sizes.
- Surrogate evidence: false
### E13. underwater light and prey detection - context-only
- Exact condition/range: Age-0 fish tested across controlled light intensities.
- Observed effect: Prey detection and foraging mechanism changed with light intensity.
- Measured: Reaction distance and prey capture
- Population/location: laboratory
- Life stage: age-0
- Evidence type: controlled sensory study
- NOVA applicability: early-life context only
- Confidence: medium-high
- Source: S10 (page: 195-205; section: Abstract and Results)
- Limitations: Does not establish an adult cloud/night catchability curve.
- Surrogate evidence: false
### E14. twilight activity - context-only
- Exact condition/range: Field observations around twilight.
- Observed effect: Activity and habitat use changed during twilight.
- Measured: Behavior and activity
- Population/location: freshwater lake
- Life stage: multiple
- Evidence type: field behavior study
- NOVA applicability: context only
- Confidence: medium
- Source: S11 (page: 173-179; section: Abstract/Results)
- Limitations: Activity is not necessarily feeding; different system and historical methods.
- Surrogate evidence: false
### E15. seasonal diet and prey - context-only
- Exact condition/range: Lake Erie stomach contents across years, seasons, basins and depths.
- Observed effect: Yellow perch used more benthic invertebrates and fish than white perch, with spatial/seasonal variation.
- Measured: Diet composition
- Population/location: Lake Erie
- Life stage: multiple
- Evidence type: field diet study
- NOVA applicability: Fish Guide context
- Confidence: medium
- Source: S12 (page: 29-35; section: Abstract)
- Limitations: Diet composition and invasive interactions do not yield a catchability curve.
- Surrogate evidence: false

## Remaining research gaps
- Replicated adult Mid-Atlantic diel feeding and standardized angling studies across seasons and clarity.
- Adult turbidity experiments that distinguish sediment from phytoplankton and measure underwater light.
- Warm-water oxygen-feeding experiments with exposure duration and prey fields.
- Tidal-stage, flow-change and angling-pressure studies for Chesapeake populations.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2025)
**Yellow Perch**. Virginia DWR.
https://dwr.virginia.gov/wildlife/information/yellow-perch/
Scope: Virginia. Access: agency HTML. Verification: AI-reviewed-unverified.
### S2. Wolfgang A. Jansen; William C. Mackay (1992)
**Foraging in yellow perch, Perca flavescens: biological and physical factors affecting diel periodicity in feeding, consumption, and movement**. Environmental Biology of Fishes 34:287-303. DOI: 10.1007/BF00004776.
https://doi.org/10.1007/BF00004776
Scope: Baptiste Lake, Alberta. Access: publisher abstract/full record. Verification: AI-reviewed-unverified.
### S3. Colleen G. Wellington (2008)
**Effects of turbidity and prey density on the foraging success of age-0 yellow perch (Perca flavescens)**. University of Toledo M.S. thesis.
https://etd.ohiolink.edu/acprod/odb_etd/ws/send_file/send?accession=toledo1216751590&disposition=inline
Scope: laboratory; western Lake Erie context. Access: university repository full PDF. Verification: AI-reviewed-unverified.
### S4. Colleen G. Wellington; Christine M. Mayer; Jonathan M. Bossenbroek; Nathan A. Stroh (2010)
**Effects of turbidity and prey density on the foraging success of age 0 year yellow perch Perca flavescens**. Journal of Fish Biology 76:1729-1741. DOI: 10.1111/j.1095-8649.2010.02612.x.
https://doi.org/10.1111/j.1095-8649.2010.02612.x
Scope: laboratory; Lake Erie stock. Access: publisher abstract plus thesis full text. Verification: AI-reviewed-unverified.
### S5. L. Zoe Almeida; Samuel C. Guffey; Maria S. Sepúlveda; Tomas O. Höök (2017)
**Behavioral and physiological responses of yellow perch (Perca flavescens) to moderate hypoxia**. Comparative Biochemistry and Physiology Part A 209:47-55. DOI: 10.1016/j.cbpa.2017.04.009.
https://doi.org/10.1016/j.cbpa.2017.04.009
Scope: laboratory hatchery populations from Lake Erie and North Carolina. Access: author/repository full PDF. Verification: AI-reviewed-unverified.
### S6. James J. Roberts; Tomas O. Höök; Stuart A. Ludsin; Steven A. Pothoven; Henry A. Vanderploeg; Stephen B. Brandt (2009)
**Effects of hypolimnetic hypoxia on foraging and distributions of Lake Erie yellow perch**. Journal of Experimental Marine Biology and Ecology 381 Supplement:S132-S142. DOI: 10.1016/j.jembe.2009.07.017.
https://doi.org/10.1016/j.jembe.2009.07.017
Scope: Lake Erie. Access: publisher/author full text. Verification: AI-reviewed-unverified.
### S7. James J. Roberts; Tomas O. Höök; Stuart A. Ludsin; Steven A. Pothoven; Henry A. Vanderploeg; Stephen B. Brandt (2012)
**Evidence of hypoxic foraging forays by yellow perch (Perca flavescens) and potential consequences for prey consumption**. Freshwater Biology 57:922-937. DOI: 10.1111/j.1365-2427.2012.02753.x.
https://doi.org/10.1111/j.1365-2427.2012.02753.x
Scope: Lake Erie. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S8. H. T. Huh; H. E. Calbert; D. A. Stuiber (1976)
**Effects of Temperature and Light on Growth of Yellow Perch and Walleye Using Formulated Feed**. Transactions of the American Fisheries Society 105(2):254-258. DOI: 10.1577/1548-8659(1976)105%3C254:EOTALO%3E2.0.CO;2.
https://doi.org/10.1577/1548-8659(1976)105%3C254:EOTALO%3E2.0.CO;2
Scope: laboratory. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S9. Daniel VanderWeyst (2014)
**The Effect of Barometric Pressure on Feeding Activity of Yellow Perch**. Journal of Earth and Life Science, Bemidji State University.
https://www.bemidjistate.edu/academics/departments/biology/media/2014/02/VanderWeyst_2014.pdf
Scope: Lake Bemidji fish; laboratory. Access: institutional full PDF. Verification: AI-reviewed-unverified.
### S10. H. E. Richmond; T. R. Hrabik; A. F. Mensinger (2004)
**Light intensity, prey detection and foraging mechanisms of age-0-year yellow perch**. Journal of Fish Biology 65:195-205. DOI: 10.1111/j.0022-1112.2004.00444.x.
https://doi.org/10.1111/j.0022-1112.2004.00444.x
Scope: laboratory. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S11. Gene S. Helfman (1979)
**Twilight activities of yellow perch, Perca flavescens**. Journal of the Fisheries Research Board of Canada 36:173-179. DOI: 10.1139/f79-027.
https://doi.org/10.1139/f79-027
Scope: freshwater lake. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S12. Donna L. Parrish; F. Joseph Margraf (1994)
**Spatial and Temporal Patterns of Food Use by White Perch and Yellow Perch in Lake Erie**. Journal of Freshwater Ecology 9(1):29-35. DOI: 10.1080/02705060.1994.9664424.
https://doi.org/10.1080/02705060.1994.9664424
Scope: Lake Erie. Access: publisher abstract. Verification: AI-reviewed-unverified.
