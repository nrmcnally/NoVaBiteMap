# White Perch
*Morone americana*

- Species ID: `white-perch`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Proposed for bite scoring**

## Executive conclusion
White perch are widely and intentionally targeted in Chesapeake tributaries, including the Northern Virginia/DC region. However, no adult environmental feeding or standardized hook-and-line rule survived, so the species is proposed for bite scoring pending direct evidence.

### Model-ready findings
- No score-ready environmental or biological candidate survived adversarial review.

### Context-only findings
- Chesapeake early-life food experiments, Wicomico thermal preference and gastric evacuation establish physiology and digestion context, not adult bite optima. Evidence: E2, E3, E4.
- Patuxent partial migration and York River telemetry support salinity, tide and site-fidelity location context. Evidence: E7, E8, E12.
- Lake Erie diet/consumption studies show prey and population dependence but transfer poorly to native Chesapeake populations. Evidence: E5, E6.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- moon phase or solunar tables
- wind or ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The final temperature preferendum near 29-31 C is not a feeding optimum.
- Gastric evacuation is not food intake or catchability.
- Diel and tidal telemetry measured movement rather than feeding.
- Most direct feeding work is larval or from invasive Lake Erie populations.

## Targetability assessment
White perch are widely and intentionally targeted in Chesapeake tributaries, including the Northern Virginia/DC region. However, no adult environmental feeding or standardized hook-and-line rule survived, so the species is proposed for bite scoring pending direct evidence.

## Candidate model rules
### R1. absoluteWaterTemperature - zero-weight
- Condition: 28.9-30.6 C laboratory final preferendum from August Wicomico fish
- Direction: none as bite rule
- Strength: zero
- Confidence: high
- Mechanism: Temperature preference is not feeding or hook vulnerability.
- Evidence: E3
- Double-counting risk: Do not turn a preferendum into an optimum; acclimation and season matter.
### R2. temperatureDependentDigestion - context-only
- Condition: Gastric evacuation equation from Lake Erie lab/field data
- Direction: faster digestion at warmer temperatures
- Strength: unquantified context
- Confidence: medium
- Mechanism: Temperature changes evacuation and potential meal turnover.
- Evidence: E4
- Double-counting risk: Do not equate evacuation with hunger, feeding rate or catchability.
### R3. preyAvailability - context-only
- Condition: Low versus high larval food and seasonal/basin prey differences
- Direction: prey limitation changes early growth and observed diets
- Strength: unknown
- Confidence: medium
- Mechanism: Food availability shapes growth and diet.
- Evidence: E2, E5, E6
- Double-counting risk: Early-life/growth endpoints and invasive Lake Erie populations limit transfer.
### R4. tidalStage - context-only
- Condition: Summer York River tributaries
- Direction: location/movement context only
- Strength: unknown
- Confidence: medium
- Mechanism: Tide alters movement within small home ranges.
- Evidence: E8
- Double-counting risk: Do not translate telemetry movement into feeding.
### R5. dielPeriod - zero-weight
- Condition: Day versus night movement
- Direction: none as bite rule
- Strength: zero
- Confidence: high
- Mechanism: Telemetry measured activity, not feeding or hook vulnerability.
- Evidence: E9
- Double-counting risk: Avoid a generic night bonus.
### R6. salinityOrMigrationContingent - context-only
- Condition: Freshwater, brackish and migratory/resident contingents
- Direction: location and population context only
- Strength: unknown
- Confidence: medium
- Mechanism: Life-history contingent and salinity affect growth/metabolism and occupancy.
- Evidence: E7, E10, E12
- Double-counting risk: Do not double count salinity, migration and season.
### R7. spawningStage - context-only
- Condition: Spring migration and adult fecundity
- Direction: unknown
- Strength: unknown
- Confidence: low
- Mechanism: Spawning changes concentration and reproductive state.
- Evidence: E11, E12
- Double-counting risk: Catch concentration can reflect access/effort, not feeding.
### R8. dissolvedOxygenTurbidityLight - unavailable
- Condition: Any adult field category
- Direction: none
- Strength: unavailable
- Confidence: high
- Mechanism: No qualifying direct feeding/catchability study.
- Evidence: E13
- Double-counting risk: Do not transfer related-species evidence.
### R9. recentAnglingPressure - unavailable
- Condition: Any duration
- Direction: none
- Strength: unavailable
- Confidence: high
- Mechanism: No hook-learning experiment.
- Evidence: E14
- Double-counting risk: Do not infer from commercial selection or abundance.
### R10. barometricPressureFrontsMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct evidence.
- Evidence: E15
- Double-counting risk: Reject folklore.
### R11. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Migration and fishing seasons do not establish intrinsic catchability.
- Evidence: E5, E8, E12
- Double-counting risk: Avoid double counting tide, spawn, temperature, access and effort.

## Evidence ledger
### E1. regional recreational targetability - context-only
- Exact condition/range: Virginia DWR identifies native and introduced populations and popularity among anglers.
- Observed effect: Confirms intentional regional targeting.
- Measured: Fishery status
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency species account
- NOVA applicability: high for targetability
- Confidence: high
- Source: S1 (section: Distribution and species account)
- Limitations: No direct bite predictors.
- Surrogate evidence: false
### E2. food concentration and temperature - context-only
- Exact condition/range: Eggs/larvae at 13, 17 and 21 C; 50 versus 800 rotifers/L and delayed high-food treatments.
- Observed effect: As little as two days of low food reduced growth/survival; delays of 4-8 days sharply reduced survival at 17 and 21 C; 13 C growth was slow regardless of food.
- Measured: Larval development, growth and survival
- Population/location: laboratory; Potomac/Patuxent broodstock
- Life stage: eggs and larvae
- Evidence type: controlled experiment
- NOVA applicability: regional origin but early-life endpoint
- Confidence: high
- Source: S2 (page: 63-72; section: Abstract, Results and Discussion; table: survival/growth tables; figure: growth figures)
- Limitations: Growth and survival are not adult feeding rate or hook-and-line catchability.
- Surrogate evidence: false
### E3. thermal preference - zero-weight
- Exact condition/range: Freshwater fish collected at 27 C; acclimation at 6, 12, 18, 24, 30 and 33 C.
- Observed effect: Final preference estimates were 28.9, 29.3 and 30.6 C by three analytical methods.
- Measured: Voluntary temperature selection
- Population/location: Wicomico River, Maryland
- Life stage: unspecified subadult/adult
- Evidence type: laboratory shuttle/preference test
- NOVA applicability: high geographic relevance but wrong endpoint
- Confidence: high
- Source: S3 (page: 129-132; section: Abstract and Results)
- Limitations: Thermal preference is not feeding optimum or catchability; August collection and acclimation matter.
- Surrogate evidence: false
### E4. temperature and digestion - context-only
- Exact condition/range: Laboratory and field gastric evacuation modeled as R = 0.028 e^(0.106T).
- Observed effect: Evacuation increased with temperature in the fitted data.
- Measured: Gastric evacuation rate
- Population/location: Lake Erie/laboratory
- Life stage: multiple
- Evidence type: laboratory and field digestion study
- NOVA applicability: mechanistic context only
- Confidence: medium-high
- Source: S4 (section: Abstract)
- Limitations: Digestion is not intake, attack rate or angler catchability; formula portability to Chesapeake prey and sizes is unknown.
- Surrogate evidence: false
### E5. season, depth and basin diet - context-only
- Exact condition/range: 1983-1985 stomach data compared seasons, western/central basins and western-basin depth.
- Observed effect: White- and yellow-perch diets varied spatially and temporally; white perch tended to use more zooplankton.
- Measured: Stomach contents
- Population/location: Lake Erie
- Life stage: multiple
- Evidence type: field diet study
- NOVA applicability: low-medium regional transfer
- Confidence: medium
- Source: S5 (section: Abstract)
- Limitations: Invasive Great Lakes population and diet composition only.
- Surrogate evidence: false
### E6. interspecific competition and food consumption - context-only
- Exact condition/range: White and yellow perch compared across Lake Erie basins.
- Observed effect: White-perch consumption estimates were reported as higher in some comparisons and differed by basin.
- Measured: Modeled food consumption and growth
- Population/location: Lake Erie
- Life stage: multiple
- Evidence type: field bioenergetics/feeding study
- NOVA applicability: contextual, low geographic transfer
- Confidence: medium
- Source: S6 (section: Abstract)
- Limitations: Consumption estimates integrate prey and temperature; does not create a NOVA coefficient.
- Surrogate evidence: false
### E7. salinity and partial migration - context-only
- Exact condition/range: Juveniles from Patuxent River contingents evaluated for growth/metabolic trajectories and salinity response.
- Observed effect: Resident and migratory contingents differed in bioenergetic trajectories; salinity and life-history strategy were intertwined.
- Measured: Growth and metabolism
- Population/location: Patuxent River, Maryland
- Life stage: juvenile
- Evidence type: controlled/common-garden and field-linked study
- NOVA applicability: high Chesapeake context
- Confidence: medium-high
- Source: S7 (page: 602-612; section: Abstract and Methods/Results)
- Limitations: Growth/metabolic trajectory does not measure feeding or catchability; contingent identity may confound salinity.
- Surrogate evidence: false
### E8. tidal stage and site fidelity - context-only
- Exact condition/range: Summer acoustic tracking in Queen Creek and Poropotank River tributaries.
- Observed effect: Most fish showed small home ranges/site fidelity and tidal movements; sudden storm-related salinity/temperature changes did not produce clear movement.
- Measured: Movement/home range
- Population/location: York River, Virginia
- Life stage: adult/subadult
- Evidence type: telemetry
- NOVA applicability: high location context
- Confidence: medium-high
- Source: S8 (page: 966-974; section: Abstract and Results)
- Limitations: Movement is not feeding; only summer and two tributaries.
- Surrogate evidence: false
### E9. time of day - zero-weight
- Exact condition/range: Acoustic telemetry across diel periods.
- Observed effect: Diel movement/behavior differed between day and night.
- Measured: Movement activity
- Population/location: New York estuary
- Life stage: adult/subadult
- Evidence type: telemetry
- NOVA applicability: context only
- Confidence: medium
- Source: S9 (page: 1330-1340; section: Abstract and Results)
- Limitations: No feeding or hook-and-line endpoint; different estuary.
- Surrogate evidence: false
### E10. salinity and habitat occupancy - context-only
- Exact condition/range: Management synthesis describes occurrence from fresh to marine salinities and preference for lower salinity.
- Observed effect: Supports broad habitat distribution and fishery context.
- Measured: Occurrence and fishery status
- Population/location: Atlantic coast/Chesapeake
- Life stage: multiple
- Evidence type: management synthesis
- NOVA applicability: regional context
- Confidence: medium
- Source: S10 (section: Life history and habitat)
- Limitations: Occurrence/tolerance is not improved feeding.
- Surrogate evidence: false
### E11. spawning and fecundity - context-only
- Exact condition/range: 182 gravid white perch from Choptank River, 2015-2018; stereological and gravimetric methods compared.
- Observed effect: Mean estimated fecundity was about 69,379 oocytes/fish and remained broadly stable, with length and year variation.
- Measured: Fecundity
- Population/location: Choptank River, Maryland
- Life stage: adult female
- Evidence type: field reproductive study
- NOVA applicability: high regional context
- Confidence: high
- Source: S11 (page: 134-142; section: Results and Discussion; table: Table 2; figure: Figures 2-3)
- Limitations: Reproductive output does not measure appetite or angling vulnerability.
- Surrogate evidence: false
### E12. spawning migration - context-only
- Exact condition/range: Chesapeake accounts and management sources place migration into fresh/low-salinity waters in spring.
- Observed effect: Seasonal concentration and accessibility may change.
- Measured: Migration/occurrence
- Population/location: Chesapeake Bay tributaries
- Life stage: adult
- Evidence type: agency/life-history synthesis
- NOVA applicability: high location context
- Confidence: medium
- Source: S1 (section: Species account)
- Limitations: Aggregation/access can alter catch counts without changing per-fish feeding.
- Surrogate evidence: false
### E13. dissolved oxygen, turbidity and light - unavailable
- Exact condition/range: Broad direct-evidence search.
- Observed effect: No adult white-perch feeding or standardized hook-and-line experiment isolated these variables.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: adult
- Evidence type: documented research gap
- NOVA applicability: high
- Confidence: high
- Source: S10 (section: Research-gap audit)
- Limitations: Do not transfer striped-bass or yellow-perch thresholds.
- Surrogate evidence: false
### E14. angling pressure and learning - unavailable
- Exact condition/range: Broad direct-evidence search.
- Observed effect: No qualifying hook-avoidance, learning or depletion study was verified.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: adult
- Evidence type: documented research gap
- NOVA applicability: high
- Confidence: high
- Source: S1 (section: Search-breadth audit)
- Limitations: Commercial/selective fishing effects on population structure are not individual catchability.
- Surrogate evidence: false
### E15. barometric pressure, fronts and moon phase - zero-weight
- Exact condition/range: Broad species-specific search.
- Observed effect: No qualifying direct feeding or catchability evidence.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: multiple
- Evidence type: documented null search
- NOVA applicability: high
- Confidence: high
- Source: S1 (section: Search-breadth audit)
- Limitations: Reject folklore.
- Surrogate evidence: false

## Remaining research gaps
- Adult Chesapeake feeding-rate experiments across temperature, oxygen, turbidity, underwater light and salinity.
- Standardized hook-and-line catchability and size-selectivity data.
- Direct tidal-current and diel feeding studies rather than telemetry alone.
- Hook avoidance, learning and recovery after angling pressure.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2025)
**White Perch**. Virginia DWR.
https://dwr.virginia.gov/wildlife/information/white-perch/
Scope: Virginia. Access: agency HTML. Verification: AI-reviewed-unverified.
### S2. Daniel Margulies (1989)
**Effects of Food Concentration and Temperature on Development, Growth, and Survival of White Perch, Morone americana, Eggs and Larvae**. Fishery Bulletin 87:63-72.
https://spo.nmfs.noaa.gov/sites/default/files/pdf-content/1989/871/margulies.pdf
Scope: Potomac and Patuxent broodstock; laboratory. Access: NOAA full PDF. Verification: AI-reviewed-unverified.
### S3. Lenwood W. Hall Jr.; Charles H. Hocutt; J. R. Stauffer Jr. (1979)
**Temperature preference of the white perch, Morone americana, collected in the Wicomico River, Maryland**. Estuaries 2:129-132. DOI: 10.2307/1351639.
https://ecosystems.psu.edu/research/labs/stauffer/publications/1970s/1979-temperature-preference-of-the-white-perch-morone-americana-collected-in-the-wicomico-river-maryland/@@download/file/Hall_etal_1979.pdf
Scope: Wicomico River, Maryland. Access: institutional full PDF. Verification: AI-reviewed-unverified.
### S4. Donna L. Parrish; F. Joseph Margraf (1990)
**Gastric evacuation rates of white perch, Morone americana, determined from laboratory and field data**. Environmental Biology of Fishes 29:155-158. DOI: 10.1007/BF00005032.
https://doi.org/10.1007/BF00005032
Scope: Lake Erie/laboratory and field. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S5. Donna L. Parrish; F. Joseph Margraf (1994)
**Spatial and Temporal Patterns of Food Use by White Perch and Yellow Perch in Lake Erie**. Journal of Freshwater Ecology 9(1):29-35. DOI: 10.1080/02705060.1994.9664424.
https://doi.org/10.1080/02705060.1994.9664424
Scope: Lake Erie. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S6. Donna L. Parrish; F. Joseph Margraf (1990)
**Interactions between White Perch (Morone americana) and Yellow Perch (Perca flavescens) in Lake Erie as Determined from Feeding and Growth**. Canadian Journal of Fisheries and Aquatic Sciences 47:1779-1787. DOI: 10.1139/f90-202.
https://doi.org/10.1139/f90-202
Scope: Lake Erie. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S7. Lisa A. Kerr; David H. Secor (2009)
**Bioenergetic trajectories underlying partial migration in Patuxent River (Chesapeake Bay) white perch (Morone americana)**. Canadian Journal of Fisheries and Aquatic Sciences 66:602-612. DOI: 10.1139/F09-027.
https://doi.org/10.1139/F09-027
Scope: Patuxent River, Maryland. Access: publisher abstract/full metadata. Verification: AI-reviewed-unverified.
### S8. Patrick McGrath; Herbert A. Austin (2009)
**Site Fidelity, Home Range, and Tidal Movements of White Perch during the Summer in Two Small Tributaries of the York River, Virginia**. Transactions of the American Fisheries Society 138:966-974. DOI: 10.1577/T08-176.1.
https://doi.org/10.1577/T08-176.1
Scope: York River tributaries, Virginia. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S9. M. M. McCauley; R. M. Cerrato; M. Sclafani; M. G. Frisk (2014)
**Diel Behavior in White Perch Revealed using Acoustic Telemetry**. Transactions of the American Fisheries Society 143(5):1330-1340. DOI: 10.1080/00028487.2014.938193.
https://doi.org/10.1080/00028487.2014.938193
Scope: Long Island estuary, New York. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S10. Atlantic States Marine Fisheries Commission / issuing agencies (1990)
**White Perch Fishery Management Plan**. Interstate fishery management plan.
https://www.nrc.gov/docs/ML1005/ML100500230.pdf
Scope: Atlantic coast and Chesapeake Bay. Access: agency full PDF. Verification: AI-reviewed-unverified.
### S11. Jacob T. Shaner; John M. Jacobs; Lance T. Yonkos; Reginal M. Harrell (2024)
**Reevaluating fecundity of white perch (Morone americana) in Chesapeake Bay with modern stereological techniques**. Fishery Bulletin 122(4):133-142. DOI: 10.7755/FB.122.4.1.
https://repository.library.noaa.gov/view/noaa/69872/noaa_69872_DS1.pdf
Scope: Choptank River, Chesapeake Bay. Access: NOAA full PDF. Verification: AI-reviewed-unverified.
