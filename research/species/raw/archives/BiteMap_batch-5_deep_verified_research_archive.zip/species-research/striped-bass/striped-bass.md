# Striped Bass
*Morone saxatilis*

- Species ID: `striped-bass`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Striped bass are a premier intentional Mid-Atlantic target. Direct juvenile consumption evidence supports Bite-scored status with one bounded dissolved-oxygen candidate; all other environmental effects remain contextual or unavailable.

### Model-ready findings
- **score**: Age-0 consumption was lower at 2 mg/L dissolved oxygen than at 4 mg/L or approximately saturated oxygen across 20-30 C laboratory treatments. Evidence: E2.

### Context-only findings
- Temperature from 20-30 C did not independently change consumption in the same factorial experiment; oxygen and temperature should not be collapsed into a generic summer optimum. Evidence: E3, E4.
- Chesapeake habitat models, diet studies and tidal movements provide prey/location context but do not directly measure hook vulnerability. Evidence: E5, E8, E9, E10, E11.
- Larval light/turbidity and nonvisual feeding results are scientifically useful but not portable to adult angling. Evidence: E6, E12.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- moon phase or solunar tables
- wind or ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The strongest oxygen experiment used small age-0 fish under controlled conditions.
- Habitat quality, growth potential and movement are not direct feeding or catchability.
- Hypoxia may both suppress consumption and concentrate fish/prey spatially, creating nonmonotonic field effects.
- No universal temperature, tide, spawning or monthly multiplier survived.

## Targetability assessment
Striped bass are a premier intentional Mid-Atlantic target. Direct juvenile consumption evidence supports Bite-scored status with one bounded dissolved-oxygen candidate; all other environmental effects remain contextual or unavailable.

## Candidate model rules
### R1. dissolvedOxygenMgL - score
- Condition: Juvenile laboratory exposure at 2 mg/L versus 4 mg/L and approximately saturated (~8 mg/L) within 20-30 C
- Direction: lower at 2 mg/L; higher at 4/saturation
- Strength: bounded moderate
- Confidence: medium-high
- Mechanism: Low oxygen constrained food consumption in age-0 striped bass.
- Evidence: E2
- Double-counting risk: Do not double count with habitat-quality models, summer season or temperature; adult/local calibration required.
### R2. waterTemperatureC - zero-weight
- Condition: 20-30 C without changing DO
- Direction: no independent consumption direction in this experiment
- Strength: zero within tested range
- Confidence: high
- Mechanism: Temperature did not independently alter consumption in the factorial test.
- Evidence: E3
- Double-counting risk: Do not infer a universal optimum or apply outside 20-30 C.
### R3. temperatureXoxygen - context-only
- Condition: Concurrent temperature and hypoxia
- Direction: interaction context only
- Strength: unknown
- Confidence: medium
- Mechanism: Growth/habitat effects arise from combined oxygen, prey and temperature constraints.
- Evidence: E4, E5
- Double-counting risk: Avoid counting oxygen, summer habitat squeeze and temperature as three independent penalties.
### R4. preyAvailability - context-only
- Condition: Local abundance and type of clupeids or other forage
- Direction: likely changes encounter and diet
- Strength: unquantified
- Confidence: medium
- Mechanism: Diet is strongly prey- and size-dependent.
- Evidence: E8, E9, E11
- Double-counting risk: Do not convert stomach occurrence to a multiplier without prey surveys.
### R5. tidalAccess - context-only
- Condition: Flooding of salt-marsh/tributary habitat
- Direction: location context only
- Strength: unknown
- Confidence: low-medium
- Mechanism: Tides alter access and movement.
- Evidence: E10
- Double-counting risk: Movement is not feeding; tide/current/light/prey can covary.
### R6. underwaterLightOrTurbidity - unavailable
- Condition: Adult field conditions
- Direction: none available
- Strength: unavailable
- Confidence: high
- Mechanism: Only larval studies were direct.
- Evidence: E6, E12
- Double-counting risk: Do not transfer larval sensory results to adult angling.
### R7. spawningStage - context-only
- Condition: Maturity or spawning migration
- Direction: unknown
- Strength: unknown
- Confidence: low
- Mechanism: A direct historical study exists but no portable quantitative result was verified.
- Evidence: E7, E13
- Double-counting risk: Do not treat aggregation, aggression or movement as appetite.
### R8. recentAnglingPressure - unavailable
- Condition: Any recent duration
- Direction: none
- Strength: unavailable
- Confidence: high
- Mechanism: No controlled hook-avoidance evidence was verified.
- Evidence: E14
- Double-counting risk: Do not infer from effort, regulations or stock trends.
### R9. barometricPressureFrontsMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct evidence.
- Evidence: E15
- Double-counting risk: Reject folklore and correlated weather proxies.
### R10. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Seasonal diet/migration does not establish intrinsic catchability.
- Evidence: E8, E9, E13
- Double-counting risk: Avoid double counting flow, prey, reproduction, access and angler effort.

## Evidence ledger
### E1. regional recreational targetability - context-only
- Exact condition/range: Virginia agency account documents intentional striped-bass fisheries and angling methods.
- Observed effect: Confirms high practical targetability in Virginia and Chesapeake/Potomac waters.
- Measured: Fishery status
- Population/location: Virginia
- Life stage: juvenile through adult
- Evidence type: agency fishery account
- NOVA applicability: high for targetability only
- Confidence: high
- Source: S1 (section: Species account and fishing)
- Limitations: Agency guidance does not validate environmental score thresholds.
- Surrogate evidence: false
### E2. dissolved oxygen - score
- Exact condition/range: Age-0 fish near 23 g; DO treatments 2, 4, and approximately 8 mg/L (saturation), crossed with 20, 23, 27, and 30 C.
- Observed effect: Food consumption increased significantly with dissolved oxygen; consumption at 2 mg/L was lower than at 4 and saturated oxygen across tested temperatures.
- Measured: Food consumed in controlled trials
- Population/location: laboratory, Chesapeake-region hatchery stock
- Life stage: age-0 juvenile
- Evidence type: controlled factorial feeding experiment
- NOVA applicability: mechanistically relevant; exact juvenile laboratory bounds only
- Confidence: high
- Source: S2 (page: S143-S149; section: Results; table: ANOVA table; figure: consumption figures)
- Limitations: Short-duration laboratory conditions, small juveniles, fixed prey and acclimation; not an adult hook-and-line curve.
- Surrogate evidence: false
### E3. absolute water temperature - zero-weight
- Exact condition/range: Same 20, 23, 27, and 30 C factorial treatments.
- Observed effect: Temperature did not independently produce a significant consumption effect in the experiment, although growth responses involved oxygen and temperature.
- Measured: Food consumption and growth
- Population/location: laboratory
- Life stage: age-0 juvenile
- Evidence type: controlled factorial feeding experiment
- NOVA applicability: high for rejecting a temperature-only inference within tested conditions
- Confidence: high
- Source: S2 (page: S143-S149; section: Results; table: ANOVA table; figure: growth/consumption figures)
- Limitations: No temperatures below 20 C were tested; absence of effect in this range is not a universal thermal null.
- Surrogate evidence: false
### E4. temperature and oxygen interaction - context-only
- Exact condition/range: 20-30 C crossed with 2, 4 and saturated mg/L DO.
- Observed effect: Growth was strongly curtailed under low oxygen, but the experiment did not support a simple temperature-only consumption optimum.
- Measured: Consumption and growth
- Population/location: laboratory
- Life stage: age-0 juvenile
- Evidence type: controlled experiment
- NOVA applicability: useful for avoiding double counting
- Confidence: high
- Source: S2 (page: S143-S149; section: Results and Discussion; table: ANOVA table)
- Limitations: Growth is not catchability; oxygen and temperature must not be collapsed into a generic summer penalty without local conditions.
- Surrogate evidence: false
### E5. habitat quality under hypoxia - context-only
- Exact condition/range: Age-2 and age-4 striped bass modeled in Chesapeake Bay using observed temperature, DO and prey abundance during 1996 and 2000.
- Observed effect: Hypoxia reduced spatial growth-rate potential and altered usable habitat; prey concentration above the oxycline could create locally favorable short-term patches.
- Measured: Modeled growth-rate potential and habitat volume
- Population/location: Chesapeake Bay
- Life stage: age-2 and age-4
- Evidence type: spatial bioenergetics modeling
- NOVA applicability: high regional context
- Confidence: medium-high
- Source: S3 (page: 989-1002; section: Results and Discussion; figure: GRP maps)
- Limitations: Model output integrates prey, temperature and oxygen; it does not directly measure strikes or angler catchability.
- Surrogate evidence: false
### E6. underwater light, turbidity and turbulence - context-only
- Exact condition/range: Striped-bass larvae exposed to controlled prey, light, turbidity and turbulence combinations.
- Observed effect: Feeding requirements and foraging rates depended on physical conditions; turbulence could reduce foraging while turbidity modified some effects.
- Measured: Larval prey capture and growth
- Population/location: laboratory
- Life stage: larvae
- Evidence type: controlled experiment
- NOVA applicability: low portability to adult angling
- Confidence: medium-high
- Source: S4 (page: 191-200; section: Results)
- Limitations: Larval sensory scale and plankton prey differ fundamentally from adult piscivory.
- Surrogate evidence: false
### E7. spawning stage - unavailable
- Exact condition/range: Adult feeding was evaluated against sexual maturity stage.
- Observed effect: The source directly addresses reproductive-state feeding, but accessible verification did not support a portable numerical multiplier.
- Measured: Stomach contents/feeding relative to maturity
- Population/location: Atlantic coastal waters
- Life stage: adult
- Evidence type: field feeding study
- NOVA applicability: regional concept only
- Confidence: low-medium
- Source: S5 (section: Title and indexed record)
- Limitations: Full quantitative result was not available in verified full text; do not infer a spawn bonus or penalty.
- Surrogate evidence: false
### E8. prey availability and season - context-only
- Exact condition/range: Coast-wide synthesis across life stages and locations.
- Observed effect: Diet composition varied with geography, season and fish size; clupeid fishes were prominent for older striped bass.
- Measured: Diet composition
- Population/location: Atlantic coast
- Life stage: multiple
- Evidence type: multi-study synthesis
- NOVA applicability: high Fish Guide relevance
- Confidence: medium-high
- Source: S6 (section: Abstract and synthesis conclusions)
- Limitations: Diet composition does not isolate feeding rate or catchability and included heterogeneous methods.
- Surrogate evidence: false
### E9. season and estuary - context-only
- Exact condition/range: 797 subadult/small-adult fish sampled spring through autumn in Massachusetts estuaries.
- Observed effect: Diets differed among estuaries and seasons, showing strong local prey dependence.
- Measured: Stomach contents
- Population/location: Massachusetts estuaries
- Life stage: subadult and small adult
- Evidence type: field diet study
- NOVA applicability: moderate transfer for forage context
- Confidence: medium-high
- Source: S7 (page: 30-45; section: Results; table: diet tables)
- Limitations: Northern estuaries and diet composition; no independent environmental bite coefficient.
- Surrogate evidence: false
### E10. tidal movement and marsh access - context-only
- Exact condition/range: 82 striped bass, 212-670 mm, tracked/sampled June-October in Delaware Bay marshes.
- Observed effect: Fish moved with tidal access and used marsh habitats; food habits differed with habitat use.
- Measured: Movement and stomach contents
- Population/location: Delaware Bay
- Life stage: subadult/adult
- Evidence type: telemetry/field diet study
- NOVA applicability: Mid-Atlantic context
- Confidence: medium
- Source: S8 (section: Abstract)
- Limitations: Movement and access are not proof of increased per-fish feeding or angler catchability.
- Surrogate evidence: false
### E11. fish size and prey selection - context-only
- Exact condition/range: Large striped bass sampled in Chesapeake Bay.
- Observed effect: Large fish consumed seasonally available fishes, with diet composition varying among sampling periods.
- Measured: Stomach contents
- Population/location: Chesapeake Bay
- Life stage: large adult
- Evidence type: field diet study
- NOVA applicability: high forage context
- Confidence: high
- Source: S9 (page: 414-423; section: Results; table: diet tables)
- Limitations: Sampling and prey fields affect observed diet; no direct catchability endpoint.
- Surrogate evidence: false
### E12. nonvisual feeding - zero-weight
- Exact condition/range: Larval fish tested at about 20 lx and darkness (0 lx), with sensory structures manipulated/observed.
- Observed effect: Larvae retained nonvisual prey-capture capacity; superficial neuromasts contributed to feeding in darkness.
- Measured: Prey-capture success
- Population/location: laboratory
- Life stage: larvae
- Evidence type: controlled sensory experiment
- NOVA applicability: low adult portability
- Confidence: high
- Source: S10 (page: 3522-3530; section: Results; figure: behavior figures)
- Limitations: Larval feeding mechanism cannot establish an adult night-bite multiplier.
- Surrogate evidence: false
### E13. streamflow and recruitment - context-only
- Exact condition/range: Broad life-history record across anadromous populations.
- Observed effect: Flow and spawning access influence recruitment and migration timing.
- Measured: Population life history
- Population/location: Atlantic coast
- Life stage: eggs through adult
- Evidence type: federal synopsis
- NOVA applicability: context only
- Confidence: medium
- Source: S11 (section: Life history and migration)
- Limitations: Recruitment and migration are not adult feeding or catchability.
- Surrogate evidence: false
### E14. angling pressure and hook avoidance - unavailable
- Exact condition/range: Broad search for repeat-capture learning, depletion or standardized pressure experiments.
- Observed effect: No qualifying species-specific experiment was verified.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: adult
- Evidence type: documented research gap
- NOVA applicability: high
- Confidence: high
- Source: S1 (section: Research-gap audit)
- Limitations: Creel effort or stock abundance cannot substitute for individual learning.
- Surrogate evidence: false
### E15. barometric pressure, fronts and moon phase - zero-weight
- Exact condition/range: Broad species-specific search.
- Observed effect: No qualifying direct feeding or hook-and-line evidence was verified.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: multiple
- Evidence type: documented null search
- NOVA applicability: high
- Confidence: high
- Source: S1 (section: Search-breadth audit)
- Limitations: Angling tradition and correlated weather cannot support a score.
- Surrogate evidence: false

## Remaining research gaps
- Adult Chesapeake/Potomac standardized angling or feeding trials across oxygen and temperature.
- Direct adult underwater-light, turbidity, flow-change and tidal-current effects with prey measured.
- Hook avoidance and short-term angling-pressure experiments.
- Replication separating fish size, prey abundance, salinity and season.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2025)
**Striped Bass**. Virginia DWR.
https://dwr.virginia.gov/wildlife/information/striped-bass/
Scope: Virginia. Access: agency HTML. Verification: AI-reviewed-unverified.
### S2. Stephen B. Brandt; Melinda Gerken; Kyle J. Hartman; Eric Demers (2009)
**Effects of hypoxia on food consumption and growth of juvenile striped bass (Morone saxatilis)**. Journal of Experimental Marine Biology and Ecology 381 Supplement:S143-S149. DOI: 10.1016/j.jembe.2009.07.028.
https://doi.org/10.1016/j.jembe.2009.07.028
Scope: laboratory fish from Chesapeake-region hatchery stock. Access: publisher record plus author-uploaded full-text inspection. Verification: AI-reviewed-unverified.
### S3. Marco Costantini; Stuart A. Ludsin; Doran M. Mason; Xinsheng Zhang; William C. Boicourt; Stephen B. Brandt (2008)
**Effect of hypoxia on habitat quality of striped bass (Morone saxatilis) in Chesapeake Bay**. Canadian Journal of Fisheries and Aquatic Sciences 65(5):989-1002. DOI: 10.1139/F08-021.
https://doi.org/10.1139/F08-021
Scope: Chesapeake Bay. Access: publisher/author full-text record. Verification: AI-reviewed-unverified.
### S4. Edward J. Chesney Jr. (1989)
**Estimating the food requirements of striped bass larvae Morone saxatilis: effects of light, turbidity and turbulence**. Marine Ecology Progress Series 53:191-200. DOI: 10.3354/meps053191.
https://doi.org/10.3354/meps053191
Scope: laboratory larvae. Access: publisher full text. Verification: AI-reviewed-unverified.
### S5. Lee Trent; William W. Hassler (1966)
**Feeding behavior of adult striped bass, Roccus saxatilis, in relation to stages of sexual maturity**. Chesapeake Science 7:189-192. DOI: 10.2307/1350432.
https://doi.org/10.2307/1350432
Scope: Atlantic coastal population. Access: publisher abstract/metadata. Verification: AI-reviewed-unverified.
### S6. John F. Walter III; Anthony S. Overton; Kristen H. Ferry; Martha E. Mather (2003)
**Atlantic coast feeding habits of striped bass: a synthesis supporting a coast-wide understanding of trophic biology**. Fisheries Management and Ecology 10:349-360. DOI: 10.1046/j.1365-2400.2003.00373.x.
https://doi.org/10.1046/j.1365-2400.2003.00373.x
Scope: U.S. Atlantic coast. Access: publisher abstract and metadata. Verification: AI-reviewed-unverified.
### S7. Kristen H. Ferry; Martha E. Mather (2012)
**Spatial and temporal diet patterns of subadult and small adult striped bass in Massachusetts estuaries: data, a synthesis, and trends across scales**. Marine and Coastal Fisheries 4:30-45. DOI: 10.1080/19425120.2011.642747.
https://doi.org/10.1080/19425120.2011.642747
Scope: Massachusetts estuaries. Access: publisher full text. Verification: AI-reviewed-unverified.
### S8. Mark Tupper; Kenneth W. Able (2000)
**Movements and food habits of striped bass (Morone saxatilis) in Delaware Bay salt marshes: comparison of a restored and a reference marsh**. Marine Biology 137:1049-1058. DOI: 10.1007/s002270000421.
https://doi.org/10.1007/s002270000421
Scope: Delaware Bay. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S9. John F. Walter III; Hampton M. Austin (2003)
**Diet composition of large striped bass (Morone saxatilis) in Chesapeake Bay**. Fishery Bulletin 101:414-423.
https://scholarworks.wm.edu/items/23335d13-3ea9-4c17-8ca0-15ed1a4ae78a
Scope: Chesapeake Bay. Access: institutional repository full text. Verification: AI-reviewed-unverified.
### S10. Sarah J. Sampson; John Duston; Roger P. Croll (2013)
**Superficial neuromasts facilitate non-visual feeding by larval striped bass (Morone saxatilis)**. Journal of Experimental Biology 216:3522-3530. DOI: 10.1242/jeb.087395.
https://doi.org/10.1242/jeb.087395
Scope: laboratory larvae. Access: publisher full text. Verification: AI-reviewed-unverified.
### S11. U.S. National Marine Fisheries Service (1980)
**Synopsis of biological data on striped bass, Morone saxatilis (Walbaum)**. FAO Fisheries Synopsis / NOAA technical publication.
https://repository.library.noaa.gov/
Scope: Atlantic coast and inland populations. Access: federal repository/catalog. Verification: AI-reviewed-unverified.
