# BiteMap NOVA research resume packet

- Completed before Batch 5: largemouth-bass, smallmouth-bass, channel-catfish, black-crappie, white-crappie, bluegill, redbreast-sunfish, pumpkinseed, green-sunfish, rock-bass, rainbow-trout, brown-trout, brook-trout, blue-catfish, flathead-catfish, white-catfish.
- Completed in Batch 5: striped-bass, white-perch, yellow-perch.
- Pending species: walleye, muskellunge, northern-snakehead, spotted-bass, common-carp, american-eel, fallfish, creek-chub, white-sucker, yellow-bullhead, brown-bullhead, northern-hogsucker, shorthead-redhorse, blacknose-dace, longnose-dace, mottled-sculpin, tessellated-darter, gizzard-shad.
- Next recommended batch: Batch 6 - walleye, muskellunge, and northern snakehead.
- Schema version: 1.1.
- Verification status: AI-reviewed-unverified.
- Known corrections: channel-catfish S13 must include James W. Avault Jr.; white-perch Hall and Stauffer Jr. suffixes are preserved; yellow-perch turbidity type is separated; striped-bass oxygen and temperature effects are not collapsed.
- Batch 5 outcome: Striped Bass and Yellow Perch remain Bite-scored with one narrow direct candidate each; White Perch is proposed for bite scoring but has no score-ready rule.
- Unresolved questions: see validation-report.json and correction-and-conflict-log.json.
- Files a new chat should receive: the two baseline archives, Batch 1 through Batch 4 archives, BiteMap_batch-5_deep_verified_research_archive.zip, and the master prompt with ACTIVE BATCH changed to BATCH 6.
