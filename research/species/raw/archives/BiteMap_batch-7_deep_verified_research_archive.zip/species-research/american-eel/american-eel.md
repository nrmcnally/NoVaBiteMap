# American Eel
*Anguilla rostrata*

- Species ID: `american-eel`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Proposed for bite scoring**

## Executive conclusion
American eel are intentionally targeted with bait in Mid-Atlantic rivers and estuaries. Direct nocturnal baited-capture and chronic-cold feeding evidence justify proposed bite scoring, but implementation should remain life-stage-, season- and waterbody-bounded until freshwater hook-and-line replication exists.

### Model-ready findings
- **score**: In a turbid Rhode Island estuary, baited capture began just after sunset, peaked about one hour later, and 99% of 24-hour captures occurred at night. Evidence: E2, E3.
- **score**: Chronic acclimation at winter-cold temperatures near or below 5 C produced feeding cessation and torpor. Evidence: E4.

### Context-only findings
- Lower Chesapeake seasonal abundance, Shenandoah telemetry and St. Lawrence activity identify availability/location changes rather than per-fish appetite. Evidence: E6, E8, E9.
- Daytime feeding during a concentrated tropical prey migration rejects an absolute nocturnal rule. Evidence: E10.
- Tidal movement and thermal preference remain zero-weight for biting. Evidence: E5, E12, E13.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The strongest diel evidence used baited traps in 20-30 ppt water, not hook-and-line in freshwater.
- Chronic cold acclimation cannot be translated into a same-day front penalty.
- Tropical daytime prey-pulse evidence shows nocturnality is conditional.
- Movement, commercial gear catch and trawl abundance remain separate from feeding.

## Targetability assessment
American eel are intentionally targeted with bait in Mid-Atlantic rivers and estuaries. Direct nocturnal baited-capture and chronic-cold feeding evidence justify proposed bite scoring, but implementation should remain life-stage-, season- and waterbody-bounded until freshwater hook-and-line replication exists.

## Candidate model rules
### R1. timeOfDay - score
- Condition: Late summer/early autumn estuarine yellow eels: just after sunset through night
- Direction: positive; daylight strongly negative
- Strength: strong within study
- Confidence: high
- Mechanism: Baited capture began immediately after sunset and was overwhelmingly nocturnal.
- Evidence: E2, E3
- Double-counting risk: Do not double count sunset, underwater light and clock time; restrict season/waterbody/life stage.
### R2. waterTemperature - score
- Condition: Chronic acclimation at or below about 5 C for more than five weeks
- Direction: strong negative/feeding cessation
- Strength: strong within study
- Confidence: high
- Mechanism: Winter torpor suppressed feeding and metabolism.
- Evidence: E4
- Double-counting risk: Do not apply to a brief cold front or infer exact field temperature without acclimation history.
### R3. waterTemperature - context-only
- Condition: 10-20 C acclimated laboratory conditions
- Direction: feeding present, not an optimum
- Strength: low
- Confidence: medium
- Mechanism: Eels fed regularly across this range.
- Evidence: E4
- Double-counting risk: Presence of feeding is not a positive curve or maximum.
### R4. thermalPreference - zero-weight
- Condition: Final preferendum near 16.7 C
- Direction: no bite weight
- Strength: zero
- Confidence: high
- Mechanism: Selected temperature measured habitat choice only.
- Evidence: E5
- Double-counting risk: Do not conflate preference with appetite.
### R5. seasonalCold - context-only
- Condition: Colder months in lower Chesapeake trawls
- Direction: lower availability/catch
- Strength: context only
- Confidence: medium
- Mechanism: Trawl catches declined as water cooled.
- Evidence: E6, E9
- Double-counting risk: Abundance, depth, activity and gear encounter are confounded.
### R6. preyPulse - context-only
- Condition: Unusually concentrated prey available in daylight
- Direction: possible exception to nocturnal pattern
- Strength: unquantified
- Confidence: low-medium
- Mechanism: Eels can feed during day when prey pulses overwhelm normal diel pattern.
- Evidence: E10
- Double-counting risk: No generic daytime bonus; requires observed prey event.
### R7. tidalStage - zero-weight
- Condition: Any tide direction
- Direction: none for bite
- Strength: zero
- Confidence: high
- Mechanism: Telemetry showed tidal movement, not feeding/catchability.
- Evidence: E12, E13
- Double-counting risk: Do not infer bite from movement.
### R8. flowDischarge - context-only
- Condition: Seasonal movement with discharge changes
- Direction: location only
- Strength: unquantified
- Confidence: medium
- Mechanism: Flow helped explain migration/movement in the Shenandoah.
- Evidence: E8
- Double-counting risk: Movement and access are separate from feeding.
### R9. silverEelStage - context-only
- Condition: Confirmed downstream-migrating silver stage
- Direction: negative feeding context
- Strength: unquantified
- Confidence: medium
- Mechanism: Digestive regression and migration reduce feeding.
- Evidence: E14
- Double-counting risk: Life stage cannot be inferred from month alone.
### R10. weatherPressureMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct endpoint evidence.
- Evidence: E15
- Double-counting risk: Reject folklore and migration-only associations.
### R11. dissolvedOxygenTurbidity - unavailable
- Condition: Any threshold
- Direction: unavailable
- Strength: unavailable
- Confidence: high
- Mechanism: No portable direct feeding/hook-and-line threshold qualified.
- Evidence: E15
- Double-counting risk: Do not use habitat/tolerance evidence.

## Evidence ledger
### E1. targetability and regional distribution - context-only
- Exact condition/range: Catadromous species occupying Atlantic coastal rivers, estuaries and accessible inland waters.
- Observed effect: Confirms Mid-Atlantic presence and intentional baited-hook/trap fisheries, with major life-stage differences.
- Measured: Distribution, life history and fishery relevance
- Population/location: Atlantic North America
- Life stage: glass, yellow and silver eel
- Evidence type: federal species account
- NOVA applicability: high for regional relevance
- Confidence: high
- Source: S1 (section: Species overview)
- Limitations: Agency account does not establish numerical bite rules.
- Surrogate evidence: false
### E2. time of day and baited capture - score
- Exact condition/range: Eight baited eel traps checked every 3 h for six 24-h periods in early September; 322 captures.
- Observed effect: 178 eels (55%) were captured just after sunset at the 20:00 check, 140 (44%) during the remainder of night, and only 4 (1%) in daylight.
- Measured: Baited-trap capture as contemporaneous foraging proxy
- Population/location: Rhode Island estuary, 20-30 ppt, turbid
- Life stage: mostly yellow eel, mean about 31 cm
- Evidence type: field baited-capture experiment
- NOVA applicability: strong direct endpoint for estuarine late-summer/fall conditions
- Confidence: high
- Source: S2 (page: 746; section: 24-hour experiment; figure: Figure 1)
- Limitations: Baited traps are not hook-and-line; salinity, turbidity, season and bait odor limit transfer.
- Surrogate evidence: false
### E3. sunset timing - score
- Exact condition/range: Traps checked every 30 min from 17:15-20:15 for six evenings in early October; 588 captures.
- Observed effect: First captures consistently occurred just after sunset, peaked about one hour after sunset, then declined.
- Measured: Half-hour baited-trap catch
- Population/location: Rhode Island estuary
- Life stage: yellow eel
- Evidence type: field baited-capture experiment
- NOVA applicability: strong timing evidence within study season
- Confidence: high
- Source: S2 (page: 746-747; section: Evening experiment; figure: Figure 2)
- Limitations: Not a universal civil-clock window; sunset, season and estuary conditions define the observation.
- Surrogate evidence: false
### E4. chronic cold and feeding - score
- Exact condition/range: Eels acclimated between 10 and 20 C versus winter temperatures at or below 5 C for more than five weeks.
- Observed effect: Eels at 10-20 C fed regularly; those acclimated to winter-cold conditions ceased feeding and entered profound metabolic torpor.
- Measured: Observed feeding state and oxygen consumption
- Population/location: laboratory, Canada
- Life stage: yellow eel
- Evidence type: controlled acclimation study
- NOVA applicability: direct feeding evidence with chronic-exposure limitation
- Confidence: high
- Source: S3 (page: 532-540; section: Abstract/Results)
- Limitations: Does not support a rapid penalty from a one-day cold front or an exact field cutoff across populations.
- Surrogate evidence: false
### E5. thermal preference - zero-weight
- Exact condition/range: Maryland eels acclimated to 6, 12, 18, 24 and 30 C, then tested in a gradient.
- Observed effect: Final preferendum was about 16.7 C and selected temperature was not strongly shifted by acclimation.
- Measured: Voluntary selected temperature
- Population/location: Maryland eastern-shore fish in laboratory
- Life stage: yellow eel
- Evidence type: controlled behavioral experiment
- NOVA applicability: regional habitat context
- Confidence: high
- Source: S4 (page: 49; section: Abstract/Methods)
- Limitations: Thermal preference is not maximum feeding or catchability.
- Surrogate evidence: false
### E6. seasonal abundance and temperature - context-only
- Exact condition/range: Trawl sampling in brackish portions of three Virginia rivers.
- Observed effect: Fewer eels were caught during colder months; abundance in trawl surveys was related to water temperature.
- Measured: Trawl abundance and stomach contents
- Population/location: lower Chesapeake Bay Virginia rivers
- Life stage: yellow eel
- Evidence type: field survey
- NOVA applicability: high regional relevance, but abundance/catchability confounded
- Confidence: medium-high
- Source: S5 (page: 62-66; section: Abstract)
- Limitations: Trawl catch can reflect movement, depth and abundance; no per-fish feeding coefficient.
- Surrogate evidence: false
### E7. diet and prey availability - context-only
- Exact condition/range: Brackish Virginia rivers.
- Observed effect: Polychaetes, crustaceans and bivalves were important prey, including soft-shell clams and blue crabs.
- Measured: Stomach contents
- Population/location: lower Chesapeake Bay
- Life stage: yellow eel
- Evidence type: field diet study
- NOVA applicability: Fish Guide and prey context
- Confidence: medium-high
- Source: S5 (page: 62-66; section: Abstract)
- Limitations: Diet composition does not quantify feeding rate.
- Surrogate evidence: false
### E8. temperature, flow and seasonal movement - context-only
- Exact condition/range: Radio-tagged 518-810 mm yellow eels near Millville Dam.
- Observed effect: Seasonal movement and upstream activity covaried with temperature and discharge.
- Measured: Telemetry movement
- Population/location: Shenandoah River, West Virginia
- Life stage: large yellow eel
- Evidence type: field telemetry thesis
- NOVA applicability: very high regional location relevance
- Confidence: medium-high
- Source: S6 (section: Abstract/Results chapters)
- Limitations: Movement is not feeding or hook vulnerability.
- Surrogate evidence: false
### E9. cold-season activity - context-only
- Exact condition/range: Long-term telemetry and hoop-net records; activity decreased at low temperature.
- Observed effect: Activity declined around 8 C and ceased near 4 C; greatest seasonal activity/hoop-net catch occurred around 8.1-11.1 C in the study system.
- Measured: Movement distance, depth and commercial hoop-net catch
- Population/location: upper St. Lawrence River
- Life stage: resident yellow eel
- Evidence type: telemetry plus fishery study
- NOVA applicability: cold-suppression context; different latitude/system
- Confidence: medium-high
- Source: S7 (section: Abstract/Results)
- Limitations: Hoop-net catch combines activity, gear encounter and seasonal aggregation; do not merge with lab feeding into a smooth curve.
- Surrogate evidence: false
### E10. daytime feeding exception - context-only
- Exact condition/range: Daytime observations during mass movement of amphidromous prey in a tropical stream.
- Observed effect: American eels fed diurnally when concentrated migrating prey were available.
- Measured: Direct feeding observations
- Population/location: Puerto Rico
- Life stage: yellow eel
- Evidence type: field natural-history study
- NOVA applicability: important contradiction to universal nocturnality
- Confidence: medium
- Source: S8 (section: Abstract)
- Limitations: Tropical prey pulse and river setting are exceptional; not a daytime bonus for NOVA.
- Surrogate evidence: false
### E11. prey selection and fish size - context-only
- Exact condition/range: Upper Delaware River stomach samples.
- Observed effect: Macroinvertebrates dominated many feeding eels; prey composition changed with fish size and local availability.
- Measured: Stomach contents and selectivity
- Population/location: Upper Delaware River
- Life stage: yellow eel
- Evidence type: field diet study
- NOVA applicability: Mid-Atlantic prey/presentation context
- Confidence: medium
- Source: S9 (section: Abstract/Results)
- Limitations: No environmental catchability response was isolated.
- Surrogate evidence: false
### E12. tidal movement and diel activity - context-only
- Exact condition/range: Acoustic/ultrasonic telemetry in tidal creeks and estuary.
- Observed effect: Eels showed diel and tidal movement cycles tied to habitat use.
- Measured: Movement and location
- Population/location: Georgia tidal creek
- Life stage: yellow eel
- Evidence type: field telemetry
- NOVA applicability: location context only
- Confidence: medium
- Source: S10 (section: Abstract)
- Limitations: Movement is not feeding; baited-capture evidence should control scoring.
- Surrogate evidence: false
### E13. tide and activity - zero-weight
- Exact condition/range: Telemetry/activity observations across tidal stages.
- Observed effect: Tides influenced movement and daily activity cycle.
- Measured: Movement/activity
- Population/location: St. Lawrence estuary
- Life stage: yellow eel
- Evidence type: field movement study
- NOVA applicability: low-to-moderate NOVA transfer
- Confidence: medium
- Source: S11 (section: Abstract)
- Limitations: No direct feeding or hook-and-line endpoint; no tide bonus.
- Surrogate evidence: false
### E14. spawning life stage - context-only
- Exact condition/range: Silver-stage downstream migration and digestive regression described in authoritative life history.
- Observed effect: Migrating silver eels reduce or cease feeding as they prepare for oceanic spawning migration.
- Measured: Life-history feeding state
- Population/location: Atlantic range
- Life stage: silver eel
- Evidence type: federal synthesis
- NOVA applicability: mechanistically important but life stage usually unavailable to app
- Confidence: medium
- Source: S1 (section: Life cycle)
- Limitations: Do not infer silver stage from season alone; target fisheries and regulations differ.
- Surrogate evidence: false
### E15. weather and moon folklore - zero-weight
- Exact condition/range: Searches for pressure, fronts, moon, wind and ordinary rainfall effects on feeding/catchability.
- Observed effect: Movement studies included hydrologic or lunar covariates, but no qualifying direct feeding or hook-and-line rule survived.
- Measured: Evidence availability
- Population/location: Atlantic North America
- Life stage: yellow eel
- Evidence type: systematic search result
- NOVA applicability: high for zero-weight decision
- Confidence: high
- Source: S6 (section: Variables and limitations)
- Limitations: Rain/discharge can alter access and migration without increasing appetite.
- Surrogate evidence: false

## Remaining research gaps
- Freshwater Potomac/Shenandoah hook-and-line replication of sunset effects.
- Direct oxygen, turbidity, salinity and current effects on feeding/catchability.
- Life-stage-specific feeding studies separating yellow and silver eels.
- Effort-controlled angling-pressure and bait/presentation research.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. U.S. Fish and Wildlife Service (2026)
**American Eel (Anguilla rostrata)**. U.S. Fish and Wildlife Service.
https://www.fws.gov/species/american-eel-anguilla-rostrata
Scope: Atlantic North America. Access: federal agency HTML. Verification: AI-reviewed-unverified.
### S2. Peter W. Sorensen; Marco L. Bianchini; Howard E. Winn (1986)
**Diel Foraging Activity of American Eels, Anguilla rostrata (LeSueur), in a Rhode Island Estuary**. Fishery Bulletin 84(3):746-747.
https://spo.nmfs.noaa.gov/sites/default/files/pdf-content/fish-bull/sorensen.pdf
Scope: Pettaquamscutt River estuary, Rhode Island. Access: NOAA-hosted full PDF. Verification: AI-reviewed-unverified.
### S3. Patrick J. Walsh; Glen D. Foster; Thomas W. Moon (1983)
**The Effects of Temperature on Metabolism of the American Eel Anguilla rostrata (LeSueur): Compensation in the Summer and Torpor in the Winter**. Physiological Zoology 56(4):532-540. DOI: 10.1086/physzool.56.4.30155876.
https://www.journals.uchicago.edu/doi/pdf/10.1086/physzool.56.4.30155876
Scope: laboratory, Canada. Access: publisher full PDF. Verification: AI-reviewed-unverified.
### S4. Theresa Y. Barila; Jay R. Stauffer Jr. (1980)
**Temperature Behavioral Responses of the American Eel, Anguilla rostrata (Lesueur), from Maryland**. Hydrobiologia 74:49-51. DOI: 10.1007/BF00009014.
https://ecosystems.psu.edu/research/labs/stauffer/publications/1980s/1980-temperature-behavioral-responses-of-the-american-eel-anguilla-rostrata-lesueur-from-maryland/@@download/file/BarilaStauffer1980.pdf
Scope: Maryland eastern shore fish; laboratory gradient. Access: author repository full PDF. Verification: AI-reviewed-unverified.
### S5. Charles A. Wenner; John A. Musick (1975)
**Food Habits and Seasonal Abundance of the American Eel, Anguilla rostrata, from the Lower Chesapeake Bay**. Chesapeake Science 16(1):62-66. DOI: 10.2307/1351085.
https://link.springer.com/article/10.2307/1351085
Scope: three lower Chesapeake Bay Virginia rivers. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S6. Stephen D. Hammond (2003)
**Seasonal Movements of Yellow-Phase American Eels (Anguilla rostrata) in the Shenandoah River, West Virginia**. West Virginia University MS thesis. DOI: 10.33915/etd.1778.
https://researchrepository.wvu.edu/etd/1778/
Scope: Shenandoah River, West Virginia. Access: university repository abstract/thesis. Verification: AI-reviewed-unverified.
### S7. Colleen M. M. Burliuk; John M. Casselman (2023)
**Seasonal Activity and Depth Distribution of Resident Yellow-Phase American Eels (Anguilla rostrata) in a Large Fluvial Ecosystem**. ICES Journal of Marine Science 80(4):923-934. DOI: 10.1093/icesjms/fsad002.
https://academic.oup.com/icesjms/article/80/4/923/7049338
Scope: upper St. Lawrence River. Access: publisher full HTML. Verification: AI-reviewed-unverified.
### S8. Augustin C. Engman; Jesse R. Fischer; Thomas J. Kwak; Michael J. Walter (2017)
**Diurnal Feeding Behavior of the American Eel Anguilla rostrata**. Food Webs 13:27–29. DOI: 10.1016/j.fooweb.2017.10.003.
https://www.usgs.gov/publications/diurnal-feeding-behavior-american-eel-anguilla-rostrata
Scope: Puerto Rico river. Access: USGS publication record/publisher abstract. Verification: AI-reviewed-unverified.
### S9. Charles E. Denoncourt; Jay R. Stauffer Jr. (1993)
**Feeding Selectivity of the American Eel Anguilla rostrata (LeSueur) in the Upper Delaware River**. American Midland Naturalist 129(2):301–308. DOI: 10.2307/2426511.
https://www.jstor.org/stable/2426511
Scope: Upper Delaware River. Access: publisher abstract/record. Verification: AI-reviewed-unverified.
### S10. Gene S. Helfman; David L. Stoneburner; E. L. Bozeman Jr.; P. A. Christian; R. Whalen (1983)
**Ultrasonic Telemetry of American Eel Movements in a Tidal Creek**. Transactions of the American Fisheries Society 112:105-110. DOI: 10.1577/1548-8659(1983)112<105:UTOAEM>2.0.CO;2.
https://doi.org/10.1577/1548-8659(1983)112%3C105:UTOAEM%3E2.0.CO;2
Scope: Georgia tidal creek. Access: publisher record/abstract. Verification: AI-reviewed-unverified.
### S11. Jean-Denis Dutil; Alain Giroux; Andrew Kemp; Guy Lavoie; Jean-Pierre Dallaire (1988)
**Tidal Influence on Movements and on Daily Cycle of Activity of American Eels**. Transactions of the American Fisheries Society 117:488-494. DOI: 10.1577/1548-8659(1988)117<0488:TIOMAO>2.3.CO;2.
https://doi.org/10.1577/1548-8659(1988)117%3C0488:TIOMAO%3E2.3.CO;2
Scope: St. Lawrence estuary. Access: publisher abstract. Verification: AI-reviewed-unverified.
