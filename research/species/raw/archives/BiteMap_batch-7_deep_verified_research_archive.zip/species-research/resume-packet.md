# BiteMap NOVA research resume packet

- Completed before Batch 7: largemouth-bass, smallmouth-bass, channel-catfish, black-crappie, white-crappie, bluegill, redbreast-sunfish, pumpkinseed, green-sunfish, rock-bass, rainbow-trout, brown-trout, brook-trout, blue-catfish, flathead-catfish, white-catfish, striped-bass, white-perch, yellow-perch, walleye, muskellunge, northern-snakehead.
- Completed in Batch 7: spotted-bass, common-carp, american-eel.
- Pending species: fallfish, creek-chub, white-sucker, yellow-bullhead, brown-bullhead, northern-hogsucker, shorthead-redhorse, blacknose-dace, longnose-dace, mottled-sculpin, tessellated-darter, gizzard-shad.
- Next recommended batch: Batch 8 - fallfish, creek chub, and white sucker.
- Schema version: 1.1.
- Verification status: AI-reviewed-unverified.
- Known corrections: channel-catfish S13 must include James W. Avault Jr.; Alabama bass and hybrids must not be silently treated as spotted bass; carp one-trial hook avoidance was not supported beyond about seven months; American-eel nocturnality has documented prey-pulse exceptions.
- Batch 7 outcome: Common Carp is Bite-scored; Spotted Bass and American Eel are proposed for bite scoring with explicit limitations.
- Unresolved questions: see validation-report.json and correction-and-conflict-log.json.
- Files a new chat should receive: the two baseline archives, the immediately preceding Batch 6 archive, BiteMap_batch-7_deep_verified_research_archive.zip, and the master prompt with ACTIVE BATCH changed to BATCH 8.
