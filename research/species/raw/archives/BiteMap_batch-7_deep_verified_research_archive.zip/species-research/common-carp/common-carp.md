# Common Carp
*Cyprinus carpio*

- Species ID: `common-carp`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Common carp are intentionally targeted throughout the Mid-Atlantic. Multiple direct feeding and hook-learning studies support Bite-scored status, but temperature and diel candidates must remain categorical and capture-history effects must not be generalized beyond the measured time windows.

### Model-ready findings
- **score**: Direct feeding experiments support bounded cold suppression, warming-related increases through intermediate temperatures, and a decline at the 34 C extreme treatment. Evidence: E2, E4.
- **score**: Direct capture experience reduced vulnerability for hours to days, while social exposure produced a weaker short-term avoidance effect. Evidence: E5, E6.
- **zero-weight**: One-trial avoidance was not supported beyond about seven months. Evidence: E7.

### Context-only findings
- Morning/evening laboratory feeding peaks are usable only as a low-strength husbandry-limited candidate. Evidence: E3.
- Domestication, boldness and bait conditioning explain population/individual differences and guide presentation. Evidence: E9, E10, E11.
- Bait encounter alone did not explain wild capture vulnerability. Evidence: E8.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- Chinese and UK experiments used cultured or juvenile fish, fixed diets and acclimation.
- Private/social learning effects are bait-, setting- and history-dependent.
- Domestication/strain effects cannot be inferred for an unknown wild population.
- Growth, stock-catch and habitat studies were not converted into bite rules.

## Targetability assessment
Common carp are intentionally targeted throughout the Mid-Atlantic. Multiple direct feeding and hook-learning studies support Bite-scored status, but temperature and diel candidates must remain categorical and capture-history effects must not be generalized beyond the measured time windows.

## Candidate model rules
### R1. waterTemperature - score
- Condition: Chronic or acclimated conditions near 6 C versus 14-28 C
- Direction: strong negative at 6 C; higher at intermediate/warm treatments
- Strength: moderate
- Confidence: medium
- Mechanism: Voluntary ration was nearly suppressed at 6 C and rose sharply by 14 C.
- Evidence: E2
- Double-counting risk: Do not double count season or short-term trend; exact strain and feeding regime matter.
### R2. waterTemperature - score
- Condition: Juveniles at 16 C versus 20-28 C
- Direction: lower feeding at 16 C; plateau around 24-28 C
- Strength: low-moderate
- Confidence: medium
- Mechanism: Temperature altered juvenile functional response and intake.
- Evidence: E4
- Double-counting risk: Juvenile laboratory result must not be merged with adult ration percentages as one curve.
### R3. extremeHeat - score
- Condition: 34 C relative to 28 C in the ration experiment
- Direction: negative
- Strength: low-moderate
- Confidence: medium
- Mechanism: Daily ration declined at the hottest treatment.
- Evidence: E2
- Double-counting risk: Do not treat 34 C as a sharp field cutoff; oxygen and acclimation may co-vary.
### R4. timeOfDay - score
- Condition: Approximately 08:00-11:00 and 19:00-23:00 under the tested husbandry
- Direction: positive windows
- Strength: low
- Confidence: low-medium
- Mechanism: Repeated diel peaks in voluntary feed intake.
- Evidence: E3
- Double-counting risk: Clock time, photoperiod, feeding schedule and temperature are confounded.
### R5. recentCapture - score
- Condition: Direct catch-and-release within hours to about one week
- Direction: negative
- Strength: moderate
- Confidence: high
- Mechanism: Private learning produced short-term hook/rig avoidance.
- Evidence: E5
- Double-counting risk: Avoid double counting recent pressure, individual capture history and population depletion.
### R6. socialExposure - score
- Condition: Witnessing conspecific capture within hours/days
- Direction: negative
- Strength: low
- Confidence: medium
- Mechanism: Social information induced temporary caution.
- Evidence: E6
- Double-counting risk: Only use where local pressure/group exposure can be proxied; effect was less persistent.
### R7. longTermCaptureMemory - zero-weight
- Condition: More than seven months after one exposure
- Direction: none supported
- Strength: zero
- Confidence: high
- Mechanism: Long-term retest did not reproduce durable one-trial avoidance.
- Evidence: E7
- Double-counting risk: Does not negate shorter learning or repeated-capture effects.
### R8. strainDomestication - context-only
- Condition: Domesticated versus wild-type ancestry
- Direction: population context
- Strength: unquantified
- Confidence: medium
- Mechanism: Domestication and boldness changed vulnerability.
- Evidence: E9, E10
- Double-counting risk: Ancestry is usually unknown and should not be inferred from body shape alone.
### R9. prebaiting - context-only
- Condition: Repeated familiar bait at a fixed site
- Direction: presentation context
- Strength: unquantified
- Confidence: medium
- Mechanism: Conditioning can aggregate fish and increase bait acceptance.
- Evidence: E11
- Double-counting risk: Belongs in Fish Guide, not weather score.
### R10. weatherPressureMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct evidence.
- Evidence: E14
- Double-counting risk: Reject folklore and effort-confounded competition data.
### R11. dissolvedOxygen - unavailable
- Condition: Any mg/L threshold from tolerance studies
- Direction: unavailable
- Strength: unavailable
- Confidence: high
- Mechanism: No direct feeding/catchability coefficient qualified.
- Evidence: E15
- Double-counting risk: Do not infer from survival or habitat occupancy.

## Evidence ledger
### E1. targetability and regional occurrence - context-only
- Exact condition/range: Widespread Virginia populations and long-standing recreational fishery.
- Observed effect: Confirms deliberate hook-and-line targeting and broad habitat availability.
- Measured: Distribution and fishery relevance
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency account
- NOVA applicability: high for targetability
- Confidence: high
- Source: S1 (section: Species account)
- Limitations: Agency natural history does not define bite multipliers.
- Surrogate evidence: false
### E2. water temperature and feeding rate - score
- Exact condition/range: Adults 630-850 g and juveniles 61-91 g tested across 4-34 C; explicit intake values reported at 6, 14, 28 and 34 C.
- Observed effect: Daily ration was very low at 6 C, increased strongly by 14 C, peaked at 28 C, and declined at 34 C; juveniles consumed a larger body-mass percentage than adults.
- Measured: Daily feed intake as percent body mass
- Population/location: controlled aquaculture, China
- Life stage: juvenile and adult
- Evidence type: controlled feeding experiment
- NOVA applicability: direct endpoint but strain, diet and culture transfer limits
- Confidence: medium-high
- Source: S2 (page: 57-61; section: Abstract/Results)
- Limitations: Do not fit a smooth universal curve from four highlighted temperatures or transfer exact percentages to wild North American carp.
- Surrogate evidence: false
### E3. time of day and temperature - score
- Exact condition/range: Across tested temperatures, 24-hour feed observations.
- Observed effect: Two principal feeding peaks occurred around 08:00-11:00 and 19:00-23:00; below 10 C the evening peak extended toward 04:00.
- Measured: Hourly distribution of daily feed intake
- Population/location: controlled aquaculture, China
- Life stage: juvenile and adult
- Evidence type: controlled feeding experiment
- NOVA applicability: low-to-moderate portability
- Confidence: medium
- Source: S2 (page: 57-61; section: Abstract/Results)
- Limitations: Feeding schedule, photoperiod and husbandry can entrain timing; not a universal clock.
- Surrogate evidence: false
### E4. juvenile temperature and foraging - score
- Exact condition/range: Juveniles 90-105 mm tested at 16, 20, 24 and 28 C with two foods.
- Observed effect: Foraging/feeding increased from 16 to 24 C and did not increase further from 24 to 28 C; growth was depressed at 16 and 28 C relative to intermediate treatments.
- Measured: Feeding rates, functional response and growth
- Population/location: laboratory, United Kingdom
- Life stage: juvenile
- Evidence type: controlled experiment
- NOVA applicability: direct feeding evidence, juvenile only
- Confidence: medium-high
- Source: S3 (section: Abstract)
- Limitations: Growth and feeding endpoints must remain separate; 24 C should not become a universal adult optimum.
- Surrogate evidence: false
### E5. recent direct capture learning - score
- Exact condition/range: Direct hooking and release followed by sham-rig/bait trials within hours and again over several days.
- Observed effect: Directly hooked carp became more cautious and less vulnerable; avoidance persisted at least 5-7 days in the study.
- Measured: Rig approach, bait ingestion and recapture vulnerability
- Population/location: controlled laboratory, Germany
- Life stage: juvenile/adult experimental fish
- Evidence type: controlled angling-learning experiment
- NOVA applicability: high mechanistic relevance; field magnitude uncertain
- Confidence: high
- Source: S4 (page: 498-511; section: Results)
- Limitations: Group history, bait type and captive setting limit numerical transfer.
- Surrogate evidence: false
### E6. social learning - score
- Exact condition/range: Naive observers witnessed conspecific capture-and-release.
- Observed effect: Socially exposed fish showed short-term caution toward baited sham rigs, but persistence was weaker and less consistent than direct experience.
- Measured: Bait ingestion and rig avoidance
- Population/location: controlled laboratory, Germany
- Life stage: juvenile/adult experimental fish
- Evidence type: controlled social-learning experiment
- NOVA applicability: possible pressure context
- Confidence: medium
- Source: S4 (page: 498-511; section: Results)
- Limitations: Population-level effect depends on visibility, group structure and repeated exposure.
- Surrogate evidence: false
### E7. long-term memory - zero-weight
- Exact condition/range: Previously directly or socially exposed carp retested 7 and 14 months after initial trial.
- Observed effect: No convincing hook avoidance remained beyond about seven months; directly exposed fish briefly took longer to approach at seven months but ingestion did not differ over the 600-s trial.
- Measured: Approach latency and bait ingestion near sham rig
- Population/location: controlled laboratory, Germany
- Life stage: experimental fish
- Evidence type: controlled long-term retest
- NOVA applicability: important null/contradiction
- Confidence: high
- Source: S5 (page: 1; section: Abstract)
- Limitations: Does not establish the shorter decay shape between one week and seven months.
- Surrogate evidence: false
### E8. bait encounter versus capture - context-only
- Exact condition/range: Wild individually tracked common carp exposed to baited locations.
- Observed effect: Encountering bait was necessary but did not by itself explain individual vulnerability; spatial encounter metrics were not sufficient predictors of capture.
- Measured: Telemetry encounters and angling capture
- Population/location: wild lake, Germany
- Life stage: adult
- Evidence type: field telemetry/angling study
- NOVA applicability: direct null finding
- Confidence: high
- Source: S6 (section: Abstract/Results)
- Limitations: Other traits, feeding motivation and bait acceptance still matter.
- Surrogate evidence: false
### E9. strain and domestication - context-only
- Exact condition/range: Domesticated mirror carp versus less-domesticated scaled/wild-type carp in experimental environments.
- Observed effect: Domesticated carp were more vulnerable to angling and showed greater food intake/bolder foraging.
- Measured: Capture vulnerability, food intake and behavior
- Population/location: experimental ponds, Germany
- Life stage: adult experimental fish
- Evidence type: controlled angling study
- NOVA applicability: population/strain modifier only
- Confidence: medium-high
- Source: S7 (page: 174-186; section: Results)
- Limitations: Virginia populations have unknown ancestry and mixed domestication history.
- Surrogate evidence: false
### E10. behavioral phenotype - context-only
- Exact condition/range: Repeated experimental hook-and-line selection.
- Observed effect: Boldness/resource-acquisition behavior was associated with greater vulnerability and could be selected against.
- Measured: Behavioral assays and angling capture
- Population/location: experimental ponds, Germany
- Life stage: adult
- Evidence type: controlled selection study
- NOVA applicability: context for persistent individual heterogeneity
- Confidence: medium-high
- Source: S8 (page: 994-1006; section: Results)
- Limitations: Not an environmental input available to BiteMap.
- Surrogate evidence: false
### E11. prebaiting and bait acceptance - context-only
- Exact condition/range: Repeated corn-pellet conditioning in semi-natural enclosures.
- Observed effect: Carp formed feeding aggregations and accepted familiar bait, supporting prebaiting as a presentation tactic.
- Measured: Bait consumption and aggregation
- Population/location: Minnesota enclosures
- Life stage: adult
- Evidence type: semi-natural feeding experiment
- NOVA applicability: Fish Guide relevance
- Confidence: medium
- Source: S9 (page: 428-440; section: Results)
- Limitations: Management-control context, not an environmental bite coefficient.
- Surrogate evidence: false
### E12. stock and catch - zero-weight
- Exact condition/range: Multi-water recreational catch/stock records.
- Observed effect: Catch reflected stocking, abundance and fishery practice; stock-catch relationships do not isolate per-fish appetite.
- Measured: Annual stock and catch
- Population/location: Czech Republic
- Life stage: fishery population
- Evidence type: observational fishery analysis
- NOVA applicability: low for NOVA activity scoring
- Confidence: medium
- Source: S10 (section: Abstract)
- Limitations: Effort, regulations, stocking and harvest confound seasonality.
- Surrogate evidence: false
### E13. population and life history - context-only
- Exact condition/range: North American occurrence and introduced status.
- Observed effect: Confirms broad ecological plasticity and variable population histories.
- Measured: Distribution and establishment
- Population/location: North America
- Life stage: multiple
- Evidence type: federal species profile
- NOVA applicability: taxonomy/context only
- Confidence: high
- Source: S11 (section: Species profile)
- Limitations: Plasticity argues against exact cross-region threshold transfer.
- Surrogate evidence: false
### E14. weather folklore - zero-weight
- Exact condition/range: Searches for barometric pressure, fronts, lunar phase, ordinary rain, wind and cloud effects.
- Observed effect: No qualifying direct common-carp feeding or standardized angling effect was verified independent of temperature, light or effort.
- Measured: Evidence availability
- Population/location: global
- Life stage: adult fishery
- Evidence type: systematic search result
- NOVA applicability: high for zero-weight decision
- Confidence: high
- Source: S4 (section: Variables studied and discussion)
- Limitations: Absence of evidence does not prove no effect.
- Surrogate evidence: false
### E15. dissolved oxygen - unavailable
- Exact condition/range: Searches for species-specific intake/catchability at measured mg/L.
- Observed effect: Tolerance and aquaculture physiology studies were available, but no portable wild feeding or hook-and-line coefficient qualified.
- Measured: Evidence availability
- Population/location: global
- Life stage: multiple
- Evidence type: systematic search result
- NOVA applicability: high for unavailable decision
- Confidence: high
- Source: S3 (section: Study scope)
- Limitations: Do not convert survival/tolerance into bite score.
- Surrogate evidence: false

## Remaining research gaps
- Wild Mid-Atlantic temperature-feeding and standardized hook-and-line studies.
- Short-term temperature-trend and oxygen-feeding interactions.
- Field estimates of learning decay under realistic fishing pressure.
- Effort-controlled diel and moon/front tests.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2026)
**Common Carp**. Virginia DWR.
https://dwr.virginia.gov/wildlife/information/common-carp/
Scope: Virginia. Access: agency HTML. Verification: AI-reviewed-unverified.
### S2. Chen Song-bo; Chen Wei-xing; Fan Zhao-ting (2012)
**Effect of Water Temperature on Feeding Rhythm in Common Carp (Cyprinus carpio haematopterus Temminck et Schlegel)**. Journal of Northeast Agricultural University (English Edition) 19(1):57-61. DOI: 10.1016/S1006-8104(12)60039-7.
https://www.sciencedirect.com/science/article/pii/S1006810412600397
Scope: controlled aquaculture experiment, China. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S3. Dalmas O. Oyugi; Julien Cucherousset; David J. Baker; J. Robert Britton (2012)
**Temperature Effects on the Growth and Foraging of Juvenile Common Carp Cyprinus carpio**. Journal of Thermal Biology 37(1):89-94. DOI: 10.1016/j.jtherbio.2011.11.005.
https://doi.org/10.1016/j.jtherbio.2011.11.005
Scope: controlled laboratory, United Kingdom. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S4. Magnus Lovén Wallerius; Jörgen I. Johnsson; Steven J. Cooke; Robert Arlinghaus (2020)
**Hook Avoidance Induced by Private and Social Learning in Common Carp**. Transactions of the American Fisheries Society 149(4):498-511. DOI: 10.1002/tafs.10246.
https://academic.oup.com/tafs/article/149/4/498/7819381
Scope: controlled laboratory/pond-origin carp, Germany. Access: publisher full HTML/PDF. Verification: AI-reviewed-unverified.
### S5. Philipp Czapla; Magnus Lovén Wallerius; Christopher T. Monk; Steven J. Cooke; Robert Arlinghaus (2023)
**Reexamining One-Trial Learning in Common Carp (Cyprinus carpio) through Private and Social Cues: No Evidence for Hook Avoidance Lasting More than Seven Months**. Fisheries Research 259:106573. DOI: 10.1016/j.fishres.2022.106573.
https://www.fecpl.ca/wp-content/uploads/2022/11/czapla-et-al-2023.pdf
Scope: controlled laboratory, Germany. Access: author-hosted full PDF. Verification: AI-reviewed-unverified.
### S6. Christopher T. Monk; Robert Arlinghaus (2017)
**Encountering a Bait Is Necessary but Insufficient to Explain Individual Variability in Vulnerability to Angling in Two Freshwater Benthivorous Fish in the Wild**. PLOS ONE 12(3):e0173989. DOI: 10.1371/journal.pone.0173989.
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0173989
Scope: wild lake, Germany. Access: publisher full HTML/PDF. Verification: AI-reviewed-unverified.
### S7. Thomas Klefoth; Thomas Pieterek; Robert Arlinghaus (2013)
**Impacts of Domestication on Angling Vulnerability of Common Carp, Cyprinus carpio: The Role of Learning, Foraging Behaviour and Food Preferences**. Fisheries Management and Ecology 20(2-3):174-186. DOI: 10.1111/j.1365-2400.2012.00865.x.
https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1365-2400.2012.00865.x
Scope: experimental ponds, Germany. Access: author/publisher full record. Verification: AI-reviewed-unverified.
### S8. Thomas Klefoth; Christian Skov; Anna Kuparinen; Robert Arlinghaus (2017)
**Toward a Mechanistic Understanding of Vulnerability to Hook-and-Line Fishing: Boldness as the Basic Target of Angling-Induced Selection**. Evolutionary Applications 10(10):994-1006. DOI: 10.1111/eva.12504.
https://pmc.ncbi.nlm.nih.gov/articles/PMC5680629/
Scope: experimental ponds, Germany. Access: PMC full text. Verification: AI-reviewed-unverified.
### S9. Peter J. Hundt; Jon Amberg; Blake W. Sauey; Kristen Vacura; Przemyslaw G. Bajer (2020)
**Tests in a Semi-Natural Environment Suggest That Bait and Switch Strategy Could Be Used to Control Invasive Common Carp**. Management of Biological Invasions 11(3):428-440. DOI: 10.3391/mbi.2020.11.3.06.
https://www.reabic.net/journals/mbi/2020/3/MBI_2020_Hundt_etal.pdf
Scope: semi-natural enclosures, Minnesota. Access: publisher full PDF. Verification: AI-reviewed-unverified.
### S10. David S. Boukal; Martin Jankovský; Jan Kubečka; Mikko Heino (2012)
**Stock–Catch Analysis of Carp Recreational Fisheries in Czech Reservoirs: Insights into Fish Survival, Water Body Productivity and Impact of Extreme Events**. Fisheries Research 119–120:23–32. DOI: 10.1016/j.fishres.2011.12.003.
https://www.sciencedirect.com/science/article/abs/pii/S0165783611003687
Scope: Czech recreational fisheries. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S11. U.S. Geological Survey Nonindigenous Aquatic Species Program (2026)
**Common Carp (Cyprinus carpio) Species Profile**. USGS NAS.
https://nas.er.usgs.gov/queries/FactSheet.aspx?speciesID=4
Scope: North America. Access: federal agency HTML. Verification: AI-reviewed-unverified.
