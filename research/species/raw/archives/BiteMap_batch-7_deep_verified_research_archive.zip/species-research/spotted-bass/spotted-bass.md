# Spotted Bass
*Micropterus punctulatus*

- Species ID: `spotted-bass`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Proposed for bite scoring**

## Executive conclusion
Spotted bass are deliberate sportfish targets in Virginia and the Southeast. They should be proposed for bite scoring, but the reviewed evidence does not yet justify an environmental production rule; the honest current implementation is targetability plus Fish Guide/location context.

### Model-ready findings
- **context-only**: Standardized Kansas stream angling captured 0-26% of estimated reach populations, confirming direct targetability but not a portable weather response. Evidence: E2, E3.
- **unavailable**: No direct environmental feeding or catchability multiplier survived the adversarial review. Evidence: E14.

### Context-only findings
- Fish larger than 200 mm consumed broader and larger prey categories; use for presentation/size context only. Evidence: E4, E11.
- Seasonal prey shifts, stream stability and thermal preference describe diet/habitat, not bite optima. Evidence: E6, E8, E10.
- Alabama bass taxonomy and hybridization create a serious study-transfer and field-identification risk in Virginia. Evidence: E13.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The direct angling study was in small Kansas streams and did not isolate environmental predictors.
- Tag-return and angler-harvest studies are effort- and gear-selective.
- Thermal preference, establishment, habitat and diet cannot become bite rules.
- Older records may mix spotted bass with taxa later separated as Alabama bass.

## Targetability assessment
Spotted bass are deliberate sportfish targets in Virginia and the Southeast. They should be proposed for bite scoring, but the reviewed evidence does not yet justify an environmental production rule; the honest current implementation is targetability plus Fish Guide/location context.

## Candidate model rules
### R1. anglingPressure - context-only
- Condition: Brief standardized angling in small stream reaches
- Direction: possible local depletion/encounter reduction
- Strength: unquantified
- Confidence: low
- Mechanism: A finite fraction of estimated populations was caught under standardized reach-level effort.
- Evidence: E2, E3
- Double-counting risk: Do not convert 0-26% into a general pressure-decay coefficient; abundance, reach size and fish behavior are confounded.
### R2. fishSize - context-only
- Condition: Fish longer than 200 mm
- Direction: prey/presentation context only
- Strength: unquantified
- Confidence: medium
- Mechanism: Diet broadened toward larger prey categories with size.
- Evidence: E4, E11
- Double-counting risk: Size also affects gear selectivity and population structure.
### R3. seasonalPrey - context-only
- Condition: Summer and early autumn young shad availability
- Direction: presentation context
- Strength: unquantified
- Confidence: low-medium
- Mechanism: Angler-harvested fish became more piscivorous as YOY shad entered diets.
- Evidence: E6
- Double-counting risk: Do not treat prey composition as a general appetite multiplier.
### R4. waterTemperature - zero-weight
- Condition: Thermal preference or acclimation temperature
- Direction: no bite weight
- Strength: zero
- Confidence: high
- Mechanism: Preference and avoidance measure habitat choice, not feeding/catchability.
- Evidence: E8
- Double-counting risk: Avoid double counting habitat occupancy and season.
### R5. streamStabilityTurbidity - zero-weight
- Condition: Stable beds versus channelized/sedimented streams
- Direction: location only
- Strength: zero for bite
- Confidence: high
- Mechanism: Establishment success reflected habitat suitability.
- Evidence: E10
- Double-counting risk: Presence/absence is not same-day catchability.
### R6. weatherPressureMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No direct species-specific endpoint study qualified.
- Evidence: E14
- Double-counting risk: Reject folklore and related black-bass transfer.
### R7. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Diet and tag-return seasonality are effort/prey/abundance confounded.
- Evidence: E6, E9
- Double-counting risk: Avoid double counting prey, access, spawning and effort.
### R8. environmentalBiteScore - unavailable
- Condition: Any production environmental multiplier
- Direction: unavailable
- Strength: unavailable
- Confidence: high
- Mechanism: The reviewed direct angling study establishes targetability but not a portable environmental response.
- Evidence: E2
- Double-counting risk: Do not manufacture a curve from habitat or diet studies.

## Evidence ledger
### E1. targetability and regional distribution - context-only
- Exact condition/range: Native in Upper Tennessee and Big Sandy watersheds; introduced in several Virginia basins.
- Observed effect: Virginia recognizes established recreational populations and species-specific identification issues.
- Measured: Distribution and fishery relevance
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency account
- NOVA applicability: high for Virginia targetability
- Confidence: high
- Source: S1 (section: Distribution and Diet)
- Limitations: Agency profile is not a quantitative bite study.
- Surrogate evidence: false
### E2. hook-and-line catchability - context-only
- Exact condition/range: Standardized bank angling before three-pass electrofishing in four Kansas streams; stock-length fish at least 180 mm.
- Observed effect: Mean angler catch was about 0.39 fish per hour; 0-26% of estimated reach populations were caught, with potential harvest estimated at 5.1 fish/ha.
- Measured: Standardized angler CPUE and fraction of estimated population captured
- Population/location: Kansas streams
- Life stage: stock length and larger
- Evidence type: controlled field angling study
- NOVA applicability: direct endpoint but geography and closed-reach design limit transfer
- Confidence: medium-high
- Source: S2 (section: Abstract and KSU project summary)
- Limitations: No weather or environmental covariate produced a portable scoring rule; population estimates and reach closure affect percentages.
- Surrogate evidence: false
### E3. fish abundance versus catchability - context-only
- Exact condition/range: Four streams had roughly 3-5 stock fish per 100 m and 21-63 fish/ha.
- Observed effect: Angling removals varied substantially among reaches despite standardized protocol.
- Measured: Population abundance and angling removal
- Population/location: Kansas streams
- Life stage: stock length and larger
- Evidence type: controlled field angling study
- NOVA applicability: supports targetability and warns against equating abundance with per-fish vulnerability
- Confidence: medium
- Source: S2 (section: Abstract and KSU history page 65)
- Limitations: Small sample of streams; environmental drivers were not isolated.
- Surrogate evidence: false
### E4. prey and fish size - context-only
- Exact condition/range: 672 fish sampled April-November; fish longer than 200 mm.
- Observed effect: Larger fish consumed more crayfish, fish, vertebrates, and aquatic/terrestrial insects by number.
- Measured: Stomach contents by fish length
- Population/location: Lake Pontchartrain Basin streams
- Life stage: juvenile and adult
- Evidence type: field diet study
- NOVA applicability: moderate guide relevance; not catchability
- Confidence: high
- Source: S3 (page: 17-24; section: Results)
- Limitations: Diet occurrence does not quantify feeding rate or lure response.
- Surrogate evidence: false
### E5. stream size and prey - context-only
- Exact condition/range: Wadeable versus non-wadeable reaches across 53 sites.
- Observed effect: Crayfish and fish occurred more frequently in diets from wadeable streams.
- Measured: Diet occurrence by stream type
- Population/location: Mississippi and Louisiana
- Life stage: juvenile and adult
- Evidence type: field diet study
- NOVA applicability: habitat/prey context only
- Confidence: medium-high
- Source: S3 (page: 17-24; section: Results)
- Limitations: Stream type bundles depth, current, prey and sampling differences.
- Surrogate evidence: false
### E6. seasonal diet - context-only
- Exact condition/range: March 1971-February 1972, 263 angler-harvested spotted bass.
- Observed effect: Spotted bass fed heavily on crayfish; black basses became more piscivorous in summer and early autumn as young shad entered diets.
- Measured: Stomach-content frequency, weight and seasonal distribution
- Population/location: Bull Shoals Reservoir
- Life stage: angler-harvested juveniles/adults
- Evidence type: field diet study
- NOVA applicability: moderate presentation context
- Confidence: medium-high
- Source: S4 (page: 519-529; section: Results tables)
- Limitations: Angler harvest is gear-selective and seasonality may reflect prey availability rather than appetite.
- Surrogate evidence: false
### E7. prey community - context-only
- Exact condition/range: Every-other-month sampling October 2006-August 2007.
- Observed effect: Spotted-bass diet by weight was dominated by crayfish, with lesser sunfish and shad; modeled consumption varied with prey and bioenergetic assumptions.
- Measured: Diet composition and modeled consumptive demand
- Population/location: Lewis Smith Lake, Alabama
- Life stage: juvenile/adult
- Evidence type: thesis field diet plus model
- NOVA applicability: contextual, reservoir-specific
- Confidence: medium
- Source: S5 (section: Abstract; spotted bass diet and bioenergetics chapters)
- Limitations: Modeled demand is not observed bite rate; striped-bass stocking study context differs from NOVA.
- Surrogate evidence: false
### E8. thermal preference - zero-weight
- Exact condition/range: Fish tested at multiple acclimation temperatures in a thermal gradient.
- Observed effect: Spotted bass selected and avoided temperature zones, demonstrating acclimation-dependent behavioral thermoregulation.
- Measured: Selected and avoided temperatures
- Population/location: laboratory
- Life stage: unspecified mixed size
- Evidence type: controlled laboratory behavior
- NOVA applicability: physiological/habitat context only
- Confidence: medium
- Source: S6 (page: 485-491; section: Abstract/Results)
- Limitations: Thermal preference is not a feeding optimum and exact thresholds should not transfer without full species table review.
- Surrogate evidence: false
### E9. season and catch records - context-only
- Exact condition/range: 1,749 spotted bass tagged in winter 1961-62; reward-tag returns and creel census.
- Observed effect: Tag returns described seasonal fishery availability and exploitation in Allatoona Reservoir.
- Measured: Tag returns and creel observations
- Population/location: Allatoona Reservoir, Georgia
- Life stage: adult fishery
- Evidence type: tagging/creel study
- NOVA applicability: low portability and effort-confounded
- Confidence: medium
- Source: S7 (page: 242-255; section: Results)
- Limitations: Season, surface temperature, effort, access, tag reporting and abundance were not separable enough for a bite rule.
- Surrogate evidence: false
### E10. habitat stability and turbidity - zero-weight
- Exact condition/range: More than 28,000 fingerlings stocked into 16 Missouri streams, 1961-1968.
- Observed effect: Fisheries established in stable, less-channelized streams; failures were associated with shifting beds, channelization and sedimentation.
- Measured: Establishment, reproduction and electrofishing occurrence
- Population/location: Missouri streams
- Life stage: stocked juveniles through established populations
- Evidence type: agency field study
- NOVA applicability: habitat suitability only
- Confidence: medium
- Source: S8 (page: 28-35; section: Abstract/Results)
- Limitations: Establishment and persistence do not measure feeding or catchability.
- Surrogate evidence: false
### E11. prey size and predator size - context-only
- Exact condition/range: Measured or estimated forage lengths swallowable by spotted bass of given lengths.
- Observed effect: Maximum ingestible prey size increased with predator length and differed among forage species.
- Measured: Morphological prey-size capacity
- Population/location: laboratory/specimen-based
- Life stage: multiple sizes
- Evidence type: feeding mechanics study
- NOVA applicability: Fish Guide use only
- Confidence: medium
- Source: S9 (page: 235-236; section: Record/summary)
- Limitations: Capacity to swallow prey is not feeding probability or environmental activity.
- Surrogate evidence: false
### E12. life stage and diet transition - context-only
- Exact condition/range: YOY fish collected during 1964-1965 reservoir filling.
- Observed effect: Small fish frequently consumed entomostracans; insects were common across sizes; larger YOY bass increasingly consumed fish.
- Measured: Stomach-content occurrence by length
- Population/location: Beaver Reservoir, Arkansas
- Life stage: young-of-year
- Evidence type: field diet study
- NOVA applicability: life-stage context only
- Confidence: medium-high
- Source: S10 (page: 510-516; section: Abstract/Results)
- Limitations: YOY reservoir-filling conditions do not transfer to adult angling.
- Surrogate evidence: false
### E13. taxonomy/population - context-only
- Exact condition/range: Alabama bass formerly treated as a spotted-bass subspecies and nearly identical in appearance.
- Observed effect: Virginia reports Alabama bass hybridization and identification risk with spotted bass.
- Measured: Taxonomy, identification and hybridization
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency account
- NOVA applicability: high transfer warning
- Confidence: high
- Source: S11 (section: Overview)
- Limitations: Studies of Alabama bass must not be silently assigned to Micropterus punctulatus.
- Surrogate evidence: false
### E14. weather folklore - zero-weight
- Exact condition/range: Searches for pressure, fronts, moon, wind and cloud effects.
- Observed effect: No qualifying direct spotted-bass feeding or standardized catchability study was verified.
- Measured: Evidence availability
- Population/location: North America
- Life stage: adult fishery
- Evidence type: systematic search result
- NOVA applicability: high for zero-weight decision
- Confidence: high
- Source: S2 (section: Study scope and excluded variables)
- Limitations: Absence of evidence is not evidence of no biological effect.
- Surrogate evidence: false

## Remaining research gaps
- Adult Mid-Atlantic standardized catchability studies with temperature, light, flow and pressure covariates.
- Direct dissolved-oxygen and turbidity feeding experiments.
- Replicated hook-learning/depletion studies.
- Genetically confirmed Virginia spotted-bass studies separated from Alabama bass and hybrids.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2025)
**Spotted Bass**. Virginia DWR.
https://dwr.virginia.gov/wildlife/information/spotted-bass/
Scope: Virginia. Access: agency HTML. Verification: AI-reviewed-unverified.
### S2. Travis B. Horton; Jeffery S. Tillma; Christopher S. Guy (2000)
**Vulnerability of Spotted Bass to Angling in Kansas Streams**. Journal of Freshwater Ecology 15(1):7-11. DOI: 10.1080/02705060.2000.9663717.
https://www.tandfonline.com/doi/abs/10.1080/02705060.2000.9663717
Scope: four Kansas streams. Access: publisher abstract plus KSU project report. Verification: AI-reviewed-unverified.
### S3. J. Brian Alford; Brian Heimann (2016)
**Spotted Bass Population Structure and Diet in Wadeable and Non-wadeable Streams Draining the Lake Pontchartrain Basin**. SEAFWA Journal 3:17-24.
https://seafwa.org/journal/2016/spotted-bass-population-structure-and-diet-wadeable-and-non-wadeable-streams-draining
Scope: Mississippi and Louisiana streams. Access: publisher full HTML/PDF. Verification: AI-reviewed-unverified.
### S4. Larry R. Aggus (1973)
**Food of Angler Harvested Largemouth, Spotted and Smallmouth Bass in Bull Shoals Reservoir**. Proceedings of the Annual Conference Southeastern Association of Game and Fish Commissioners 26:519-529.
https://seafwa.org/sites/default/files/journal-articles/AGGUS-519.pdf
Scope: Bull Shoals Reservoir, Arkansas-Missouri. Access: publisher full PDF. Verification: AI-reviewed-unverified.
### S5. Michael Shepherd (2008)
**Effects of Striped Bass Stocking on Largemouth Bass and Spotted Bass in Lewis Smith Lake, Alabama**. Auburn University MS thesis.
http://hdl.handle.net/10415/1096
Scope: Lewis Smith Lake, Alabama. Access: university repository full PDF. Verification: AI-reviewed-unverified.
### S6. Donald S. Cherry; Kenneth L. Dickson; John Cairns Jr. (1975)
**Temperatures Selected and Avoided by Fish at Various Acclimation Temperatures**. Journal of the Fisheries Research Board of Canada 32(4):485-491. DOI: 10.1139/f75-059.
https://cdnsciencepub.com/doi/10.1139/f75-059
Scope: laboratory; multiple freshwater fishes including spotted bass. Access: publisher abstract/record. Verification: AI-reviewed-unverified.
### S7. Leon Kirkland (1963)
**Results of a Tagging Study on the Spotted Bass, Micropterus punctulatus**. Proceedings of the Annual Conference Southeastern Association of Game and Fish Commissioners 17:242-255.
https://seafwa.org/proceedings?field_year_target_id=All&items_per_page=50&keys=&order=field_year&page=76&sort=asc
Scope: Allatoona Reservoir, Georgia. Access: publisher abstract and proceedings PDF. Verification: AI-reviewed-unverified.
### S8. Otto F. Fajen (1975)
**The Establishment of Spotted Bass Fisheries in Some Northern Missouri Streams**. Proceedings of the Annual Conference Southeastern Association of Game and Fish Commissioners 28:28-35.
https://seafwa.org/journal/1975/establishment-spotted-bass-fisheries-some-northern-missouri-streams
Scope: Missouri streams. Access: publisher full HTML/PDF. Verification: AI-reviewed-unverified.
### S9. J. M. Lawrence (1961)
**Estimated Lengths of Various Forage Fishes Spotted Bass Can Swallow**. Proceedings of the Annual Conference Southeastern Association of Game and Fish Commissioners 15:235-236.
https://seafwa.org/journal?page=168
Scope: laboratory or specimen-based feeding measurements. Access: publisher abstract/record. Verification: AI-reviewed-unverified.
### S10. Ronald G. Hodson (1968)
**Food of Young-of-the-Year Largemouth and Spotted Bass During the Filling of Beaver Reservoir, Arkansas**. Proceedings of the Annual Conference Southeastern Association of Game and Fish Commissioners 22:510-516.
https://seafwa.org/proceedings?field_year_target_id=All&id=5573&items_per_page=50&keys=&order=field_year&page=22&sort=desc
Scope: Beaver Reservoir, Arkansas. Access: publisher abstract/full PDF. Verification: AI-reviewed-unverified.
### S11. Virginia Department of Wildlife Resources (2024)
**Alabama Bass**. Virginia DWR.
https://dwr.virginia.gov/wildlife/information/alabama-bass/
Scope: Virginia. Access: agency HTML. Verification: AI-reviewed-unverified.
