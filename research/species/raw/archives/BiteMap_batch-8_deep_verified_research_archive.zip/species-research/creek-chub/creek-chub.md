# Creek Chub
*Semotilus atromaculatus*

- Species ID: `creek-chub`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Proposed for bite scoring**

## Executive conclusion
Creek chub are common, locally catchable Northern Virginia stream fish and directly strike artificial lures. One field diel-feeding result supports proposed bite scoring, but temperature and habitat findings remain context-only.

### Model-ready findings
- **score**: Summer field data found creek-chub feeding most intense in early evening and least intense in the morning. Evidence: E2.

### Context-only findings
- Temperature effects were strongly dependent on brook-trout/brown-trout competition and should not become a simple warming bonus. Evidence: E6, E7, E12.
- Spawning current, cover use, movement and personality are location or Fish Guide context. Evidence: E5, E9, E10.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The strongest feeding-periodicity study is from one Minnesota summer.
- Competition experiments used juvenile laboratory fish and cannot isolate an absolute creek-chub optimum.
- Movement and cortisol studies did not measure feeding or capture.
- Local agency accounts establish targetability but not environmental effect sizes.

## Targetability assessment
Creek chub are common, locally catchable Northern Virginia stream fish and directly strike artificial lures. One field diel-feeding result supports proposed bite scoring, but temperature and habitat findings remain context-only.

## Candidate model rules
### R1. timeOfDay - score
- Condition: Summer in comparable small streams: early evening versus morning
- Direction: positive
- Strength: low-moderate
- Confidence: medium-high
- Mechanism: Field stomach-content data showed greatest feeding intensity in early evening.
- Evidence: E2
- Double-counting risk: Do not double count sunset, terrestrial insect input and season.
### R2. seasonWithinSummer - context-only
- Condition: Later versus earlier summer in the Minnesota study
- Direction: negative context
- Strength: unquantified
- Confidence: medium
- Mechanism: Observed feeding intensity declined over the sampled summer.
- Evidence: E3
- Double-counting risk: Prey, temperature and sampling date are confounded; no monthly curve.
### R3. temperatureCompetitorInteraction - context-only
- Condition: 18-22 C with brook trout present, or broader 3-26 C paired trials
- Direction: context-dependent
- Strength: unquantified
- Confidence: high
- Mechanism: Temperature shifted competitive feeding and aggression.
- Evidence: E6, E7
- Double-counting risk: Requires competitor identity/abundance; do not apply as simple temperature score.
### R4. waterTemperature - zero-weight
- Condition: Any single-species optimum inferred from competition experiments
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No clean single-species response qualified.
- Evidence: E12
- Double-counting risk: Avoid double counting trout stress and competitive release.
### R5. currentVelocity - context-only
- Condition: More than 15 cm/s at shallow spawning sites
- Direction: location context only
- Strength: unquantified
- Confidence: medium
- Mechanism: Measured condition described spawning habitat.
- Evidence: E5
- Double-counting risk: Not a bite or feeding threshold.
### R6. coverAndMovement - context-only
- Condition: Available covered habitat patches in low-gradient streams
- Direction: location context
- Strength: unquantified
- Confidence: medium
- Mechanism: Creek chub moved among patches and used cover.
- Evidence: E10
- Double-counting risk: Movement is not appetite.
### R7. dissolvedOxygenTurbidity - unavailable
- Condition: Any threshold
- Direction: unavailable
- Strength: unavailable
- Confidence: high
- Mechanism: No direct feeding/catchability evidence.
- Evidence: E13
- Double-counting risk: Do not use tolerance classifications.
### R8. weatherPressureMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct evidence.
- Evidence: E14
- Double-counting risk: Reject folklore.
### R9. monthlyActivity - zero-weight
- Condition: Fixed monthly curve
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No direct monthly curve.
- Evidence: E15
- Double-counting risk: Separate diel, spawn and prey processes.
### R10. lureTargetability - context-only
- Condition: Small artificial lures and trout-sized offerings
- Direction: Fish Guide only
- Strength: unquantified
- Confidence: medium
- Mechanism: Regional agencies document deliberate captures.
- Evidence: E1
- Double-counting risk: Not an environmental multiplier.

## Evidence ledger
### E1. targetability and local occurrence - context-only
- Exact condition/range: Fairfax County stream surveys and agency description.
- Observed effect: Creek chub are locally common and grow large enough to be caught on artificial lures; Maryland notes they readily strike trout lures.
- Measured: Regional occurrence and intentional hook-and-line practicality
- Population/location: Northern Virginia and Maryland
- Life stage: adult
- Evidence type: agency species accounts
- NOVA applicability: direct local targetability
- Confidence: high
- Source: S1 (section: Creek Chub)
- Limitations: Not a standardized CPUE study.
- Surrogate evidence: false
### E2. time of day - score
- Exact condition/range: Summer field sampling in a Minnesota stream.
- Observed effect: Feeding was most intense in early evening and least intense in the morning.
- Measured: Stomach fullness/feeding intensity by diel interval
- Population/location: Minnesota stream
- Life stage: mixed sizes
- Evidence type: field diet study
- NOVA applicability: moderate transfer to similar small streams
- Confidence: medium-high
- Source: S3 (page: 283-289; section: Results/feeding periodicity)
- Limitations: Single region and summer; terrestrial prey drift and light may be mechanisms.
- Surrogate evidence: false
### E3. seasonal feeding - context-only
- Exact condition/range: Summer sampling across the study period.
- Observed effect: Feeding intensity declined as summer progressed.
- Measured: Stomach-content feeding intensity
- Population/location: Minnesota stream
- Life stage: mixed sizes
- Evidence type: field diet study
- NOVA applicability: context only
- Confidence: medium
- Source: S3 (page: 283-289; section: Results)
- Limitations: Calendar timing, prey availability, temperature and fish condition were not separated.
- Surrogate evidence: false
### E4. prey availability - context-only
- Exact condition/range: Summer diet observations.
- Observed effect: Food composition broadly reflected prey availability, with creek chub using aquatic and terrestrial prey.
- Measured: Diet composition and environmental prey samples
- Population/location: Minnesota stream
- Life stage: mixed sizes
- Evidence type: field diet study
- NOVA applicability: Fish Guide and forage context
- Confidence: medium-high
- Source: S3 (page: 283-289; section: Food results)
- Limitations: Diet occurrence does not establish bite response to weather.
- Surrogate evidence: false
### E5. spawning habitat and flow - context-only
- Exact condition/range: Mink River spawning in mid-to-late May; water shallower than 25 cm and current faster than 15 cm/s.
- Observed effect: Spawning occurred in shallow, relatively fast water and habitats differed by age.
- Measured: Spawning place/time and habitat occupancy
- Population/location: Mink River, Manitoba
- Life stage: adult/juvenile
- Evidence type: field life-history study
- NOVA applicability: regional context only
- Confidence: medium
- Source: S4 (page: 357-362; section: Abstract/results)
- Limitations: Current used for spawning is not a feeding or catchability optimum.
- Surrogate evidence: false
### E6. temperature x competitor interaction - context-only
- Exact condition/range: Fish tested at 18, 20 and 22 C alone and with brook trout.
- Observed effect: Warming changed competitive feeding and aggression; creek chub retained or gained relative advantage while brook-trout feeding declined in paired trials.
- Measured: Prey consumption and aggression
- Population/location: controlled laboratory; Appalachian-source fish
- Life stage: juvenile
- Evidence type: controlled experiment
- NOVA applicability: mechanistically relevant but competitor abundance is required
- Confidence: high
- Source: S5 (section: Methods and Results; Figures 2-5)
- Limitations: Does not support a simple creek-chub temperature bonus when alone.
- Surrogate evidence: false
### E7. broader temperature competition - context-only
- Exact condition/range: 3-26 C experiments with creek chub, brook trout and brown trout.
- Observed effect: Creek chub competitive success increased at warm treatments, becoming dominant against trout around 22-26 C.
- Measured: Food consumption and aggression in paired trials
- Population/location: laboratory, Wyoming
- Life stage: juvenile
- Evidence type: controlled competition experiment
- NOVA applicability: context for species interactions
- Confidence: high
- Source: S6 (page: 1894-1901; section: Results; figures)
- Limitations: Warm temperatures also stressed trout; relative dominance is not absolute feeding optimum.
- Surrogate evidence: false
### E8. short-term physiological stress - zero-weight
- Exact condition/range: Cortisol challenge in mesocosm and natural stream trials.
- Observed effect: No clear difference in fine-scale movement, larger movement or diel activity was detected after the short-term cortisol treatment.
- Measured: Movement and activity
- Population/location: Ontario stream/mesocosm
- Life stage: wild adults
- Evidence type: controlled field/mesocosm experiment
- NOVA applicability: useful null for activity inference
- Confidence: medium-high
- Source: S7 (page: 1138-1158; section: Results)
- Limitations: Feeding and angling were not measured; mortality effects occurred later.
- Surrogate evidence: false
### E9. personality and body size - context-only
- Exact condition/range: Repeated boldness, exploration and activity assays across populations.
- Observed effect: Behavioral traits were repeatable; larger individuals tended to be less active and population differences occurred.
- Measured: Behavioral assays
- Population/location: multiple populations
- Life stage: juvenile/adult
- Evidence type: controlled behavior study
- NOVA applicability: individual heterogeneity context
- Confidence: medium-high
- Source: S8 (section: Abstract and Results)
- Limitations: Personality is not a real-time environmental input or direct catchability endpoint.
- Surrogate evidence: false
### E10. movement and cover - context-only
- Exact condition/range: Two-week summer mark-recapture in a low-gradient sand stream.
- Observed effect: About 44% changed habitat patches; median movement was approximately 49 m and cover influenced patch use.
- Measured: Movement among habitat patches
- Population/location: Wyoming plains stream
- Life stage: mixed sizes
- Evidence type: field movement study
- NOVA applicability: location context only
- Confidence: medium-high
- Source: S9 (page: 258-272; section: Abstract/results)
- Limitations: Movement and cover occupancy do not establish feeding.
- Surrogate evidence: false
### E11. lake resource partitioning - context-only
- Exact condition/range: Co-occurring brook trout and creek chub in oligotrophic Quebec lakes.
- Observed effect: Species partitioned resources and habitat; interactions varied with community context.
- Measured: Diet and habitat use
- Population/location: southern Quebec lakes
- Life stage: mixed sizes
- Evidence type: field ecology study
- NOVA applicability: waterbody-transfer warning
- Confidence: medium
- Source: S10 (page: 1612-1617; section: Abstract/results)
- Limitations: Lake results should not set stream bite rules.
- Surrogate evidence: false
### E12. thermal optimum - zero-weight
- Exact condition/range: Direct feeding experiments included temperature but only within competitor designs.
- Observed effect: No portable single-species thermal feeding optimum was verified.
- Measured: Evidence synthesis
- Population/location: laboratory and field range
- Life stage: juvenile/mixed
- Evidence type: adversarial synthesis
- NOVA applicability: high for zero-weight
- Confidence: high
- Source: S5 (section: Discussion)
- Limitations: Competition, appetite and trout stress are intertwined.
- Surrogate evidence: false
### E13. dissolved oxygen and turbidity - unavailable
- Exact condition/range: Searches for measured oxygen/turbidity feeding or hook-and-line effects.
- Observed effect: No qualifying direct creek-chub coefficient was verified.
- Measured: Evidence availability
- Population/location: range-wide
- Life stage: multiple
- Evidence type: documented search
- NOVA applicability: high
- Confidence: high
- Source: S11 (section: Species profile and references)
- Limitations: Do not infer from occurrence in tolerant streams.
- Surrogate evidence: false
### E14. weather and moon - zero-weight
- Exact condition/range: Pressure, fronts, moon phase, wind, cloud and rainfall searches.
- Observed effect: No qualifying direct creek-chub feeding or catchability study was verified.
- Measured: Evidence availability
- Population/location: range-wide
- Life stage: adult fishery
- Evidence type: documented search
- NOVA applicability: high
- Confidence: high
- Source: S1 (section: Variables absent from agency account)
- Limitations: Absence of evidence is not proof of no biological effect.
- Surrogate evidence: false
### E15. monthly activity - zero-weight
- Exact condition/range: Spawning, summer diet and movement evidence.
- Observed effect: No direct numerical month-by-month per-fish activity curve qualified.
- Measured: Evidence availability
- Population/location: North America
- Life stage: multiple
- Evidence type: adversarial synthesis
- NOVA applicability: high
- Confidence: high
- Source: S3 (page: 283-289; section: Study period)
- Limitations: Do not transform seasonal observations into monthly scores.
- Surrogate evidence: false

## Remaining research gaps
- Mid-Atlantic hook-and-line CPUE studies across time of day and seasons.
- Single-species adult temperature-feeding experiments.
- Dissolved oxygen, turbidity, light and flow-change effects on feeding.
- Recent angling-pressure and learning studies.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Fairfax County Public Works and Environmental Services (n.d.)
**Minnows: Creek Chub**. Fairfax County Government.
https://www.fairfaxcounty.gov/publicworks/stormwater/fish/minnows
Scope: Fairfax County, Virginia. Access: county HTML. Verification: AI-reviewed-unverified.
### S2. Maryland Department of Natural Resources, Maryland Biological Stream Survey (n.d.)
**Creek Chub**. Maryland DNR.
https://eyesonthebay.dnr.maryland.gov/mbss/SA_spec6.cfm?species=Creek+chub
Scope: Maryland. Access: agency HTML. Verification: AI-reviewed-unverified.
### S3. Willard E. Barber; W. L. Minckley (1971)
**Summer Foods of the Cyprinid Fish Semotilus atromaculatus**. Transactions of the American Fisheries Society 100(2):283-289. DOI: 10.1577/1548-8659(1971)100<283:SFOTCF>2.0.CO;2.
https://academic.oup.com/tafs/article/100/2/283/7894466
Scope: Minnesota stream. Access: publisher record and original PDF. Verification: AI-reviewed-unverified.
### S4. Robert W. Moshenko; John H. Gee (1973)
**Diet, Time and Place of Spawning, and Environments Occupied by Creek Chub (Semotilus atromaculatus) in the Mink River, Manitoba**. Journal of the Fisheries Research Board of Canada 30(3):357-362. DOI: 10.1139/f73-065.
https://cdnsciencepub.com/doi/10.1139/f73-065
Scope: Mink River, Manitoba. Access: publisher record/abstract. Verification: AI-reviewed-unverified.
### S5. Bryan R. Colby; Jonathan M. Niles; Matthew H. Persons; Matthew J. Wilson (2022)
**Shifting thermal regimes influence competitive feeding and aggression dynamics of brook trout (Salvelinus fontinalis) and creek chub (Semotilus atromaculatus)**. Ecology and Evolution 12:e9056. DOI: 10.1002/ece3.9056.
https://pmc.ncbi.nlm.nih.gov/articles/PMC9251879/
Scope: laboratory fish from central Appalachian streams. Access: open-access full text. Verification: AI-reviewed-unverified.
### S6. Yoshinori Taniguchi; Frank J. Rahel; Douglas C. Novinger; Kenneth G. Gerow (1998)
**Temperature mediation of competitive interactions among three fish species that replace each other along longitudinal stream gradients**. Canadian Journal of Fisheries and Aquatic Sciences 55:1894-1901. DOI: 10.1139/f98-072.
https://www.uwyo.edu/dbmcd/people/faculty/rahel/publications/taniguchi-rahel-novinger-gerow-1998.pdf
Scope: laboratory, Wyoming. Access: author-hosted full PDF. Verification: AI-reviewed-unverified.
### S7. A. Nagrodski; K. J. Murchie; K. M. Stamplecoskie; C. D. Suski; S. J. Cooke (2013)
**Effects of an experimental short-term cortisol challenge on the behaviour of wild creek chub Semotilus atromaculatus in mesocosm and stream environments**. Journal of Fish Biology 82:1138-1158. DOI: 10.1111/jfb.12049.
https://onlinelibrary.wiley.com/doi/10.1111/jfb.12049
Scope: Ontario, Canada. Access: publisher record and full PDF. Verification: AI-reviewed-unverified.
### S8. Jacob P. Barrett; Mollie F. Cashner (2024)
**An investigation of personality in the Creek Chub, Semotilus atromaculatus**. Environmental Biology of Fishes 107:1497-1513. DOI: 10.1007/s10641-024-01630-2.
https://link.springer.com/article/10.1007/s10641-024-01630-2
Scope: multiple North American creek-chub populations. Access: publisher full HTML. Verification: AI-reviewed-unverified.
### S9. Laura A. T. Belica; Frank J. Rahel (2008)
**Movements of creek chubs, Semotilus atromaculatus, among habitat patches in a plains stream**. Ecology of Freshwater Fish 17(2):258-272. DOI: 10.1111/j.1600-0633.2007.00277.x.
https://onlinelibrary.wiley.com/doi/10.1111/j.1600-0633.2007.00277.x
Scope: low-gradient plains stream, Wyoming. Access: publisher abstract/record. Verification: AI-reviewed-unverified.
### S10. Pierre Magnan; Gerald J. Fitzgerald (1982)
**Resource partitioning between brook trout (Salvelinus fontinalis Mitchill) and creek chub (Semotilus atromaculatus Mitchill) in selected oligotrophic lakes of southern Quebec**. Canadian Journal of Zoology 60:1612-1617. DOI: 10.1139/z82-211.
https://cdnsciencepub.com/doi/10.1139/z82-211
Scope: southern Quebec lakes. Access: publisher abstract/record. Verification: AI-reviewed-unverified.
### S11. U.S. Geological Survey Nonindigenous Aquatic Species Program (n.d.)
**Creek Chub (Semotilus atromaculatus) Species Profile**. USGS.
https://nas.er.usgs.gov/queries/factsheet.aspx?SpeciesID=649
Scope: North America. Access: federal HTML profile. Verification: AI-reviewed-unverified.
