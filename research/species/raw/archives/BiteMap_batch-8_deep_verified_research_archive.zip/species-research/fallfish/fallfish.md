# Fallfish
*Semotilus corporalis*

- Species ID: `fallfish`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Proposed for bite scoring**

## Executive conclusion
Fallfish are intentionally targetable in Virginia and Maryland and have one direct feeding-periodicity predictor. Proposed bite scoring is scientifically defensible only as a low-strength, season- and habitat-bounded diel candidate.

### Model-ready findings
- **score**: A single summer river study found a distinct late-day/evening feeding peak; this supports only a bounded low-strength diel candidate. Evidence: E2.

### Context-only findings
- Exceptional salmon egg and parr pulses changed fallfish diets, but those prey subsidies are not transferable to NOVA calendar rules. Evidence: E6, E7.
- Spawning temperature, habitat overlap and waterbody occupancy remain context-only. Evidence: E4, E8, E9.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The only direct diel study sampled one summer 24-hour period in New York.
- Salmon egg/parr studies concern an unusual prey subsidy absent in Northern Virginia.
- Spawning onset and warming-related habitat overlap do not establish bite optima.
- Agency lure guidance is not a controlled gear comparison.

## Targetability assessment
Fallfish are intentionally targetable in Virginia and Maryland and have one direct feeding-periodicity predictor. Proposed bite scoring is scientifically defensible only as a low-strength, season- and habitat-bounded diel candidate.

## Candidate model rules
### R1. timeOfDay - score
- Condition: Summer, comparable river habitat: late-day/evening relative to other sampled diel intervals
- Direction: positive
- Strength: low
- Confidence: medium
- Mechanism: A field stomach-content study found a distinct diel feeding peak.
- Evidence: E2
- Double-counting risk: Do not double count sunset, terrestrial-insect fall, season and water clarity.
### R2. preyPulse - context-only
- Condition: Locally concentrated energy-rich prey such as exposed eggs or newly emerged small fish
- Direction: positive context
- Strength: unquantified
- Confidence: medium
- Mechanism: Fallfish exploited exceptional salmon egg/parr pulses.
- Evidence: E6, E7
- Double-counting risk: NOVA lacks the studied Pacific-salmon subsidy; use prey observations, not calendar dates.
### R3. fishSize - context-only
- Condition: At least 100-150 mm in the salmon-egg study
- Direction: diet shift toward larger/high-energy prey
- Strength: unquantified
- Confidence: high
- Mechanism: Gape and foraging ability changed prey use.
- Evidence: E6
- Double-counting risk: Do not convert diet shift into catchability or a generic size bonus.
### R4. spawningStage - context-only
- Condition: Observed spawning near 14.4 C in Massachusetts
- Direction: location context only
- Strength: unquantified
- Confidence: medium
- Mechanism: Adults aggregate and construct communal gravel nests.
- Evidence: E4
- Double-counting risk: Spawning and nest aggregation do not prove feeding.
### R5. waterTemperature - zero-weight
- Condition: Any universal feeding optimum inferred from spawning, distribution or warming studies
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No direct temperature-feeding curve qualified.
- Evidence: E4, E8, E11
- Double-counting risk: Avoid double counting season and habitat occupancy.
### R6. dissolvedOxygen - unavailable
- Condition: Any mg/L category
- Direction: unavailable
- Strength: unavailable
- Confidence: high
- Mechanism: No direct feeding/catchability endpoint qualified.
- Evidence: E12
- Double-counting risk: Tolerance or occurrence must not be substituted.
### R7. weatherPressureFronts - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct evidence.
- Evidence: E13
- Double-counting risk: Reject folklore.
### R8. moonPhase - zero-weight
- Condition: Any phase
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct evidence.
- Evidence: E13
- Double-counting risk: Do not infer from nighttime angling anecdotes.
### R9. monthlyActivity - zero-weight
- Condition: Fixed numerical monthly curve
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No direct monthly per-fish curve.
- Evidence: E14
- Double-counting risk: Separate temperature, spawn, prey and access.
### R10. lureAndBait - context-only
- Condition: Small flies, jigs, spinners, plugs and live bait
- Direction: Fish Guide only
- Strength: unquantified
- Confidence: medium
- Mechanism: Regional agencies document practical intentional targeting.
- Evidence: E10
- Double-counting risk: Not an environmental score input.

## Evidence ledger
### E1. targetability and regional relevance - context-only
- Exact condition/range: Virginia rivers and streams; adults may exceed 15-20 inches.
- Observed effect: Virginia DWR describes deliberate ultralight and fly-fishing for an aggressive, hard-fighting native fish.
- Measured: Intentional recreational targeting and regional distribution
- Population/location: Virginia
- Life stage: adult
- Evidence type: agency fishery account
- NOVA applicability: directly applicable to NOVA targetability
- Confidence: high
- Source: S1 (section: Article body, paragraphs 3-12)
- Limitations: Agency feature is not a standardized catchability experiment.
- Surrogate evidence: false
### E2. time of day - score
- Exact condition/range: One 24-hour summer sampling period in the Salmon River, New York.
- Observed effect: Fallfish displayed a distinct feeding peak; supporting study materials place the peak late in the day/evening.
- Measured: Stomach fullness/food consumption over diel intervals
- Population/location: Salmon River, New York
- Life stage: mixed sizes
- Evidence type: field diel diet study
- NOVA applicability: moderate ecological similarity but single river and season
- Confidence: medium
- Source: S4 (page: 326-334; section: Abstract and diel-feeding results)
- Limitations: Exact clock time, water clarity, prey drift and season may not transfer.
- Surrogate evidence: false
### E3. diet composition - context-only
- Exact condition/range: Same summer 24-hour study.
- Observed effect: Terrestrial invertebrates comprised about 30% of fallfish food and diet overlap with other cyprinids was moderate.
- Measured: Stomach contents and diet-overlap indices
- Population/location: Salmon River, New York
- Life stage: mixed sizes
- Evidence type: field diet study
- NOVA applicability: Fish Guide/prey context only
- Confidence: medium-high
- Source: S4 (page: 326-334; section: Abstract)
- Limitations: Diet composition does not establish lure response or a universal activity multiplier.
- Surrogate evidence: false
### E4. spawning temperature - context-only
- Exact condition/range: Spawning observed when water reached approximately 14.4 C in Massachusetts.
- Observed effect: Spawning began at the observed temperature; eggs hatched in 138-144 hours at 17.0 +/- 0.5 C.
- Measured: Spawning timing and egg development
- Population/location: Massachusetts streams
- Life stage: adults/eggs
- Evidence type: field and developmental study
- NOVA applicability: regional seasonal context only
- Confidence: medium-high
- Source: S3 (page: 717-725; section: Spawning and development)
- Limitations: Spawning threshold is not a feeding optimum or catchability rule.
- Surrogate evidence: false
### E5. general diet - context-only
- Exact condition/range: Seasonal stomach sampling in Massachusetts.
- Observed effect: Fallfish were omnivorous and consumed a broad range of aquatic and terrestrial food items.
- Measured: Stomach contents
- Population/location: Massachusetts streams
- Life stage: juvenile and adult
- Evidence type: field life-history study
- NOVA applicability: presentation context only
- Confidence: medium
- Source: S3 (page: 723-725; section: Food habits)
- Limitations: Occurrence does not measure feeding rate.
- Surrogate evidence: false
### E6. fish size and prey pulse - context-only
- Exact condition/range: 647 fallfish in autumn 2007-2008; size groups below 100 mm, 100-149 mm, and at least 150 mm.
- Observed effect: Salmon-egg contribution increased above 100 mm; the largest group had 86.1% eggs in diet.
- Measured: Diet contribution by fish size
- Population/location: Salmon River, New York
- Life stage: juvenile/adult
- Evidence type: field diet study
- NOVA applicability: low for NOVA because Pacific salmon egg pulse is absent
- Confidence: high
- Source: S5 (page: 630-633; section: Abstract/results)
- Limitations: Highly unusual prey subsidy; do not create a generic large-fish feeding bonus.
- Surrogate evidence: false
### E7. seasonal prey pulse - context-only
- Exact condition/range: May versus June, 2009-2012; fallfish estimate available for 2009.
- Observed effect: Predation on Chinook parr was higher in May than June; fallfish were estimated to consume 2.9 million parr in 2009.
- Measured: Predation estimates from diet and prey abundance
- Population/location: Salmon River, New York
- Life stage: mixed sizes
- Evidence type: field predation study
- NOVA applicability: surrogate for prey pulses, not NOVA calendar scoring
- Confidence: medium-high
- Source: S6 (page: 74-84; section: Abstract/results)
- Limitations: Salmon emergence and hatchery context are absent in NOVA; abundance and prey availability confound per-fish intake.
- Surrogate evidence: false
### E8. habitat and competition - context-only
- Exact condition/range: Six sites in a warming Quebec boreal river.
- Observed effect: Fallfish had a narrower habitat niche, were more abundant than brook trout, and both diets were dominated by aquatic insects.
- Measured: Capture, habitat, stomach contents and stable isotopes
- Population/location: Jacques-Cartier River, Quebec
- Life stage: mixed sizes
- Evidence type: field ecology study
- NOVA applicability: context for warm-water expansion and prey overlap
- Confidence: medium-high
- Source: S10 (section: Abstract; Results)
- Limitations: Habitat occupancy and abundance are not bite probability.
- Surrogate evidence: false
### E9. geographic population differences - context-only
- Exact condition/range: Virginia account contrasts southern river/stream populations with northern lake/pond populations.
- Observed effect: Waterbody type and geography differ across the range.
- Measured: Distribution and habitat description
- Population/location: Virginia and range-wide
- Life stage: multiple
- Evidence type: agency synthesis
- NOVA applicability: high transfer-warning value
- Confidence: medium
- Source: S1 (section: Article body, distribution paragraph)
- Limitations: Descriptive account, not quantified feeding evidence.
- Surrogate evidence: false
### E10. angling presentation - context-only
- Exact condition/range: Agency accounts list small jigs, spinners, plugs, flies and live bait.
- Observed effect: Fallfish willingly strike diverse presentations and are intentionally catchable on light tackle.
- Measured: Fishery observations
- Population/location: Virginia and Maryland
- Life stage: adult
- Evidence type: agency guidance
- NOVA applicability: high Fish Guide value
- Confidence: medium
- Source: S1 (section: Article body, fishing paragraph)
- Limitations: No controlled gear comparison or environmental coefficient.
- Surrogate evidence: false
### E11. temperature trend - unavailable
- Exact condition/range: Searches for short-term warming/cooling effects on feeding or hook-and-line catchability.
- Observed effect: No qualifying species-specific direct study was verified.
- Measured: Evidence availability
- Population/location: range-wide
- Life stage: multiple
- Evidence type: documented search
- NOVA applicability: high for model exclusion
- Confidence: high
- Source: S3 (section: Study scope and literature reviewed)
- Limitations: Absence of evidence does not prove no response.
- Surrogate evidence: false
### E12. dissolved oxygen - unavailable
- Exact condition/range: Searches for measured mg/L effects on feeding/catchability.
- Observed effect: No qualifying direct fallfish feeding or angling coefficient was verified.
- Measured: Evidence availability
- Population/location: range-wide
- Life stage: multiple
- Evidence type: documented search
- NOVA applicability: high for model exclusion
- Confidence: high
- Source: S10 (section: Methods and variables measured)
- Limitations: Do not infer from habitat presence or tolerance.
- Surrogate evidence: false
### E13. weather and lunar variables - zero-weight
- Exact condition/range: Barometric pressure, fronts, moon phase, wind, rainfall and cloud searches.
- Observed effect: No qualifying direct species-specific feeding or standardized catchability effect was verified.
- Measured: Evidence availability
- Population/location: range-wide
- Life stage: adult fishery
- Evidence type: documented search
- NOVA applicability: high for zero-weight decision
- Confidence: high
- Source: S1 (section: Agency article variables absent)
- Limitations: Angler lore is not evidence; absence does not establish no biological effect.
- Surrogate evidence: false
### E14. monthly activity - zero-weight
- Exact condition/range: Regional natural history, spawning and prey studies.
- Observed effect: No direct month-by-month per-fish feeding or catchability curve was verified.
- Measured: Evidence availability
- Population/location: Mid-Atlantic and northeastern range
- Life stage: multiple
- Evidence type: adversarial synthesis
- NOVA applicability: high
- Confidence: high
- Source: S2 (section: Distribution, spawning and fishing notes)
- Limitations: Seasons and availability cannot substitute for direct activity measurement.
- Surrogate evidence: false

## Remaining research gaps
- Replicated Mid-Atlantic diel feeding or standardized hook-and-line studies.
- Direct temperature, dissolved oxygen, turbidity, light and flow-change feeding experiments.
- Angling-pressure and hook-avoidance studies.
- Adult size-specific catchability under local conditions.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Mike Pinder; Virginia Department of Wildlife Resources (n.d.)
**Fallfish: Little Tarpon of the Commonwealth**. Virginia DWR.
https://dwr.virginia.gov/blog/fallfish-little-tarpon-of-the-commonwealth/
Scope: Virginia, including Potomac, Rappahannock, James and York drainages. Access: agency HTML. Verification: AI-reviewed-unverified.
### S2. Maryland Department of Natural Resources (n.d.)
**Maryland Fish Facts: Fallfish**. Maryland DNR.
https://dnr.maryland.gov/fisheries/Pages/fish-facts.aspx?fishname=fallfish
Scope: Maryland. Access: agency HTML. Verification: AI-reviewed-unverified.
### S3. Roger J. Reed (1971)
**Biology of the Fallfish, Semotilus corporalis (Pisces, Cyprinidae)**. Transactions of the American Fisheries Society 100(4):717-725. DOI: 10.1577/1548-8659(1971)100<717:BOTFSC>2.0.CO;2.
https://academic.oup.com/tafs/article/100/4/717/7894389
Scope: Massachusetts streams. Access: publisher record and original PDF. Verification: AI-reviewed-unverified.
### S4. James H. Johnson (2015)
**Summer diel diet and feeding periodicity of four species of cyprinids in the Salmon River, New York**. American Midland Naturalist 173(2):326-334. DOI: 10.1674/amid-173-02-326-334.1.
https://pubs.usgs.gov/publication/70160762
Scope: Salmon River, New York. Access: USGS bibliographic record and abstract. Verification: AI-reviewed-unverified.
### S5. James H. Johnson; Christopher C. Nack; Marc A. Chalupnicki (2009)
**Predation by fallfish (Semotilus corporalis) on Pacific salmon eggs in the Salmon River, New York**. Journal of Great Lakes Research 35(4):630-633. DOI: 10.1016/j.jglr.2009.08.001.
https://pubs.usgs.gov/publication/70035960
Scope: Salmon River, New York. Access: USGS record and abstract. Verification: AI-reviewed-unverified.
### S6. James H. Johnson; Christopher C. Nack; Marc Chalupnicki; Ross Abbett; James E. McKenna Jr. (2016)
**Predation on Chinook Salmon parr by hatchery salmonids and Fallfish in the Salmon River, New York**. North American Journal of Fisheries Management 36(1):74-84. DOI: 10.1080/02755947.2015.1103821.
https://pubs.usgs.gov/publication/70175456
Scope: Salmon River, New York. Access: USGS record and abstract. Verification: AI-reviewed-unverified.
### S7. B. C. Victor; E. B. Brothers (1982)
**Age and growth of the fallfish Semotilus corporalis with daily otolith increments as a method of annulus verification**. Canadian Journal of Zoology 60:2543-2550. DOI: 10.1139/z82-326.
https://cdnsciencepub.com/doi/10.1139/z82-326
Scope: northeastern North America. Access: publisher record/abstract. Verification: AI-reviewed-unverified.
### S8. U.S. Geological Survey Nonindigenous Aquatic Species Program (n.d.)
**Fallfish (Semotilus corporalis) Species Profile**. USGS.
https://nas.er.usgs.gov/queries/factsheet.aspx?SpeciesID=573
Scope: North America. Access: federal HTML profile. Verification: AI-reviewed-unverified.
### S9. U.S. Fish and Wildlife Service (n.d.)
**Fallfish (Semotilus corporalis)**. U.S. Fish and Wildlife Service.
https://www.fws.gov/species/fallfish-semotilus-corporalis
Scope: North America. Access: federal HTML profile. Verification: AI-reviewed-unverified.
### S10. Aglaé H. Lambert; Gilbert Cabana; Eva C. Enders (2026)
**Ecological niche overlap in a warming boreal river: a case study of brook trout (Salvelinus fontinalis) and fallfish (Semotilus corporalis)**. Environmental Biology of Fishes 109:91. DOI: 10.1007/s10641-026-01860-6.
https://link.springer.com/article/10.1007/s10641-026-01860-6
Scope: Jacques-Cartier River, Quebec. Access: publisher full HTML. Verification: AI-reviewed-unverified.
