# BiteMap NOVA research resume packet

- Completed before Batch 8: largemouth-bass, smallmouth-bass, channel-catfish, black-crappie, white-crappie, bluegill, redbreast-sunfish, pumpkinseed, green-sunfish, rock-bass, rainbow-trout, brown-trout, brook-trout, blue-catfish, flathead-catfish, white-catfish, striped-bass, white-perch, yellow-perch, walleye, muskellunge, northern-snakehead, spotted-bass, common-carp, american-eel.
- Completed in Batch 8: fallfish, creek-chub, white-sucker.
- Pending species: yellow-bullhead, brown-bullhead, northern-hogsucker, shorthead-redhorse, blacknose-dace, longnose-dace, mottled-sculpin, tessellated-darter, gizzard-shad.
- Next recommended batch: Batch 9 - yellow bullhead, brown bullhead, and northern hogsucker.
- Schema version: 1.1.
- Verification status: AI-reviewed-unverified.
- Known corrections: channel-catfish S13 must include James W. Avault Jr.; fallfish salmon-prey pulses are not transferable to NOVA; creek-chub temperature evidence is competitor-dependent; white-sucker telemetry preference is not a feeding optimum and the 18-versus-25 C null must be retained.
- Batch 8 outcome: all three species are proposed for bite scoring, with one bounded score candidate each and explicit limitations.
- Unresolved questions: see validation-report.json and correction-and-conflict-log.json.
- Files a new chat should receive: the two baseline archives, the immediately preceding Batch 7 archive, BiteMap_batch-8_deep_verified_research_archive.zip, and the master prompt with ACTIVE BATCH changed to BATCH 9.
