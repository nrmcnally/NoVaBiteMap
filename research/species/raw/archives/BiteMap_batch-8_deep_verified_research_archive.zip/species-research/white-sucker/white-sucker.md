# White Sucker
*Catostomus commersonii*

- Species ID: `white-sucker`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Proposed for bite scoring**

## Executive conclusion
White sucker are intentional roughfish targets and common in Northern Virginia. Direct feeding experiments justify proposed bite scoring, but only as a low-strength categorical juvenile temperature candidate with the newer null finding preserved.

### Model-ready findings
- **score**: A controlled juvenile experiment supports a categorical intermediate-temperature feeding candidate: 22-25 C treatments generally outperformed 19 and 28 C extremes. Evidence: E2.
- **zero-weight**: A separate 18-versus-25 C experiment found no feeding-efficiency difference, requiring low-strength implementation and explicit contradiction retention. Evidence: E4.

### Context-only findings
- Velocity interacted with temperature in a flume, but the response was nonlinear and does not translate directly to river discharge. Evidence: E3.
- Thermal occupancy, spawning migration, circadian activity and HSI curves remain context-only or zero-weight. Evidence: E6, E8, E9, E11, E13.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The score candidate is juvenile laboratory evidence, not an adult field optimum.
- The 18-versus-25 C null result contradicts a simple monotonic warming rule.
- Telemetry temperature selection is habitat occupancy, not appetite.
- Mixed-species spawning migration cannot establish white-sucker bite probability.

## Targetability assessment
White sucker are intentional roughfish targets and common in Northern Virginia. Direct feeding experiments justify proposed bite scoring, but only as a low-strength categorical juvenile temperature candidate with the newer null finding preserved.

## Candidate model rules
### R1. waterTemperature - score
- Condition: Juvenile laboratory conditions: 22-25 C compared with 19 or 28 C
- Direction: positive at intermediate treatments; lower at tested extremes
- Strength: low-moderate
- Confidence: high
- Mechanism: Temperature affected prey consumption and feeding latency.
- Evidence: E2
- Double-counting risk: Do not double count acclimation, prey type or body size; no smooth adult curve.
### R2. currentVelocity - context-only
- Condition: 0-0.6 m/s at 22 and 25 C in the flume
- Direction: interaction/context-dependent
- Strength: low
- Confidence: medium-high
- Mechanism: Local velocity and temperature jointly affected prey consumption.
- Evidence: E3
- Double-counting risk: Discharge is not local velocity; response was nonlinear and competitor-dependent.
### R3. waterTemperature - zero-weight
- Condition: 18 versus 25 C functional-response experiment
- Direction: no feeding-efficiency difference supported
- Strength: zero
- Confidence: high
- Mechanism: A newer experiment found no significant temperature effect on white-sucker feeding efficiency.
- Evidence: E4
- Double-counting risk: Preserve as contradiction to overgeneralizing E2; endpoints and designs differ.
### R4. thermalPreference - zero-weight
- Condition: Telemetry selection of approximately 10-16 C
- Direction: none for bite scoring
- Strength: zero
- Confidence: high
- Mechanism: Occupancy indicates habitat use, not appetite.
- Evidence: E6
- Double-counting risk: Do not combine with feeding experiments as an optimum.
### R5. spawningMigration - context-only
- Condition: Previous-day warming/discharge and sunset entry in a mixed-sucker run
- Direction: location context only
- Strength: unquantified
- Confidence: medium
- Mechanism: Environmental cues altered tributary entry.
- Evidence: E8, E9
- Double-counting risk: Mixed species and movement endpoint; avoid double counting flow, spawn and encounter rate.
### R6. timeOfDay - zero-weight
- Condition: Circadian movement or sunset migration
- Direction: none for bite scoring
- Strength: zero
- Confidence: high
- Mechanism: Activity/migration was not feeding or hook-and-line capture.
- Evidence: E9, E11
- Double-counting risk: Do not infer a night or sunset bonus.
### R7. preyAvailability - context-only
- Condition: Benthic invertebrate community and prey selection
- Direction: Fish Guide context
- Strength: unquantified
- Confidence: medium
- Mechanism: White sucker selectively forage among benthic prey.
- Evidence: E10, E12
- Double-counting risk: No direct lure/bait or catchability coefficient.
### R8. dissolvedOxygen - unavailable
- Condition: Any mg/L category
- Direction: unavailable
- Strength: unavailable
- Confidence: high
- Mechanism: No direct feeding/catchability coefficient qualified.
- Evidence: E14
- Double-counting risk: Do not use tolerance or HSI curves.
### R9. weatherPressureMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct evidence.
- Evidence: E14
- Double-counting risk: Reject folklore.
### R10. monthlyActivity - zero-weight
- Condition: Fixed monthly curve
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No direct monthly per-fish curve.
- Evidence: E15
- Double-counting risk: Separate temperature, migration, spawn and accessibility.

## Evidence ledger
### E1. targetability and local occurrence - context-only
- Exact condition/range: Fairfax County and Maryland stream records; adults can exceed 20 inches.
- Observed effect: White sucker are common local benthic fish and are recognized in recreational records/roughfish fisheries.
- Measured: Local occurrence and intentional targeting plausibility
- Population/location: Northern Virginia and Maryland
- Life stage: adult
- Evidence type: agency species accounts
- NOVA applicability: high for NOVA presence and targetability
- Confidence: high
- Source: S10 (section: White Sucker)
- Limitations: Agency occurrence is not standardized angling evidence.
- Surrogate evidence: false
### E2. water temperature and prey consumption - score
- Exact condition/range: Juvenile white suckers acclimated/tested at 19, 22, 25 and 28 C.
- Observed effect: Prey consumption was greatest at intermediate treatments, with 25 C high in the temperature trial; consumption and latency were poorer at the 19 and 28 C extremes.
- Measured: Number of prey consumed, attacks and feeding latency
- Population/location: laboratory; wild Ontario-source juveniles
- Life stage: juvenile
- Evidence type: controlled feeding experiment
- NOVA applicability: direct endpoint but juvenile/laboratory limited
- Confidence: high
- Source: S1 (section: Results 3.1-3.2; table: Table 2; figure: Figures 2-3)
- Limitations: Do not fit a smooth adult field curve; attack count and consumption did not respond identically.
- Surrogate evidence: false
### E3. current velocity x temperature - context-only
- Exact condition/range: 0, 0.15, 0.3 and 0.6 m/s at 22 and 25 C.
- Observed effect: Consumption generally changed with velocity and temperature interactions; white sucker response was weaker/nonlinear and at 0.6 m/s and 25 C exceeded round goby.
- Measured: Prey consumed, attacks and latency
- Population/location: laboratory; Ontario-source juveniles
- Life stage: juvenile
- Evidence type: controlled feeding experiment
- NOVA applicability: mechanistic but not portable as monotonic flow rule
- Confidence: high
- Source: S1 (section: Results 3.3-3.4; table: Table 3; figure: Figures 4-5)
- Limitations: Flume velocity, competitor presence and temperature interact; river discharge is not equivalent to local velocity.
- Surrogate evidence: false
### E4. temperature and feeding efficiency null - zero-weight
- Exact condition/range: Functional-response trials at 18 and 25 C.
- Observed effect: White-sucker feeding efficiency did not significantly differ between 18 and 25 C, contradicting a simple monotonic warming rule.
- Measured: Functional response/feeding efficiency
- Population/location: laboratory; Quebec-source fish
- Life stage: juvenile/adult experimental fish
- Evidence type: controlled feeding experiment
- NOVA applicability: important direct null
- Confidence: high
- Source: S2 (section: Results; figure: Functional-response figures)
- Limitations: Different design, prey and endpoints from S1; neither study alone defines a field optimum.
- Surrogate evidence: false
### E5. temperature and body condition - context-only
- Exact condition/range: Same 18 versus 25 C experiment over time.
- Observed effect: White suckers at 25 C showed a decline in body condition.
- Measured: Body condition
- Population/location: laboratory; Quebec-source fish
- Life stage: experimental fish
- Evidence type: controlled physiology experiment
- NOVA applicability: context only
- Confidence: high
- Source: S2 (section: Results; Discussion)
- Limitations: Condition is not feeding rate or catchability.
- Surrogate evidence: false
### E6. seasonal thermal occupancy - zero-weight
- Exact condition/range: Telemetry in a small boreal lake; open-water season.
- Observed effect: Fish selected near-bottom areas shallower than 10 m and temperatures roughly 10-16 C, and avoided water below about 6 C.
- Measured: Habitat occupancy and telemetry movement
- Population/location: northern Ontario lake
- Life stage: adult
- Evidence type: field telemetry study
- NOVA applicability: habitat context only
- Confidence: high
- Source: S3 (section: Abstract and Results)
- Limitations: Selection is not a feeding optimum; lake environment differs from NOVA streams.
- Surrogate evidence: false
### E7. movement rate - context-only
- Exact condition/range: Seasonal telemetry in the same lake.
- Observed effect: Movement and habitat use changed seasonally, but movement rates were comparatively consistent.
- Measured: Telemetry movement
- Population/location: northern Ontario lake
- Life stage: adult
- Evidence type: field telemetry study
- NOVA applicability: location context only
- Confidence: medium-high
- Source: S3 (section: Results)
- Limitations: Movement is not feeding or catchability.
- Surrogate evidence: false
### E8. migration temperature and discharge - context-only
- Exact condition/range: Annual tributary entry; mixed sucker species.
- Observed effect: Entry probability increased with previous-day temperature and discharge and varied by time of day.
- Measured: Migratory detections/river entry
- Population/location: Great Lakes tributary
- Life stage: adult spawning migrants
- Evidence type: field migration study
- NOVA applicability: surrogate and movement-only
- Confidence: medium
- Source: S4 (page: 1159-1170; section: Abstract/results)
- Limitations: Mixed species; migration concentration and access are not appetite.
- Surrogate evidence: true
### E9. time of day migration - context-only
- Exact condition/range: Same mixed-sucker migration study.
- Observed effect: River entry probability was higher near sunset and lower near midnight.
- Measured: Migratory detections
- Population/location: Great Lakes tributary
- Life stage: adult spawning migrants
- Evidence type: field migration study
- NOVA applicability: surrogate location context only
- Confidence: medium
- Source: S4 (page: 1159-1170; section: Abstract/results)
- Limitations: Not white-sucker-specific feeding or angling vulnerability.
- Surrogate evidence: true
### E10. prey selection - context-only
- Exact condition/range: Field/laboratory assessment of available benthic prey and sucker diets.
- Observed effect: White sucker selected among benthic prey rather than consuming strictly in environmental proportion.
- Measured: Diet and prey selectivity
- Population/location: Canadian lakes
- Life stage: mixed sizes
- Evidence type: field feeding ecology study
- NOVA applicability: Fish Guide context
- Confidence: medium-high
- Source: S5 (page: 1320-1331; section: Abstract/results)
- Limitations: Prey preference does not yield an environmental bite multiplier.
- Surrogate evidence: false
### E11. circadian activity - zero-weight
- Exact condition/range: Individual versus shoaling white suckers under laboratory diel conditions.
- Observed effect: Circadian activity differed with social setting.
- Measured: Locomotor activity
- Population/location: laboratory
- Life stage: unspecified
- Evidence type: controlled activity study
- NOVA applicability: behavior context only
- Confidence: medium
- Source: S6 (page: 1399-1403; section: Abstract/results)
- Limitations: Activity was measured, not feeding or hook-and-line capture.
- Surrogate evidence: false
### E12. historical diet and growth - context-only
- Exact condition/range: Early federal study across development and seasons.
- Observed effect: White suckers consumed benthic invertebrates and detrital material, with diet changing through development.
- Measured: Stomach contents, growth and development
- Population/location: North American freshwater
- Life stage: larvae through adults
- Evidence type: field life-history report
- NOVA applicability: prey/life-stage context
- Confidence: medium
- Source: S7 (page: 147-184; section: Food habits)
- Limitations: Historical methods and no standardized catchability endpoint.
- Surrogate evidence: false
### E13. habitat suitability and flow - zero-weight
- Exact condition/range: HSI synthesis of temperature, substrate, cover, current and spawning requirements.
- Observed effect: Report supplies habitat-suitability curves but not direct feeding or angling coefficients.
- Measured: Habitat suitability synthesis
- Population/location: North America
- Life stage: multiple
- Evidence type: federal technical synthesis
- NOVA applicability: context/zero-weight for biting
- Confidence: high
- Source: S8 (section: Model variables and suitability curves)
- Limitations: HSI values must not be repurposed as bite scores.
- Surrogate evidence: false
### E14. dissolved oxygen, weather and moon - unavailable
- Exact condition/range: Searches for direct feeding/catchability responses to oxygen, pressure, fronts, moon, wind and cloud.
- Observed effect: No portable species-specific direct coefficient was verified.
- Measured: Evidence availability
- Population/location: range-wide
- Life stage: multiple
- Evidence type: documented search
- NOVA applicability: high
- Confidence: high
- Source: S8 (section: Literature review)
- Limitations: Survival/tolerance and movement cannot substitute.
- Surrogate evidence: false
### E15. monthly activity - zero-weight
- Exact condition/range: Seasonal habitat, spawning migration, and historical life-history evidence.
- Observed effect: No direct numerical month-by-month per-fish feeding or hook-and-line catchability curve qualified.
- Measured: Evidence availability
- Population/location: North America
- Life stage: multiple
- Evidence type: adversarial synthesis
- NOVA applicability: high
- Confidence: high
- Source: S3 (section: Seasonal results)
- Limitations: Do not infer from spawning runs or angler availability.
- Surrogate evidence: false

## Remaining research gaps
- Adult wild Mid-Atlantic feeding and hook-and-line catchability experiments.
- Replication of the 19/22/25/28 C juvenile categories with natural prey.
- Direct oxygen, turbidity and underwater-light feeding studies.
- Effort-controlled diel, flow and angling-pressure studies.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Meagan M. Kindree; Nicholas E. Jones; Nicholas E. Mandrak (2024)
**Interactive effects of temperature and velocity on the feeding behavior of competing native and invasive stream fishes**. Frontiers in Ecology and Evolution 12:1290083. DOI: 10.3389/fevo.2024.1290083.
https://www.frontiersin.org/journals/ecology-and-evolution/articles/10.3389/fevo.2024.1290083/full
Scope: laboratory; wild Ontario-source juvenile white suckers and round goby. Access: publisher full HTML. Verification: AI-reviewed-unverified.
### S2. Christophe Benjamin; Jaclyn Hill; Anthony Ricciardi (2026)
**Thermal effects on feeding efficiency and body condition in invasive and native benthivorous freshwater fishes**. Biological Invasions 28:51. DOI: 10.1007/s10530-026-03767-w.
https://pmc.ncbi.nlm.nih.gov/articles/PMC12901266/
Scope: laboratory; Quebec-source white suckers and round goby. Access: open-access full text. Verification: AI-reviewed-unverified.
### S3. Ian A. Richter; Karen E. Smokorowski; Paul J. Blanchfield (2024)
**Seasonal habitat use of white sucker Catostomus commersonii in a small Boreal lake**. Environmental Biology of Fishes 107:1529-1545. DOI: 10.1007/s10641-024-01581-8.
https://link.springer.com/article/10.1007/s10641-024-01581-8
Scope: small boreal lake, northern Ontario. Access: publisher full HTML. Verification: AI-reviewed-unverified.
### S4. Reid G. Swanson; Erin L. McCann; Nicholas S. Johnson; Daniel P. Zielinski (2021)
**Environmental factors influencing annual sucker (Catostomus sp.) migration into a Great Lakes tributary**. Journal of Great Lakes Research 47(4):1159-1170. DOI: 10.1016/j.jglr.2021.04.003.
https://www.sciencedirect.com/science/article/abs/pii/S0380133021000910
Scope: Great Lakes tributary; mixed sucker assemblage dominated by white and longnose sucker. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S5. Nathalie Saint-Jacques; Harold H. Harvey; Donald A. Jackson (2000)
**Selective foraging in the white sucker (Catostomus commersoni)**. Canadian Journal of Zoology 78(8):1320-1331. DOI: 10.1139/z00-067.
https://cdnsciencepub.com/doi/10.1139/z00-067
Scope: Canadian lakes. Access: publisher record/abstract. Verification: AI-reviewed-unverified.
### S6. M. Kavaliers (1980)
**Circadian activity of the white sucker, Catostomus commersoni: comparison of individual and shoaling fish**. Canadian Journal of Zoology 58:1399-1403. DOI: 10.1139/z80-192.
https://cdnsciencepub.com/doi/10.1139/z80-192
Scope: laboratory. Access: publisher record/abstract. Verification: AI-reviewed-unverified.
### S7. Norman Hamilton Stewart (1926)
**Development, growth, and food habits of the white sucker, Catostomus commersonii Le Sueur**. Bulletin of the U.S. Bureau of Fisheries 42:147-184.
https://spo.nmfs.noaa.gov/content/development-growth-and-food-habits-white-sucker-catostomus-commersonii-le-sueur
Scope: North American freshwater systems. Access: NOAA scan and catalog record. Verification: AI-reviewed-unverified.
### S8. Kathleen A. Twomey; Kathryn L. Williamson; Patrick C. Nelson (1984)
**Habitat suitability index models and instream flow suitability curves: White sucker**. U.S. Fish and Wildlife Service FWS/OBS-82/10.64, 56 pp..
https://mrwa.org/wp-content/uploads/repository/white-sucker.pdf
Scope: North America. Access: full agency PDF. Verification: AI-reviewed-unverified.
### S9. Maryland Department of Natural Resources, Maryland Biological Stream Survey (n.d.)
**White Sucker**. Maryland DNR.
https://eyesonthebay.dnr.maryland.gov/mbss/SA_spec6.cfm?species=White+sucker
Scope: Maryland. Access: agency HTML. Verification: AI-reviewed-unverified.
### S10. Fairfax County Public Works and Environmental Services (n.d.)
**Suckers: White Sucker**. Fairfax County Government.
https://www.fairfaxcounty.gov/publicworks/stormwater/fish/suckers
Scope: Fairfax County, Virginia. Access: county HTML. Verification: AI-reviewed-unverified.
### S11. Connecticut Department of Energy and Environmental Protection (n.d.)
**White Sucker**. Connecticut DEEP.
https://portal.ct.gov/DEEP/Fishing/Freshwater/Freshwater-Fishes-of-Connecticut/White-Sucker
Scope: Connecticut. Access: agency HTML. Verification: AI-reviewed-unverified.
