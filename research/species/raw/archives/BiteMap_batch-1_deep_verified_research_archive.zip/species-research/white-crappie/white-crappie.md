# White crappie (*Pomoxis annularis*)

**BiteMap species ID:** `white-crappie`  
**Schema:** 1.1  
**Research status:** PARTIAL  
**Targetability recommendation:** Bite-scored  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

White crappie are intentionally targeted in Virginia, with direct size-selectivity and tailwater exploitation evidence. Flow evidence is retained as waterbody-specific context rather than a generic bite bonus.

### Model-ready findings

- **score** — Crappie angling was size-selective, with returns peaking approximately at 26–32 cm total length within the measured range. Evidence: E3.
- **zero-weight** — Juvenile white-crappie consumption stayed comparatively uniform from 0 to 50 NTU, rejecting a generic turbidity bonus or penalty in that experimental range. Evidence: E4, E5.

### Context-only findings

- Kaw Dam tailwater exploitation rose with discharge and photoperiod, but discharge primarily changed immigration and concentration; extreme flow also caused emigration. Evidence: E6, E7, E8.
- Poverty Point supported very high exploitation and catch rates, demonstrating targetability and pressure but not an intrinsic daily bite curve. Evidence: E9, E10, E11.

### Rejected or zero-weight assumptions

- barometric pressure and pressure trend
- generic cold-front or warm-front classification
- wind as an independent direct biological multiplier
- ordinary rainfall as an independent direct multiplier
- cloud-cover bonus without measured underwater light
- moon phase or solunar tables
- growth optimum used as bite optimum
- movement or habitat occupancy used as feeding
- spawning or nest defense labeled as feeding
- monthly curves derived from angling seasons or folklore

### Contradictions and limitations

- Moderately high Kaw tailwater discharge increased exploitation through immigration/concentration, while extreme discharge also promoted downstream emigration.
- Photoperiod correlated with exploitation but was confounded by season, effort, discharge, temperature, and fish availability.
- High reservoir exploitation demonstrates targetability but not a daily environmental bite rule.

## Targetability recommendation

**Bite-scored** — White crappie are intentionally targeted in Virginia, with direct size-selectivity and tailwater exploitation evidence. Flow evidence is retained as waterbody-specific context rather than a generic bite bonus.

## Candidate model rules

### R1. `fishLengthCm` — score
- **Condition:** 26–32 cm total length within contexts comparable to the five-reservoir tagging study
- **Direction / strength / confidence:** increase / moderate / medium
- **Mechanism:** Angler returns peaked in this measured size band.
- **Evidence:** E3
- **Double-counting risk:** Bound to the measured 20.0–39.8 cm range and avoid duplicating gear/retention selectivity.

### R2. `fishLengthCm` — score
- **Condition:** Near 20 cm or above approximately 32 cm within the measured range
- **Direction / strength / confidence:** decrease / weak-to-moderate / medium
- **Mechanism:** Return probability declined toward both ends of the observed size distribution.
- **Evidence:** E3
- **Double-counting risk:** Do not invent a universal continuous curve.

### R3. `turbidityNtu` — zero-weight
- **Condition:** 0–50 NTU for juveniles under the tested prey/light conditions
- **Direction / strength / confidence:** neutral / moderate / high
- **Mechanism:** White-crappie consumption stayed comparatively uniform with increasing turbidity.
- **Evidence:** E4, E5
- **Double-counting risk:** Null impairment is not evidence of a positive turbid-water bonus and is not adult hook-and-line evidence.

### R4. `tailwaterDischarge` — context-only
- **Condition:** Kaw Dam tailwater discharge high enough to entrain or concentrate white crappie
- **Direction / strength / confidence:** context-only / strong / medium
- **Mechanism:** Exploitation rose with discharge mainly through immigration/accessibility.
- **Evidence:** E6
- **Double-counting risk:** Do not reuse Oklahoma discharge values or interpret concentration as increased feeding.

### R5. `extremeTailwaterDischarge` — zero-weight
- **Condition:** Extremely high Kaw Dam discharge
- **Direction / strength / confidence:** decrease or relocation / moderate / medium
- **Mechanism:** Some fish emigrated downstream, contradicting a monotonic flow bonus.
- **Evidence:** E7
- **Double-counting risk:** Tailwater geometry and dam operations dominate; avoid generic rising-flow scoring.

### R6. `photoperiod` — context-only
- **Condition:** Longer day length in the Kaw tailwater seasonal regression
- **Direction / strength / confidence:** context-only / weak / low
- **Mechanism:** Photoperiod correlated with exploitation but covaried with discharge, season, effort, temperature, and fish immigration.
- **Evidence:** E8
- **Double-counting risk:** Do not stack with month, temperature, time of day, and seasonal effort.

### R7. `populationExploitation` — context-only
- **Condition:** Known high-exploitation, high-effort reservoir population
- **Direction / strength / confidence:** context-only / strong / medium
- **Mechanism:** Poverty Point showed very high exploitation and sustained crappie effort.
- **Evidence:** E9, E10
- **Double-counting risk:** This describes fishery pressure/targetability, not intrinsic daily bite probability.

### R8. `foragingSearchMode` — context-only
- **Condition:** Saltatory searching and life-stage-dependent prey detection
- **Direction / strength / confidence:** context-only / moderate / medium
- **Mechanism:** White crappie alternate movement and stationary visual searching; performance changes ontogenetically.
- **Evidence:** E13, E14
- **Double-counting risk:** Fish Guide/presentation only; do not turn a mechanism into an environmental multiplier.

### R9. `spawningPhase` — context-only
- **Condition:** Spring and early-summer staging, nesting, and guarding
- **Direction / strength / confidence:** context-only / unknown / low
- **Mechanism:** Aggregation and defense may change vulnerability without measuring feeding.
- **Evidence:** E15
- **Double-counting risk:** Do not label defense as feeding.

### R10. `barometerFrontWindRainCloudMoon` — zero-weight
- **Condition:** Any direct atmospheric or solunar multiplier
- **Direction / strength / confidence:** neutral / unknown / medium
- **Mechanism:** No qualifying direct species-specific evidence was found.
- **Evidence:** E16
- **Double-counting risk:** Do not double count aquatic effects mediated by discharge, light, temperature, or oxygen.

## Evidence ledger

### E1 — Taxonomy and name
- **Exact condition/range:** Accepted as Pomoxis annularis; supplied and accepted names match.
- **Observed effect:** No species-level name change affecting Northern Virginia was identified.
- **Measured:** Taxonomic identity
- **Population/location:** Range-wide
- **Life stage:** Not applicable
- **Evidence type:** taxonomic catalog
- **NOVA applicability:** Direct naming applicability; not a score input
- **Confidence:** high
- **Source / locator:** S1 — section: Pomoxis annularis species record
- **Limitations:** Taxonomic identity does not imply behavioral uniformity.
- **Recommended model use:** unavailable
- **Surrogate evidence:** false

### E2 — Regional occurrence, habitat, diet, and recreational use
- **Exact condition/range:** Virginia reservoirs, rivers, and impoundments.
- **Observed effect:** White crappie are an intentionally targeted Virginia panfish; regional habitat and life history support guide context.
- **Measured:** Agency synthesis
- **Population/location:** Virginia
- **Life stage:** Mixed
- **Evidence type:** government species account
- **NOVA applicability:** High regional relevance; not a short-term bite function
- **Confidence:** medium
- **Source / locator:** S2 — section: Habitat; Diet; Reproduction; Fishing
- **Limitations:** The account does not separate effort, abundance, and intrinsic catchability.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E3 — Fish size and hook-and-line catchability
- **Exact condition/range:** Tagged fish 20.0–39.8 cm total length; angler returns 20.0–38.8 cm; five southern reservoirs.
- **Observed effect:** Return probability was low near 20 cm, highest approximately 26–32 cm, and declined among longer fish; no species difference was detected between black and white crappie in this size-selectivity pattern.
- **Measured:** Hook-and-line recapture/return rate
- **Population/location:** Mississippi, Louisiana, and Arkansas reservoirs
- **Life stage:** Subadult and adult
- **Evidence type:** field tagging/angler return
- **NOVA applicability:** Direct catchability evidence with bounded transfer
- **Confidence:** medium
- **Source / locator:** S4 — page: 706–709; section: Abstract; Results; figure: Figure 1
- **Limitations:** Do not extrapolate outside the measured length range or interpret as a physiological optimum.
- **Recommended model use:** score
- **Surrogate evidence:** false

### E4 — Turbidity and juvenile prey consumption
- **Exact condition/range:** 0, 25, and 50 NTU controlled treatments.
- **Observed effect:** Juvenile white crappies maintained comparatively uniform consumption as turbidity increased; the tested range did not produce a general feeding impairment.
- **Measured:** Prey consumption
- **Population/location:** Controlled Illinois experiment
- **Life stage:** Juvenile
- **Evidence type:** controlled foraging experiment
- **NOVA applicability:** Supports zero weight for a generic 0–50 NTU penalty in juveniles
- **Confidence:** high
- **Source / locator:** S3 — page: 123–129; section: Methods; Results
- **Limitations:** Does not establish adult angling performance or benefits of turbid water.
- **Recommended model use:** zero-weight
- **Surrogate evidence:** false

### E5 — Turbidity and prey selectivity
- **Exact condition/range:** 0, 25, and 50 NTU with multiple invertebrate prey types.
- **Observed effect:** White crappies were less size-selective than black crappies and maintained prey consumption across treatments.
- **Measured:** Prey selection and consumption
- **Population/location:** Controlled Illinois experiment
- **Life stage:** Juvenile
- **Evidence type:** controlled foraging experiment
- **NOVA applicability:** Mechanistic context only
- **Confidence:** medium
- **Source / locator:** S3 — page: 127–129; section: Results; Discussion
- **Limitations:** Specific prey assemblage and juvenile stage limit transfer.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E6 — Tailwater discharge and angler exploitation
- **Exact condition/range:** Tagging study in the Kaw Dam tailwater with concurrent discharge, water-quality, weather, and photoperiod data.
- **Observed effect:** White-crappie exploitation was positively correlated with discharge; discharge was the most important variable in the fitted model.
- **Measured:** Angler exploitation of tagged fish
- **Population/location:** Kaw Dam tailwater, Oklahoma
- **Life stage:** Subadult and adult
- **Evidence type:** field tagging and environmental regression
- **NOVA applicability:** Direct catchability/exploitation endpoint, but highly system-specific
- **Confidence:** medium
- **Source / locator:** S6 — page: 35–39; section: Abstract; Methods; Results; table: Regression analyses
- **Limitations:** High discharge promoted immigration/entrainment and concentration; this is not necessarily increased feeding and is not portable to ordinary reservoirs or rivers.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E7 — Extreme high discharge and movement
- **Exact condition/range:** Highest-discharge tailwater periods.
- **Observed effect:** Extremely high discharge also promoted downstream emigration of at least some tagged fish, showing a nonmonotonic accessibility mechanism.
- **Measured:** Tag detections/returns and movement inference
- **Population/location:** Kaw Dam tailwater, Oklahoma
- **Life stage:** Subadult and adult
- **Evidence type:** field tagging study
- **NOVA applicability:** Important contradiction to a generic rising-flow bonus
- **Confidence:** medium
- **Source / locator:** S6 — page: 35; 38–39; section: Abstract; Discussion
- **Limitations:** The exact discharge values are dam- and geometry-specific.
- **Recommended model use:** zero-weight
- **Surrogate evidence:** false

### E8 — Photoperiod and exploitation
- **Exact condition/range:** Seasonal photoperiod included in the Kaw tailwater regression.
- **Observed effect:** Exploitation was positively correlated with photoperiod, but discharge was more important.
- **Measured:** Angler exploitation of tagged fish
- **Population/location:** Kaw Dam tailwater, Oklahoma
- **Life stage:** Subadult and adult
- **Evidence type:** field regression
- **NOVA applicability:** Context only because photoperiod covaries with season, effort, fish immigration, and temperature
- **Confidence:** low
- **Source / locator:** S6 — page: 35–39; section: Abstract; Results
- **Limitations:** Cannot establish a portable daylight or seasonal feeding multiplier.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E9 — Population exploitation and targetability
- **Exact condition/range:** 243 white crappie tagged January–March 2009; 135 reported harvested by May 31.
- **Observed effect:** Estimated exploitation was 59.3% under stated assumptions and potentially exceeded 70% under alternative mortality/nonreporting assumptions.
- **Measured:** Tag returns and creel survey
- **Population/location:** Poverty Point Reservoir, Louisiana
- **Life stage:** Subadult and adult
- **Evidence type:** field tagging and creel study
- **NOVA applicability:** Strong targetability and pressure context
- **Confidence:** medium
- **Source / locator:** S7 — page: 136; 139–141; section: Abstract; Results
- **Limitations:** One new, highly accessible reservoir; exploitation reflects abundance, effort, regulations, reporting, and harvest behavior.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E10 — Catch rate and angler effort
- **Exact condition/range:** Eight-month creel survey; mean harvested fish length 290 mm.
- **Observed effect:** Crappie anglers harvested 1.33 crappie per hour; estimated angler effort was 21.8 h/ha during the creel period.
- **Measured:** Creel catch and effort
- **Population/location:** Poverty Point Reservoir, Louisiana
- **Life stage:** Subadult and adult
- **Evidence type:** creel survey
- **NOVA applicability:** Demonstrates intentional targetability, not intrinsic bite probability
- **Confidence:** medium
- **Source / locator:** S7 — page: 136; 139–140; section: Abstract; Results
- **Limitations:** Catch rate combines abundance, effort, skill, and regulations.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E11 — Size selectivity within a high-exploitation fishery
- **Exact condition/range:** Tagged white crappie later caught versus not caught in the Poverty Point study.
- **Observed effect:** Caught tagged fish were larger on average than uncaught tagged fish (about 285 versus 268 mm in the reported analysis).
- **Measured:** Length comparison of caught and uncaught tagged fish
- **Population/location:** Poverty Point Reservoir, Louisiana
- **Life stage:** Subadult and adult
- **Evidence type:** field tagging study
- **NOVA applicability:** Consistent with size-related vulnerability, but population-specific
- **Confidence:** medium
- **Source / locator:** S7 — page: 139–140; section: Results
- **Limitations:** Size can correlate with gear selectivity, habitat, and angler retention.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E12 — Species identity and angling vulnerability
- **Exact condition/range:** Spring and fall 1992–1993; black, white, and natural hybrid crappies.
- **Observed effect:** White crappies were underrepresented in angler catch relative to independent sampling in Weiss Reservoir.
- **Measured:** Relative angling vulnerability
- **Population/location:** Weiss Reservoir, Alabama
- **Life stage:** Subadult and adult
- **Evidence type:** field comparative catch study
- **NOVA applicability:** Population/species context only
- **Confidence:** medium
- **Source / locator:** S5 — section: Abstract
- **Limitations:** One reservoir; abundance sampling and phenotype classification affect inference.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E13 — Foraging search mode
- **Exact condition/range:** Laboratory observations of planktivorous white crappie.
- **Observed effect:** White crappie used saltatory search: intermittent swimming with prey searching while stationary, rather than continuous cruising or classic ambush.
- **Measured:** Foraging behavior and attack sequence
- **Population/location:** Laboratory
- **Life stage:** Juvenile/subadult
- **Evidence type:** controlled behavioral study
- **NOVA applicability:** Useful for Fish Guide/presentation mechanism
- **Confidence:** medium
- **Source / locator:** S8 — section: Abstract
- **Limitations:** Search mode does not directly predict hourly catchability.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E14 — Ontogeny of foraging behavior
- **Exact condition/range:** Larval and juvenile white crappie across body sizes.
- **Observed effect:** Components of search and prey-location performance changed with development and fish size.
- **Measured:** Search behavior and prey-location distance
- **Population/location:** Laboratory
- **Life stage:** Larval and juvenile
- **Evidence type:** controlled behavioral study
- **NOVA applicability:** Life-stage context only
- **Confidence:** medium
- **Source / locator:** S9 — section: Abstract
- **Limitations:** Larval behavior is not transferable to adult angling without validation.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E15 — Reproduction and nest defense
- **Exact condition/range:** Spring/early-summer nesting and male parental care.
- **Observed effect:** Spawning can alter location and produce defense, but no direct white-crappie catchability study isolated feeding from nest defense.
- **Measured:** Agency/life-history synthesis
- **Population/location:** Virginia and range-wide
- **Life stage:** Adults
- **Evidence type:** government synthesis
- **NOVA applicability:** Regional context only
- **Confidence:** medium
- **Source / locator:** S2 — section: Reproduction
- **Limitations:** No production bite bonus is justified.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E16 — Atmospheric weather and lunar variables
- **Exact condition/range:** Barometric pressure, fronts, wind, ordinary rain, cloud cover, and moon phase.
- **Observed effect:** No qualifying white-crappie study isolated these atmospheric variables for feeding or per-fish catchability after aquatic mediators were controlled.
- **Measured:** Evidence gap after broad search
- **Population/location:** Range-wide
- **Life stage:** Mixed
- **Evidence type:** systematic evidence-gap assessment
- **NOVA applicability:** Supports zero weight
- **Confidence:** medium
- **Source / locator:** S6 — page: 35–40; section: Variables considered and discussion
- **Limitations:** The tailwater study included weather data but did not establish portable folklore-style pressure, front, moon, or wind rules.
- **Recommended model use:** zero-weight
- **Surrogate evidence:** false

## Remaining research gaps

- Portable adult white-crappie feeding/catchability response to water temperature and short-term trend
- Dissolved-oxygen feeding and angling thresholds
- Non-tailwater flow-rate-of-change studies in Mid-Atlantic rivers and reservoirs
- Adult turbidity/light interaction with angling gear
- Pressure/learning studies separated from harvest and abundance
- Direct atmospheric weather and moon tests after aquatic mediators are controlled

## Complete bibliography

### S1
California Academy of Sciences (2026). **Eschmeyer’s Catalog of Fishes: Genera, Species, References — Pomoxis annularis**. California Academy of Sciences.
- URL: https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatmain.asp
- Geographic scope: Range-wide taxonomic record
- Access mode: taxonomic-catalog-web
- Verification: AI-reviewed-unverified

### S2
Virginia Department of Wildlife Resources (n.d.). **White Crappie**. Virginia Department of Wildlife Resources.
- URL: https://dwr.virginia.gov/wildlife/information/white-crappie/
- Geographic scope: Virginia
- Access mode: agency-web-full-text
- Verification: AI-reviewed-unverified

### S3
Sara R. Andree and David H. Wahl (2019). **Effects of turbidity on foraging of juvenile black and white crappies**. Ecology of Freshwater Fish 28(1):123–131. DOI: 10.1111/eff.12436.
- URL: https://doi.org/10.1111/eff.12436
- Geographic scope: Controlled laboratory/pond-origin juveniles, Illinois
- Access mode: author-upload-full-text
- Verification: AI-reviewed-unverified

### S4
L. E. Miranda and B. S. Dorr (2000). **Size Selectivity of Crappie Angling**. North American Journal of Fisheries Management 20(3):706–710. DOI: 10.1577/1548-8675(2000)020<0706:SSOCA>2.3.CO;2.
- URL: https://doi.org/10.1577/1548-8675(2000)020%3C0706:SSOCA%3E2.3.CO;2
- Geographic scope: Five lakes and reservoirs in Mississippi, Louisiana, and Arkansas
- Access mode: author-upload-full-text
- Verification: AI-reviewed-unverified

### S5
Vincent H. Travnichek, Michael J. Maceina, and Rex A. Dunham (1997). **Angling vulnerability of black crappies, white crappies, and their naturally produced hybrid in Weiss Reservoir, Alabama, USA**. Fisheries Research 29(2):185–191. DOI: 10.1016/S0165-7836(96)00522-X.
- URL: https://doi.org/10.1016/S0165-7836(96)00522-X
- Geographic scope: Weiss Reservoir, Alabama
- Access mode: publisher-abstract-only
- Verification: AI-reviewed-unverified

### S6
Kenneth K. Cunningham and Alexander V. Zale (1998). **Dynamics of White Crappie Exploitation in an Oklahoma Tailwater Fishery**. Proceedings of the Oklahoma Academy of Science 78:35–40.
- URL: https://ojs.library.okstate.edu/osu/index.php/OAS/article/view/5632
- Geographic scope: Kaw Dam tailwater, north-central Oklahoma
- Access mode: repository-full-text
- Verification: AI-reviewed-unverified

### S7
Ryan S. Daniel (2011). **An Analysis of Exploitation and Harvest of White Crappie in Poverty Point Reservoir, Louisiana**. Proceedings of the Annual Conference of the Southeastern Association of Fish and Wildlife Agencies 65:136–142.
- URL: https://seafwa.org/journal/2011/analysis-exploitation-and-harvest-white-crappie-poverty-point-reservoir-louisiana
- Geographic scope: Poverty Point Reservoir, Louisiana
- Access mode: agency-association-full-text
- Verification: AI-reviewed-unverified

### S8
W. John O’Brien, Barbara I. Evans, and Gregory L. Howick (1986). **A New View of the Predation Cycle of a Planktivorous Fish, White Crappie (Pomoxis annularis)**. Canadian Journal of Fisheries and Aquatic Sciences 43(10):1894–1899. DOI: 10.1139/f86-234.
- URL: https://doi.org/10.1139/f86-234
- Geographic scope: Laboratory observations of white crappie
- Access mode: publisher-abstract-only
- Verification: AI-reviewed-unverified

### S9
Howard I. Browman and W. John O’Brien (1992). **The ontogeny of search behavior in the white crappie, Pomoxis annularis**. Environmental Biology of Fishes 34(2):181–195. DOI: 10.1007/BF00002393.
- URL: https://doi.org/10.1007/BF00002393
- Geographic scope: Laboratory larval and juvenile white crappie
- Access mode: publisher-abstract-only
- Verification: AI-reviewed-unverified

### S10
Smithsonian Environmental Research Center, National Estuarine and Marine Exotic Species Information System (n.d.). **White Crappie species account**. Smithsonian Institution.
- URL: https://invasions.si.edu/nemesis/species_summary/163060
- Geographic scope: Range-wide synthesis; tidal Chesapeake context included
- Access mode: agency-web-full-text
- Verification: AI-reviewed-unverified

## Adversarial review outcome

Every proposed score rule was rechecked against the measured endpoint. Movement, habitat occupancy, growth, survival, reproductive behavior, and creel seasonality were retained as context unless feeding or hook-and-line catchability was measured directly. Numerical conditions were kept within the studied units and populations, contradictory or null findings were preserved, and no final production multiplier or smooth response curve was invented.
