# Black crappie (*Pomoxis nigromaculatus*)

**BiteMap species ID:** `black-crappie`  
**Schema:** 1.1  
**Research status:** PARTIAL  
**Targetability recommendation:** Bite-scored  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Black crappie are intentionally targeted throughout Virginia and direct angling studies support limited size-based catchability calibration, while most environmental variables remain contextual or unsupported.

### Model-ready findings

- **score** — Crappie angling was size-selective: returns peaked approximately at 26–32 cm total length and declined near the measured lower and upper ends. Evidence: E3.
- **zero-weight** — Juvenile black-crappie foraging was not generally impaired from 0 to 50 NTU in the controlled study, so a generic penalty or bonus in that range is not defensible. Evidence: E5, E6.

### Context-only findings

- Black crappie were more vulnerable than white crappie and natural hybrids in one Alabama reservoir, but this is population context rather than a dynamic score. Evidence: E4.
- Winter oxygen, temperature, and current altered habitat selection, and one Ontario study found July nighttime return to feeding habitat. These are location/context signals, not universal bite multipliers. Evidence: E7, E9.

### Rejected or zero-weight assumptions

- barometric pressure and pressure trend
- generic cold-front or warm-front classification
- wind as an independent direct biological multiplier
- ordinary rainfall as an independent direct multiplier
- cloud-cover bonus without measured underwater light
- moon phase or solunar tables
- growth optimum used as bite optimum
- movement or habitat occupancy used as feeding
- spawning or nest defense labeled as feeding
- monthly curves derived from angling seasons or folklore

### Contradictions and limitations

- A nighttime feeding pattern in one Ontario lake conflicts with any universal daylight/nocturnal classification.
- Turbidity was not generally harmful to juvenile foraging, but that null result does not establish an adult turbidity benefit.
- Winter movement toward oxygenated water is not evidence of greater feeding.

## Targetability recommendation

**Bite-scored** — Black crappie are intentionally targeted throughout Virginia and direct angling studies support limited size-based catchability calibration, while most environmental variables remain contextual or unsupported.

## Candidate model rules

### R1. `fishLengthCm` — score
- **Condition:** 26–32 cm total length within populations and gear contexts comparable to the five-reservoir tagging study
- **Direction / strength / confidence:** increase / moderate / medium
- **Mechanism:** Angler returns peaked in this measured size band.
- **Evidence:** E3
- **Double-counting risk:** Do not extrapolate beyond 20.0–39.8 cm, duplicate retention/gear selectivity, or treat as a physiological optimum.

### R2. `fishLengthCm` — score
- **Condition:** Near 20 cm or above approximately 32 cm within the measured 20.0–39.8 cm range
- **Direction / strength / confidence:** decrease / weak-to-moderate / medium
- **Mechanism:** Tagged-fish return probability was lower at the small and large ends of the observed range.
- **Evidence:** E3
- **Double-counting risk:** Use a bounded categorical calibration candidate, not a smooth universal curve.

### R3. `turbidityNtu` — zero-weight
- **Condition:** 0–50 NTU for juvenile black crappie under the tested prey and light conditions
- **Direction / strength / confidence:** neutral / moderate / high
- **Mechanism:** Foraging did not collapse across the tested range.
- **Evidence:** E5, E6
- **Double-counting risk:** Do not interpret null impairment as a turbidity benefit or transfer to adults and lures.

### R4. `speciesOrPopulationVulnerability` — context-only
- **Condition:** Black crappie phenotype in Weiss Reservoir versus white crappie and natural hybrids
- **Direction / strength / confidence:** increase / moderate / medium
- **Mechanism:** Black crappie were overrepresented in angler catch relative to independent sampling.
- **Evidence:** E4
- **Double-counting risk:** Do not encode a universal species bonus across waters.

### R5. `winterHabitatQuality` — context-only
- **Condition:** Dissolved oxygen below 2 mg/L, temperature at or below 1°C, or current above about 1 cm/s in winter backwaters
- **Direction / strength / confidence:** context-only / moderate / medium
- **Mechanism:** Fish relocated to trade off oxygen, temperature, and current.
- **Evidence:** E7
- **Double-counting risk:** Movement/habitat selection is not feeding; do not score exact thresholds outside winter backwaters.

### R6. `timeOfDay` — context-only
- **Condition:** Any universal daytime or nighttime category
- **Direction / strength / confidence:** context-only / unknown / medium
- **Mechanism:** One Ontario study found July nighttime return to feeding habitat, but diel behavior is waterbody and season dependent.
- **Evidence:** E9
- **Double-counting risk:** Do not stack clock time with underwater light, prey movement, and habitat occupancy.

### R7. `spawningPhase` — context-only
- **Condition:** Spring and early-summer staging, nesting, and male guarding
- **Direction / strength / confidence:** context-only / unknown / low
- **Mechanism:** Reproduction changes location and may produce defense without proving increased feeding.
- **Evidence:** E12
- **Double-counting risk:** Do not label nest defense as feeding or add a generic spring bonus.

### R8. `barometerFrontWindRainCloudMoon` — zero-weight
- **Condition:** Any direct atmospheric or solunar multiplier
- **Direction / strength / confidence:** neutral / unknown / medium
- **Mechanism:** No qualifying species-specific direct evidence was found.
- **Evidence:** E13
- **Double-counting risk:** Prefer measured aquatic conditions; do not double count weather-mediated temperature, light, flow, or oxygen.

### R9. `recentAnglingPressure` — unavailable
- **Condition:** Any numerical short-term learning or depletion curve
- **Direction / strength / confidence:** unknown / unknown / medium
- **Mechanism:** Available studies do not separate learning from removal, density, effort, and size selectivity.
- **Evidence:** E14
- **Double-counting risk:** Do not infer pressure decay from declining catch alone.

## Evidence ledger

### E1 — Taxonomy and name
- **Exact condition/range:** Accepted as Pomoxis nigromaculatus; supplied and accepted names match.
- **Observed effect:** No species-level name change affecting Northern Virginia was identified.
- **Measured:** Taxonomic identity
- **Population/location:** Range-wide
- **Life stage:** Not applicable
- **Evidence type:** taxonomic catalog
- **NOVA applicability:** Direct naming applicability; not a score input
- **Confidence:** high
- **Source / locator:** S1 — section: Pomoxis nigromaculatus species record
- **Limitations:** Taxonomic identity does not imply behavioral uniformity among populations.
- **Recommended model use:** unavailable
- **Surrogate evidence:** false

### E2 — Regional occurrence, habitat, diet, and recreational use
- **Exact condition/range:** Virginia ponds, lakes, reservoirs, and slow river habitats.
- **Observed effect:** Black crappie are an established Virginia sport fish associated with cover and open-water prey; the account supports targetability and regional context.
- **Measured:** Agency synthesis
- **Population/location:** Virginia
- **Life stage:** Mixed
- **Evidence type:** government species account
- **NOVA applicability:** High regional relevance; not a per-fish bite function
- **Confidence:** medium
- **Source / locator:** S2 — section: Habitat; Diet; Reproduction; Fishing
- **Limitations:** The page does not isolate short-term feeding or catchability from abundance and access.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E3 — Fish size and hook-and-line catchability
- **Exact condition/range:** Tagged fish 20.0–39.8 cm total length; angler returns 20.0–38.8 cm; five southern reservoirs.
- **Observed effect:** Return probability was low near 20 cm, highest approximately 26–32 cm, and declined among longer fish.
- **Measured:** Hook-and-line recapture/return rate
- **Population/location:** Mississippi, Louisiana, and Arkansas reservoirs
- **Life stage:** Subadult and adult
- **Evidence type:** field tagging/angler return
- **NOVA applicability:** Direct catchability evidence, but transfer is limited by gear, regulations, fish size structure, and region
- **Confidence:** medium
- **Source / locator:** S4 — page: 706–709; section: Abstract; Results; figure: Figure 1
- **Limitations:** The relationship is not a universal smooth curve and should be bounded to the measured size range.
- **Recommended model use:** score
- **Surrogate evidence:** false

### E4 — Species identity and angling vulnerability
- **Exact condition/range:** Spring and fall 1992–1993; black, white, and natural hybrid crappies in Weiss Reservoir.
- **Observed effect:** Black crappies were overrepresented in angler catch relative to independent sampling, while white crappies were underrepresented.
- **Measured:** Relative angling vulnerability
- **Population/location:** Weiss Reservoir, Alabama
- **Life stage:** Subadult and adult
- **Evidence type:** field comparative catch study
- **NOVA applicability:** Supports population/species context, not a real-time environmental multiplier
- **Confidence:** medium
- **Source / locator:** S5 — section: Abstract
- **Limitations:** The study was one reservoir and phenotype composition, gear, abundance, and hybrid identification may limit transfer.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E5 — Turbidity and juvenile prey consumption
- **Exact condition/range:** 0, 25, and 50 NTU controlled treatments.
- **Observed effect:** Juvenile black crappies maintained foraging and consumed greater diet biomass than white crappies; the tested turbidity range did not cause a general feeding collapse.
- **Measured:** Prey consumption and diet biomass
- **Population/location:** Controlled Illinois experiment
- **Life stage:** Juvenile
- **Evidence type:** controlled foraging experiment
- **NOVA applicability:** Useful to reject a generic 0–50 NTU penalty for juveniles; not an adult angling threshold
- **Confidence:** high
- **Source / locator:** S3 — page: 123–129; section: Methods; Results; table: Diet biomass and prey-consumption analyses
- **Limitations:** Juvenile, controlled conditions and live invertebrate prey do not directly represent adult lure catchability.
- **Recommended model use:** zero-weight
- **Surrogate evidence:** false

### E6 — Turbidity and prey selection
- **Exact condition/range:** 0, 25, and 50 NTU with Chaoborus, Chironomus, Daphnia, and other prey.
- **Observed effect:** Black crappies showed stronger prey-size selectivity; Chaoborus were preferred, Chironomus avoided, and Daphnia avoided by black crappies.
- **Measured:** Prey selection
- **Population/location:** Controlled Illinois experiment
- **Life stage:** Juvenile
- **Evidence type:** controlled foraging experiment
- **NOVA applicability:** Mechanistic presentation context only
- **Confidence:** medium
- **Source / locator:** S3 — page: 127–129; section: Results; Discussion; figure: Prey selectivity plots
- **Limitations:** Prey assemblage and juvenile size are highly specific.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E7 — Winter dissolved oxygen, temperature, and current
- **Exact condition/range:** Backwater conditions with dissolved oxygen above or below 2 mg/L, temperature around/below 1°C, and current around/above 1 cm/s.
- **Observed effect:** When dissolved oxygen exceeded 2 mg/L, black crappies selected water above 1°C and little detectable current; below 2 mg/L they moved toward higher oxygen even when colder or flowing.
- **Measured:** Habitat selection and movement
- **Population/location:** Upper Mississippi River backwater lakes
- **Life stage:** Mixed sizes in winter field telemetry/sampling
- **Evidence type:** field habitat-selection study
- **NOVA applicability:** Winter location context; not feeding or catchability
- **Confidence:** medium
- **Source / locator:** S6 — section: Abstract
- **Limitations:** The endpoint was habitat selection, not prey consumption or angling. Exact thresholds are season- and system-specific.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E8 — Adult movement and seasonal space use
- **Exact condition/range:** Ultrasonic telemetry April–August 1991.
- **Observed effect:** Adult black crappie movement and habitat use changed through spring and summer in Brant Lake.
- **Measured:** Movement and habitat use
- **Population/location:** Brant Lake, South Dakota
- **Life stage:** Adult
- **Evidence type:** field telemetry
- **NOVA applicability:** Location context only
- **Confidence:** medium
- **Source / locator:** S8 — page: 137–146; section: Methods; Results
- **Limitations:** Movement is not a feeding-rate measurement and the lake differs from Northern Virginia reservoirs and rivers.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E9 — Diel space use and feeding
- **Exact condition/range:** May and July sampling across 1.5–7.0 m depth zones.
- **Observed effect:** Black crappies showed a distinct July diel movement, largely absent from the study area by day and returning at night to feed.
- **Measured:** Distribution plus stomach/feeding pattern
- **Population/location:** Lake Opinicon, Ontario
- **Life stage:** Mixed adult-sized fish
- **Evidence type:** field assemblage study
- **NOVA applicability:** Supports context-dependent nocturnal feeding in one lake, not a universal night bonus
- **Confidence:** medium
- **Source / locator:** S10 — section: Synopsis
- **Limitations:** Only an abstract/synopsis was accessible; results are assemblage- and season-specific.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E10 — Diet ontogeny and prey availability
- **Exact condition/range:** Black crappie sampled in Lake Opinicon across sizes and seasons.
- **Observed effect:** Diet shifted progressively with size and available prey; the species used planktonic and larger prey as it grew.
- **Measured:** Stomach contents and diet composition
- **Population/location:** Lake Opinicon, Ontario
- **Life stage:** Juvenile through adult
- **Evidence type:** field diet study
- **NOVA applicability:** Supports prey and life-stage context
- **Confidence:** medium
- **Source / locator:** S7 — section: Abstract
- **Limitations:** Diet composition does not provide a bite-score multiplier and full text was not accessible in this review.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E11 — Low-temperature feeding evidence
- **Exact condition/range:** Field observations of several Great Lakes-region fishes at low seasonal temperatures.
- **Observed effect:** Black crappie were among species reported feeding at low temperatures; no universal cessation temperature was established for adult angling.
- **Measured:** Stomach contents/feeding occurrence
- **Population/location:** Great Lakes region
- **Life stage:** Mixed
- **Evidence type:** field feeding study cited in authoritative synopsis
- **NOVA applicability:** Relevant only as evidence against a hard folklore cessation threshold
- **Confidence:** low
- **Source / locator:** S9 — page: Literature synthesis section; section: Temperature and feeding references
- **Limitations:** The underlying older article was not available in full text here; exact population, sizes, and temperatures should be rechecked before calibration.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E12 — Reproduction and nest defense
- **Exact condition/range:** Spring to early-summer nesting; males build and guard nests.
- **Observed effect:** Reproductive behavior can aggregate fish and produce defensive responses, but no direct black-crappie angling study isolated feeding from nest defense.
- **Measured:** Agency/life-history synthesis
- **Population/location:** Virginia and range-wide
- **Life stage:** Adult males and females
- **Evidence type:** government synthesis
- **NOVA applicability:** Regional timing context only
- **Confidence:** medium
- **Source / locator:** S2 — section: Reproduction
- **Limitations:** Spawning temperature and calendar values are not converted into bite optima.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E13 — Atmospheric weather and lunar variables
- **Exact condition/range:** Barometric pressure, fronts, wind, ordinary rain, cloud cover, and moon phase.
- **Observed effect:** No qualifying black-crappie study directly isolated these variables for feeding, foraging, or hook-and-line catchability.
- **Measured:** Evidence gap after broad search
- **Population/location:** Range-wide
- **Life stage:** Mixed
- **Evidence type:** systematic evidence-gap assessment
- **NOVA applicability:** Directly relevant to model exclusion
- **Confidence:** medium
- **Source / locator:** S9 — section: Bibliography and reviewed environmental literature
- **Limitations:** Absence of evidence is not proof of no biological effect; it is sufficient to reject unsupported production weight.
- **Recommended model use:** zero-weight
- **Surrogate evidence:** false

### E14 — Fishing pressure, learning, and depletion
- **Exact condition/range:** Recent angling exposure independent of harvest and abundance.
- **Observed effect:** No qualifying black-crappie experiment separated learning or hook avoidance from depletion, size selectivity, effort, or fish density.
- **Measured:** Evidence gap after broad search
- **Population/location:** Range-wide
- **Life stage:** Subadult and adult
- **Evidence type:** systematic evidence-gap assessment
- **NOVA applicability:** Directly relevant to withholding a pressure rule
- **Confidence:** medium
- **Source / locator:** S4 — page: 706–710; section: Discussion
- **Limitations:** Tag-return studies show selectivity but do not isolate learning.
- **Recommended model use:** unavailable
- **Surrogate evidence:** false

## Remaining research gaps

- Direct adult black-crappie feeding or hook-and-line catchability across temperature and temperature trend in the Mid-Atlantic
- Adult dissolved-oxygen feeding/catchability functions in reservoirs and rivers
- Adult turbidity and underwater-light catchability studies with angling gear
- Potomac, Occoquan, Shenandoah, and Rappahannock movement/feeding studies
- Experiments separating hook avoidance or learning from harvest depletion
- Direct tests of atmospheric pressure, fronts, wind, rain, clouds, and moon after aquatic mediators are controlled

## Complete bibliography

### S1
California Academy of Sciences (2026). **Eschmeyer’s Catalog of Fishes: Genera, Species, References — Pomoxis nigromaculatus**. California Academy of Sciences.
- URL: https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatmain.asp
- Geographic scope: Range-wide taxonomic record
- Access mode: taxonomic-catalog-web
- Verification: AI-reviewed-unverified

### S2
Virginia Department of Wildlife Resources (n.d.). **Black Crappie**. Virginia Department of Wildlife Resources.
- URL: https://dwr.virginia.gov/wildlife/information/black-crappie/
- Geographic scope: Virginia
- Access mode: agency-web-full-text
- Verification: AI-reviewed-unverified

### S3
Sara R. Andree and David H. Wahl (2019). **Effects of turbidity on foraging of juvenile black and white crappies**. Ecology of Freshwater Fish 28(1):123–131. DOI: 10.1111/eff.12436.
- URL: https://doi.org/10.1111/eff.12436
- Geographic scope: Controlled laboratory/pond-origin juveniles, Illinois
- Access mode: author-upload-full-text
- Verification: AI-reviewed-unverified

### S4
L. E. Miranda and B. S. Dorr (2000). **Size Selectivity of Crappie Angling**. North American Journal of Fisheries Management 20(3):706–710. DOI: 10.1577/1548-8675(2000)020<0706:SSOCA>2.3.CO;2.
- URL: https://doi.org/10.1577/1548-8675(2000)020%3C0706:SSOCA%3E2.3.CO;2
- Geographic scope: Five lakes and reservoirs in Mississippi, Louisiana, and Arkansas
- Access mode: author-upload-full-text
- Verification: AI-reviewed-unverified

### S5
Vincent H. Travnichek, Michael J. Maceina, and Rex A. Dunham (1997). **Angling vulnerability of black crappies, white crappies, and their naturally produced hybrid in Weiss Reservoir, Alabama, USA**. Fisheries Research 29(2):185–191. DOI: 10.1016/S0165-7836(96)00522-X.
- URL: https://doi.org/10.1016/S0165-7836(96)00522-X
- Geographic scope: Weiss Reservoir, Alabama
- Access mode: publisher-abstract-only
- Verification: AI-reviewed-unverified

### S6
B. C. Knights, Barry L. Johnson, and M. B. Sandheinrich (1995). **Responses of Bluegills and Black Crappies to Dissolved Oxygen, Temperature, and Current in Backwater Lakes of the Upper Mississippi River during Winter**. North American Journal of Fisheries Management 15(2):390–399. DOI: 10.1577/1548-8675(1995)015<0390:ROBABC>2.3.CO;2.
- URL: https://doi.org/10.1577/1548-8675(1995)015%3C0390:ROBABC%3E2.3.CO;2
- Geographic scope: Upper Mississippi River backwater lakes
- Access mode: agency-metadata-and-abstract
- Verification: AI-reviewed-unverified

### S7
Allen Keast (1968). **Feeding Biology of the Black Crappie, Pomoxis nigromaculatus**. Journal of the Fisheries Research Board of Canada 25(2):285–297. DOI: 10.1139/f68-024.
- URL: https://doi.org/10.1139/f68-024
- Geographic scope: Lake Opinicon, Ontario
- Access mode: publisher-abstract-only
- Verification: AI-reviewed-unverified

### S8
Christopher S. Guy, Robert M. Neumann, and David W. Willis (1992). **Movement Patterns of Adult Black Crappie, Pomoxis nigromaculatus, in Brant Lake, South Dakota**. Journal of Freshwater Ecology 7(2):137–147. DOI: 10.1080/02705060.1992.9664679.
- URL: https://doi.org/10.1080/02705060.1992.9664679
- Geographic scope: Brant Lake, South Dakota
- Access mode: publisher-full-text
- Verification: AI-reviewed-unverified

### S9
Jennifer R. Powell and Marc-André Plourde (2025). **A Biological Synopsis of Black Crappie (Pomoxis nigromaculatus)**. Canadian Manuscript Report of Fisheries and Aquatic Sciences 3256.
- URL: https://publications.gc.ca/site/eng/9.953251/publication.html
- Geographic scope: Range-wide synthesis with Canadian management emphasis
- Access mode: agency-report-full-text
- Verification: AI-reviewed-unverified

### S10
Allen Keast and Michael G. Fox (1992). **Space use and feeding patterns of an offshore fish assemblage in a shallow mesotrophic lake**. Environmental Biology of Fishes 34:159–170. DOI: 10.1007/BF00002391.
- URL: https://doi.org/10.1007/BF00002391
- Geographic scope: Lake Opinicon, Ontario
- Access mode: publisher-abstract-and-synopsis
- Verification: AI-reviewed-unverified

## Adversarial review outcome

Every proposed score rule was rechecked against the measured endpoint. Movement, habitat occupancy, growth, survival, reproductive behavior, and creel seasonality were retained as context unless feeding or hook-and-line catchability was measured directly. Numerical conditions were kept within the studied units and populations, contradictory or null findings were preserved, and no final production multiplier or smooth response curve was invented.
