# Bluegill (*Lepomis macrochirus*)

**BiteMap species ID:** `bluegill`  
**Schema:** 1.1  
**Research status:** PARTIAL  
**Targetability recommendation:** Bite-scored  
**Verification status:** AI-reviewed-unverified

## Executive conclusion

Bluegill are heavily and intentionally targeted in Virginia. Direct foraging and angling-vulnerability experiments support a narrow artificial-light rule and multiple contextual or null findings, while most public weather variables remain unsupported.

### Model-ready findings

- **score** — Intermittent nighttime artificial light at 12 lx reduced juvenile Bluegill strike and prey-capture rates; this is a narrow direct feeding rule. Evidence: E3.
- **zero-weight** — Steady nighttime light at 1, 4, or 12 lx had no apparent effect on the measured juvenile foraging metrics and should not receive an automatic score. Evidence: E4.
- **zero-weight** — Metabolic phenotype did not differ between captured and uncaptured Bluegill in the realistic angling/respirometry study. Evidence: E10.

### Context-only findings

- Turbidity reduced larval consumption mainly when underwater light was low; this is a life-stage-specific interaction, not an adult NTU curve. Evidence: E5.
- Angling selectively captured behavioral phenotypes, including sociable fish, but boldness/timidity effects were setting-dependent and are not operational environmental inputs. Evidence: E6, E7, E8, E9.
- Age-0 winter consumption and survival depended jointly on temperature, food, size, and condition; adult bite optimum was not measured. Evidence: E12.

### Rejected or zero-weight assumptions

- barometric pressure and pressure trend
- generic cold-front or warm-front classification
- wind as an independent direct biological multiplier
- ordinary rainfall as an independent direct multiplier
- cloud-cover bonus without measured underwater light
- moon phase or solunar tables
- growth optimum used as bite optimum
- movement or habitat occupancy used as feeding
- spawning or nest defense labeled as feeding
- monthly curves derived from angling seasons or folklore

### Contradictions and limitations

- Angled fish were more timid than seined fish in one comparison, yet bolder fish were more catchable in a separate outdoor-pool trial.
- Steady 1–12 lx nighttime light was null, whereas intermittent 12 lx light reduced foraging; natural moon and clouds were not tested.
- Larval turbidity × light effects and age-0 winter consumption cannot be silently transferred to adult anglers.

## Targetability recommendation

**Bite-scored** — Bluegill are heavily and intentionally targeted in Virginia. Direct foraging and angling-vulnerability experiments support a narrow artificial-light rule and multiple contextual or null findings, while most public weather variables remain unsupported.

## Candidate model rules

### R1. `intermittentArtificialLightLux` — score
- **Condition:** Intermittent nighttime artificial light at 12 lx, matching the juvenile mesocosm treatment
- **Direction / strength / confidence:** decrease / moderate / high
- **Mechanism:** Flashing/intermittent high-intensity light reduced strike and prey-capture rates.
- **Evidence:** E3
- **Double-counting risk:** Restrict to artificial intermittent illumination; do not generalize to moon, clouds, steady lights, adults, or natural waters.

### R2. `steadyArtificialLightLux` — zero-weight
- **Condition:** Steady nighttime artificial light at 1, 4, or 12 lx in juvenile mesocosms
- **Direction / strength / confidence:** neutral / moderate / high
- **Mechanism:** No apparent effect on the measured foraging metrics.
- **Evidence:** E4
- **Double-counting risk:** Do not infer neutrality at other spectra/intensities or under different cover and prey.

### R3. `turbidityLightInteraction` — context-only
- **Condition:** Larval conditions where sediment turbidity coincides with underwater light below roughly 450 lx
- **Direction / strength / confidence:** decrease / moderate / medium
- **Mechanism:** Consumption declined under the combined low-light/turbidity condition.
- **Evidence:** E5
- **Double-counting risk:** Larval-only; do not score adults or create a universal NTU threshold.

### R4. `individualTimidity` — context-only
- **Condition:** Population- and setting-specific behavioral phenotype
- **Direction / strength / confidence:** context-only / moderate / medium
- **Mechanism:** Angled versus seined fish differed in timidity, but direction changed in a second experiment.
- **Evidence:** E6, E7
- **Double-counting risk:** Contradictory setting effects prohibit a universal personality bonus.

### R5. `individualSociability` — context-only
- **Condition:** More sociable individuals in the studied pond
- **Direction / strength / confidence:** increase / moderate / medium
- **Mechanism:** Sociable Bluegill were selectively captured.
- **Evidence:** E8
- **Double-counting risk:** Trait is not observable from public environmental data and may covary with group location.

### R6. `aggressionDominance` — zero-weight
- **Condition:** Aggression or dominance phenotype
- **Direction / strength / confidence:** neutral / unknown / medium
- **Mechanism:** No similarly clear capture association was supported in the reviewed sociability study.
- **Evidence:** E9
- **Double-counting risk:** Do not substitute nesting aggression for general feeding catchability.

### R7. `metabolicPhenotype` — zero-weight
- **Condition:** Standard or maximum metabolic rate, postexercise oxygen use, or recovery time in the studied fish
- **Direction / strength / confidence:** neutral / moderate / high
- **Mechanism:** Captured and uncaptured Bluegill did not differ.
- **Evidence:** E10
- **Double-counting risk:** Do not infer individual metabolic state from ambient temperature or weather.

### R8. `winterHabitatQuality` — context-only
- **Condition:** Dissolved oxygen below 2 mg/L, temperature at or below 1°C, or current above about 1 cm/s in winter backwaters
- **Direction / strength / confidence:** context-only / moderate / medium
- **Mechanism:** Fish altered habitat selection to balance oxygen, temperature, and current.
- **Evidence:** E11
- **Double-counting risk:** Movement is not feeding or angling; thresholds are winter backwater-specific.

### R9. `winterTemperatureFoodSize` — context-only
- **Condition:** Age-0 fish at 4°C versus 9°C with food present/absent and 20–30 versus 50–60 mm size classes
- **Direction / strength / confidence:** context-only / strong / high
- **Mechanism:** Consumption and survival depended jointly on temperature, food, size, and condition.
- **Evidence:** E12
- **Double-counting risk:** Do not use juvenile survival/feeding as an adult bite optimum.

### R10. `spawningPhase` — context-only
- **Condition:** Early-summer colonies and male guarding
- **Direction / strength / confidence:** context-only / unknown / low
- **Mechanism:** Local vulnerability can reflect defense rather than feeding.
- **Evidence:** E16
- **Double-counting risk:** Do not stack with generic summer, shallow-water, or aggression bonuses.

### R11. `barometerFrontWindRainCloudMoon` — zero-weight
- **Condition:** Any direct atmospheric or natural-lunar multiplier
- **Direction / strength / confidence:** neutral / unknown / medium
- **Mechanism:** No qualifying direct Bluegill evidence was found; artificial-light evidence is not a surrogate.
- **Evidence:** E17
- **Double-counting risk:** Avoid double counting measured underwater light, temperature, flow, and oxygen.

### R12. `recentAnglingPressure` — unavailable
- **Condition:** Any short-term learning/depletion curve
- **Direction / strength / confidence:** unknown / unknown / medium
- **Mechanism:** Individual vulnerability is selective, but no portable pressure-decay function was identified.
- **Evidence:** E18
- **Double-counting risk:** Do not infer learning from falling catch without accounting for removals and effort.

## Evidence ledger

### E1 — Taxonomy and name
- **Exact condition/range:** Accepted as Lepomis macrochirus; supplied and accepted names match.
- **Observed effect:** No species-level name change affecting Northern Virginia was identified.
- **Measured:** Taxonomic identity
- **Population/location:** Range-wide
- **Life stage:** Not applicable
- **Evidence type:** taxonomic catalog
- **NOVA applicability:** Direct naming applicability; not a score input
- **Confidence:** high
- **Source / locator:** S1 — section: Lepomis macrochirus species record
- **Limitations:** Taxonomic identity does not imply behavioral uniformity among ecotypes.
- **Recommended model use:** unavailable
- **Surrogate evidence:** false

### E2 — Regional occurrence, habitat, diet, and recreational use
- **Exact condition/range:** Virginia ponds, reservoirs, lakes, and slow-flowing waters, commonly near vegetation and cover.
- **Observed effect:** Bluegill are broadly and intentionally targeted in Virginia; agency life history supports targetability and location context.
- **Measured:** Agency synthesis
- **Population/location:** Virginia
- **Life stage:** Mixed
- **Evidence type:** government species account
- **NOVA applicability:** High regional relevance; not an environmental catchability function
- **Confidence:** medium
- **Source / locator:** S2 — section: Habitat; Diet; Reproduction; Fishing
- **Limitations:** The account does not quantify short-term feeding probability.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E3 — Intermittent artificial light and foraging
- **Exact condition/range:** Juvenile Bluegill exposed at night to an intermittent 12 lx treatment in outdoor mesocosms over six weeks.
- **Observed effect:** Intermittent high-intensity artificial light reduced prey-capture rate and strike rate relative to dark/steady treatments.
- **Measured:** Capture rate, strike rate, and foraging behavior
- **Population/location:** Outdoor mesocosms, Ohio
- **Life stage:** Juvenile
- **Evidence type:** controlled mesocosm foraging experiment
- **NOVA applicability:** Direct feeding/attack evidence, but only for a narrow artificial-light condition
- **Confidence:** high
- **Source / locator:** S4 — page: 152–160; section: Methods; Results; figure: Foraging-response figures
- **Limitations:** Do not generalize to moon phase, cloud cover, ordinary shoreline lighting, adults, or natural waters.
- **Recommended model use:** score
- **Surrogate evidence:** false

### E4 — Steady artificial light and foraging
- **Exact condition/range:** Steady nighttime treatments of 1, 4, or 12 lx compared with dark controls.
- **Observed effect:** Steady light treatments showed no apparent effect on capture efficiency, capture rate, strike rate, or latency in the studied juvenile mesocosms.
- **Measured:** Capture efficiency, rate, strikes, latency
- **Population/location:** Outdoor mesocosms, Ohio
- **Life stage:** Juvenile
- **Evidence type:** controlled mesocosm experiment
- **NOVA applicability:** Direct null evidence within tested conditions
- **Confidence:** high
- **Source / locator:** S4 — page: 152–160; section: Results; Discussion
- **Limitations:** A null in this design does not prove no effects at other spectra, intensities, cover, prey, or life stages.
- **Recommended model use:** zero-weight
- **Surrogate evidence:** false

### E5 — Turbidity × underwater light interaction
- **Exact condition/range:** Larval Bluegill tested across sediment turbidity and light levels; low-light portions fell below roughly 450 lx.
- **Observed effect:** Sediment turbidity reduced consumption primarily under lower light; at high light, prey biomass consumed did not differ with turbidity although prey size selection changed.
- **Measured:** Prey consumption and selection
- **Population/location:** Laboratory
- **Life stage:** Larval
- **Evidence type:** controlled foraging experiment
- **NOVA applicability:** Mechanistic context; not an adult bite rule
- **Confidence:** medium
- **Source / locator:** S5 — page: 781–787; section: Methods; Results; figure: Consumption by turbidity and light
- **Limitations:** Larvae, experimental prey, and illumination differ from adult recreational fisheries; do not create a universal NTU curve.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E6 — Personality and angling vulnerability
- **Exact condition/range:** Wild juvenile Bluegill captured by angling versus beach seining, then behaviorally tested.
- **Observed effect:** Angled fish were more timid and carried fewer ectoparasites than seined fish.
- **Measured:** Capture method association with behavior
- **Population/location:** Ontario field capture plus laboratory tests
- **Life stage:** Juvenile
- **Evidence type:** comparative capture/behavior study
- **NOVA applicability:** Direct catchability association but not a real-time environmental input
- **Confidence:** medium
- **Source / locator:** S6 — page: 749–755; section: Abstract; Results
- **Limitations:** Capture method can create sampling bias; behavior was measured after capture and may be population-specific.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E7 — Boldness contradiction across experiments
- **Exact condition/range:** Large outdoor-pool angling trial with individually tagged, previously behavior-tested Bluegill.
- **Observed effect:** The timidity relationship from the capture-method comparison did not carry over consistently; bolder individuals were more likely to be angled in open water away from refuge in the pool experiment.
- **Measured:** Angling outcome versus prior boldness score
- **Population/location:** Large outdoor experimental pool
- **Life stage:** Juvenile
- **Evidence type:** controlled/semi-natural angling experiment
- **NOVA applicability:** Contradictory context demonstrating no universal personality rule
- **Confidence:** medium
- **Source / locator:** S6 — page: 749–755; section: Abstract; Results; Discussion
- **Limitations:** Experimental setting and refuge geometry may drive the direction of the effect.
- **Recommended model use:** zero-weight
- **Surrogate evidence:** false

### E8 — Sociability and angling vulnerability
- **Exact condition/range:** Naturalistic experimental pond; captured and uncaptured Bluegill assessed for sociability.
- **Observed effect:** More sociable Bluegill were selectively captured by recreational angling.
- **Measured:** Angling capture and behavioral phenotype
- **Population/location:** Experimental pond, Illinois
- **Life stage:** Mixed subadult/adult-sized fish
- **Evidence type:** semi-natural angling experiment
- **NOVA applicability:** Direct vulnerability evidence but the trait is not operationally observable in BiteMap
- **Confidence:** medium
- **Source / locator:** S7 — section: Abstract
- **Limitations:** Population, social environment, lure, and angling protocol limit transfer.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E9 — Aggression/dominance and angling vulnerability
- **Exact condition/range:** Same naturalistic pond experiment.
- **Observed effect:** Aggression or dominance did not provide the same clear capture association as sociability.
- **Measured:** Behavioral phenotype versus capture
- **Population/location:** Experimental pond, Illinois
- **Life stage:** Mixed subadult/adult-sized fish
- **Evidence type:** semi-natural angling experiment
- **NOVA applicability:** Null/contradictory context
- **Confidence:** medium
- **Source / locator:** S7 — section: Abstract
- **Limitations:** Abstract-only access limits detailed effect-size verification.
- **Recommended model use:** zero-weight
- **Surrogate evidence:** false

### E10 — Metabolic phenotype and angling vulnerability
- **Exact condition/range:** 23 Bluegill captured at least once and 25 not captured, assessed by intermittent-flow respirometry.
- **Observed effect:** Captured and uncaptured fish did not differ in standard or maximum metabolic rate, postexercise oxygen consumption, or recovery time.
- **Measured:** Metabolic traits and capture history
- **Population/location:** Illinois experimental fish
- **Life stage:** Subadult/adult-sized
- **Evidence type:** realistic angling plus respirometry
- **NOVA applicability:** Direct null evidence against a metabolism-based vulnerability rule
- **Confidence:** high
- **Source / locator:** S8 — page: 1264–1270; section: Abstract; Methods; Results
- **Limitations:** Results are context-specific; they do not prove physiology never matters under other conditions.
- **Recommended model use:** zero-weight
- **Surrogate evidence:** false

### E11 — Winter dissolved oxygen, temperature, and current
- **Exact condition/range:** Backwater conditions with dissolved oxygen above/below 2 mg/L, temperature near/below 1°C, and current around/above 1 cm/s.
- **Observed effect:** When oxygen exceeded 2 mg/L, Bluegill selected water above 1°C and little detectable current; under lower oxygen they moved toward higher oxygen even if colder or flowing.
- **Measured:** Habitat selection and movement
- **Population/location:** Upper Mississippi River backwater lakes
- **Life stage:** Mixed
- **Evidence type:** field winter habitat study
- **NOVA applicability:** Winter location context only
- **Confidence:** medium
- **Source / locator:** S3 — section: Abstract
- **Limitations:** Endpoint was movement/habitat, not feeding or hook-and-line catchability.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E12 — Winter temperature, food, size, consumption, and survival
- **Exact condition/range:** Age-0 Bluegill, 4°C versus 9°C, food present/absent, small 20–30 mm versus large 50–60 mm total length.
- **Observed effect:** Food-treated fish consumed roughly 2–4% body weight/day in warm treatments, about 1–2.5% for small fish in cold treatment, and about 0.4–0.8% for large fish in cold treatment; survival depended strongly on body size and condition.
- **Measured:** Feed consumption, condition, and survival
- **Population/location:** Laboratory, Illinois
- **Life stage:** Age-0
- **Evidence type:** controlled overwinter experiment
- **NOVA applicability:** Shows temperature–size–food interaction, but not adult bite optimum
- **Confidence:** high
- **Source / locator:** S9 — page: 1298–1303; section: Abstract; Methods; Results
- **Limitations:** Juvenile winter survival and provided food cannot be translated into adult angling scores.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E13 — Diel feeding periodicity
- **Exact condition/range:** Repeated stomach-content sampling by hour of day in lake fishes including Bluegill.
- **Observed effect:** Feeding periodicity and food uptake varied by hour in the studied lake population.
- **Measured:** Stomach fullness and food uptake
- **Population/location:** Lake Opinicon, Ontario
- **Life stage:** Mixed
- **Evidence type:** field diel feeding study
- **NOVA applicability:** Direct feeding endpoint but insufficiently portable for a universal clock rule
- **Confidence:** low
- **Source / locator:** S10 — section: Abstract
- **Limitations:** Full text was inaccessible and exact bluegill hourly peaks were not used as scoring thresholds.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E14 — Daily feeding rate methodology
- **Exact condition/range:** Radioisotope-based estimate of daily Bluegill feeding rate.
- **Observed effect:** The study demonstrated that daily consumption can be quantified, but did not provide a portable real-time environmental predictor for BiteMap.
- **Measured:** Daily food uptake
- **Population/location:** Experimental study
- **Life stage:** Mixed
- **Evidence type:** controlled feeding-rate study
- **NOVA applicability:** Methodological context
- **Confidence:** low
- **Source / locator:** S11 — section: Abstract
- **Limitations:** No production rule is justified without detailed conditions and a portable predictor.
- **Recommended model use:** unavailable
- **Surrogate evidence:** false

### E15 — Body size, prey profitability, and habitat use
- **Exact condition/range:** Field and experimental comparisons across Bluegill body sizes.
- **Observed effect:** Foraging efficiency, prey choice, and profitable habitat differed with body size.
- **Measured:** Foraging efficiency, diet, and habitat use
- **Population/location:** Michigan lakes and experiments
- **Life stage:** Juvenile and adult size classes
- **Evidence type:** field/laboratory foraging study
- **NOVA applicability:** Supports size/life-stage context, not a single universal bite-size curve
- **Confidence:** medium
- **Source / locator:** S12 — section: Abstract
- **Limitations:** Abstract-only access and differing prey/habitats prevent numerical calibration here.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E16 — Reproduction and nest defense
- **Exact condition/range:** Early-summer colony nesting and male defense of eggs/fry.
- **Observed effect:** Nest defense can produce strikes or increased local vulnerability without representing feeding motivation.
- **Measured:** Agency/life-history synthesis
- **Population/location:** Virginia
- **Life stage:** Adults, especially guarding males
- **Evidence type:** government synthesis
- **NOVA applicability:** Regional context only
- **Confidence:** medium
- **Source / locator:** S2 — section: Reproduction
- **Limitations:** No direct experiment isolated feeding versus defense in hook-and-line catches.
- **Recommended model use:** context-only
- **Surrogate evidence:** false

### E17 — Atmospheric weather, moon, and natural-light folklore
- **Exact condition/range:** Barometric pressure, fronts, wind, ordinary rain, cloud cover, and moon phase.
- **Observed effect:** No qualifying Bluegill study established direct natural-weather or lunar catchability effects after underwater light, temperature, oxygen, and habitat were separated.
- **Measured:** Evidence gap after broad search
- **Population/location:** Range-wide
- **Life stage:** Mixed
- **Evidence type:** systematic evidence-gap assessment
- **NOVA applicability:** Supports zero weight
- **Confidence:** medium
- **Source / locator:** S4 — page: 152–162; section: Discussion
- **Limitations:** The artificial-light experiment does not justify natural moon or cloud rules.
- **Recommended model use:** zero-weight
- **Surrogate evidence:** false

### E18 — Recent angling pressure, learning, and depletion
- **Exact condition/range:** Repeated recent angling exposure independent of removals and density.
- **Observed effect:** Behavioral vulnerability studies show individual selectivity, but no qualifying study provided a portable short-term pressure-decay function separated from harvest depletion.
- **Measured:** Evidence gap and synthesis
- **Population/location:** Range-wide
- **Life stage:** Mixed
- **Evidence type:** systematic evidence-gap assessment
- **NOVA applicability:** Withhold production pressure multiplier
- **Confidence:** medium
- **Source / locator:** S6 — page: 749–757; section: Discussion
- **Limitations:** Capture history, population structure, refuge, and removal can all change observed catch rates.
- **Recommended model use:** unavailable
- **Surrogate evidence:** false

## Remaining research gaps

- Adult wild Bluegill feeding/catchability curves across water temperature, trend, and dissolved oxygen
- Adult turbidity and natural-underwater-light angling experiments
- Natural diel and seasonal catchability studies controlling angler effort, cover, and prey
- Short-term angling-pressure learning separated from removal and density
- Northern Virginia population/size/sex validation of personality vulnerability
- Direct barometric pressure, fronts, wind, rain, cloud, and moon studies after aquatic mediators are controlled

## Complete bibliography

### S1
California Academy of Sciences (2026). **Eschmeyer’s Catalog of Fishes: Genera, Species, References — Lepomis macrochirus**. California Academy of Sciences.
- URL: https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatmain.asp
- Geographic scope: Range-wide taxonomic record
- Access mode: taxonomic-catalog-web
- Verification: AI-reviewed-unverified

### S2
Virginia Department of Wildlife Resources (n.d.). **Bluegill**. Virginia Department of Wildlife Resources.
- URL: https://dwr.virginia.gov/wildlife/information/bluegill/
- Geographic scope: Virginia
- Access mode: agency-web-full-text
- Verification: AI-reviewed-unverified

### S3
B. C. Knights, Barry L. Johnson, and M. B. Sandheinrich (1995). **Responses of Bluegills and Black Crappies to Dissolved Oxygen, Temperature, and Current in Backwater Lakes of the Upper Mississippi River during Winter**. North American Journal of Fisheries Management 15(2):390–399. DOI: 10.1577/1548-8675(1995)015<0390:ROBABC>2.3.CO;2.
- URL: https://doi.org/10.1577/1548-8675(1995)015%3C0390:ROBABC%3E2.3.CO;2
- Geographic scope: Upper Mississippi River backwater lakes
- Access mode: agency-metadata-and-abstract
- Verification: AI-reviewed-unverified

### S4
Susanna E. Harrison and Suzanne M. Gray (2024). **Effects of light pollution on Bluegill foraging behavior**. Transactions of the American Fisheries Society 153(2):152–162. DOI: 10.1002/tafs.10451.
- URL: https://doi.org/10.1002/tafs.10451
- Geographic scope: Outdoor mesocosms, Ohio; juvenile Bluegill
- Access mode: author-upload-full-text
- Verification: AI-reviewed-unverified

### S5
Jeffrey G. Miner and Roy A. Stein (1993). **Interactive Influence of Turbidity and Light on Larval Bluegill (Lepomis macrochirus) Foraging**. Canadian Journal of Fisheries and Aquatic Sciences 50(4):781–788. DOI: 10.1139/f93-090.
- URL: https://doi.org/10.1139/f93-090
- Geographic scope: Laboratory larval Bluegill
- Access mode: author-upload-full-text
- Verification: AI-reviewed-unverified

### S6
Alexander D. M. Wilson, Thomas R. Binder, Keegan P. McGrath, Steven J. Cooke, and Jean-Guy J. Godin (2011). **Capture technique and fish personality: angling targets timid bluegill sunfish, Lepomis macrochirus**. Canadian Journal of Fisheries and Aquatic Sciences 68(5):749–757. DOI: 10.1139/f2011-019.
- URL: https://doi.org/10.1139/f2011-019
- Geographic scope: Wild juvenile Bluegill; Ontario field capture and laboratory behavior tests
- Access mode: author-repository-full-text
- Verification: AI-reviewed-unverified

### S7
Michael J. Louison, Jennifer D. Jeffrey, Cory D. Suski, and Jeffrey A. Stein (2018). **Sociable bluegill, Lepomis macrochirus, are selectively captured via recreational angling**. Animal Behaviour 142:129–137. DOI: 10.1016/j.anbehav.2018.06.013.
- URL: https://doi.org/10.1016/j.anbehav.2018.06.013
- Geographic scope: Naturalistic experimental pond, Illinois
- Access mode: publisher-abstract-only
- Verification: AI-reviewed-unverified

### S8
Michael J. Louison, J. A. Stein, and C. D. Suski (2018). **Metabolic phenotype is not associated with vulnerability to angling in bluegill sunfish (Lepomis macrochirus)**. Canadian Journal of Zoology 96:1264–1271. DOI: 10.1139/cjz-2017-0363.
- URL: https://doi.org/10.1139/cjz-2017-0363
- Geographic scope: Realistic angling sessions and intermittent-flow respirometry, Illinois
- Access mode: author-repository-full-text
- Verification: AI-reviewed-unverified

### S9
Daniel E. Shoup and David H. Wahl (2011). **Body Size, Food, and Temperature Affect Overwinter Survival of Age-0 Bluegills**. Transactions of the American Fisheries Society 140(5):1298–1304. DOI: 10.1080/00028487.2011.621812.
- URL: https://doi.org/10.1080/00028487.2011.621812
- Geographic scope: Laboratory age-0 Bluegill, Illinois
- Access mode: author-repository-full-text
- Verification: AI-reviewed-unverified

### S10
Allen Keast and Linda Welsh (1968). **Daily Feeding Periodicities, Food Uptake Rates, and Dietary Changes with Hour of Day in Some Lake Fishes**. Journal of the Fisheries Research Board of Canada 25(6):1133–1144. DOI: 10.1139/f68-099.
- URL: https://doi.org/10.1139/f68-099
- Geographic scope: Lake Opinicon, Ontario
- Access mode: publisher-abstract-only
- Verification: AI-reviewed-unverified

### S11
Seppo E. Kolehmainen (1974). **Daily Feeding Rates of Bluegill (Lepomis macrochirus) Determined by a Refined Radioisotope Method**. Journal of the Fisheries Research Board of Canada 31(1):67–74. DOI: 10.1139/f74-010.
- URL: https://doi.org/10.1139/f74-010
- Geographic scope: Experimental Bluegill feeding-rate study
- Access mode: publisher-abstract-only
- Verification: AI-reviewed-unverified

### S12
Gary G. Mittelbach (1981). **Foraging Efficiency and Body Size: A Study of Optimal Diet and Habitat Use by Bluegills**. Ecology 62(5):1370–1386. DOI: 10.2307/1937300.
- URL: https://doi.org/10.2307/1937300
- Geographic scope: Michigan lakes and laboratory/field experiments
- Access mode: publisher-abstract-only
- Verification: AI-reviewed-unverified

## Adversarial review outcome

Every proposed score rule was rechecked against the measured endpoint. Movement, habitat occupancy, growth, survival, reproductive behavior, and creel seasonality were retained as context unless feeding or hook-and-line catchability was measured directly. Numerical conditions were kept within the studied units and populations, contradictory or null findings were preserved, and no final production multiplier or smooth response curve was invented.
