# BiteMap NOVA research resume packet

## Completed species
- largemouth-bass (previous archive; verification audit pending)
- smallmouth-bass (previous archive; verification audit pending)
- channel-catfish (previous structural template; S13 coauthor correction required)
- black-crappie (Batch 1)
- white-crappie (Batch 1)
- bluegill (Batch 1)

## Pending species
- Batch 2: redbreast-sunfish, pumpkinseed, green-sunfish, rock-bass
- Batch 3: rainbow-trout, brown-trout, brook-trout
- Batch 4: blue-catfish, flathead-catfish, white-catfish
- Batch 5: striped-bass, white-perch, yellow-perch
- Batch 6: walleye, muskellunge, northern-snakehead
- Batch 7: spotted-bass, common-carp, american-eel
- Batch 8: fallfish, creek-chub, white-sucker
- Batch 9: yellow-bullhead, brown-bullhead, northern-hogsucker
- Batch 10: shorthead-redhorse, blacknose-dace, longnose-dace
- Batch 11: mottled-sculpin, tessellated-darter, gizzard-shad

## Next recommended batch
**Batch 2 — Sunfishes.** Pumpkinseed, green sunfish, and rock bass must receive serious independent targetability assessments rather than being presumed guide-only.

## Schema and verification
- Schema version: 1.1
- Verification status: AI-reviewed-unverified
- Batch 1 archive: BiteMap_batch-1_deep_verified_research_archive.zip

## Known corrections
- Channel-catfish reference archive S13 must list Kenneth O. Allen **and James W. Avault Jr.**
- Andree & Wahl’s crappie paper uses the original title-page byline **Sara R. Andree and David H. Wahl**; upload-site metadata using “Sara Craft” was rejected.
- Baseline Batch 1 reports were shallow and contained synthesis-derived activity/spawn statements that were not accepted as feeding/catchability rules.

## Unresolved questions
- black-crappie: The older low-temperature feeding article was not available in full text during this run; it supports only a cautious context statement, not calibration.
- black-crappie: No direct adult Mid-Atlantic temperature, oxygen, turbidity, weather, or pressure catchability experiment was found.
- white-crappie: The Kaw tailwater flow relationship lacks portability to ordinary reservoirs/rivers and must be locally validated before scoring.
- white-crappie: No direct adult oxygen or temperature catchability function was found.
- bluegill: Natural moon/cloud effects cannot be inferred from the artificial-light mesocosm study.
- bluegill: Adult Mid-Atlantic temperature, oxygen, turbidity, and short-term pressure functions remain unavailable.

## Files a new chat must receive
1. BiteMap_complete_37_species_research_archive.zip
2. BiteMap_channel-catfish_deep_verified_research_archive.zip
3. BiteMap_batch-1_deep_verified_research_archive.zip
4. The master research prompt, changed to `ACTIVE BATCH = BATCH 2`

Do not treat prior validation as human verification. Recheck original title pages and bylines for every included source.
