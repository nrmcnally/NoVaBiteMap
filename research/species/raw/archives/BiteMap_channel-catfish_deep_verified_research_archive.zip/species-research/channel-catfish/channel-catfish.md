# BiteMap NOVA Fisheries-Science Evidence Review

## Species 3 of 37 - Channel catfish

| Field | Value |
|---|---|
| Priority | 3 |
| BiteMap status | current |
| BiteMap speciesId | `channel-catfish` |
| Supplied scientific name | *Ictalurus punctatus* |
| Accepted scientific name | *Ictalurus punctatus* |
| Research status | PARTIAL |

Machine-readable JSON supplied separately in the research archive.

Bibliographic identity was checked against each DOI landing page or original document. Source claims and locators remain AI-reviewed-unverified pending independent BiteMap audit.

## Taxonomy check

The currently accepted name remains **_Ictalurus punctatus_ (Rafinesque, 1818)**. The original combination was **_Silurus punctatus_**. No species-level geographic revision was identified that changes the Northern Virginia target name. [S1](https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatget.asp?spid=54206)

Relevant aliases and historical usages:

- Silurus punctatus Rafinesque, 1818 (original combination)
- Ictalurus lacustris punctatus (Rafinesque, 1818) (former subspecies combination)
- Pimelodus nigricans Lesueur, 1819 (historical name of uncertain or context-dependent synonymy; use only as a search alias)

### Geographic, stocking, and hybrid applicability warning

The accepted scientific name remains Ictalurus punctatus. No species-level geographic split was identified that changes the Northern Virginia name. Applicability can nevertheless differ among hatchery strains, crossbreeds, and Channel Catfish x Blue Catfish hybrids, which have shown different angling vulnerability. Virginia populations are native only in parts of southwestern Virginia and widely introduced elsewhere; stocking lineage and management history can therefore affect transfer. Continue using BiteMap speciesId channel-catfish.

## 1. Executive conclusion

### Strongest supported predictors

- **Feeding declines gradually with seasonal cooling, but Channel Catfish continue feeding at low temperatures; no hard cold-water cessation value is supported.** Model use: **score**. Evidence: E5, E6.
- **During cold-water conditions, warming or stable water supported greater feeding than actively cooling water in the reviewed winter experiment.** Model use: **score**. Evidence: E7.
- **Sustained extreme warm water in the 31-35 C treatment reduced feeding even while activity increased, so movement must not be treated as feeding.** Model use: **score**. Evidence: E8, E9.
- **Reduced dissolved oxygen lowered feed consumption across laboratory and warm-pond studies, with strong impairment at severe oxygen deficits.** Model use: **score**. Evidence: E10, E11, E12.
- **Freshly stocked harvestable Channel Catfish were especially catchable during the first fishing period after put-and-take stocking, followed by rapid decline.** Model use: **score**. Evidence: E18.

### Context only

- Virginia anglers intentionally target Channel Catfish across ponds, reservoirs, and warmwater streams, and stocked fisheries require management-history context. Model use: **context-only**. Evidence: E3.
- Diel behavior is flexible: adult Conowingo feeding was daylight-heavy with an afternoon maximum, while river telemetry and juvenile evidence showed stronger night activity. Model use: **context-only**. Evidence: E4, E14, E15, E20.
- Elevated flow can relocate fish into floodplain, oxbow, and backwater habitat, changing location rather than proving increased feeding. Model use: **context-only**. Evidence: E13.
- Spawning, seasonal creel patterns, and hatchery strain or hybrid identity affect interpretation but do not support generic bonuses. Model use: **context-only**. Evidence: E2, E17, E19, E20.

### Unsupported popular claims - zero weight

- barometric pressure
- pressure trend
- generic cold-front or warm-front classification
- wind as an independent biological multiplier
- ordinary rainfall as an independent multiplier
- cloud-cover bonus
- moon phase or solunar tables
- universal night-bite multiplier
- generic stained-water benefit
- fixed tide-stage rule
- growth optimum used as bite optimum

### Most important evidence gaps

- Direct wild-adult hook-and-line catchability across temperature and dissolved oxygen in Mid-Atlantic waters
- Field validation of aquaculture feeding relationships in rivers and reservoirs
- Measured turbidity and underwater-visibility effects on adult feeding or catchability
- Direct Channel Catfish nest-defense catchability evidence
- Waterbody-specific flow-rate-of-change and tidal-current studies
- Fishing-pressure learning versus harvest-depletion experiments
- Direct weather-variable tests after aquatic mediators are controlled

## Research breadth audit

This replacement used **17 genuinely relevant sources**, including eight peer-reviewed primary studies, five government technical or species sources, one thesis, one university extension synthesis, one taxonomic catalog, and one additional peer-reviewed juvenile-behavior study. The prior template-level package contained three sources and four evidence records. The replacement closes with 20 evidence-ledger records after targeted searches across taxonomy, Virginia management and angler use, Mid-Atlantic stomach chronology, winter feeding, extreme heat, temperature-oxygen interactions, warm-pond oxygen minima, river-floodplain movement, diel telemetry, juvenile diel feeding, salinity, strain and hybrid catchability, immediate post-stocking creel catch, and Pennsylvania seasonal catch.

The added sources materially changed the model conclusion. The old package found no safe predictor; the replacement supports bounded temperature-trend, extreme-heat, dissolved-oxygen, and immediate post-stocking rules while retaining null values for unsupported universal optima, cessation points, salinity ranges, turbidity thresholds, and weather effects. Full search details and exclusions are in `search-breadth-audit.json`.

## 2. Evidence ledger

| Evidence ID | Variable | Exact condition or range | Observed effect | What was measured | Population/location | Life stage | Evidence type | Applicability to Northern Virginia | Confidence | Model use | Source ID and locator | Limitations |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E1 | Taxonomy | Original description as Silurus punctatus Rafinesque, 1818; currently valid as Ictalurus punctatus | The accepted scientific name remains Ictalurus punctatus. No taxonomic split requiring a different Northern Virginia name was identified. | expert/agency synthesis | Type locality Ohio River; taxonomic record is range-wide | Not applicable | taxonomic catalog | Directly applicable to naming; not a biological score input | high | unavailable | [S1](https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatget.asp?spid=54206); Species record for punctatus, Silurus Rafinesque | Taxonomic validity does not establish that all hatchery strains, crosses, or hybrids have identical behavior. |
| E2 | Virginia habitat, diet, and reproduction | Virginia rivers, reservoirs, ponds, and warmwater habitats; spawning generally April-June | Channel Catfish are opportunistic feeders using fish, invertebrates, and other foods. Adults use varied still and flowing waters. Spawning occurs in concealed cavities, with males preparing and guarding nests. | expert/agency synthesis | Virginia | Mixed; reproduction concerns adults | government species account | Direct regional context | medium | context-only | [S2](https://dwr.virginia.gov/wildlife/information/channel-catfish/); Diet; Habitat; Reproduction | The account does not quantify short-term feeding or hook-and-line catchability functions. |
| E3 | Recreational targeting and stocked-fish context | 2016 Virginia angler survey and statewide stocked fisheries | Fifty-four percent of surveyed Virginia anglers reported specifically fishing for catfish; reported catfish effort occurred in small impoundments (23%), large impoundments (27%), warmwater streams (38%), and private lakes (12%). The plan notes stocked Channel Catfish are vulnerable to anglers. | expert/agency synthesis | Virginia | Catchable stocked fish and mixed wild fish | government technical report | Direct management and targetability relevance | medium | context-only | [S3](https://dwr.virginia.gov/wp-content/uploads/media/Virginia-Channel-Catfish-Management-Plan.pdf); p. 2; Introduction and 2016 Angler Survey summary | Survey percentages describe angler participation and habitat choice, not per-fish environmental catchability. |
| E4 | Diel feeding chronology | Three-hour stomach collections across 24 hours in July-November | Freshly ingested food occurred at every collection. Feeding began increasing around 0400, reached a maximum between 1500 and 1800, and was heavier during daylight in the studied reservoir. | prey consumption | Conowingo Reservoir, Maryland-Pennsylvania border | Subadult and adult fish represented in 798 stomachs | government technical report | High regional relevance, but one reservoir and one seasonal study | medium | context-only | [S4](https://seafwa.org/sites/default/files/journal-articles/MATHUR-377.pdf); p. 379; Food and feeding chronology | Stomach chronology is not angling catchability. Gear, prey availability, reservoir operations, and season may alter diel timing. |
| E5 | Seasonal cooling and feeding | July-November; water temperature declined from approximately 82 F in July to 53 F in November | The percentage of empty stomachs increased as the season cooled, consistent with declining feeding intensity, while feeding did not cease. | prey consumption | Conowingo Reservoir, Maryland-Pennsylvania border | Subadult and adult | government technical report | High regional relevance | medium | score | [S4](https://seafwa.org/sites/default/files/journal-articles/MATHUR-377.pdf); p. 379; Food and feeding chronology; seasonal stomach fullness | Temperature covaried with month, prey, and reservoir conditions. Empty-stomach frequency is not a calibrated catchability curve. |
| E6 | Cold-water feeding rate | Average feed consumption was approximately 0.7% body weight at 15.7-21.1 C, 0.3% at 10.1-15.6 C, and 0.1% at 10 C or lower; voluntary feeding was observed down to 7 C | Feed intake was progressively reduced at colder temperatures, but Channel Catfish continued accepting feed at 7 C. | feeding rate | Mississippi earthen ponds and indoor winter-feeding vats | Market-size and submarket cultured fish | peer-reviewed primary study | Mechanistically relevant; commercial feed and southern aquaculture conditions limit direct transfer | medium | score | [S5](https://academic.oup.com/naja/article/73/1/60/7834420); p. 64; Vat Study - feed consumption results; Table 6; Figure 2 | Rations were management treatments, not unrestricted wild foraging. Percent-body-weight values must not be interpreted as BiteMap score multipliers. |
| E7 | Short-term temperature trend | Winter days classified by increasing, decreasing, or unchanged water temperature within approximately 7-21.1 C | Feed consumption was significantly greater on warming or thermally stable days than on cooling days. | feeding rate | Mississippi winter aquaculture ponds and vats | Cultured subadult and adult-sized fish | peer-reviewed primary study | Plausible short-term mechanism for Mid-Atlantic winter waters; magnitude not portable | medium | score | [S5](https://academic.oup.com/naja/article/73/1/60/7834420); p. 64; Vat Study - temperature-direction analysis; Figure 2 | The result involved offered commercial feed and managed ponds. It does not establish a universal front or barometric-pressure rule. |
| E8 | Chronic high-temperature feeding | Cyclic temperature treatments of 23-27, 27-31, and 31-35 C | Feed consumption was greatest at 27-31 C and declined in the 31-35 C treatment. | feeding rate | Controlled aquaculture tanks in Mississippi | Juvenile Channel Catfish | peer-reviewed primary study | Direction of extreme-heat effect is useful; juvenile aquaculture values are not a wild adult bite optimum | medium | score | [S6](https://academic.oup.com/naja/article/75/1/77/7834728); p. 81; Results; Figure 3 | Do not set 27-31 C as an optimum bite range. Fish size, ration, cycling regime, and captive density differ from Northern Virginia fisheries. |
| E9 | Movement versus feeding under high heat | Cyclic 31-35 C treatment compared with cooler treatments | General activity was greatest in the hottest treatment even though feed consumption declined and survival was lower, demonstrating that movement can increase while feeding performance worsens. | movement/activity | Controlled aquaculture tanks in Mississippi | Juvenile | peer-reviewed primary study | Strong adversarial warning; exact treatment not directly transferable | high | context-only | [S6](https://academic.oup.com/naja/article/75/1/77/7834728); p. 81-82; Results - Feed Consumption, Activity, and Survival; Discussion; Figure 3-5 | Activity was observed in tanks and may include stress behavior. It must not be interpreted as higher catchability. |
| E10 | Temperature-dissolved oxygen interaction on feeding | 15.7-31.7 C and 30, 70, or 100% air saturation | Feed intake increased with temperature across the tested range and declined progressively as oxygen fell from 100 to 30% saturation; feed intake was significantly lowest at 15.7 C and highest at 30 C with 100% saturation in the tested treatments. | feeding rate | Controlled aquaria simulating southeastern United States spring and fall | Juveniles initially about 15 g and 10-12 cm | peer-reviewed primary study | Mechanistically useful; juvenile aquaculture experiment, no descending thermal limb | medium | score | [S7](https://www.sciencedirect.com/science/article/pii/S0044848699002744); p. 342; Results and discussion; Figure 2 | The study could not produce the supra-optimal descending limb. Growth values and the 30 C treatment must not be converted into a wild adult bite optimum. |
| E11 | Dissolved oxygen saturation and appetite | 100, 60, and 36% oxygen saturation | Food consumption and growth were substantially reduced at 36% saturation while survival remained 100%, separating feeding impairment from lethality. | feeding rate | Controlled aquaculture experiment | Juvenile Channel Catfish | peer-reviewed primary study | Supports low-oxygen feeding penalty; percent saturation should be preserved | medium | score | [S8](https://academic.oup.com/tafs/article-abstract/102/4/835/7895306); p. 835; Abstract | Only the abstract was accessed. Percent saturation varies in mg/L with temperature, pressure, and salinity, so no universal mg/L conversion is supplied. |
| E12 | Minimum daily dissolved oxygen and feed consumption | Warm earthen ponds; feed began decreasing below approximately 3.0 mg/L and declined rapidly below 2.5 mg/L; at 1.7 mg/L feed was 44.1% below the high-oxygen control | Lower nightly minimum dissolved oxygen reduced the amount of feed consumed, with a nonlinear increase in feeding loss at severe minima. | feeding rate | Commercial-scale earthen ponds in Mississippi | Stocked production fish | peer-reviewed primary study | Useful for warm ponds and reservoirs with nightly oxygen minima; not a universal river threshold | medium | score | [S9](https://academic.oup.com/naja/article/70/4/371/7849058); p. 378; Discussion - feed consumption response to minimum dissolved oxygen; Table 1 and 3; Figure 4 | Aeration treatments, stocked density, pellet feeding, and warm pond conditions differ from wild Northern Virginia systems. Use only within compatible warmwater contexts. |
| E13 | Elevated flow and floodplain access | Low-flow channel conditions versus elevated flow connecting river channel, oxbow, and floodplain habitats | During low flow, tracked fish largely remained in-channel and moved less than 1 km. During elevated flow, fish moved into or remained within floodplain-connected reaches; several entered floodplain or oxbow habitat, and one moved approximately 40 km. | movement/activity | Coldwater River floodplain system, Mississippi | Adult radio-tagged fish | government technical report | Qualitatively relevant to connected river-floodplain systems; less direct for confined Northern Virginia reaches | medium | context-only | [S10](https://seafwa.org/journal/1997/channel-catfish-movements-relation-river-channel-floodplain-connections); p. 108; Results; Table 1 | Movement and habitat access do not establish increased feeding or hook-and-line catchability. Absolute flows are system-specific. |
| E14 | Diel and seasonal river movement | September 2014-April 2016, 24-hour locations of 27 Channel Catfish in a 16-km lower Wabash River reach | Movement was greatest at night across seasons; displacement was greatest in fall and lower in spring. Activity increased as water temperature decreased, while gauge height was not a significant predictor. Bank and riprap use varied by season and day-night period. | movement/activity | Lower Wabash River, Illinois-Indiana | Adult | thesis or dissertation | Large Midwestern river context; useful for habitat and diel context but conflicts with feeding-temperature studies | low | context-only | [S11](https://thekeep.eiu.edu/theses/2504/); Repository abstract | Only the repository abstract was accessible. Increased movement during cooling does not mean increased feeding; exact results require full-text audit. |
| E15 | Juvenile nocturnal feeding | Juveniles 20-56 mm observed across diel periods in natural habitat | Juveniles were more abundant during evening and night and fed mainly during darkness. | prey consumption | Natural habitat outside the Mid-Atlantic | Small juveniles | peer-reviewed primary study | Low for adult angling forecasts; supports life-stage-specific flexibility | low | context-only | [S12](https://link.springer.com/article/10.1007/s10228-018-0653-4); p. 166; Abstract | Only the abstract was accessed. Juvenile behavior and study geography cannot override adult Conowingo feeding chronology. |
| E16 | Salinity tolerance of early life stages | Egg and larval exposures up to approximately 16 ppt; hatching success declined around 8 ppt and post-yolk-sac survival was limited near 9-10 ppt | Early life stages tolerated some brackish exposure, but development and survival declined as salinity increased. | survival | Laboratory early-life-stage experiment | Eggs and larvae | government technical report | Relevant only to reproduction in tidal-brackish waters, not adult catchability | low | context-only | [S13](https://seafwa.org/journal/1969/effects-salinity-growth-and-survival-channel-catfish-ictalurus-punctatus); p. 319; Abstract | The full report was accessed, but this record concerns early life stages. Adult salinity preference, feeding, and angling catchability were not measured. |
| E17 | Genetic stock and hybrid catchability | Multiple Channel Catfish strains, crossbreeds, and Channel Catfish x Blue Catfish hybrids in controlled ponds | Angling vulnerability differed among genetic groups; hybrids and some crosses were more catchable than parental or comparison strains. | angling catchability | Controlled pond experiments in the southeastern United States | Stocked catchable fish | peer-reviewed primary study | Important applicability warning for stocked Northern Virginia fisheries | medium | context-only | [S14](https://www.sciencedirect.com/science/article/pii/0044848686901973); p. 193; Abstract | Only the abstract was accessed. Genetic composition in individual Northern Virginia stockings is often unknown, so no environmental multiplier is justified. |
| E18 | Immediate post-stocking catchability | Equal numbers of marked Channel Catfish and hybrids stocked into four urban ponds on three occasions; five daily creel surveys over two weeks | Nearly five times more Channel Catfish than hybrids were harvested in the first daily survey after stocking. Channel Catfish harvest declined significantly by the second survey, and later surveys showed no significant type difference. | angling catchability | Four urban put-and-take fisheries in Texas | Harvestable fish around 305 mm total length | peer-reviewed primary study | Strong for managed put-and-take ponds immediately after stocking; weak for wild rivers and established populations | medium | score | [S15](https://academic.oup.com/najfm/article-abstract/41/S1/S293/7748545); p. S293; Abstract | Only the abstract was accessed. The decline may combine harvest depletion, dispersal, acclimation, angler effort, and behavioral change; it is not evidence of a feeding surge. |
| E19 | Seasonal angler catch in Mid-Atlantic waters | Pennsylvania creel surveys from 1986-2002; reservoir catches greatest July-October and river catches greatest June-September | Observed angler catches were seasonally concentrated in warmer months, with different timing between reservoirs and rivers. | angling catchability | Pennsylvania rivers, reservoirs, and lakes | Catchable mixed-size fish | government technical report | Good regional context; not a per-fish environmental function | medium | context-only | [S16](https://www.pa.gov/content/dam/copapwp-pagov/en/fishandboat/documents/about-us/agencyoverview/species-mgmt-plans/catfishmgmtplan.pdf); p. 19; Angler use and seasonal catch | Catch totals confound fish abundance, effort, access, gear, harvest, and daytime survey design. Use as categorical seasonal context only. |
| E20 | Feeding mode, diel flexibility, and spawning synthesis | Species-life-history synthesis for southeastern Channel Catfish | Channel Catfish use taste and olfaction, feed near the bottom, and may feed by day or night. Spawning is associated with warm water and cavities, with male parental care. | expert/agency synthesis | Southeastern United States | Mixed | university extension | Mechanistically relevant for guide and habitat context | medium | context-only | [S17](https://srac.msstate.edu/pdfs/Fact%20Sheets/180%20Channel%20Catfish-%20Life%20History%20and%20Biology.pdf); p. 2-3; Habitat; Feeding; Spawning | The document includes aquaculture growth guidance. Growth optima and farm-management thresholds are not bite optima. |

## 3. Variable-by-variable synthesis

### A. Water temperature

The evidence supports a **gradual and conditional temperature function**, not a universal optimum. Mid-Atlantic stomach data showed less feeding as water cooled from summer into November, and winter experiments documented reduced but continuing feeding down to 7 C. Warming or stable winter water supported more feeding than active cooling. At the opposite extreme, cyclic 31-35 C exposure reduced feeding even while activity rose. Model use: **score**, with exact optimum, decline-onset, and cessation fields left null. Evidence: E5-E10.

### B. Dissolved oxygen

Three independent feeding studies support reduced consumption as oxygen falls. Controlled experiments preserved percent saturation, while warm earthen-pond work identified a context-specific decline below about 3.0 mg/L and a sharper decline below 2.5 mg/L. These units and contexts must not be merged into a universal threshold. Model use: **score** in compatible contexts. Evidence: E10-E12.

### C. Time and underwater light

Diel behavior is not universally nocturnal. Adult Conowingo fish consumed food throughout the day and night but fed most heavily during daylight with an afternoon maximum. Lower Wabash adults moved most at night, while small juveniles elsewhere fed mainly in darkness. Movement, life stage, and prey consumption therefore point to a flexible classification. Model use: **context-only**. Evidence: E4, E14, E15, E20.

### D. Reproductive phase

Virginia spawning is generally April-June in concealed cavities, with male nest preparation and parental care. No direct study established that guarding males are unusually vulnerable to hook-and-line presentations. Model use: **context-only**; nest defense must not be scored by copying black-bass evidence. Evidence: E2, E20.

### E. Flow and water level

Elevated flow can reconnect channel, oxbow, and floodplain habitat and cause major relocation. This can change where fish are accessible but does not prove a whole-river feeding increase. Gauge height was not significant in the accessible abstract of the lower Wabash movement study. Model use: **context-only**. Evidence: E13, E14.

### F. Turbidity and visibility

Channel Catfish possess strong chemical senses, but no qualifying study established a numerical turbidity response for adult feeding or hook-and-line catchability. The common claim that stained water automatically improves catfish biting is unsupported. Model use: **unavailable** for scoring. Evidence: E20.

### G. Tidal, current, and salinity effects

The species can occur in tidal fresh and brackish settings, but the reviewed salinity evidence concerns eggs and larvae. No adult salinity preference, tidal-stage, or measured-current catchability function was identified. Model use: **context-only**. Evidence: E13, E16.

### H. Weather variables

No qualifying species-specific evidence isolated direct barometric-pressure, front, wind, rain, cloud, or moon effects. Water-temperature trend and floodplain connectivity are measurable aquatic mechanisms and should not be relabeled as atmospheric effects. Model use: **zero-weight** for direct weather terms. Evidence: E7, E13.

### I. Seasonality

Pennsylvania creel surveys found warm-season catch concentrations that differed between rivers and reservoirs, while regional stomach data and controlled feeding explain part of that pattern through temperature. Monthly classifications remain categorical and contextual to avoid counting month, temperature, and spawning more than once. Evidence: E5-E7, E19.

### J. Habitat, stocking, and presentation

Fresh stockings can create a short, direct accessibility pulse in put-and-take ponds. Genetic strain and Channel x Blue hybrid identity also affect vulnerability. In rivers, flow can relocate fish into newly connected habitat. These factors are more defensible than generic lure or weather claims, but each requires explicit waterbody and management context. Evidence: E3, E13, E17, E18.

## 4. Conflict and uncertainty report

### Numerical ranges that must remain separate

- The winter ration categories in E6 were management treatments and cannot be converted into exact BiteMap multipliers.
- The 27-31 C treatment produced the greatest feeding in E8, but it is not a validated wild-adult optimum. The 31-35 C treatment supports an extreme-heat penalty only.
- E10 and E11 use percent oxygen saturation; E12 uses minimum daily mg/L in warm earthen ponds. They are not interchangeable without temperature, pressure, salinity, and system context.
- Early-life salinity values in E16 are survival limits for eggs and larvae, not adult feeding or habitat optima.

### Movement-feeding conflicts

- High-temperature activity increased while feeding fell in E9.
- Lower Wabash movement increased during cooling in E14, while Conowingo and winter-feeding evidence showed feeding declined with cooling.
- Floodplain movement in E13 changes location and access, not necessarily motivation to feed.

### Catchability and stocking conflicts

- Genetic strains and hybrids differed in controlled angling vulnerability, so stocked populations cannot be treated as behaviorally identical.
- The post-stocking catch pulse in E18 may reflect availability, acclimation, harvest depletion, dispersal, and angler effort. It should not be described as increased feeding.
- Pennsylvania creel patterns include abundance and effort and therefore remain context-only.

### Popular claims lacking reliable evidence

- Channel Catfish are not supported as universally nocturnal.
- Barometer, fronts, wind, rain, cloud cover, and moon phase receive zero direct weight.
- Turbid or stained water is not automatically beneficial without measured species-specific evidence.
- Growth optima and aquaculture feeding maxima are not bite optima.

### Fields where the correct answer remains unknown

- Wild adult optimum feeding or catchability temperature.
- Wild adult oxygen-avoidance and feeding-cessation values.
- Adult turbidity and underwater-light response.
- Direct male nest-defense catchability.
- Tidal-current and salinity effects on adult catchability.
- Learning versus depletion after repeated angling.

## 5. Candidate model rules

| Input | Condition | Direction | Strength | Confidence | Model use | Mechanism | Evidence | Double-counting risk |
|---|---|---|---|---|---|---|---|---|
| seasonalWaterTemperature | Progressive cooling from summer toward winter within the population's recent thermal history | decrease | moderate | medium | score | Regional stomach data and controlled winter feeding both show declining consumption as water cools, while feeding persists at low temperatures. | E5, E6 | Do not add independent month, winter, photoperiod, and temperature penalties for the same seasonal mechanism. |
| shortTermWaterTemperatureTrend | Cooling day versus warming or thermally stable day during cold-water conditions | decrease | weak | medium | score | Winter feed intake was lower on cooling days than on warming or unchanged days within the studied managed-pond range. | E7 | Do not relabel this as a cold-front or barometric-pressure effect; use measured water-temperature trend only. |
| extremeWarmWater | Sustained cyclic water temperature reaching 31-35 C (87.8-95 F) | decrease | moderate | medium | score | Juvenile feed consumption declined in the hottest treatment even as general activity increased, consistent with heat stress rather than inactivity. | E8, E9 | Do not set 27-31 C as a wild bite optimum or separately stack heat, summer, and oxygen penalties without measured inputs. |
| dissolvedOxygenPercentSaturation | Declining oxygen saturation below well-oxygenated conditions, especially near 36% or lower in the studied experiments | decrease | moderate | medium | score | Feed intake declined progressively with oxygen saturation, and food consumption was severely reduced at 36% saturation despite survival. | E10, E11 | Do not convert percent saturation to a fixed mg/L value without water temperature, pressure, and salinity. |
| minimumDailyDissolvedOxygen | Warm pond or reservoir nightly minimum below approximately 3.0 mg/L, with stronger penalty below 2.5 mg/L | decrease | moderate | medium | score | Commercial-pond feed consumption declined as minimum daily oxygen fell, with a nonlinear loss at severe minima. | E12 | Use only where a comparable warmwater nightly minimum is measured; do not combine blindly with percent-saturation rule. |
| recentStocking | Same day or first daily fishing period after a documented put-and-take Channel Catfish stocking | increase | moderate | medium | score | Newly stocked harvestable Channel Catfish were exceptionally accessible immediately after stocking; catch declined sharply by the next daily survey. | E18 | Restrict to managed stocked ponds and avoid stacking with abundance or generic seasonal bonuses. The mechanism is accessibility and depletion, not proven feeding. |
| timeOfDay | Any universal night, dawn, or afternoon category | context-only | unknown | medium | context-only | Adult Mid-Atlantic stomach data indicated strong daylight and afternoon feeding, whereas river telemetry and juvenile work indicated nocturnal behavior. | E4, E14, E15, E20 | Do not use time of day independently from life stage, waterbody, season, cover, and actual underwater light. |
| riverFlowConnectivity | Elevated flow reconnects channel, floodplain, oxbow, or backwater habitat | context-only | moderate | medium | context-only | Adults relocated into newly connected floodplain and oxbow habitat during elevated flow. | E13 | Do not translate movement into increased feeding or reuse Mississippi discharge values in Northern Virginia. |
| spawningPhase | April-June Virginia cavity spawning and male guarding | context-only | unknown | low | context-only | Spawning and male nest defense may change location and behavior, but no direct angling-catchability study of guarding Channel Catfish was identified. | E2, E20 | Do not copy black-bass nest-defense catchability to Channel Catfish. |
| stockOrHybridIdentity | Unknown hatchery strain, crossbreed, or Channel x Blue hybrid contribution | context-only | moderate | medium | context-only | Genetic groups differed in angling vulnerability in controlled studies. | E17, E18 | Do not assume every Virginia stocking consists of a single known strain or pure Channel Catfish unless stocking records confirm it. |
| seasonMonth | Pennsylvania reservoir July-October or river June-September catch concentration | context-only | moderate | medium | context-only | Creel catches were concentrated in warm months but reflect effort, abundance, access, and sampling design as well as fish behavior. | E19 | Do not stack seasonal catch context with measured temperature and stocking effects. |
| barometerWindCloudMoon | Any direct weather or solunar rule | neutral | unknown | low | zero-weight | No qualifying species-specific study isolated these variables after aquatic mediators were controlled. | E4, E7, E13, E14 | Model measured water temperature, oxygen, flow, turbidity, and stocking rather than atmospheric folklore. |

### Monthly regional activity classification

| Month | Level | Mechanisms | Model use | Evidence |
|---|---|---|---|---|
| January | low | cold-water feeding is reduced but not absent; winter fish may still move and accept food | context-only | E5, E6, E7 |
| February | low | cold-water feeding remains reduced; warming or stable water can support more feeding than active cooling | context-only | E6, E7 |
| March | variable | warming trend can increase feeding; stocking schedules may create local put-and-take opportunities | context-only | E7, E18 |
| April | variable | warming increases feeding opportunity; Virginia pre-spawn and early spawning behavior begins in some waters | context-only | E2, E7, E20 |
| May | variable | warmwater feeding increases; cavity spawning and male parental care can alter habitat use | context-only | E2, E10, E20 |
| June | moderate | Pennsylvania river catches begin their seasonal maximum period; spawning and post-spawn states overlap among waters | context-only | E2, E19 |
| July | high | regional creel catches are seasonally concentrated; warmwater feeding can be strong if oxygen remains adequate | context-only | E10, E12, E19 |
| August | high | regional creel catches remain concentrated; nightly oxygen minima can constrain feeding in warm stratified waters | context-only | E12, E19 |
| September | moderate | river and reservoir catches remain seasonally elevated; cooling can begin reducing feeding depending on waterbody | context-only | E5, E19 |
| October | variable | reservoir catches may remain elevated; seasonal cooling increasingly reduces feeding | context-only | E5, E19 |
| November | low | Conowingo stomach data showed increased empty-stomach frequency as water cooled toward 53 F; feeding persists but is reduced | context-only | E5, E6 |
| December | low | cold-water ration and consumption are reduced; short warming periods may still improve feeding relative to cooling days | context-only | E6, E7 |

## 6. Sources

- **S1 - Eschmeyer's Catalog of Fishes: Ictalurus punctatus (Rafinesque, 1818)**. Ronald Fricke, William N. Eschmeyer, and Richard van der Laan, editors (2026). Eschmeyer's Catalog of Fishes, California Academy of Sciences (online version, updated 7 July 2026). Type: taxonomic catalog. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Global taxonomic catalog; type locality Ohio River, United States. [Source link](https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatget.asp?spid=54206)
- **S2 - Channel Catfish**. Virginia Department of Wildlife Resources (2024). Virginia DWR Species Profile Database (last updated 14 August 2024). Type: government species account. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Virginia. [Source link](https://dwr.virginia.gov/wildlife/information/channel-catfish/)
- **S3 - Channel Catfish Management Plan**. VDWR Small Impoundments Committee (2021). Virginia Department of Wildlife Resources, October 2021. Type: government technical report. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Virginia statewide stocked and naturally reproducing fisheries. [Source link](https://dwr.virginia.gov/wp-content/uploads/media/Virginia-Channel-Catfish-Management-Plan.pdf)
- **S4 - Food Habits and Feeding Chronology of Channel Catfish Ictalurus punctatus (Rafinesque), in Conowingo Reservoir**. Dilip Mathur (1970). Proceedings of the Annual Conference of the Southeastern Association of Game and Fish Commissioners, volume 24, pages 377-386. Type: government technical report. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Conowingo Reservoir, lower Susquehanna River, Maryland-Pennsylvania border. [Source link](https://seafwa.org/sites/default/files/journal-articles/MATHUR-377.pdf)
- **S5 - Effects of Winter Feeding of Channel Catfish on Production in Multibatch Systems**. Adam S. Nanninga, Carole R. Engle, Nathan Stone, and Andrew E. Goodwin (2011). North American Journal of Aquaculture, volume 73, issue 1, pages 60-67. DOI: 10.1080/15222055.2011.544628. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Commercial-scale earthen ponds and indoor vats in Arkansas. [Source link](https://academic.oup.com/naja/article/73/1/60/7834420)
- **S6 - Influences of Cyclic, High Temperatures on Juvenile Channel Catfish Growth and Feeding**. Michael B. Arnold, Eugene L. Torrans, and Peter J. Allen (2013). North American Journal of Aquaculture, volume 75, issue 1, pages 77-84. DOI: 10.1080/15222055.2012.732674. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Controlled aquaculture tanks in Mississippi using juvenile Channel Catfish. [Source link](https://academic.oup.com/naja/article/75/1/77/7834728)
- **S7 - Effects of water temperature and dissolved oxygen on daily feed consumption, feed utilization and growth of channel catfish (Ictalurus punctatus)**. J. Alejandro Buentello, Delbert M. Gatlin III, and William H. Neill (2000). Aquaculture, volume 182, issues 3-4, pages 339-352. DOI: 10.1016/S0044-8486(99)00274-4. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Controlled aquaculture experiment simulating southeastern United States spring and fall conditions. [Source link](https://www.sciencedirect.com/science/article/pii/S0044848699002744)
- **S8 - The Influence of Dissolved Oxygen on the Growth of Channel Catfish**. James W. Andrews, Takeshi Murai, and George Gibbons (1973). Transactions of the American Fisheries Society, volume 102, issue 4, pages 835-838. DOI: 10.1577/1548-8659(1973)102<835:TIODOO>2.0.CO;2. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Controlled feeding experiment; southeastern aquaculture context. [Source link](https://academic.oup.com/tafs/article-abstract/102/4/835/7895306)
- **S9 - Production Responses of Channel Catfish to Minimum Daily Dissolved Oxygen Concentrations in Earthen Ponds**. Eugene L. Torrans (2008). North American Journal of Aquaculture, volume 70, issue 4, pages 371-381. DOI: 10.1577/A07-102.1. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Commercial-scale earthen ponds in Mississippi. [Source link](https://academic.oup.com/naja/article/70/4/371/7849058)
- **S10 - Channel Catfish Movements in Relation to River Channel-Floodplain Connections**. Joseph E. Flotemersch, Donald C. Jackson, and John R. Jackson (1997). Proceedings of the Annual Conference of the Southeastern Association of Fish and Wildlife Agencies, volume 51, pages 106-112. Type: government technical report. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Yockanookany River floodplain system, Mississippi. [Source link](https://seafwa.org/journal/1997/channel-catfish-movements-relation-river-channel-floodplain-connections)
- **S11 - Diel and Seasonal Patterns of Channel Catfish Movement and Habitat Use in the Lower Wabash River**. Hanna Gibbs Kruckman (2016). Master of Science thesis, Eastern Illinois University, Masters Theses 2504. Type: thesis or dissertation. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Lower Wabash River, Illinois-Indiana. [Source link](https://thekeep.eiu.edu/theses/2504/)
- **S12 - Nocturnal activity and feeding of juvenile channel catfish, Ictalurus punctatus, around offshore breakwaters in Lake Kasumigaura, Japan**. Kazuya Yamazaki, Kouki Kanou, and Kazunori Arayama (2019). Ichthyological Research, volume 66, pages 166-171. DOI: 10.1007/s10228-018-0653-4. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Natural habitat study of small juveniles outside the Mid-Atlantic. [Source link](https://link.springer.com/article/10.1007/s10228-018-0653-4)
- **S13 - Effects Of Salinity On Growth And Survival Of Channel Catfish, Ictalurus Punctatus**. Kenneth O. Allen (1969). Proceedings of the Annual Conference of the Southeastern Association of Game and Fish Commissioners, volume 23, pages 319-331. Type: government technical report. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Laboratory early-life-stage salinity experiments. [Source link](https://seafwa.org/journal/1969/effects-salinity-growth-and-survival-channel-catfish-ictalurus-punctatus)
- **S14 - Comparison of strains, crossbreeds and hybrids of channel catfish for vulnerability to angling**. Rex A. Dunham, R. Oneal Smitherman, Randell K. Goodman, and Philip Kemp (1986). Aquaculture, volume 57, issues 1-4, pages 193-201. DOI: 10.1016/0044-8486(86)90197-3. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Controlled ponds; hatchery strains, crosses, and Channel Catfish x Blue Catfish hybrids. [Source link](https://www.sciencedirect.com/science/article/pii/0044848686901973)
- **S15 - Relative Catchability of Channel Catfish and Blue Catfish x Channel Catfish Hybrids by Anglers in Put-and-Take Urban Fisheries**. Thomas J. Hungerford, Kristopher A. Bodine, John E. Tibbs, Randall A. Myers, David Prangnell, Daniel J. Daugherty, and J. Warren Schlechte (2021). North American Journal of Fisheries Management, volume 41, issue S1, pages S293-S297. DOI: 10.1002/nafm.10596. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Four small urban put-and-take fisheries in Texas. [Source link](https://academic.oup.com/najfm/article-abstract/41/S1/S293/7748545)
- **S16 - Strategic Plan for Management of Channel Catfish and Flathead Catfish in Pennsylvania 2013-2017**. Rick Lorson and Mike Depew (2013). Pennsylvania Fish and Boat Commission, Bureau of Fisheries, Fisheries Management Area 8, April 2013. Type: government technical report. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Pennsylvania rivers, reservoirs, and lakes; Mid-Atlantic recreational fisheries. [Source link](https://www.pa.gov/content/dam/copapwp-pagov/en/fishandboat/documents/about-us/agencyoverview/species-mgmt-plans/catfishmgmtplan.pdf)
- **S17 - Channel Catfish: Life History and Biology**. Thomas L. Wellborn (1988). Southern Regional Aquaculture Center, SRAC Publication No. 180 (L-2402), Texas Agricultural Extension Service, December 1988. Type: university extension. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Southeastern United States aquaculture and species-life-history synthesis. [Source link](https://srac.msstate.edu/pdfs/Fact%20Sheets/180%20Channel%20Catfish-%20Life%20History%20and%20Biology.pdf)

## 7. Final verdict

**RESEARCH STATUS: PARTIAL**

### SAFE TO IMPLEMENT

- Retain Ictalurus punctatus as the accepted name and channel-catfish as the stable BiteMap speciesId; treat strain and hybrid identity as an applicability issue rather than a taxonomy change. Model use: **unavailable**. Evidence: E1.
- Use a gradual cold-season feeding reduction rather than a hard shutoff; preserve null optimum and cessation values. Model use: **score**. Evidence: E5, E6.
- Within cold-water conditions, use measured water-temperature trend so active cooling is less favorable than warming or stable water. Model use: **score**. Evidence: E7.
- Apply a bounded extreme-heat feeding penalty when sustained water reaches the studied 31-35 C range, with juvenile aquaculture limitations displayed. Model use: **score**. Evidence: E8, E9.
- Use dissolved-oxygen feeding penalties only in the measured units and compatible contexts: percent saturation for controlled studies and minimum daily mg/L for warm pond-like systems. Model use: **score**. Evidence: E10, E11, E12.
- Apply an immediate post-stocking accessibility increase only to documented put-and-take Channel Catfish stockings, then decay it rapidly. Model use: **score**. Evidence: E18.

### CONTEXT ONLY

- Virginia angler targeting, stocked-fish management, and waterbody type should be displayed as fishery context rather than a biological activity multiplier. Model use: **context-only**. Evidence: E3.
- Diel period is flexible and population-specific; show adult daylight feeding and night-movement evidence without a universal hourly multiplier. Model use: **context-only**. Evidence: E4, E14, E15, E20.
- Elevated flow can relocate fish into connected floodplain, oxbow, and backwater habitat. Model use: **context-only**. Evidence: E13.
- Virginia spawning phase and male parental care alter habitat use, but direct nest-defense catchability is unknown. Model use: **context-only**. Evidence: E2, E20.
- Seasonal Mid-Atlantic creel patterns can guide descriptive context but not per-fish scoring. Model use: **context-only**. Evidence: E19.
- Hatchery strain, crossbreed, or hybrid identity may alter catchability and should be displayed when known. Model use: **context-only**. Evidence: E17, E18.

### DO NOT IMPLEMENT

- Do not assign a universal optimum bite-temperature range from aquaculture growth or feed-consumption peaks.. Model use: **zero-weight**. Evidence: E8, E10, E20.
- Do not apply a universal night multiplier; adult regional feeding and other movement evidence conflict.. Model use: **zero-weight**. Evidence: E4, E14, E15.
- Do not convert floodplain movement, high-temperature activity, or habitat occupancy into increased feeding.. Model use: **zero-weight**. Evidence: E9, E13, E14.
- Do not assign direct weight to barometer, pressure change, generic fronts, cloud cover, ordinary rain, wind, or moon phase.. Model use: **zero-weight**. Evidence: no qualifying direct species-specific evidence.
- Do not transfer early-life salinity limits or black-bass nest-defense catchability to adult Channel Catfish.. Model use: **zero-weight**. Evidence: E16, E2.

### MISSING

- Wild adult temperature-catchability validation
- Wild adult oxygen-catchability validation
- Adult turbidity and underwater-light studies
- River-specific flow-rate-of-change functions
- Tidal current and salinity feeding studies
- Nest-defense catchability evidence
- Fishing-pressure learning separated from depletion
- Regional stocking genetics and hybrid identity
- Direct atmospheric-weather evidence

Machine-readable JSON supplied separately in the research archive.

Bibliographic identity was checked against each DOI landing page or original document. Source claims and locators remain AI-reviewed-unverified pending independent BiteMap audit.

## Targetability Assessment

Not applicable: Channel catfish is already a current BiteMap bite-scored species.
