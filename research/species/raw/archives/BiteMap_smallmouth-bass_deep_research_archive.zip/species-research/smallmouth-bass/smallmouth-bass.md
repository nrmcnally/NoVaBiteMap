# BiteMap NOVA Fisheries-Science Evidence Review

## Species 2 of 37 - Smallmouth bass

| Field | Value |
|---|---|
| Priority | 2 |
| BiteMap status | current |
| BiteMap speciesId | `smallmouth-bass` |
| Supplied scientific name | *Micropterus dolomieu* |
| Accepted scientific name | *Micropterus dolomieu* |
| Research status | PARTIAL |

Machine-readable JSON supplied separately in the research archive.

## Taxonomy check

The currently accepted name for Smallmouth Bass remains **_Micropterus dolomieu_ (Lacepede, 1802)**. Virginia DWR uses that name, and the taxonomic review did not identify a nomenclatural change for Northern Virginia fish. The historical spelling **_Micropterus dolomieui_** appears frequently in older fisheries literature but is an incorrect spelling that should be retained only as a search alias. [S1](https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatget.asp?spid=19646) [S2](https://www.nature.com/articles/s41598-022-11743-2)

Relevant aliases and historical usages:

- Micropterus dolomieui (frequent historical misspelling in older literature)
- Micropterus dolomieu dolomieu (former nominate-subspecies usage in literature)

### Species-complex and geographic applicability warning

The accepted name for the Northern Virginia target remains Micropterus dolomieu. The Smallmouth Bass complex includes Neosho Bass (Micropterus velox) and genetically distinct Little River and Ouachita lineages in the Interior Highlands. Results from Arkansas, Oklahoma, and Ozark populations require lineage screening before transfer. The historical spelling dolomieui is incorrect but should remain a literature-search alias. Continue using BiteMap speciesId smallmouth-bass.

## 1. Executive conclusion

### Strongest supported predictors

- **Seasonal cooling produces a substantial, gradual decline in free-swimming adult activity, but does not support a hard feeding shutoff.** Model use: **score**. Evidence: E2.
- **Increasing short-term turbidity from clear water through the tested 0-40 NTU range reduced adult prey consumption and changed prey selection.** Model use: **score**. Evidence: E4.
- **Actively nest-guarding males can be highly vulnerable to angling because of brood defense, not elevated feeding.** Model use: **score**. Evidence: E7, E8.

### Context only

- Daytime and crepuscular activity tendencies vary by season and habitat and should guide context rather than create a fixed hourly multiplier. Model use: **context-only**. Evidence: E3.
- Virginia spawning chronology, flood interruption, nest failure, and reservoir migrations alter location and reproductive vulnerability but are not general feeding functions. Model use: **context-only**. Evidence: E5, E6, E9.
- Current velocity, depth, substrate, and cover affect habitat use and presentation, while sampling-method bias complicates catch-rate interpretation. Model use: **context-only**. Evidence: E10, E11.

### Unsupported popular claims - zero weight

- barometric pressure
- pressure trend
- generic cold-front or warm-front rule
- wind as an independent biological multiplier
- ordinary rain as an independent multiplier
- cloud-cover bonus
- moon phase or solunar tables
- generic stained-water benefit
- fixed tide-stage rule
- universal best-bite temperature

### Most important evidence gaps

- Direct non-spawning hook-and-line catchability across temperature in Mid-Atlantic waters
- Adult feeding and catchability responses to dissolved oxygen
- Field validation of the turbidity relationship in Northern Virginia
- Fishing-pressure learning experiments in Smallmouth Bass
- Potomac and Shenandoah flow-rate-of-change studies
- Direct weather-variable tests after aquatic mediators are controlled

## Research breadth audit

This replacement used **13 genuinely relevant sources**, including nine peer-reviewed primary studies, two government technical reports, one Virginia government species account, and one taxonomic catalog. The prior template-level package contained three sources and four evidence records. The replacement closes with 13 evidence records only after searches across taxonomy, annual and diel telemetry, turbidity and prey consumption, Virginia spawning and flow, direct nest-angling vulnerability, parental-care energetics, Virginia reservoir migration, stream habitat and current, mixed-gear capture probability, and thermal and dissolved-oxygen syntheses.

The added literature changed the model conclusion rather than merely lengthening the bibliography: it supports a direct turbidity relationship, a seasonal activity relationship, and a carefully bounded nest-defense catchability relationship while retaining null values for unsupported optimum temperature and dissolved-oxygen fields. Full search details and exclusions are in `search-breadth-audit.json`.

## 2. Evidence ledger

| Evidence ID | Variable | Exact condition or range | Observed effect | What was measured | Population/location | Life stage | Evidence type | Applicability to Northern Virginia | Confidence | Model use | Source ID and locator | Limitations |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E1 | Regional habitat, diet, and reproductive context | Virginia coolwater streams and reservoirs; agency account reports spring spawning as water begins to exceed 60 F | Adults use oxygenated coolwater streams, rocky or gravel habitats, seasonal riffle-run-pool features, cover, and reservoirs with submerged structure; males build and defend nests. | expert/agency synthesis | Virginia | Mixed; reproductive statements concern adults | government species account | Direct regional relevance | medium | context-only | [S3](https://dwr.virginia.gov/wildlife/information/smallmouth-bass/); Diet; Habitat; Reproduction | Agency synthesis does not quantify feeding, angling catchability, temperature response curves, or waterbody-specific timing. The 60 F statement is a regional spawning cue, not a bite threshold. |
| E2 | Seasonal water temperature and annual activity | Year-round monitoring from August 2021 through August 2024 across Lake Ontario and two St. Lawrence River reaches | Daily activity was lowest in winter, increased rapidly during spring, peaked in early summer, and declined through late summer and fall; metabolic-rate estimates peaked in August. Winter activity remained low but nonzero. | movement/activity | Eastern Lake Ontario and St. Lawrence River | Adult | peer-reviewed primary study | Strong species relevance, but Great Lakes climate and habitat differ from Northern Virginia rivers and reservoirs | high | score | [S4](https://link.springer.com/article/10.1186/s40317-026-00455-3); Results - Annual activity modelling; Results - Metabolic rate; Discussion; Figure Figures 3 and 6 | Acceleration and modeled metabolic rate are not feeding rate or hook-and-line catchability. Population, habitat, and climate affected the timing and magnitude of activity. |
| E3 | Time of day and underwater light | Season-specific diel models across lake and river habitats | Activity was generally elevated during daytime with evidence of crepuscular behavior, especially in summer, but daily patterns and midday reductions varied among locations and seasons. | movement/activity | Eastern Lake Ontario and St. Lawrence River | Adult | peer-reviewed primary study | Moderate; broad diel tendency is relevant but exact hourly patterns are not portable | medium | context-only | [S4](https://link.springer.com/article/10.1186/s40317-026-00455-3); Abstract - Results; Results - Daily activity modelling; Discussion; Figure Figure 4 | Activity does not identify feeding or strike probability. Location-specific differences argue against a universal dawn, dusk, or midday multiplier. |
| E4 | Turbidity and prey consumption | Laboratory treatments of 0, 5, 10, 20, and 40 NTU, with and without cover; adults averaged 290 +/- 41 mm total length | Prey consumed per hour was highest at 0 NTU and lower at every nonzero treatment; feeding rate was negatively related to turbidity. Turbidity also shifted prey selection, while cover did not change overall consumption rate. | prey consumption | Laboratory pools; adult fish collected from Illinois lakes and rivers | Adult | peer-reviewed primary study | Strong mechanistic relevance to short turbidity pulses in visual-feeding adults; field catchability remains untested | high | score | [S5](https://www.researchgate.net/publication/244836976_Effects_of_Turbidity_and_Cover_on_Prey_Selectivity_of_Adult_Smallmouth_Bass); p. 353-357; Abstract; Methods; Results; Discussion; Table Tables 1 and 2; Figure Figures 1 and 2 | The experiment was not designed to measure long-term feeding rate; trial duration varied, fish were maintained in clear water, and hook-and-line catchability was not measured. Do not infer a precise field threshold or assume all stained water is harmful. |
| E5 | Spawning temperature and streamflow | New River sites in Virginia and West Virginia; late April through mid-July; mean daily water temperature 12.5-23.5 C | Temperature explained most spawning-day variation. A June flood interrupted spawning, which resumed as water receded; a temperature-and-discharge model classified 72% of spawning and nonspawning days. | movement/activity | New River main stem and tributaries, Virginia and West Virginia | Spawning adults | peer-reviewed primary study | High regional relevance to Virginia rivers; exact ranges are spawning-specific and not bite thresholds | high | context-only | [S6](https://sitesreservoirproject.riptideweb.com/references/REF21/Appx_11E_ReservoirWaterSurfaceElevationSummaryTable/Grahamn%20and%20Orth%20.1986.%20Temperature%20Streamflowon%20Spawning%20Smallmouth%20Bass.pdf); p. 693-695 and 701; Abstract; Results; Discussion | Measured spawning chronology, not feeding or angling catchability. The source-specific temperature range and flood response should not be copied to all Northern Virginia waters. |
| E6 | Nesting success under flow and temperature variation | Regulated North Anna River, Virginia; spawning began near 15 C; high flow greater than 10 m3/s | High flow disrupted spawning five times and accounted for 85% of nest failures. Successful nests were associated with warmer incubation conditions, lower mean discharge during incubation, and less exposure to velocity increases. | survival | North Anna River, Virginia | Nesting adults, eggs, and larvae | peer-reviewed primary study | High regional relevance for reproductive success and nest persistence | medium | context-only | [S7](https://academic.oup.com/tafs/article-pdf/124/5/726/61142141/tafs_124_5_tafs0726.pdf); p. 726; Abstract | Only the abstract was accessed. Nest success and larval production are not feeding, adult activity, or hook-and-line catchability. The 10 m3/s value is system-specific. |
| E7 | Reproductive phase - nest-guarding male catchability | Experimental angling of males guarding newly deposited eggs in southeastern Ontario lakes | Seventy percent of nesting male smallmouth bass were hooked; vulnerability increased with brood size and aggressive nest defense. | angling catchability | Seven southeastern Ontario lakes | Adult nesting males | peer-reviewed primary study | Strong mechanism and species relevance; regional timing and angler protocols differ | high | score | [S8](https://academic.oup.com/tafs/article-abstract/133/5/1100/7887981); p. 1100; Abstract | Only the abstract was accessed. The effect applies to actively guarding males and reflects territorial brood defense, not increased feeding. Vulnerability is not uniform among males. |
| E8 | Nest defense, energetic cost, and feeding separation | Lake Erie with hyperabundant round gobies versus Lake Opeongo with fewer mostly open-water nest predators | Lake Erie males chased predators nine times more often, and modeled parental-care costs increased standard metabolic rate by 210% versus 28% in Lake Opeongo. Guarding males consumed few prey and only increased foraging as offspring became independent. | movement/activity | Lake Erie, United States, and Lake Opeongo, Ontario | Adult nesting males | peer-reviewed primary study | Strong mechanistic warning; predator communities and energetic costs vary by waterbody | medium | context-only | [S9](https://academic.oup.com/beheco/article/16/2/427/297852); p. 427; Abstract | Only the abstract was accessed. Modeled energetic cost and defensive activity do not establish general feeding or catchability outside the nest-guarding phase. |
| E9 | Seasonal reservoir movement and spawning migration | Two-year mark-recapture and ultrasonic telemetry study in 1,024-ha Lake Moomaw, Virginia | Less than 20% of the adult population was estimated to use reservoir headwaters during spawning; migrants mainly originated within 9 km, and fish commonly returned to previously occupied areas after spawning. | movement/activity | Lake Moomaw, western Virginia | Adult | government technical report | High regional relevance to Virginia reservoirs, but system-specific | high | context-only | [S10](https://seafwa.org/sites/default/files/journal-articles/Garren-165-174.pdf); p. 165 and 169-170; Abstract; Results; Table Tables 1 and 2 | Movement and aggregation can change where fish are encountered but do not prove higher feeding motivation or per-fish catchability. Only a minority used headwaters. |
| E10 | Current velocity, depth, substrate, and light | Shallow Flat River pools in summer; preferred reduced currents generally below 15 cm/s and depths greater than 45 cm | When current velocity was experimentally increased, bass spent less time in the habitat, foraged less, and moved more. Sun-versus-shade manipulation did not alter habitat use. | habitat selection | Flat River, Michigan | Juvenile to adult-sized stream fish | peer-reviewed primary study | Moderate qualitative relevance to Northern Virginia streams; exact velocities and depths are not portable | medium | context-only | [S11](https://academic.oup.com/tafs/article/115/2/322/7892241); p. 322; Abstract | Only the abstract was accessed. Habitat occupancy and foraging observations are not hook-and-line catchability. The light result concerns habitat use, not feeding under cloud cover. |
| E11 | Sampling method and short-term recapture | Mark-recapture sampling by angling and boat electrofishing in the Broad River, South Carolina | Angling and electrofishing had different capture probabilities and size selectivity. No PIT-tagged fish was recaptured by angling two days after initial capture, which the authors discussed as possible short-term trap shyness. | angling catchability | Broad River, South Carolina | Catchable juvenile and adult fish | peer-reviewed primary study | Useful caution for interpreting catch rates and possible pressure effects; magnitude is not transferable | medium | context-only | [S12](https://sites.warnercnr.colostate.edu/wp-content/uploads/sites/112/2018/01/Mycko-et-al-2018-bass-angling-e-fishing.pdf); p. 77 and 82; Abstract; Discussion; Table Table 3; Figure Figure 3 | The study estimated abundance, not environmental bite response. Non-recapture after two days cannot isolate learning from location, effort, lure, or detection effects and is insufficient for a pressure-scoring function. |
| E12 | Thermal feeding and performance thresholds - synthesis quality | North American literature synthesis reporting mixed values for feeding, growth, movement, and tolerance | The synthesis compiles cold-feeding and preferred-temperature estimates, but the values derive from different populations, life stages, acclimation histories, and endpoints and do not establish a portable adult bite optimum. | expert/agency synthesis | North American studies synthesized for Canadian risk assessment | Mixed | government technical report | Useful for identifying research gaps, not for a numerical Northern Virginia score | medium | unavailable | [S13](https://publications.gc.ca/collections/collection_2010/mpo-dfo/Fs97-4-2887-eng.pdf); p. 9-10; 3.2.1 Temperature | Secondary synthesis mixes feeding, growth, preference, survival, and early-life evidence. Exact temperature thresholds remain unavailable for direct bite scoring. |
| E13 | Dissolved oxygen thresholds - synthesis quality | Literature synthesis discussing oxygen concentrations for normal activity, spawning, embryos, and larvae | The synthesis indicates that oxygen requirements vary by life stage and endpoint, but it does not provide direct adult feeding or angling-catchability functions suitable for Northern Virginia. | expert/agency synthesis | North American studies synthesized for Canadian risk assessment | Mixed, including early life stages | government technical report | Useful for gap identification only | medium | unavailable | [S13](https://publications.gc.ca/collections/collection_2010/mpo-dfo/Fs97-4-2887-eng.pdf); p. 11; 3.2.4 Dissolved oxygen | Secondary synthesis; survival, reproduction, and normal activity cannot be converted into adult feeding or catchability thresholds. Numeric model values are intentionally left null. |

## 3. Variable-by-variable synthesis

### A. Water temperature

The best direct field evidence supports a **gradual seasonal activity function**, not a numerical feeding optimum. Free-swimming adults increased activity rapidly in spring, peaked in early summer, and declined through fall to low but nonzero winter levels. The Great Lakes study also showed that habitat and population changed the magnitude and timing, so BiteMap should use an acclimation-aware trend rather than a universal calendar or cutoff. Model use: **score** for the seasonal temperature/activity trend; exact feeding bands remain **unavailable**. Evidence: E2, E12.

### B. Dissolved oxygen

No reviewed study established a direct adult feeding or hook-and-line catchability response to dissolved oxygen. The available synthesis combines early-life survival, spawning, general activity, and other endpoints. All numerical oxygen fields therefore remain null. Model use: **unavailable**. Evidence: E13.

### C. Time and underwater light

Adult field activity was commonly higher during daylight and showed crepuscular tendencies, particularly in summer, but patterns varied among lake and river sites and included inconsistent midday reductions. Turbidity evidence demonstrates that underwater visibility matters to foraging, but neither daylight category nor cloud cover alone is a sufficient proxy. Model use: **context-only**. Evidence: E3, E4, E10.

### D. Reproductive phase

Virginia spawning chronology is controlled jointly by warming and discharge. New River spawning occurred from late April into mid-July in the study year, and flooding interrupted activity. North Anna River evidence shows that high flow can destroy nests. Direct angling evidence shows that actively guarding males are unusually vulnerable, but the mechanism is brood defense. Model use: **score** only for the narrowly identified nest-defense phase; all broader pre-spawn, spawning, and recovery patterns are **context-only**. Evidence: E5-E9.

### E. Flow and water level

Flow affects reproductive timing, nest survival, local current refuge, and fish location. It does not yet support a portable rising-water or falling-water bite rule. The North Anna discharge value is not transferable to other rivers, and increased movement under current does not necessarily mean increased feeding. Model use: **context-only**. Evidence: E5, E6, E10.

### F. Turbidity and visibility

The strongest feeding experiment exposed adult Smallmouth Bass to 0, 5, 10, 20, and 40 NTU. Consumption per hour was highest in clear water, lower at all nonzero treatments, and negatively related to turbidity; prey selection also shifted. This is directly useful as a short-term visual-foraging relationship, but it is not a validated field catchability threshold. Model use: **score**, conservatively bounded to the tested domain. Evidence: E4.

### G. Tidal, current, and salinity effects

The Northern Virginia Smallmouth Bass target is primarily freshwater. Current can alter local habitat use, but no qualifying source supports tidal-stage or salinity scoring. Model use: current is **context-only**; tide and salinity are **zero-weight**. Evidence: E10.

### H. Weather variables

No qualifying species-specific evidence isolated direct barometric-pressure, storm-front, wind, rain, cloud, or moon effects on activity or hook-and-line catchability. Rain and wind may matter indirectly by changing turbidity, current, temperature, or presentation. Model use: **zero-weight** for direct weather terms.

### I. Seasonality

Monthly classifications are categorical context derived from measured seasonal activity and regional reproduction, not decimal scores. Temperature, season, photoperiod, and spawning must not be counted independently when they represent the same mechanism. Evidence: E2, E5-E9.

### J. Habitat and presentation

Virginia fish use rocky or gravel habitats, seasonal pools, runs, riffles, cover, and reservoir structure. Increased local current reduced habitat use and foraging in one stream study, and a minority of Lake Moomaw adults migrated into headwaters during spring. These results can guide likely fish location and presentation but do not prove increased feeding motivation. Model use: **context-only**. Evidence: E1, E9, E10.

## 4. Conflict and uncertainty report

### Numerical ranges that should not be merged

- The New River spawning range of 12.5-23.5 C and the Virginia DWR statement that spawning begins as water surpasses 60 F describe reproductive timing, not an optimum bite band. Different waters, years, and hydrology can shift timing.
- The North Anna high-flow value greater than 10 m3/s is a system-specific nest-failure result and must not be applied to the Potomac, Shenandoah, Rappahannock, or Occoquan.
- Thermal and dissolved-oxygen values in the government synopsis mix feeding, growth, preference, survival, spawning, embryos, larvae, and adults. They cannot be silently averaged into catchability thresholds.

### Geographic and taxonomic transfer risks

- Great Lakes activity patterns involve colder, large connected lake-river habitats. The direction of seasonal change is useful; the calendar timing and magnitude are not automatically transferable.
- Interior Highlands research may involve Neosho Bass or distinct Little River and Ouachita lineages rather than the Northern Virginia target. Such evidence was not used for direct rules here.
- Ontario nest-angling evidence has a strong species-specific mechanism, but the exact capture percentage should not be treated as a Virginia probability.

### Popular claims lacking reliable evidence

- Falling barometer, approaching fronts, wind, rain, cloud cover, and moon phase receive zero direct weight.
- There is no supported universal fall feeding frenzy, dawn bonus, or best-bite temperature.
- Moderate stain was not shown to improve Smallmouth Bass feeding in the reviewed experiment; consumption declined when turbidity increased from clear water.

### Fields where the correct answer remains unknown

- Adult feeding and catchability thresholds for dissolved oxygen.
- A portable optimum feeding or bite temperature range.
- Direct non-spawning hook-and-line catchability across environmental conditions in Northern Virginia.
- The recovery time after turbidity pulses in field conditions.
- A validated fishing-pressure learning function for Smallmouth Bass.

## 5. Candidate model rules

| Input | Condition | Direction | Strength | Confidence | Model use | Mechanism | Evidence | Double-counting risk |
|---|---|---|---|---|---|---|---|---|
| waterTemperatureTrend | Progressive seasonal cooling relative to the population's recent thermal history | decrease | moderate | medium | score | Free-swimming adult activity declines through fall and reaches low winter levels while remaining nonzero. | E2 | Do not add an independent winter or month penalty if temperature trend already captures the same seasonal mechanism. |
| turbidity | Increasing short-term turbidity within the experimentally tested 0-40 NTU range | decrease | moderate | high | score | Adult prey consumption declined as turbidity increased, consistent with impaired visual foraging. | E4 | Do not stack separate rain, flow, muddy-water, and visibility penalties when they represent the same turbidity pulse. Do not extrapolate beyond the tested range. |
| reproductivePhase | Male actively guarding newly deposited eggs or dependent fry | increase | strong | high | score | Aggressive brood defense increases vulnerability to presentations near the nest. | E7, E8 | Do not label the effect feeding, apply it to females, or stack it with generic spring, shallow-water, and spawning bonuses. |
| timeOfDay | Daytime or crepuscular period relative to full night | context-only | moderate | medium | context-only | Field activity was often higher during daytime and showed crepuscular tendencies, but patterns differed by season and habitat. | E3 | Do not create fixed dawn or dusk multipliers or stack time of day with cloud and underwater-light proxies. |
| riverCurrent | Local current increases enough to displace fish from preferred reduced-velocity habitat | context-only | moderate | medium | context-only | Fish reduced habitat use and foraging and moved more when local current was increased. | E10 | Do not use the Flat River's depth or velocity values as universal thresholds or confuse habitat relocation with reduced whole-waterbody activity. |
| spawningFlowStability | Flood or high-flow pulse during spawning and nest incubation | context-only | strong | high | context-only | Flooding interrupted spawning and high flow caused nest failures in Virginia rivers. | E5, E6 | This is reproductive chronology and nest survival, not a direct adult bite modifier. Do not transfer source-specific discharge numbers between rivers. |
| springMigration | Reservoir fish moving toward tributary or headwater spawning habitat | context-only | moderate | medium | context-only | A minority of Lake Moomaw adults used headwaters during spring and commonly returned afterward. | E9 | Do not assume all reservoir adults migrate or convert aggregation into a per-fish feeding increase. |
| recentFishingPressure | Recent capture or intensive localized fishing effort | unknown | unknown | low | unavailable | One abundance study suggested possible short-term trap shyness, but it did not isolate learned avoidance or establish an environmental function. | E11 | Do not copy the Largemouth Bass fishing-pressure function to Smallmouth Bass without direct validation. |
| dissolvedOxygen | Any proposed adult feeding or catchability threshold | unknown | unknown | low | unavailable | Available reviewed synthesis mixes life stages and endpoints and does not support a direct adult bite function. | E13 | Do not convert spawning, survival, or general-activity oxygen guidance into adult feeding thresholds. |

### Monthly regional activity classification

| Month | Level | Mechanisms | Model use | Evidence |
|---|---|---|---|---|
| January | low | winter activity is near annual minimum; cold-season energy conservation | context-only | E2 |
| February | low | winter activity remains low but nonzero; deep or low-current winter habitat may concentrate fish | context-only | E2, E10 |
| March | variable | rapid warming can increase activity; pre-spawn movement may begin at different times among waters | context-only | E1, E2, E9 |
| April | variable | spring activity rises; pre-spawn and early spawning movement; flow instability can interrupt reproductive behavior | context-only | E2, E5, E9 |
| May | high | high seasonal activity; spawning and active brood defense; regional river and reservoir movements | context-only | E2, E5, E7, E9 |
| June | high | activity approaches early-summer peak; nest defense or post-spawn transition; flood pulses can disrupt nesting | context-only | E2, E5, E6, E7 |
| July | variable | Great Lakes activity can remain high early in the month; Northern Virginia heat, flow, oxygen, and turbidity can alter habitat and foraging | context-only | E2, E4, E10 |
| August | variable | metabolic demand may be high while movement and habitat responses depend on heat and flow; no direct adult oxygen threshold is available | context-only | E2, E13 |
| September | moderate | seasonal cooling begins; activity remains waterbody and flow dependent | context-only | E2, E10 |
| October | variable | fall cooling and redistribution; no direct fall-feeding bonus is supported | context-only | E2, E9 |
| November | low | declining activity and transition toward winter habitat | context-only | E2 |
| December | low | annual activity minimum and energy conservation | context-only | E2 |

## 6. Sources

- **S1 - Eschmeyer's Catalog of Fishes: Micropterus dolomieu record**. California Academy of Sciences (2026). Eschmeyer's Catalog of Fishes, online version. Type: taxonomic catalog. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Global taxonomic catalog; target record concerns eastern North America. [Source link](https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatget.asp?spid=19646)
- **S2 - Phylogenomics and species delimitation of the economically important Black Basses (Micropterus)**. Daemin Kim, Andrew T. Taylor, and Thomas J. Near (2022). Scientific Reports 12:9113. DOI: 10.1038/s41598-022-11743-2. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Range-wide North American Micropterus sampling, including the Smallmouth Bass species complex. [Source link](https://www.nature.com/articles/s41598-022-11743-2)
- **S3 - Smallmouth Bass**. Virginia Department of Wildlife Resources (2025). Virginia DWR Species Profile Database. Type: government species account. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Virginia. [Source link](https://dwr.virginia.gov/wildlife/information/smallmouth-bass/)
- **S4 - Activity and metabolic rate of free-swimming smallmouth bass (Micropterus dolomieu) in large, interconnected ecosystems**. Patrick H. Wolf, Connor W. Elliott, Paul J. Blanchfield, Mark S. Ridgway, et al. (2026). Animal Biotelemetry 14:15. DOI: 10.1186/s40317-026-00455-3. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Eastern Lake Ontario and upper and middle St. Lawrence River. [Source link](https://link.springer.com/article/10.1186/s40317-026-00455-3)
- **S5 - Effects of Turbidity and Cover on Prey Selectivity of Adult Smallmouth Bass**. Mark W. Carter, Daniel E. Shoup, John M. Dettmers, and David H. Wahl (2010). Transactions of the American Fisheries Society 139:353-361. DOI: 10.1577/T08-159.1. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Laboratory pools; adult fish collected from Illinois lakes and rivers. [Source link](https://www.researchgate.net/publication/244836976_Effects_of_Turbidity_and_Cover_on_Prey_Selectivity_of_Adult_Smallmouth_Bass)
- **S6 - Effects of Temperature and Streamflow on Time and Duration of Spawning by Smallmouth Bass**. Robert J. Graham and Donald J. Orth (1986). Transactions of the American Fisheries Society 115:693-702. DOI: 10.1577/1548-8659(1986)115<693:EOTASO>2.0.CO;2. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Three main-stem sections and two tributaries of the New River, Virginia and West Virginia. [Source link](https://sitesreservoirproject.riptideweb.com/references/REF21/Appx_11E_ReservoirWaterSurfaceElevationSummaryTable/Grahamn%20and%20Orth%20.1986.%20Temperature%20Streamflowon%20Spawning%20Smallmouth%20Bass.pdf)
- **S7 - Factors Affecting Nesting Success of Smallmouth Bass in a Regulated Virginia Stream**. Joseph A. Lukas and Donald J. Orth (1995). Transactions of the American Fisheries Society 124:726-735. DOI: 10.1577/1548-8659(1995)124<0726:FANSOS>2.3.CO;2. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: North Anna River, Virginia. [Source link](https://academic.oup.com/tafs/article-pdf/124/5/726/61142141/tafs_124_5_tafs0726.pdf)
- **S8 - Factors Affecting the Vulnerability to Angling of Nesting Male Largemouth and Smallmouth Bass**. Cory D. Suski and David P. Philipp (2004). Transactions of the American Fisheries Society 133:1100-1106. DOI: 10.1577/T03-079.1. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Seven southeastern Ontario lakes. [Source link](https://academic.oup.com/tafs/article-abstract/133/5/1100/7887981)
- **S9 - Increased parental care cost for nest-guarding fish in a lake with hyperabundant nest predators**. Geoffrey B. Steinhart, Melissa E. Sandrene, Stephanie Weaver, Roy A. Stein, and Elizabeth A. Marschall (2005). Behavioral Ecology 16:427-434. DOI: 10.1093/beheco/ari006. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Lake Erie, United States, and Lake Opeongo, Ontario. [Source link](https://academic.oup.com/beheco/article/16/2/427/297852)
- **S10 - Seasonal Movement and Distribution of Smallmouth Bass in a Virginia Impoundment**. D. A. Garren, J. J. Ney, and P. E. Bugas, Jr. (2001). Proceedings of the Annual Conference of the Southeastern Association of Fish and Wildlife Agencies 55:165-174. Type: government technical report. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Lake Moomaw, western Virginia. [Source link](https://seafwa.org/sites/default/files/journal-articles/Garren-165-174.pdf)
- **S11 - Habitat Selection by Smallmouth Bass in Response to Physical Characteristics in a Natural Stream**. Edward T. Rankin (1986). Transactions of the American Fisheries Society 115:322-334. DOI: 10.1577/1548-8659(1986)115<322:HSBSBI>2.0.CO;2. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Flat River, Michigan. [Source link](https://academic.oup.com/tafs/article/115/2/322/7892241)
- **S12 - Using angling and electric fishing to estimate smallmouth bass abundance in a river**. S. A. Mycko, Y. Kanno, and J. M. Bettinger (2018). Fisheries Management and Ecology 25:77-84. DOI: 10.1111/fme.12269. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Broad River, South Carolina. [Source link](https://sites.warnercnr.colostate.edu/wp-content/uploads/sites/112/2018/01/Mycko-et-al-2018-bass-angling-e-fishing.pdf)
- **S13 - Biological Synopsis of Smallmouth Bass (Micropterus dolomieu)**. T. G. Brown, B. Runciman, S. Pollard, A. D. A. Grant, and M. J. Bradford (2009). Canadian Manuscript Report of Fisheries and Aquatic Sciences 2887. Type: government technical report. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: North American literature synthesis with emphasis on invasion risk in British Columbia. [Source link](https://publications.gc.ca/collections/collection_2010/mpo-dfo/Fs97-4-2887-eng.pdf)

## 7. Final verdict

**RESEARCH STATUS: PARTIAL**

### SAFE TO IMPLEMENT

- Retain Micropterus dolomieu as the accepted name and smallmouth-bass as the stable BiteMap speciesId, while screening Interior Highlands evidence for species-complex applicability. Model use: **unavailable**. Evidence: taxonomy sources S1-S2.
- Use an acclimation-aware seasonal cold reduction in activity rather than a hard feeding shutoff. Model use: **score**. Evidence: E2.
- Apply a negative short-term turbidity relationship within the evidenced 0-40 NTU range, without inventing a single field threshold. Model use: **score**. Evidence: E4.
- Allow a brood-defense vulnerability modifier only for actively nest-guarding males and label the mechanism as nest defense. Model use: **score**. Evidence: E7, E8.

### CONTEXT ONLY

- Daytime and crepuscular movement tendency. Model use: **context-only**. Evidence: E3.
- Spawning chronology, flood interruption, nest success, and post-spawn recovery. Model use: **context-only**. Evidence: E5, E6, E8.
- Spring reservoir migration and return movement. Model use: **context-only**. Evidence: E9.
- Current velocity, depth, substrate, and cover as location and presentation context. Model use: **context-only**. Evidence: E10.
- Sampling-method bias and possible short-term trap shyness. Model use: **context-only**. Evidence: E11.

### DO NOT IMPLEMENT

- Universal best-bite, optimum-feeding, or feeding-cessation temperatures. Model use: **zero-weight**. Evidence: E2, E12.
- Adult dissolved-oxygen thresholds derived from mixed life-stage synthesis. Model use: **zero-weight**. Evidence: E13.
- A universal dawn, dusk, or midday multiplier. Model use: **zero-weight**. Evidence: E3.
- Barometer, fronts, cloud, rain, wind, moon, or solunar multipliers. Model use: **zero-weight**. Evidence basis: no qualifying direct species-specific study found.
- Transfer of the North Anna 10 m3/s high-flow value to other rivers. Model use: **zero-weight**. Evidence: E6.
- Treating movement, nest success, habitat occupancy, metabolic rate, or nest defense as feeding. Model use: **zero-weight**. Evidence: E2, E5, E6, E7, E8, E9, E10.

### MISSING

- Northern Virginia non-spawning catchability experiments
- Direct adult oxygen-feeding evidence
- Field turbidity and hook-and-line validation
- Fishing-pressure learning experiments
- River-specific rate-of-change functions
- Direct weather-variable evidence
- Regional genetics where nonnative stocks may have been introduced

Machine-readable JSON supplied separately in the research archive.

## Targetability Assessment

Not applicable: Smallmouth bass is already a current BiteMap bite-scored species.
