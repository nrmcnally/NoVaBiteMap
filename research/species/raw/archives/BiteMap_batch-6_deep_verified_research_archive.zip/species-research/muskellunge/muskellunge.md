# Muskellunge
*Esox masquinongy*

- Species ID: `muskellunge`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Muskellunge are intentionally targeted in several Virginia rivers. Direct angling studies support Bite-scored status, but solar, lunar and warm-period effects are small, observational or sparse and must remain low-strength candidates.

### Model-ready findings
- **score**: Escanaba Lake trip success declined modestly from low to high solar radiation. Evidence: E2.
- **score**: A 341,959-fish voluntary catch database showed a small repeatable association with full and new moon periods. Evidence: E4, E5.
- **score**: James River tagged muskellunge were rarely caught during the warm-water July-August period, supporting a low-confidence warm-period catchability reduction. Evidence: E6.

### Context-only findings
- Warm-water catch-and-release mortality is a handling and conservation endpoint, not a bite predictor. Evidence: E7.
- Bait, guide status, prey choice and diet belong in Fish Guide/context layers. Evidence: E8, E9, E10.
- Seasonal telemetry and Virginia management records locate fish and quantify availability, not feeding. Evidence: E11, E12.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- All Escanaba environmental effects were statistically very small.
- The lunar database is voluntary and lacks complete effort denominators.
- Warm-water James River recaptures were sparse and cannot define a sharp threshold.
- The commonly repeated 84 F feeding-cessation claim was not primary-verified.

## Targetability assessment
Muskellunge are intentionally targeted in several Virginia rivers. Direct angling studies support Bite-scored status, but solar, lunar and warm-period effects are small, observational or sparse and must remain low-strength candidates.

## Candidate model rules
### R1. solarRadiationWm2 - score
- Condition: Very low versus high surface solar radiation in Escanaba Lake
- Direction: decrease with higher radiation
- Strength: small
- Confidence: low-medium
- Mechanism: Lower light may improve ambush conditions or alter fish/angler behavior.
- Evidence: E2
- Double-counting risk: Do not double count with dusk, cloud, turbidity or underwater light; one-lake effect was very small.
### R2. lunarPhase - score
- Condition: Near full or new moon versus intermediate lunar dates
- Direction: increase
- Strength: very small
- Confidence: low-medium
- Mechanism: A large self-reported database showed a repeatable lunar-cycle association without a demonstrated mechanism.
- Evidence: E4, E5
- Double-counting risk: Do not add moon-position and lunar-phase bonuses; effort/reporting and latitude remain confounders.
### R3. warmWaterPeriod - score
- Condition: James River July-August, commonly >25 C
- Direction: decrease in observed capture opportunity
- Strength: weak/uncalibrated
- Confidence: low-medium
- Mechanism: Tagged fish were rarely recaptured during the warm-water period.
- Evidence: E6
- Double-counting risk: Do not convert to a sharp 25 C threshold or stack with seasonal angler-effort and mortality rules.
### R4. timeOfDay - context-only
- Condition: Dusk compared with dawn/day among successful trips
- Direction: possible increase
- Strength: weak
- Confidence: low
- Mechanism: Sparse data suggested higher CPUE at dusk.
- Evidence: E3
- Double-counting risk: Only nine successful dusk trips; no nighttime data.
### R5. baitAndGuide - context-only
- Condition: Live bait or guided trip
- Direction: increase
- Strength: small
- Confidence: medium
- Mechanism: Technique and expertise changed trip success.
- Evidence: E8
- Double-counting risk: Fish Guide only; skill and trip selection confound.
### R6. postReleaseTemperature - context-only
- Condition: 19.6-32.6 C after capture
- Direction: survival risk context
- Strength: not a bite effect
- Confidence: medium
- Mechanism: Warm-water capture can affect post-release outcomes.
- Evidence: E7
- Double-counting risk: Never convert mortality risk into bite probability.
### R7. preyAvailability - context-only
- Condition: Local prey type and size
- Direction: diet/presentation context
- Strength: unquantified
- Confidence: medium
- Mechanism: Prey selection and diet vary with fish size and prey community.
- Evidence: E9, E10
- Double-counting risk: Do not infer catch rate without prey abundance and presentation data.
### R8. seasonalMovement - context-only
- Condition: Season and connected habitat
- Direction: location context
- Strength: unknown
- Confidence: medium
- Mechanism: Adults make seasonal movements.
- Evidence: E11, E12
- Double-counting risk: Movement and population density are not feeding.
### R9. waterTemperatureF - zero-weight
- Condition: At or above 84 F
- Direction: none; unsupported threshold
- Strength: zero
- Confidence: high
- Mechanism: No original direct feeding experiment verified universal cessation.
- Evidence: E13
- Double-counting risk: Corrects the shallow baseline; avoid false precision.
### R10. barometricPressureFrontWind - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct portable evidence.
- Evidence: E14
- Double-counting risk: Reject folklore and tiny confounded correlations.
### R11. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Season and warm-water behavior must be represented by measured inputs, not a folklore curve.
- Evidence: E6, E11, E12
- Double-counting risk: Avoid double counting temperature, movement, effort and stocking.

## Evidence ledger
### E1. regional targetability and distribution - context-only
- Exact condition/range: DWR identifies established and stocked fisheries in the James, New, Shenandoah and Tennessee systems.
- Observed effect: Confirms intentional Virginia recreational targeting.
- Measured: Targetability and distribution
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency account
- NOVA applicability: high
- Confidence: high
- Source: S1 (section: Distribution)
- Limitations: Does not establish bite predictors.
- Surrogate evidence: false
### E2. solar radiation - score
- Exact condition/range: Escanaba Lake trip records from low (<25 W/m2) to high (>450 W/m2) radiation.
- Observed effect: Modeled trip-success probability declined from about 0.17 at low radiation to about 0.11 at high radiation.
- Measured: Angler trip success
- Population/location: Escanaba Lake, Wisconsin
- Life stage: adult fishery
- Evidence type: long-term angler census/model
- NOVA applicability: potential low-light candidate; one lake
- Confidence: medium
- Source: S2 (section: Muskellunge trip success results; figure: solar-radiation partial dependence)
- Limitations: All modeled effects were very small; angler behavior and presentation may covary.
- Surrogate evidence: false
### E3. time of day - context-only
- Exact condition/range: Dawn, day and dusk among successful Escanaba Lake trips.
- Observed effect: Positive-trip CPUE was highest at dusk, but only nine successful dusk trips were available.
- Measured: Catch per successful trip
- Population/location: Escanaba Lake, Wisconsin
- Life stage: adult fishery
- Evidence type: long-term census/model
- NOVA applicability: too sparse for score
- Confidence: low
- Source: S2 (section: Muskellunge catch-rate results; table: diel estimates)
- Limitations: Severe sample-size limitation and no overnight fishing.
- Surrogate evidence: false
### E4. moon phase - score
- Exact condition/range: 341,959 voluntary catch records from North America, 1970-2013.
- Observed effect: Catch was cyclic with the lunar month; more fish were reported near full and new moons, with a small effect roughly equivalent to about 5% less time per catch.
- Measured: Reported angler catch timing
- Population/location: North America
- Life stage: adult recreational catches
- Evidence type: large observational database
- NOVA applicability: broad geography but self-reported/effort limitations
- Confidence: medium
- Source: S3 (section: Results; figure: lunar periodic regression)
- Limitations: Effort, reporting, trip timing and latitude can confound; mechanism was not demonstrated.
- Surrogate evidence: false
### E5. moon position - context-only
- Exact condition/range: Escanaba Lake moon overhead, underfoot or neither.
- Observed effect: Trip success was somewhat higher near overhead/underfoot, but positive-trip CPUE showed a different ordering.
- Measured: Trip success and CPUE
- Population/location: Escanaba Lake, Wisconsin
- Life stage: adult fishery
- Evidence type: long-term census/model
- NOVA applicability: contradictory endpoint evidence
- Confidence: low-medium
- Source: S2 (section: Muskellunge results; figure: lunar position effects)
- Limitations: Do not stack lunar phase and moon-position bonuses; effects were very small.
- Surrogate evidence: false
### E6. warm-water catchability - score
- Exact condition/range: James River warm-water period, July-August, with water commonly >25 C.
- Observed effect: Few tagged muskellunge were caught during the warm-water window, limiting population-level effects of release mortality.
- Measured: Recapture/catchability during warm-water period
- Population/location: James River, Virginia
- Life stage: adults >=650 mm
- Evidence type: telemetry and angler recapture study
- NOVA applicability: high geographic relevance, but low event count
- Confidence: medium
- Source: S4 (section: Abstract and Results)
- Limitations: Low catches may reflect angler effort, fish behavior, distribution or gear; no continuous temperature response was established.
- Surrogate evidence: false
### E7. temperature and post-release mortality - context-only
- Exact condition/range: 50 angled fish at 19.6-32.6 C; 32 captures above 25 C in experimental ponds.
- Observed effect: Study quantified post-release mortality at elevated temperatures.
- Measured: Survival after angling
- Population/location: experimental ponds
- Life stage: adults >760 mm
- Evidence type: controlled catch-and-release experiment
- NOVA applicability: Virginia-management context, not bite endpoint
- Confidence: medium-high
- Source: S5 (section: Abstract)
- Limitations: Mortality and physiological stress are not catchability or feeding.
- Surrogate evidence: false
### E8. bait and guide status - context-only
- Exact condition/range: Live versus artificial bait; guided versus unguided trips.
- Observed effect: Live bait and guided trips had modestly higher predicted success; all effect sizes were very small.
- Measured: Angler trip success
- Population/location: Escanaba Lake, Wisconsin
- Life stage: adult fishery
- Evidence type: long-term census/model
- NOVA applicability: Fish Guide context
- Confidence: medium
- Source: S2 (section: Muskellunge trip success results)
- Limitations: Skill, effort and trip selection confound.
- Surrogate evidence: false
### E9. prey selection and consumption time - context-only
- Exact condition/range: Age-0 muskellunge and northern pike offered multiple prey types in laboratory trials.
- Observed effect: Species differed in prey selection and time to consumption.
- Measured: Prey choice and time to consume prey
- Population/location: laboratory
- Life stage: age-0
- Evidence type: controlled experiment
- NOVA applicability: life-stage/guide context only
- Confidence: medium
- Source: S6 (section: Abstract)
- Limitations: No environmental predictor and no adult catchability endpoint.
- Surrogate evidence: false
### E10. diet and fish size - context-only
- Exact condition/range: 1,092 muskellunge from 34 Wisconsin waters, 226-1,180 mm.
- Observed effect: Food occurred in 34.3% of stomachs; diet was diverse and varied with size and availability.
- Measured: Stomach contents
- Population/location: northern Wisconsin lakes
- Life stage: juveniles and adults
- Evidence type: field diet study
- NOVA applicability: prey/presentation context, not bite coefficient
- Confidence: medium-high
- Source: S7 (page: 258-270; section: Results; table: diet composition tables)
- Limitations: Stomach occurrence is affected by digestion and capture timing.
- Surrogate evidence: false
### E11. seasonal movement - context-only
- Exact condition/range: Acoustic telemetry in a large connecting-river system.
- Observed effect: Seasonal movements crossed jurisdictions and habitats.
- Measured: Movement and seasonal habitat use
- Population/location: St. Clair-Detroit River System
- Life stage: adults
- Evidence type: telemetry
- NOVA applicability: low direct transfer; context only
- Confidence: medium
- Source: S9 (section: Abstract)
- Limitations: Movement does not establish feeding or hook vulnerability.
- Surrogate evidence: false
### E12. stocking, abundance and pressure - context-only
- Exact condition/range: Virginia management plan documents low-density trophy fisheries and stocking dependence.
- Observed effect: Supports availability, regulations and population context.
- Measured: Fishery structure
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency management synthesis
- NOVA applicability: high for local management
- Confidence: high
- Source: S8 (section: Fishery status and management)
- Limitations: Low density affects encounter probability but is not per-fish bite rate.
- Surrogate evidence: false
### E13. historical 84 F feeding claim - zero-weight
- Exact condition/range: Baseline archive repeated an agency-style claim that feeding stops near 84 F.
- Observed effect: No original species-specific feeding experiment supporting a universal 84 F cessation threshold was verified.
- Measured: Claim audit
- Population/location: multiple
- Life stage: multiple
- Evidence type: adversarial evidence audit
- NOVA applicability: high
- Confidence: high
- Source: S10 (section: Life-history bibliography)
- Limitations: Physiological tolerance and anecdote cannot become an exact bite threshold.
- Surrogate evidence: false
### E14. barometric pressure/fronts/wind - zero-weight
- Exact condition/range: Broad direct-evidence search.
- Observed effect: No robust species-specific pressure/front rule was verified; Escanaba wind-direction effects were tiny and plausibly behavioral/effort confounding.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: adult fishery
- Evidence type: search synthesis
- NOVA applicability: high
- Confidence: medium-high
- Source: S2 (section: Discussion)
- Limitations: Wind may alter presentation or effort without a direct physiological mechanism.
- Surrogate evidence: false

## Remaining research gaps
- Replicated Virginia/Mid-Atlantic catchability studies with continuous water temperature and effort.
- Direct feeding experiments across light, temperature, oxygen and prey availability in adults.
- Controlled pressure/learning and recapture-recovery studies.
- Mechanistic lunar research separating effort, reporting and illumination.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2026)
**Muskellunge**. Virginia DWR.
https://dwr.virginia.gov/wildlife/information/muskellunge/
Scope: Virginia. Access: agency HTML. Verification: AI-reviewed-unverified.
### S2. Stephanie L. Shaw; Kathryn M. Renik; Greg G. Sass (2021)
**Angler and environmental influences on walleye Sander vitreus and muskellunge Esox masquinongy angler catch in Escanaba Lake, Wisconsin 2003-2015**. PLOS ONE 16(9):e0257882. DOI: 10.1371/journal.pone.0257882.
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0257882
Scope: Escanaba Lake, Wisconsin. Access: publisher full HTML/PDF. Verification: AI-reviewed-unverified.
### S3. Mark R. Vinson; Ted R. Angradi (2014)
**Muskie Lunacy: Does the Lunar Cycle Influence Angler Catch of Muskellunge (Esox masquinongy)?**. PLOS ONE 9(5):e98046. DOI: 10.1371/journal.pone.0098046.
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0098046
Scope: North American Muskies Inc. records. Access: publisher full HTML/PDF. Verification: AI-reviewed-unverified.
### S4. Cory J. Bauerlien; Derek P. Crane; Scott M. Smith; George Palmer; Tyler Young; Daniel B. Goetz; Jeff Hansbarger; Kyle J. Hartman (2022)
**Low catchability limits the effect of warm-water catch-and-release mortality on muskellunge**. Fisheries Research 254:106434. DOI: 10.1016/j.fishres.2022.106434.
https://www.sciencedirect.com/science/article/pii/S0165783622002119
Scope: James River, Virginia. Access: publisher abstract/author full text. Verification: AI-reviewed-unverified.
### S5. Ian T. Booth; Cory J. Bauerlien; Derek P. Crane; Scott M. Smith; George Palmer; Tyler Young; Daniel B. Goetz; Jeff Hansbarger; Kyle J. Hartman (2023)
**Evaluating Muskellunge catch-and-release mortality at elevated summer water temperature**. Transactions of the American Fisheries Society 152:577-590. DOI: 10.1002/tafs.10418.
https://onlinelibrary.wiley.com/doi/10.1002/tafs.10418
Scope: experimental ponds; southern U.S. fish. Access: publisher abstract/full metadata. Verification: AI-reviewed-unverified.
### S6. Ryan T. Kapuscinski; Derek P. Crane; Christopher J. Gronda (2022)
**Prey selection and time to consumption differ between congeneric muskellunge and northern pike**. Journal of Great Lakes Research 48:1087-1092. DOI: 10.1016/j.jglr.2022.05.008.
https://doi.org/10.1016/j.jglr.2022.05.008
Scope: laboratory, Great Lakes region. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S7. Michael A. Bozek; Thomas M. Burri; Richard V. Frie (1999)
**Diets of Muskellunge in Northern Wisconsin Lakes**. North American Journal of Fisheries Management 19:258-270. DOI: 10.1577/1548-8675(1999)019<0258:DOMINW>2.0.CO;2.
https://files.dnr.state.mn.us/fisheries/species/mue/mue_diets.pdf
Scope: 34 northern Wisconsin waters. Access: agency-hosted full PDF. Verification: AI-reviewed-unverified.
### S8. Virginia Department of Wildlife Resources (2020)
**Virginia Muskellunge Management Plan 2020-2025**. Virginia DWR.
https://dwr.virginia.gov/wp-content/uploads/media/Virginia-Muskellunge-Management-Plan-2020-2025.pdf
Scope: Virginia. Access: agency full PDF. Verification: AI-reviewed-unverified.
### S9. Jason M. Hessenauer; Edward F. Roseman; Todd A. Hayden; Matthew D. Faust; Jason C. Boase; Robert L. DeBruyne; Richard T. Kraus; Aaron T. Fisk (2021)
**Seasonal movements of muskellunge in the St. Clair-Detroit River System: implications for multi-jurisdictional fisheries management**. Journal of Great Lakes Research 47:1245-1256. DOI: 10.1016/j.jglr.2021.03.006.
https://www.sciencedirect.com/science/article/abs/pii/S0380133020302847
Scope: St. Clair-Detroit River System. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S10. U.S. Fish and Wildlife Service (2019)
**Ecological Risk Screening Summary: Muskellunge (Esox masquinongy)**. U.S. Fish and Wildlife Service.
https://www.fws.gov/sites/default/files/documents/Ecological-Risk-Screening-Summary-Muskellunge.pdf
Scope: North America. Access: agency full PDF. Verification: AI-reviewed-unverified.
