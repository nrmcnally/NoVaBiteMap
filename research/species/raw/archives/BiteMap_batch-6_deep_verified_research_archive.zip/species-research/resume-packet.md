# BiteMap NOVA research resume packet

- Completed before Batch 6: largemouth-bass, smallmouth-bass, channel-catfish, black-crappie, white-crappie, bluegill, redbreast-sunfish, pumpkinseed, green-sunfish, rock-bass, rainbow-trout, brown-trout, brook-trout, blue-catfish, flathead-catfish, white-catfish, striped-bass, white-perch, yellow-perch.
- Completed in Batch 6: walleye, muskellunge, northern-snakehead.
- Pending species: spotted-bass, common-carp, american-eel, fallfish, creek-chub, white-sucker, yellow-bullhead, brown-bullhead, northern-hogsucker, shorthead-redhorse, blacknose-dace, longnose-dace, mottled-sculpin, tessellated-darter, gizzard-shad.
- Next recommended batch: Batch 7 - spotted bass, common carp, and American eel.
- Schema version: 1.1.
- Verification status: AI-reviewed-unverified.
- Known corrections: channel-catfish S13 must include James W. Avault Jr.; no universal muskellunge 84 F feeding cessation is implemented; northern-snakehead local direct evidence supports daylight/morning rather than generic low-light feeding; walleye light rules retain life-stage and double-counting limits.
- Batch 6 outcome: all three species remain Bite-scored, with bounded direct candidates and substantial context-only evidence.
- Unresolved questions: see validation-report.json and correction-and-conflict-log.json.
- Files a new chat should receive: the two baseline archives, Batch 1 through Batch 5 archives, BiteMap_batch-6_deep_verified_research_archive.zip, and the master prompt with ACTIVE BATCH changed to BATCH 7.
