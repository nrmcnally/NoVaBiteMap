# Northern Snakehead
*Channa argus*

- Species ID: `northern-snakehead`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Northern snakehead are intentionally targeted throughout the Potomac/Chesapeake region. Highly local feeding evidence supports Bite-scored status with daylight/morning and outgoing-tide candidates, but both are seasonal and low-complexity rather than universal.

### Model-ready findings
- **score**: In the tidal Potomac during May-June, fresh feeding and movement were greater during daylight, feeding was highest in the morning, and no fresh prey was found in the sampled overnight interval. Evidence: E2, E15.
- **score**: Feeding observations in the same study were highest during outgoing tides. Evidence: E3.

### Context-only findings
- Spawning onset was associated with more empty stomachs, but defensive strikes may diverge from feeding. Evidence: E5.
- Vegetation, low velocity, tributary use and seasonal movements provide highly local location context. Evidence: E6, E7, E8.
- Diet, bioenergetics, ration and metabolism studies describe prey demand and physiology, not same-day hook vulnerability. Evidence: E9, E10, E11, E14.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The direct Potomac model explained only about 6% of feeding variation.
- Sampling covered May-June and should not become a year-round daylight curve.
- Tide and time of day were correlated with prey movement and habitat access.
- The baseline low-light description conflicts with the strongest local direct evidence.

## Targetability assessment
Northern snakehead are intentionally targeted throughout the Potomac/Chesapeake region. Highly local feeding evidence supports Bite-scored status with daylight/morning and outgoing-tide candidates, but both are seasonal and low-complexity rather than universal.

## Candidate model rules
### R1. timeOfDay - score
- Condition: May-June tidal Potomac: daylight, especially morning, versus overnight
- Direction: increase during daylight/morning
- Strength: moderate
- Confidence: medium
- Mechanism: Fresh prey and movement were concentrated in daylight; no fresh prey was detected during the sampled overnight interval.
- Evidence: E2, E15
- Double-counting risk: Do not stack daylight, morning and solar-light bonuses; evidence is seasonal and capture-method specific.
### R2. tidalStage - score
- Condition: Outgoing tide during May-June Potomac sampling
- Direction: increase
- Strength: small to moderate
- Confidence: medium
- Mechanism: Fresh feeding observations were highest on outgoing tides.
- Evidence: E3
- Double-counting risk: Tide, time, current direction, prey drift and habitat access covary; local tidal data required.
### R3. spawningStage - context-only
- Condition: Onset of spawning in late May in the study
- Direction: feeding may decrease
- Strength: unquantified
- Confidence: medium
- Mechanism: Empty stomachs increased as spawning began.
- Evidence: E5
- Double-counting risk: Defensive strikes can diverge from feeding; do not apply as a catchability penalty without angling data.
### R4. waterTemperature - unavailable
- Condition: Any universal thermal optimum or short-term trend
- Direction: none available
- Strength: unavailable
- Confidence: high
- Mechanism: Local model did not establish a portable temperature threshold; bioenergetics gives maximum-consumption context only.
- Evidence: E4, E10, E14
- Double-counting risk: Do not infer from metabolism, occupancy or modeled maximum consumption.
### R5. habitatVegetationVelocity - context-only
- Condition: Shallow vegetated low-velocity habitats
- Direction: location context
- Strength: unknown
- Confidence: medium-high
- Mechanism: Telemetry and habitat selection identify where fish may occur.
- Evidence: E6, E7, E8
- Double-counting risk: Presence is not feeding or catchability.
### R6. preyAvailability - context-only
- Condition: Local fish and other prey community
- Direction: diet/presentation context
- Strength: unquantified
- Confidence: medium-high
- Mechanism: Potomac diet was broad and prey-dependent.
- Evidence: E9
- Double-counting risk: No prey-density response curve was measured.
### R7. populationExpansion - zero-weight
- Condition: Increasing survey catch during invasion growth
- Direction: none for per-fish bite
- Strength: zero
- Confidence: high
- Mechanism: Catch trend was abundance-driven.
- Evidence: E13
- Double-counting risk: Do not train a bite model on invasion-era abundance as intrinsic activity.
### R8. metabolicRate - zero-weight
- Condition: Acclimation and acute temperature effects
- Direction: physiology only
- Strength: none for bite
- Confidence: high
- Mechanism: Respiratory metabolism changed with temperature.
- Evidence: E14
- Double-counting risk: Metabolism is not voluntary feeding.
### R9. moonPressureFrontWind - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero/unavailable
- Confidence: high
- Mechanism: No qualifying direct species-specific feeding/catchability evidence.
- Evidence: E11
- Double-counting risk: Reject folklore and surrogate evidence.
### R10. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: The direct diel/tide evidence covers May-June only and should not be extrapolated to a monthly curve.
- Evidence: E2, E3, E5, E7
- Double-counting risk: Avoid double counting spawning, tide, temperature, vegetation and effort.

## Evidence ledger
### E1. regional targetability and management - context-only
- Exact condition/range: Established Chesapeake/Potomac population managed as invasive harvest target.
- Observed effect: Confirms intentional hook-and-line targeting in the application region.
- Measured: Targetability and management status
- Population/location: Chesapeake Bay watershed
- Life stage: multiple
- Evidence type: agency management plan
- NOVA applicability: very high regional relevance
- Confidence: high
- Source: S1 (section: Distribution, recreational fishery and management)
- Limitations: Management goal and harvest encouragement do not establish bite predictors.
- Surrogate evidence: false
### E2. time of day - score
- Exact condition/range: 273 fish sampled through 24 h during May-June 2007-2008; fresh prey occurrence by capture time.
- Observed effect: No fresh prey items were found from about 00:30 to 07:30; feeding and movement were greater during daylight and feeding was highest in the morning.
- Measured: Fresh gut contents and telemetry movement
- Population/location: tidal Potomac River, Maryland/Virginia
- Life stage: adults during prespawn/early spawning
- Evidence type: in situ field sampling and telemetry
- NOVA applicability: exceptionally high geographic relevance
- Confidence: medium-high
- Source: S2 (page: 69-81; section: Results and Discussion; figure: diel feeding plots)
- Limitations: Only May-June; electrofishing capture and digestion timing can affect temporal inference.
- Surrogate evidence: false
### E3. tidal stage/current - score
- Exact condition/range: Feeding observations classified by tidal phase in the same Potomac study.
- Observed effect: Feeding was highest during outgoing tides.
- Measured: Fresh gut contents by tide
- Population/location: tidal Potomac River
- Life stage: adults during May-June
- Evidence type: field sampling/model
- NOVA applicability: high local relevance
- Confidence: medium
- Source: S2 (page: 69-81; section: Results; figure: feeding by tide figure)
- Limitations: Time of day and tide covary; model explained only a small fraction of variation.
- Surrogate evidence: false
### E4. temperature, sex and size - context-only
- Exact condition/range: Random-forest predictors included time, tide, date, temperature, total length and sex.
- Observed effect: The model explained about 6% of feeding variation; time and tide were more informative than a portable temperature threshold.
- Measured: Fresh-prey occurrence/model fit
- Population/location: tidal Potomac River
- Life stage: adults
- Evidence type: field model
- NOVA applicability: high local relevance but weak explanatory power
- Confidence: medium
- Source: S2 (page: 69-81; section: Results; table: random forest predictor summary)
- Limitations: Do not infer a temperature curve from variable importance.
- Surrogate evidence: false
### E5. spawning stage/date - context-only
- Exact condition/range: May-June sampling across onset of spawning.
- Observed effect: Empty stomach frequency increased near the end of May as spawning began.
- Measured: Stomach emptiness by date
- Population/location: tidal Potomac River
- Life stage: adults
- Evidence type: field sampling
- NOVA applicability: high regional relevance
- Confidence: medium
- Source: S2 (page: 69-81; section: Results and Discussion; figure: date/feeding plot)
- Limitations: Reduced feeding does not rule out defensive or territorial strikes.
- Surrogate evidence: false
### E6. habitat occupancy - context-only
- Exact condition/range: Seasonal meso- and microhabitat selection in the Potomac system.
- Observed effect: Fish selected shallow, vegetated and low-velocity habitats with seasonal variation.
- Measured: Habitat selection
- Population/location: Potomac River system
- Life stage: adults
- Evidence type: telemetry/habitat study
- NOVA applicability: high location relevance
- Confidence: medium-high
- Source: S3 (section: Abstract)
- Limitations: Occupancy is not feeding or catchability.
- Surrogate evidence: false
### E7. seasonal movement and home range - context-only
- Exact condition/range: Tagged fish in the Potomac catchment across seasons.
- Observed effect: Movement, dispersal and home range varied seasonally and among individuals.
- Measured: Movement and home range
- Population/location: Potomac River catchment
- Life stage: adults
- Evidence type: telemetry
- NOVA applicability: high regional relevance
- Confidence: medium-high
- Source: S4 (section: Abstract)
- Limitations: Movement does not establish appetite or a bite multiplier.
- Surrogate evidence: false
### E8. tidal distribution and movement - context-only
- Exact condition/range: Radio telemetry and survey observations in tidal Potomac tributaries.
- Observed effect: Fish occupied tributaries and tidal habitats and showed movement among locations.
- Measured: Distribution and movement
- Population/location: tidal Potomac River
- Life stage: adults
- Evidence type: agency telemetry study
- NOVA applicability: high regional relevance
- Confidence: medium-high
- Source: S5 (page: 161-167; section: Results; table: locations; figure: movement maps)
- Limitations: No direct feeding endpoint.
- Surrogate evidence: false
### E9. prey availability and diet - context-only
- Exact condition/range: Lower Potomac stomach contents compared with largemouth bass, smallmouth bass and channel catfish.
- Observed effect: Northern snakehead consumed diverse fishes and other prey; diet overlapped with co-occurring predators.
- Measured: Diet composition and overlap
- Population/location: lower Potomac River
- Life stage: juveniles and adults
- Evidence type: field diet study
- NOVA applicability: high regional relevance
- Confidence: medium-high
- Source: S6 (section: Abstract)
- Limitations: Diet occurrence does not quantify day-specific catchability.
- Surrogate evidence: false
### E10. temperature-dependent consumption model - context-only
- Exact condition/range: Published bioenergetics information used to simulate Chesapeake watershed maximum consumption.
- Observed effect: Model predicted temperature-dependent maximum consumption and large annual prey demand, explicitly representing maximum rather than realized natural feeding.
- Measured: Modeled maximum consumption
- Population/location: Chesapeake Bay watershed
- Life stage: modeled populations
- Evidence type: bioenergetics synthesis
- NOVA applicability: regional context; not observed bite rate
- Confidence: medium
- Source: S7 (section: Abstract)
- Limitations: Model inputs came from published studies/populations; maximum consumption is not field intake or catchability.
- Surrogate evidence: false
### E11. ration and growth - context-only
- Exact condition/range: 188.54 +/- 13.80 g fish fed 0, 1, 2, 4% body weight/day or satiation at 28 C.
- Observed effect: Specific growth rate increased with ration; energy allocation and conversion changed with feeding level.
- Measured: Growth and energy budget
- Population/location: laboratory
- Life stage: subadults
- Evidence type: controlled feeding experiment
- NOVA applicability: physiology context only
- Confidence: medium-high
- Source: S8 (section: Abstract)
- Limitations: Ration was imposed; this does not identify environmental drivers of voluntary feeding.
- Surrogate evidence: false
### E12. reproduction and growth - context-only
- Exact condition/range: Newly established Potomac population.
- Observed effect: Growth and reproductive behavior were documented for the local population.
- Measured: Growth and reproduction
- Population/location: Potomac River
- Life stage: multiple
- Evidence type: field population study
- NOVA applicability: high regional context
- Confidence: medium
- Source: S9 (section: Abstract)
- Limitations: No standardized catchability endpoint.
- Surrogate evidence: false
### E13. population expansion and catch rate - zero-weight
- Exact condition/range: Early invasion years in the Potomac system.
- Observed effect: Catch/relative abundance increased dramatically as the population expanded.
- Measured: Survey catch and abundance trend
- Population/location: Potomac River system
- Life stage: population
- Evidence type: field population study
- NOVA applicability: high regional context
- Confidence: medium
- Source: S10 (section: Abstract)
- Limitations: Increase reflects abundance, colonization and survey catchability, not individual feeding.
- Surrogate evidence: false
### E14. temperature acclimation and metabolism - context-only
- Exact condition/range: Acute temperature changes after acclimation in laboratory snakehead.
- Observed effect: Respiratory metabolism depended on acclimation and acute temperature.
- Measured: Oxygen consumption/metabolism
- Population/location: laboratory, China
- Life stage: juveniles/subadults
- Evidence type: physiology experiment
- NOVA applicability: low portability to field bite scoring
- Confidence: medium
- Source: S12 (page: 535-542; section: Results; table: metabolic rates)
- Limitations: Metabolism is not feeding or hook-and-line catchability.
- Surrogate evidence: false
### E15. low-light folklore claim - zero-weight
- Exact condition/range: Baseline description suggested flexible feeding with frequent low-light activity.
- Observed effect: Direct Potomac evidence instead found daylight/morning feeding and no fresh prey overnight during the sampled season.
- Measured: Conflict audit
- Population/location: Potomac versus baseline generalization
- Life stage: adults
- Evidence type: adversarial review
- NOVA applicability: high
- Confidence: high
- Source: S2 (page: 69-81; section: Discussion)
- Limitations: Season-specific evidence should not become a year-round daylight curve.
- Surrogate evidence: false

## Remaining research gaps
- Repeat diel and tidal feeding/catchability sampling across all seasons and Potomac tributaries.
- Direct hook-and-line catchability studies rather than electrofishing/gut-content inference.
- Temperature, oxygen, turbidity and salinity experiments using adult Potomac fish.
- Flow/discharge effects outside tidal-current direction and controlled angling-pressure studies.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Maryland Department of Natural Resources and Mid-Atlantic partners (2023)
**Northern Snakehead Control and Management Plan for the Chesapeake Bay Watershed**. Chesapeake Bay Program / Maryland DNR.
https://dnrweb.dnr.state.md.us/archive/fisheries/ChesapeakeBay_NorthernSnakehead_FMP_3-2023.pdf
Scope: Chesapeake Bay watershed. Access: agency full PDF. Verification: AI-reviewed-unverified.
### S2. Nicolas W. R. Lapointe; Ryan K. Saylor; Paul L. Angermeier (2019)
**Diel Feeding and Movement Activity of Northern Snakehead Channa argus**. Proceedings of the First International Snakehead Symposium, AFS Symposium 89:69-81. DOI: 10.47886/9781934874585.ch6.
https://cwf-fcf.org/en/resources/research-papers/Lapointe-et-al-2019-Diel-activity-of-Northern-Snakehead.pdf
Scope: tidal Potomac River, Maryland and Virginia. Access: author/organization full PDF. Verification: AI-reviewed-unverified.
### S3. Nicolas W. R. Lapointe; James T. Thorson; Paul L. Angermeier (2010)
**Seasonal meso- and microhabitat selection by the northern snakehead (Channa argus) in the Potomac River system**. Ecology of Freshwater Fish 19:566-577. DOI: 10.1111/j.1600-0633.2010.00446.x.
https://doi.org/10.1111/j.1600-0633.2010.00446.x
Scope: Potomac River system. Access: publisher abstract/full manuscript. Verification: AI-reviewed-unverified.
### S4. Nicolas W. R. Lapointe; John S. Odenkirk; Paul L. Angermeier (2013)
**Seasonal movement, dispersal, and home range of Northern Snakehead Channa argus (Actinopterygii, Perciformes) in the Potomac River catchment**. Hydrobiologia 709:73-87. DOI: 10.1007/s10750-012-1437-x.
https://doi.org/10.1007/s10750-012-1437-x
Scope: Potomac River catchment. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S5. Stephen J. Owens; John S. Odenkirk; Robert Greenlee (2008)
**Northern Snakehead Movement and Distribution in the Tidal Potomac River System**. Proceedings of the Annual Conference of the Southeastern Association of Fish and Wildlife Agencies 62:161-167.
https://seafwa.org/sites/default/files/journal-articles/OWENS-161-167.pdf
Scope: tidal Potomac River. Access: agency/proceedings full PDF. Verification: AI-reviewed-unverified.
### S6. Ryan K. Saylor; Nicolas W. R. Lapointe; Paul L. Angermeier (2012)
**Diet of non-native northern snakehead (Channa argus) compared to three co-occurring predators in the lower Potomac River, USA**. Ecology of Freshwater Fish 21:443-452. DOI: 10.1111/j.1600-0633.2012.00563.x.
https://www.usgs.gov/publications/diet-non-native-northern-snakehead-channa-argus-compared-three-co-occurring-predators
Scope: lower Potomac River. Access: USGS record/publisher abstract. Verification: AI-reviewed-unverified.
### S7. Joseph W. Love; Joshua J. Newhard (2021)
**Using Published Information to Predict Consumption by Northern Snakehead in the Chesapeake Bay Watershed**. Transactions of the American Fisheries Society 150:609-621. DOI: 10.1002/tafs.10306.
https://doi.org/10.1002/tafs.10306
Scope: Chesapeake Bay watershed model. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S8. Jiashou Liu; Tangling Zhang; Duane C. Chapman (1998)
**Growth and energy budget of Northern Snakehead Channa argus in relation to ration**. Journal of Fish Biology 53:1319-1330. DOI: 10.1111/j.1095-8649.1998.tb00250.x.
https://www.usgs.gov/publications/growth-and-energy-budget-northern-snakehead-channa-argus-relation-ration
Scope: laboratory, China/USGS record. Access: USGS abstract record. Verification: AI-reviewed-unverified.
### S9. Amy M. Gascho Landis; Nicolas W. R. Lapointe; Paul L. Angermeier (2011)
**Individual growth and reproductive behavior in a newly established population of Northern Snakehead (Channa argus), Potomac River, USA**. Hydrobiologia 661:123-131. DOI: 10.1007/s10750-010-0509-z.
https://doi.org/10.1007/s10750-010-0509-z
Scope: Potomac River. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S10. John S. Odenkirk; Stephen Owens (2007)
**Expansion of a northern snakehead population in the Potomac River system**. Transactions of the American Fisheries Society 136:1633-1639. DOI: 10.1577/T07-025.1.
https://doi.org/10.1577/T07-025.1
Scope: Potomac River system. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S11. U.S. Fish and Wildlife Service (2024)
**Ecological Risk Screening Summary: Northern Snakehead (Channa argus)**. U.S. Fish and Wildlife Service.
https://www.fws.gov/sites/default/files/documents/2024-11/ecological-risk-screening-summary-northern-snakehead.pdf
Scope: United States and native range. Access: agency full PDF. Verification: AI-reviewed-unverified.
### S12. Hui Xie; Xiuming Lü; Yao Yu; Tianxiang Gao; Qing Nie; Dapeng Ma; Xiaolong Li (2017)
**Effects of acute temperature change and temperature acclimation on the respiratory metabolism of the snakehead Channa argus**. Turkish Journal of Fisheries and Aquatic Sciences 17:535-542. DOI: 10.4194/1303-2712-v17_3_10.
https://www.trjfas.org/uploads/pdf_1237.pdf
Scope: laboratory, China. Access: journal full PDF. Verification: AI-reviewed-unverified.
