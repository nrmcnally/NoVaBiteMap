# Walleye
*Sander vitreus*

- Species ID: `walleye`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Walleye are a deliberate Virginia sportfish target. Direct low-light foraging, low-light angling and age-specific catchability evidence support Bite-scored status, but every rule requires bounded implementation and regional calibration.

### Model-ready findings
- **score**: Age-0 prey capture was greatest at approximately 0.05-1 lx, while complete darkness and brighter treatments produced lower capture success. Evidence: E2, E3.
- **score**: Escanaba Lake angler trip success was higher at dawn/dusk and lower under high solar radiation. Evidence: E4.
- **score**: Escanaba Lake catchability generally declined from age 3 through age 8. Evidence: E7.

### Context-only findings
- Thermal-optical habitat, adult temperature occupancy and seasonal movements describe habitat and production, not same-day appetite. Evidence: E9, E10, E11.
- Live bait produced higher catch rates in one long-term fishery and belongs primarily in the Fish Guide. Evidence: E5, E6.
- A small cumulative-capture effect was inconsistent in observed data and is not a validated pressure-decay rule. Evidence: E12.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The strongest light-foraging experiment used age-0 fish in a laboratory.
- The long-term catch studies came from one intensively monitored Wisconsin lake.
- Age effects conflict with some other fisheries and may include learning, selectivity or mortality.
- Thermal preference, occupied temperature and population production are not feeding optima.

## Targetability assessment
Walleye are a deliberate Virginia sportfish target. Direct low-light foraging, low-light angling and age-specific catchability evidence support Bite-scored status, but every rule requires bounded implementation and regional calibration.

## Candidate model rules
### R1. underwaterLightLux - score
- Condition: Measured underwater illuminance approximately 0.05-1 lx, versus full darkness or brighter treatments
- Direction: increase
- Strength: bounded moderate
- Confidence: medium
- Mechanism: Walleye visual sensitivity supported the highest juvenile prey-capture success at twilight-range light.
- Evidence: E2, E3
- Double-counting risk: Do not double count with time of day, cloud, turbidity or solar radiation; adult/local calibration required.
### R2. solarRadiationOrDiel - score
- Condition: Dawn/dusk or lower measured solar radiation in a lake fishery
- Direction: increase
- Strength: small to moderate
- Confidence: medium
- Mechanism: Lower ambient light increased modeled angling trip success.
- Evidence: E4
- Double-counting risk: Time of day is a proxy for underwater light and angler behavior; do not add separate dusk and low-light bonuses.
### R3. fishAgeOrSize - score
- Condition: Escanaba Lake ages 3-8
- Direction: decrease with age within studied population
- Strength: moderate
- Confidence: medium
- Mechanism: Older fish showed lower estimated angling catchability.
- Evidence: E7
- Double-counting risk: Age, size, gear selectivity and learned avoidance can overlap; do not universalize to Virginia strains.
### R4. baitType - context-only
- Condition: Live bait versus artificial bait
- Direction: live bait higher
- Strength: moderate
- Confidence: medium
- Mechanism: Bait selection changed catch rate.
- Evidence: E5, E6
- Double-counting risk: Fish Guide only; technique and skill confounding.
### R5. populationDensity - zero-weight
- Condition: Within Escanaba Lake study range
- Direction: no catchability effect
- Strength: zero
- Confidence: medium-high
- Mechanism: Individual catchability did not covary with density.
- Evidence: E8
- Double-counting risk: Total catch still depends on abundance; do not confuse catchability and encounter abundance.
### R6. thermalOpticalHabitat - context-only
- Condition: Lake depth, clarity and thermal structure
- Direction: location/productivity context
- Strength: unquantified
- Confidence: medium
- Mechanism: Combined habitat controls population production and distribution.
- Evidence: E9, E10, E11
- Double-counting risk: Do not turn production or occupancy into a same-day bite score.
### R7. recentAnglingPressure - context-only
- Condition: Cumulative annual proportion caught
- Direction: possible small decrease
- Strength: weak
- Confidence: low
- Mechanism: Depletion or learning may reduce CPUE, but observed support was inconsistent.
- Evidence: E12
- Double-counting risk: Season and population removal can double count.
### R8. stockingRecency - context-only
- Condition: Recent stocking or strong survey year class
- Direction: availability only
- Strength: unknown
- Confidence: high
- Mechanism: Stocking and abundance affect whether fish are present.
- Evidence: E13
- Double-counting risk: No post-stocking feeding surge was measured.
### R9. barometricPressureFrontMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero/unavailable
- Confidence: high
- Mechanism: No qualifying portable direct evidence.
- Evidence: E14
- Double-counting risk: Reject folklore and correlated weather proxies.
### R10. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Seasonal movement and harvest do not establish intrinsic bite rate.
- Evidence: E9, E10, E13
- Double-counting risk: Avoid double counting temperature, light, spawning and effort.

## Evidence ledger
### E1. regional targetability and distribution - context-only
- Exact condition/range: Virginia native, naturalized and stocked populations; current DWR fishery account.
- Observed effect: Confirms intentional recreational targeting and population-specific management.
- Measured: Targetability and distribution
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency account
- NOVA applicability: high for Virginia targetability
- Confidence: high
- Source: S1 (section: Distribution)
- Limitations: Agency account does not establish bite predictors.
- Surrogate evidence: false
### E2. underwater light - score
- Exact condition/range: Age-0 trials from darkness through 1 lx and brighter; best capture success at 0.05-1 lx.
- Observed effect: Prey-capture success averaged 20.5% at 0.05-1 lx and declined to roughly 10-12% in full darkness and brighter treatments.
- Measured: Prey reaction distance and capture success
- Population/location: laboratory
- Life stage: age-0
- Evidence type: controlled experiment
- NOVA applicability: mechanistically relevant but life-stage and laboratory transfer limits
- Confidence: high
- Source: S3 (page: 147-160; section: Results; table: light treatment results; figure: reaction distance and capture success figures)
- Limitations: Does not prove adult hook-and-line response or a universal lux curve.
- Surrogate evidence: false
### E3. underwater light - context-only
- Exact condition/range: Reaction distance from full darkness to 1 lx and higher light.
- Observed effect: Mean reaction distance increased from 12 cm in darkness to 27 cm at 1 lx, then plateaued near 28-30 cm.
- Measured: Visual prey-detection distance
- Population/location: laboratory
- Life stage: age-0
- Evidence type: controlled experiment
- NOVA applicability: supports mechanism; not adult catchability
- Confidence: high
- Source: S3 (page: 147-160; section: Results; figure: reaction-distance figure)
- Limitations: Detection distance and successful attack are different endpoints.
- Surrogate evidence: false
### E4. time of day and solar radiation - score
- Exact condition/range: Escanaba Lake trips classified dawn, day, dusk; solar radiation approximately 3-570 W/m2.
- Observed effect: Predicted trip-success odds were greatest at dusk and dawn; success declined as solar radiation increased.
- Measured: Angler trip success
- Population/location: Escanaba Lake, Wisconsin
- Life stage: adult fishery
- Evidence type: long-term angler census/model
- NOVA applicability: moderate transfer to reservoir/lake fisheries; uncertain for rivers
- Confidence: medium-high
- Source: S2 (section: Walleye trip success results; table: model estimates; figure: predicted probability figures)
- Limitations: Fishing was not sampled through the full night; weather and angler behavior can covary with radiation.
- Surrogate evidence: false
### E5. bait type - context-only
- Exact condition/range: Live bait versus artificial bait in the same long-term fishery.
- Observed effect: Live bait produced higher modeled catch rate than artificial bait.
- Measured: Angler CPUE
- Population/location: Escanaba Lake, Wisconsin
- Life stage: adult fishery
- Evidence type: long-term angler census
- NOVA applicability: Fish Guide relevance; not environmental score
- Confidence: medium
- Source: S2 (section: Walleye catch rate results; table: candidate models)
- Limitations: Technique choice and angler skill may confound.
- Surrogate evidence: false
### E6. bait type - context-only
- Exact condition/range: 1993-2015 Escanaba Lake live-bait and artificial-lure effort/catch records.
- Observed effect: Bait type influenced effort and catch rates.
- Measured: Angler effort and catch rate
- Population/location: Escanaba Lake, Wisconsin
- Life stage: adult fishery
- Evidence type: long-term angling analysis
- NOVA applicability: guide-only transfer
- Confidence: medium
- Source: S9 (section: Abstract)
- Limitations: Abstract-only; bait regulations and skill differ locally.
- Surrogate evidence: false
### E7. fish age - score
- Exact condition/range: Ages 3-8 in Escanaba Lake, 1980-1995.
- Observed effect: Catchability generally decreased from age 3 through age 8 and did not vary with population density.
- Measured: Individual angling catchability by age
- Population/location: Escanaba Lake, Wisconsin
- Life stage: ages 3-8
- Evidence type: mark-recapture/angling study
- NOVA applicability: potential size/age vulnerability context; population specific
- Confidence: medium-high
- Source: S5 (page: 873-881; section: Results and Discussion; table: age-specific catchability tables)
- Limitations: Age and size are correlated; western Lake Erie studies reported a different age pattern.
- Surrogate evidence: false
### E8. population density - zero-weight
- Exact condition/range: Annual population density variation in Escanaba Lake.
- Observed effect: Walleye angling catchability did not vary with population density in the study.
- Measured: Catchability-density relationship
- Population/location: Escanaba Lake, Wisconsin
- Life stage: adult fishery
- Evidence type: mark-recapture/angling study
- NOVA applicability: useful null finding
- Confidence: medium-high
- Source: S5 (page: 873-881; section: Results and Discussion)
- Limitations: One intensively studied lake; density may still affect total encounters through abundance.
- Surrogate evidence: false
### E9. water clarity and temperature - context-only
- Exact condition/range: Thermal-optical habitat area model across Ontario lakes.
- Observed effect: Walleye production and sustainable harvest were associated with combined light, depth, temperature and productivity; modeled clarity optimum varied with lake depth/thermocline.
- Measured: Population production and harvest capacity
- Population/location: Ontario lakes
- Life stage: populations
- Evidence type: cross-lake synthesis/model
- NOVA applicability: habitat context only
- Confidence: medium
- Source: S6 (page: 588-605; section: Model and Results; figure: thermal-optical habitat curves)
- Limitations: Population production is not per-fish feeding or same-day catchability.
- Surrogate evidence: false
### E10. seasonal temperature occupancy - context-only
- Exact condition/range: Adult telemetry across Lake Huron and Lake Erie through the year.
- Observed effect: Experienced temperature differed by lake and month; sex, length and diel period were not significant in the reported thermal model.
- Measured: Temperatures occupied by tagged adults
- Population/location: Great Lakes
- Life stage: adults
- Evidence type: telemetry
- NOVA applicability: movement/habitat context; low portability to NOVA reservoirs
- Confidence: medium-high
- Source: S7 (page: 98-106; section: Results; table: model terms; figure: predicted temperatures)
- Limitations: Thermal occupancy is not feeding optimum.
- Surrogate evidence: false
### E11. seasonal movement - context-only
- Exact condition/range: Tagged Lake Erie adults and thermal environment.
- Observed effect: Seasonal movements were evaluated in relation to behavioural thermoregulation.
- Measured: Movement and temperature use
- Population/location: Lake Erie
- Life stage: adults
- Evidence type: telemetry
- NOVA applicability: context only
- Confidence: medium
- Source: S10 (section: Abstract)
- Limitations: Movement is not feeding or catchability.
- Surrogate evidence: false
### E12. recent cumulative harvest/pressure - context-only
- Exact condition/range: Cumulative proportion of the population caught within years in Escanaba Lake.
- Observed effect: Model-predicted CPUE declined slightly with cumulative capture, but observed patterns were often similar across exposure levels.
- Measured: Angling CPUE and population capture history
- Population/location: Escanaba Lake, Wisconsin
- Life stage: adult fishery
- Evidence type: long-term census/model
- NOVA applicability: suggestive, not robust enough for score
- Confidence: low-medium
- Source: S2 (section: Walleye catch rate results; figure: partial dependence plots)
- Limitations: Season, depletion, learning and changing effort are confounded.
- Surrogate evidence: false
### E13. stocking and abundance - context-only
- Exact condition/range: Current Virginia forecast uses recent survey length distributions and stocking history.
- Observed effect: Supports where targetable populations exist, not a post-stocking feeding surge.
- Measured: Population availability
- Population/location: Virginia
- Life stage: multiple
- Evidence type: agency survey summary
- NOVA applicability: high for access, none for bite
- Confidence: high
- Source: S11 (section: Waterbody forecasts)
- Limitations: Survey abundance and stocking are not intrinsic catchability.
- Surrogate evidence: false
### E14. barometric pressure, fronts and moon - unavailable
- Exact condition/range: Broad search across direct walleye feeding/catchability literature.
- Observed effect: No qualifying species-specific portable effect was verified for production scoring.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: multiple
- Evidence type: search synthesis
- NOVA applicability: high
- Confidence: high
- Source: S8 (section: Environmental biology and bibliography)
- Limitations: Absence of verified evidence is not proof of no biological effect.
- Surrogate evidence: false

## Remaining research gaps
- Adult Mid-Atlantic underwater-light and standardized hook-and-line experiments.
- Direct dissolved-oxygen, short-term temperature-trend and turbidity effects on feeding/catchability.
- River-specific flow and current-change studies.
- Replication of age/size vulnerability in Virginia strains and stocked populations.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2026)
**Walleye**. Virginia DWR.
https://dwr.virginia.gov/wildlife/information/walleye/
Scope: Virginia. Access: agency HTML. Verification: AI-reviewed-unverified.
### S2. Stephanie L. Shaw; Kathryn M. Renik; Greg G. Sass (2021)
**Angler and environmental influences on walleye Sander vitreus and muskellunge Esox masquinongy angler catch in Escanaba Lake, Wisconsin 2003-2015**. PLOS ONE 16(9):e0257882. DOI: 10.1371/journal.pone.0257882.
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0257882
Scope: Escanaba Lake, Wisconsin. Access: publisher full HTML/PDF. Verification: AI-reviewed-unverified.
### S3. Noland O. Michels; Quinnlan C. Smith; Loranzie S. Rogers; Thomas R. Hrabik; Greg G. Sass; Allen F. Mensinger (2025)
**Visual sensitivity, foraging behavior, and success of walleye (Sander vitreus) under ecologically relevant downwelling light conditions**. Environmental Biology of Fishes 108:147-160. DOI: 10.1007/s10641-024-01650-y.
https://doi.org/10.1007/s10641-024-01650-y
Scope: laboratory; Upper Midwest fish. Access: publisher full-text preview/manuscript. Verification: AI-reviewed-unverified.
### S4. Lisa M. Einfalt; Edward J. Grace; David H. Wahl (2012)
**Effects of simulated light intensity, habitat complexity and forage type on predator-prey interactions in walleye Sander vitreus**. Ecology of Freshwater Fish 21:560-569. DOI: 10.1111/j.1600-0633.2012.00576.x.
https://onlinelibrary.wiley.com/doi/10.1111/j.1600-0633.2012.00576.x
Scope: laboratory, Illinois. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S5. Justine R. Newby; Michael J. Hansen; Steven P. Newman; Charles J. Edwards (2000)
**Catchability of Walleyes to Angling in Escanaba Lake, Wisconsin, 1980-1995**. North American Journal of Fisheries Management 20:873-881. DOI: 10.1577/1548-8675(2000)020<0873:COWTAI>2.0.CO;2.
https://academic.oup.com/najfm/article-pdf/20/4/873/61069595/nafm0873.pdf
Scope: Escanaba Lake, Wisconsin. Access: publisher full PDF. Verification: AI-reviewed-unverified.
### S6. Nigel P. Lester; Alan J. Dextrase; Robert S. Kushneriuk; Martin R. Rawson; Paul A. Ryan (2004)
**Light and Temperature: Key Factors Affecting Walleye Abundance and Production**. Transactions of the American Fisheries Society 133:588-605. DOI: 10.1577/T02-111.1.
https://onlinelibrary.wiley.com/doi/10.1577/T02-111.1
Scope: Ontario lakes. Access: publisher abstract/full manuscript mirror. Verification: AI-reviewed-unverified.
### S7. Tyler B. Peat; Todd A. Hayden; Lee F. G. Gutowsky; Christopher S. Vandergoot; David G. Fielder; Charles P. Madenjian; Karen J. Murchie; John M. Dettmers; Charles C. Krueger; Steven J. Cooke (2015)
**Seasonal thermal ecology of adult walleye (Sander vitreus) in Lake Huron and Lake Erie**. Journal of Thermal Biology 53:98-106. DOI: 10.1016/j.jtherbio.2015.08.009.
https://www.fecpl.ca/wp-content/uploads/2015/08/Peat-et-al.-2015-Journal-of-Thermal-Biology.pdf
Scope: Lake Huron and Lake Erie. Access: author-hosted full PDF. Verification: AI-reviewed-unverified.
### S8. Gordon F. Hartman (2009)
**A Biological Synopsis of Walleye (Sander vitreus)**. Canadian Manuscript Report of Fisheries and Aquatic Sciences 2888.
https://publications.gc.ca/collections/collection_2009/mpo-dfo/Fs97-4-2888E.pdf
Scope: North America. Access: government full PDF. Verification: AI-reviewed-unverified.
### S9. Christopher T. Bailey; Austin M. Noring; Stephanie L. Shaw; Greg G. Sass (2019)
**Live versus artificial bait influences on walleye (Sander vitreus) angler effort and catch rates on Escanaba Lake, Wisconsin, 1993-2015**. Fisheries Research 219:105330. DOI: 10.1016/j.fishres.2019.105330.
https://doi.org/10.1016/j.fishres.2019.105330
Scope: Escanaba Lake, Wisconsin. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S10. Graham D. Raby; Christopher S. Vandergoot; Todd A. Hayden; Matthew D. Faust; Richard T. Kraus; John M. Dettmers; Steven J. Cooke; Charles C. Krueger; Aaron T. Fisk (2018)
**Does behavioural thermoregulation underlie seasonal movements in Lake Erie walleye?**. Canadian Journal of Fisheries and Aquatic Sciences 75:488-496. DOI: 10.1139/cjfas-2017-0145.
https://cdnsciencepub.com/doi/10.1139/cjfas-2017-0145
Scope: Lake Erie. Access: publisher abstract. Verification: AI-reviewed-unverified.
### S11. Virginia Department of Wildlife Resources (2026)
**2026 Walleye Fishing Forecast**. Virginia DWR.
https://dwr.virginia.gov/fishing/forecasts-and-reports/walleye-forecast/
Scope: Virginia reservoirs and rivers. Access: agency HTML. Verification: AI-reviewed-unverified.
