# BiteMap NOVA research resume packet

- Completed before Batch 4: largemouth-bass, smallmouth-bass, channel-catfish, black-crappie, white-crappie, bluegill, redbreast-sunfish, pumpkinseed, green-sunfish, rock-bass, rainbow-trout, brown-trout, brook-trout.
- Completed in Batch 4: blue-catfish, flathead-catfish, white-catfish.
- Pending species: striped-bass, white-perch, yellow-perch, walleye, muskellunge, northern-snakehead, spotted-bass, common-carp, american-eel, fallfish, creek-chub, white-sucker, yellow-bullhead, brown-bullhead, northern-hogsucker, shorthead-redhorse, blacknose-dace, longnose-dace, mottled-sculpin, tessellated-darter, gizzard-shad.
- Next recommended batch: Batch 5 - striped bass, white perch, and yellow perch.
- Schema version: 1.1.
- Verification status: AI-reviewed-unverified.
- Known corrections: channel-catfish S13 must include James W. Avault Jr.; Ralph W. Tingley III's suffix is preserved; White Catfish retains Ictalurus catus as a historical alias; Perry and Avault retain Jr. suffixes.
- Batch 4 outcome: Blue Catfish and Flathead Catfish remain Bite-scored with narrow direct candidates; White Catfish is proposed for bite scoring but has no score-ready environmental rule.
- Unresolved questions: see validation-report.json and correction-and-conflict-log.json.
- Files a new chat should receive: the two baseline archives, Batch 1, Batch 2, Batch 3, BiteMap_batch-4_deep_verified_research_archive.zip, and the master prompt with ACTIVE BATCH changed to BATCH 5.
