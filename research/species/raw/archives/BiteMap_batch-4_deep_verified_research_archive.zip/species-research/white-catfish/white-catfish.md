# White Catfish
*Ameiurus catus*

- Species ID: `white-catfish`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Proposed for bite scoring**

## Executive conclusion
White catfish are a legitimate regional recreational target, not merely incidental. However, no direct environmental feeding or standardized catchability rule survived review, so the species is proposed for bite scoring pending new evidence rather than promoted to production scoring.

### Model-ready findings
- No score-ready environmental or biological candidate survived adversarial review.

### Context-only findings
- Patuxent River temperature/salinity work establishes survival tolerance only, not feeding or catchability. Evidence: E2.
- Diet, habitat, growth and estuarine population studies support Fish Guide and location context. Evidence: E3, E4, E5, E6, E7.
- Virginia and Maryland agency records support intentional regional targeting despite limited direct research. Evidence: E1, E11.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- moon phase or solunar tables
- wind or ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The direct primary evidence base is dominated by survival, growth, habitat and population endpoints.
- Broad temperature and salinity occurrence ranges must not be rebranded as bite optima.
- Regional targetability is plausible and agency-supported, but direct predictive variables remain insufficient.
- California and northern-estuary findings may not transfer to Virginia populations or waterbody types.

## Targetability assessment
White catfish are a legitimate regional recreational target, not merely incidental. However, no direct environmental feeding or standardized catchability rule survived review, so the species is proposed for bite scoring pending new evidence rather than promoted to production scoring.

## Candidate model rules
### R1. temperatureOrSalinityTolerance - zero-weight
- Condition: Lethal or survival range from physiology studies
- Direction: none as a bite rule
- Strength: zero
- Confidence: high
- Mechanism: Survival limits do not identify feeding, attack or hook vulnerability.
- Evidence: E2, E8, E12
- Double-counting risk: Do not turn tolerance boundaries into optima or smooth bite curves.
### R2. preyAndLifeStage - context-only
- Condition: Juveniles versus larger fish
- Direction: changes expected prey spectrum
- Strength: unknown
- Confidence: low-medium
- Mechanism: Ontogeny changes diet from small benthic invertebrates toward larger invertebrates, carrion and fish.
- Evidence: E3, E4
- Double-counting risk: Fish Guide context; original thesis locators remain incomplete.
### R3. spawningStage - context-only
- Condition: June-July Hudson spawning or reported 21-30 C spawning range
- Direction: unknown
- Strength: unknown
- Confidence: low
- Mechanism: Spawning changes habitat use and parental behavior.
- Evidence: E10
- Double-counting risk: Do not treat as a feeding bonus or exact NOVA calendar.
### R4. habitatType - context-only
- Condition: Sluggish backwater, estuarine or off-channel habitat
- Direction: location context only
- Strength: unknown
- Confidence: medium
- Mechanism: Habitat occupancy and competition affect where fish occur.
- Evidence: E6, E7
- Double-counting risk: Presence is not catchability and abundance can be confounded by channel catfish.
### R5. dielPeriodOrUnderwaterLight - unavailable
- Condition: Any category
- Direction: none
- Strength: unavailable
- Confidence: high
- Mechanism: No qualifying direct feeding/catchability study.
- Evidence: E13
- Double-counting risk: Do not repeat unsourced nocturnal folklore.
### R6. flowTurbidityDissolvedOxygen - unavailable
- Condition: Any category
- Direction: none
- Strength: unavailable
- Confidence: high
- Mechanism: No qualifying direct white-catfish feeding or standardized hook-and-line evidence.
- Evidence: E13
- Double-counting risk: Do not transfer channel-catfish thresholds.
### R7. recentAnglingPressure - unavailable
- Condition: Any duration
- Direction: none
- Strength: unavailable
- Confidence: high
- Mechanism: No hook-avoidance or depletion experiment was verified.
- Evidence: E14
- Double-counting risk: Do not infer from low fishery effort or population decline.
### R8. barometricPressureFrontsMoonWind - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct evidence.
- Evidence: E13
- Double-counting risk: Reject folklore.
### R9. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Life-history season and regulations do not establish intrinsic catchability.
- Evidence: E10, E11
- Double-counting risk: Avoid double counting reproduction, effort and temperature.

## Evidence ledger
### E1. regional targetability - context-only
- Exact condition/range: Virginia and Maryland agency accounts describe white catfish as a recreational food/game fish caught with bottom-fishing methods.
- Observed effect: Confirms plausible intentional regional targeting distinct from evidence sufficiency for scoring.
- Measured: Fishery status, distribution and fishing guidance
- Population/location: Virginia and Maryland
- Life stage: adult
- Evidence type: agency species accounts
- NOVA applicability: high for targetability only
- Confidence: high
- Source: S1 (section: Species account)
- Limitations: Guidance does not provide standardized catch-rate or environmental experiments.
- Surrogate evidence: false
### E2. temperature and salinity survival - context-only
- Exact condition/range: Patuxent River white catfish exposed to lethal temperature and salinity trials.
- Observed effect: The study established physiological tolerance boundaries for temperature and salinity.
- Measured: Mortality/survival tolerance
- Population/location: Patuxent River, Maryland
- Life stage: unspecified/multiple
- Evidence type: controlled physiology experiment, abstract-level
- NOVA applicability: high geographic relevance but wrong endpoint for bite
- Confidence: medium-high
- Source: S3 (section: Abstract)
- Limitations: Lethal limits are not feeding optima, preference, activity or catchability thresholds; exact acclimation details require full text.
- Surrogate evidence: false
### E3. food habits - context-only
- Exact condition/range: Lower Housatonic River thesis examined growth, mortality and food habits.
- Observed effect: Documents natural diet and population biology but no verified direct environmental feeding-rate coefficient was accessible in this run.
- Measured: Stomach contents, growth and mortality
- Population/location: Lower Housatonic River, Connecticut
- Life stage: multiple
- Evidence type: graduate thesis/catalog-level
- NOVA applicability: moderate geographic similarity
- Confidence: low-medium
- Source: S4 (section: Catalog title/record)
- Limitations: Full thesis and exact tables were not retrieved; no numerical bite rule can be supported.
- Surrogate evidence: false
### E4. prey selection and life stage - context-only
- Exact condition/range: California estuarine diet work summarized by USFWS.
- Observed effect: Young fish consumed amphipods, mysids and chironomid larvae; larger fish added larger invertebrates, carrion and fishes.
- Measured: Diet composition
- Population/location: San Francisco Estuary, California
- Life stage: juvenile through adult
- Evidence type: graduate thesis summarized by agency
- NOVA applicability: low geographic portability but useful Fish Guide context
- Confidence: medium-low
- Source: S12 (page: 8; section: Biology summary)
- Limitations: Original thesis byline/title page and claim tables were not directly inspected; California introduced population.
- Surrogate evidence: false
### E5. growth and life history - context-only
- Exact condition/range: Hudson River Estuary population at the northern range edge.
- Observed effect: Growth and life-history patterns were described for an estuarine population.
- Measured: Age, growth and life history
- Population/location: Hudson River Estuary, New York
- Life stage: multiple
- Evidence type: field population study, abstract-level
- NOVA applicability: context only
- Confidence: medium
- Source: S6 (section: Abstract)
- Limitations: Growth is not feeding or hook-and-line catchability.
- Surrogate evidence: false
### E6. habitat use and competition - context-only
- Exact condition/range: Native white catfish and introduced channel catfish compared in the Hudson River Estuary.
- Observed effect: Distribution, habitat use, growth and condition differed between species/populations.
- Measured: Habitat occupancy, growth and condition
- Population/location: Hudson River Estuary, New York
- Life stage: multiple
- Evidence type: field comparative study, abstract-level
- NOVA applicability: estuarine context
- Confidence: medium
- Source: S7 (section: Abstract)
- Limitations: Habitat presence and condition are not bite probability; species interactions confound abundance.
- Surrogate evidence: false
### E7. population abundance - context-only
- Exact condition/range: Delaware River Estuary population characteristics.
- Observed effect: White and channel catfish population structure was documented in a Mid-Atlantic estuary.
- Measured: Abundance, size/age structure and population metrics
- Population/location: Delaware River Estuary
- Life stage: multiple
- Evidence type: agency/proceedings field study
- NOVA applicability: high regional context
- Confidence: medium
- Source: S8 (section: Proceedings record)
- Limitations: Population abundance does not establish per-fish feeding or catchability.
- Surrogate evidence: false
### E8. brackish-water culture - context-only
- Exact condition/range: Blue, channel and white catfish cultured in brackish ponds.
- Observed effect: White catfish survived and grew under tested pond salinities, demonstrating culture tolerance.
- Measured: Survival and growth
- Population/location: Louisiana brackish ponds
- Life stage: juvenile/culture fish
- Evidence type: aquaculture experiment
- NOVA applicability: low for natural NOVA feeding
- Confidence: medium
- Source: S9 (page: 397-406; section: Methods and Results)
- Limitations: Aquaculture growth/survival cannot be converted into a salinity bite bonus.
- Surrogate evidence: false
### E9. growth and mortality - context-only
- Exact condition/range: St. Marys River field population.
- Observed effect: Relative abundance, growth and mortality were estimated.
- Measured: Population metrics
- Population/location: St. Marys River, Georgia/Florida
- Life stage: multiple
- Evidence type: field population study, abstract-level
- NOVA applicability: context only
- Confidence: medium
- Source: S10 (section: Abstract)
- Limitations: No direct feeding or hook-and-line endpoint.
- Surrogate evidence: false
### E10. spawning temperature and habitat - context-only
- Exact condition/range: Agency synthesis reports Hudson spawning in June-July along sandy shoals and rock piles at roughly 23-25 C; broader synthesis reports 21-30 C.
- Observed effect: Temperature and habitat coincide with reproduction.
- Measured: Spawning timing and habitat
- Population/location: Hudson River and broader range
- Life stage: adult
- Evidence type: agency synthesis
- NOVA applicability: context only
- Confidence: medium
- Source: S11 (page: 1; section: Species synopsis)
- Limitations: Spawning occurrence is not feeding or catchability; defensive behavior may differ from appetite.
- Surrogate evidence: false
### E11. recreational fishery intensity - context-only
- Exact condition/range: New York assessment states Hudson sportfishing for white catfish is thought to be low and much catfish effort targets introduced channel catfish.
- Observed effect: Targeting intensity varies regionally despite the species being catchable.
- Measured: Agency fishery assessment
- Population/location: Hudson River Estuary, New York
- Life stage: adult
- Evidence type: agency synthesis
- NOVA applicability: supports targetability nuance
- Confidence: medium
- Source: S11 (page: 4-6; section: Threats, trends, and recreational context)
- Limitations: New York effort does not determine Virginia interest.
- Surrogate evidence: false
### E12. thermal and salinity range - zero-weight
- Exact condition/range: USFWS synthesis reports occurrence from near 0 to 31 C and adult laboratory tolerance up to about 14 PSU.
- Observed effect: Broad survival/occurrence range.
- Measured: Occurrence and tolerance
- Population/location: United States
- Life stage: multiple
- Evidence type: federal synthesis
- NOVA applicability: context only
- Confidence: medium
- Source: S12 (page: 8; section: Biology)
- Limitations: These are survival/occurrence values, not feeding or bite thresholds.
- Surrogate evidence: false
### E13. time of day, light and weather - unavailable
- Exact condition/range: Broad search across primary and agency sources.
- Observed effect: No direct white-catfish study was verified that isolated diel light, turbidity, dissolved oxygen, flow, barometric pressure, fronts, rainfall, wind or moon phase against feeding or standardized hook-and-line catchability.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: multiple
- Evidence type: documented research gap
- NOVA applicability: high
- Confidence: high
- Source: S12 (page: 1-21; section: Reference screening)
- Limitations: No evidence is not proof of no effect; no model weight is justified.
- Surrogate evidence: false
### E14. angling pressure and learning - unavailable
- Exact condition/range: Broad search for hook avoidance, learning, depletion or recapture behavior.
- Observed effect: No qualifying white-catfish experiment was verified.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: multiple
- Evidence type: documented research gap
- NOVA applicability: high
- Confidence: high
- Source: S11 (page: 1-11; section: Assessment and reference screening)
- Limitations: Population decline or low effort cannot substitute for individual learning evidence.
- Surrogate evidence: false

## Remaining research gaps
- A primary adult feeding-rate study across temperature, oxygen, salinity, turbidity and diel light.
- Standardized Mid-Atlantic hook-and-line catchability or reward-tag studies.
- Accessible full text and exact claim tables for Housatonic and California diet theses.
- Hook avoidance, learning, depletion and angling-pressure experiments.
- Tidal-stage and discharge studies that measure feeding rather than occupancy.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (n.d.)
**White Catfish**. Virginia Department of Wildlife Resources.
https://dwr.virginia.gov/wildlife/information/white-catfish/
Scope: Virginia. Access: agency-web-page. Verification: AI-reviewed-unverified.
### S2. Maryland Department of Natural Resources (n.d.)
**White Catfish**. Maryland Department of Natural Resources.
https://dnr.maryland.gov/fisheries/pages/fish-facts.aspx?fishname=White%20Catfish
Scope: Maryland. Access: agency-web-page. Verification: AI-reviewed-unverified.
### S3. Arthur W. Kendall and Frank J. Schwartz (1968)
**Lethal Temperature and Salinity Tolerances of the White Catfish, Ictalurus catus, from the Patuxent River, Maryland**. Chesapeake Science 9(2):103-108. DOI: 10.2307/1351252.
https://link.springer.com/article/10.2307/1351252
Scope: Patuxent River, Maryland. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S4. Stephen J. Caromile (1994)
**Growth, Mortality, and Food Habits of White Catfish, Ameiurus catus, in the Lower Housatonic River, Connecticut**. University of Connecticut.
https://search.lib.uconn.edu/permalink/01UCT_STORRS/1o2co0h/alma991007223039703501
Scope: Lower Housatonic River, Connecticut. Access: university-catalog-record. Verification: AI-reviewed-unverified.
### S6. Michael J. Hughes and Douglas M. Carlson (1986)
**White Catfish Growth and Life History in the Hudson River Estuary, New York**. Journal of Freshwater Ecology 3(3):407-418. DOI: 10.1080/02705060.1986.9665132.
https://www.tandfonline.com/doi/abs/10.1080/02705060.1986.9665132
Scope: Hudson River Estuary, New York. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S7. Stephen M. Jordan, Robert M. Neumann, and Eric T. Schultz (2004)
**Distribution, Habitat Use, Growth, and Condition of a Native and an Introduced Catfish Species in the Hudson River Estuary**. Journal of Freshwater Ecology 19(1):59-66. DOI: 10.1080/02705060.2004.9664513.
https://www.tandfonline.com/doi/abs/10.1080/02705060.2004.9664513
Scope: Hudson River Estuary, New York. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S8. D. H. Keller (2011)
**Population Characteristics of White Catfish and Channel Catfish in the Delaware River Estuary**. American Fisheries Society Symposium 77:423-436.
https://fisheries.org/docs/books/54077C/20.pdf
Scope: Delaware River Estuary. Access: proceedings-record. Verification: AI-reviewed-unverified.
### S9. William G. Perry Jr. and James W. Avault Jr. (1969)
**Preliminary Experiments on the Culture of Blue, Channel, and White Catfish in Brackish Water Ponds**. Proceedings of the Southeastern Association of Game and Fish Commissioners 22:397-406.
https://seafwa.org/sites/default/files/journal-articles/PERRY-397-406.pdf
Scope: Brackish-water ponds, Louisiana. Access: proceedings-pdf-full-text. Verification: AI-reviewed-unverified.
### S10. Peter C. Sakaris, Timothy F. Bonvechio, and Bryant R. Bowen (2017)
**Relative Abundance, Growth, and Mortality of the White Catfish, Ameiurus catus L., in the St. Marys River**. Southeastern Naturalist 16(3):331-342. DOI: 10.1656/058.016.0319.
https://doi.org/10.1656/058.016.0319
Scope: St. Marys River, Georgia/Florida. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S11. Rich Pendleton and New York State Department of Environmental Conservation (2024)
**White Catfish Species Status Assessment**. New York State Department of Environmental Conservation.
https://extapps.dec.ny.gov/fs/programs/dfw/SWAP2025/Freshwater%20Fish/whitecatfish.pdf
Scope: New York/Hudson River Estuary. Access: agency-pdf-full-text. Verification: AI-reviewed-unverified.
### S12. U.S. Fish and Wildlife Service (2021)
**White Catfish (Ameiurus catus) Ecological Risk Screening Summary**. U.S. Fish and Wildlife Service.
https://www.fws.gov/sites/default/files/documents/Ecological-Risk-Screening-Summary-White_catfish.pdf
Scope: United States and introduced range. Access: agency-pdf-full-text. Verification: AI-reviewed-unverified.
### S13. Smithsonian Environmental Research Center (n.d.)
**Ameiurus catus Species Summary**. National Estuarine and Marine Exotic Species Information System.
https://invasions.si.edu/nemesis/species_summary/164037
Scope: Atlantic coast and introduced estuaries. Access: federal-research-web-synthesis. Verification: AI-reviewed-unverified.
