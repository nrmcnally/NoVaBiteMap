# Flathead Catfish
*Pylodictis olivaris*

- Species ID: `flathead-catfish`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Flathead catfish are deliberately targeted in large Mid-Atlantic rivers. Direct juvenile feeding-temperature evidence is sufficient for Bite-scored status, but implementation must remain categorical and life-stage limited.

### Model-ready findings
- **score**: Juvenile laboratory fish rarely fed below 15 C, most stopped at 11 C, and none consumed food at 7 C or below. Evidence: E2, E3.
- **score**: Juvenile maximum consumption was significantly higher at 19 C than colder treatments and remained elevated through 32 C. Evidence: E2.

### Context-only findings
- Virginia and Pennsylvania diet studies show strong piscivory and regional prey dependence, useful for Fish Guide and forage context. Evidence: E6, E7, E8.
- Extreme-flow diet differences are potentially useful but remain confounded and lack a portable flow threshold. Evidence: E9.
- Seasonal and diel telemetry describe location and movement, not feeding. Evidence: E11, E12, E13.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- moon phase or solunar tables
- wind or ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The strongest thermal evidence is juvenile laboratory work and may not describe trophy adults.
- High-temperature consumption through 32 C is not proof that hot field conditions improve catchability or survival.
- Movement studies cannot justify a night, winter or spawning bite multiplier.
- Diet composition differs sharply among tidal Virginia and Susquehanna populations.

## Targetability assessment
Flathead catfish are deliberately targeted in large Mid-Atlantic rivers. Direct juvenile feeding-temperature evidence is sufficient for Bite-scored status, but implementation must remain categorical and life-stage limited.

## Candidate model rules
### R1. waterTemperatureC - score
- Condition: Juvenile laboratory fish at <=7 C
- Direction: strong decrease / no consumption observed
- Strength: strong
- Confidence: medium-high
- Mechanism: Cold temperature suppressed juvenile feeding under the tested design.
- Evidence: E3
- Double-counting risk: Do not transfer a hard adult field cutoff or double count season.
### R2. waterTemperatureC - score
- Condition: Juvenile laboratory fish below 15 C, especially around 11 C
- Direction: decrease
- Strength: moderate-strong
- Confidence: medium-high
- Mechanism: Feeding became rare below 15 C and most fish stopped at 11 C.
- Evidence: E2, E3
- Double-counting risk: Keep categorical and bounded; do not invent a smooth curve.
### R3. waterTemperatureC - score
- Condition: Juvenile laboratory fish at 19-32 C
- Direction: increase relative to colder tested treatments
- Strength: moderate
- Confidence: medium
- Mechanism: Maximum consumption was significantly higher at 19 C and remained elevated through 32 C.
- Evidence: E2
- Double-counting risk: Not an adult optimum and not evidence that extreme field heat improves catchability.
### R4. fishTotalLength - context-only
- Condition: Adult size alone
- Direction: variable/uncertain
- Strength: unknown
- Confidence: medium
- Mechanism: Tag returns varied among size classes and river reaches without one portable pattern.
- Evidence: E4
- Double-counting risk: Do not import Missouri size bins as a universal NOVA curve.
### R5. preyAssemblage - context-only
- Condition: Availability of fish prey or crayfish
- Direction: changes prey selection
- Strength: unknown
- Confidence: medium-high
- Mechanism: Regional prey fields and predator size shaped diet.
- Evidence: E6, E7, E8
- Double-counting risk: Fish Guide/forage context; do not equate diet occurrence with catch rate.
### R6. extremeFlow - context-only
- Condition: Flood-year category without local prey and temperature controls
- Direction: unknown
- Strength: unknown
- Confidence: low
- Mechanism: Flow may alter prey access, fullness and condition, but causal direction was not portable.
- Evidence: E9
- Double-counting risk: Avoid double counting discharge, floodplain access, prey and temperature.
### R7. dielPeriod - zero-weight
- Condition: Night versus day based only on telemetry movement
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Movement timing was measured, not feeding or angling.
- Evidence: E12
- Double-counting risk: No generic nighttime bite bonus.
### R8. winterMovement - zero-weight
- Condition: Minimal winter movement
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Low movement cannot be converted into feeding cessation; only juvenile laboratory cold feeding was direct.
- Evidence: E3, E11
- Double-counting risk: Keep movement and feeding endpoints separate.
### R9. spawningMovementOrFlood - zero-weight
- Condition: Tributary use during putative spawn
- Direction: none as a bite rule
- Strength: zero
- Confidence: high
- Mechanism: Movement/access was measured, not appetite.
- Evidence: E13
- Double-counting risk: Avoid double counting flow, season and reproduction.
### R10. barometricPressureFrontsMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct evidence.
- Evidence: E14
- Double-counting risk: Reject folklore.
### R11. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Thermal feeding evidence is laboratory and movement studies are not feeding.
- Evidence: E2, E11, E13
- Double-counting risk: Avoid double counting temperature and spawning.

## Evidence ledger
### E1. regional recreational targetability - context-only
- Exact condition/range: Virginia agency species account describes flathead catfish as an established large-river sportfish.
- Observed effect: Confirms intentional hook-and-line targeting in the region.
- Measured: Fishery status and distribution
- Population/location: Virginia
- Life stage: adult
- Evidence type: agency species account
- NOVA applicability: high for targetability only
- Confidence: high
- Source: S1 (section: Species account)
- Limitations: Does not support environmental bite rules.
- Surrogate evidence: false
### E2. absolute water temperature - score
- Exact condition/range: Juvenile laboratory trials across 3-32 C.
- Observed effect: Maximum daily consumption increased with temperature, was significantly higher at 19 C than at colder temperatures, and remained elevated through 32 C.
- Measured: Maximum daily consumption and metabolic demand
- Population/location: Laboratory
- Life stage: juvenile
- Evidence type: controlled feeding experiment, abstract-level
- NOVA applicability: mechanistically direct but juvenile and nonfield
- Confidence: medium-high
- Source: S2 (section: Abstract)
- Limitations: No adult field validation; only exact tested conditions are portable.
- Surrogate evidence: false
### E3. cold feeding cessation - score
- Exact condition/range: Same juvenile laboratory temperature series.
- Observed effect: Fish rarely ate below 15 C, most stopped feeding at 11 C, and none consumed food at 7 C or below.
- Measured: Occurrence of feeding and consumption
- Population/location: Laboratory
- Life stage: juvenile
- Evidence type: controlled feeding experiment, abstract-level
- NOVA applicability: useful bounded cold candidate
- Confidence: medium-high
- Source: S2 (section: Abstract)
- Limitations: Juvenile laboratory fish; acclimation, prey and exposure duration require full-text confirmation before production calibration.
- Surrogate evidence: false
### E4. fish size and exploitation - context-only
- Exact condition/range: Reward-tagged flathead catfish in 12 size groups beginning at 381 mm TL.
- Observed effect: Exploitation was highly variable among sizes and reaches rather than forming one consistent size-response curve.
- Measured: Reported harvest and release corrected for nonreporting
- Population/location: Missouri and Mississippi rivers, Missouri
- Life stage: adult
- Evidence type: field tagging/fisher returns
- NOVA applicability: direct catchability endpoint but weak portability
- Confidence: medium
- Source: S3 (section: Abstract)
- Limitations: Angler selectivity, gear, regulations and local abundance confound intrinsic vulnerability.
- Surrogate evidence: false
### E5. gear/presentation - context-only
- Exact condition/range: Gear-specific exploitation in the Missouri agency final report associated with the Winders study.
- Observed effect: Rod/reel, trotline, bank-pole and other methods produced different reported exploitation contributions.
- Measured: Gear-specific tag returns
- Population/location: Missouri and Mississippi rivers
- Life stage: adult
- Evidence type: tagging and fishery report
- NOVA applicability: Fish Guide relevance
- Confidence: medium
- Source: S3 (page: S247-S254; section: Results)
- Limitations: Gear use and effort were not standardized as a feeding experiment.
- Surrogate evidence: false
### E6. regional prey selection - context-only
- Exact condition/range: 766 flathead catfish captured at more than 1,500 sites; 731 stomachs examined.
- Observed effect: Virginia tidal-river fish were piscine specialists feeding heavily on gizzard shad, white perch, and Alosa species.
- Measured: Diet composition, trophic level and distribution
- Population/location: James, Pamunkey, and Mattaponi rivers, Virginia
- Life stage: multiple sizes
- Evidence type: field diet and distribution study
- NOVA applicability: high regional forage context
- Confidence: high
- Source: S4 (page: 390-402; section: Abstract and Results; table: diet tables; figure: distribution/diet figures)
- Limitations: Diet composition does not establish feeding rate, tide, temperature or catchability.
- Surrogate evidence: false
### E7. fish size and diet - context-only
- Exact condition/range: Flathead catfish across size classes in Virginia tidal rivers.
- Observed effect: Dominant fish prey varied among size classes; larger fish remained strongly piscivorous.
- Measured: Diet composition by predator size
- Population/location: Virginia tidal rivers
- Life stage: multiple sizes
- Evidence type: field diet study
- NOVA applicability: regional Fish Guide context
- Confidence: medium-high
- Source: S4 (page: 390-402; section: Results and Discussion; table: diet tables)
- Limitations: Size-related diet is not size-related hook vulnerability.
- Surrogate evidence: false
### E8. regional prey availability - context-only
- Exact condition/range: Susquehanna River basin diet study detected 47 prey species; crayfish occurred in more than 34% of diets across size classes and fish consumption increased with predator size.
- Observed effect: Flathead catfish showed opportunistic, length-driven diet shifts shaped by regional prey assemblages.
- Measured: Stomach contents and prey identification
- Population/location: Susquehanna River basin, Pennsylvania
- Life stage: multiple sizes
- Evidence type: field diet study
- NOVA applicability: high Mid-Atlantic prey context
- Confidence: high
- Source: S5 (section: Results and Discussion; table: diet tables; figure: diet figures)
- Limitations: Diet occurrence does not quantify feeding intensity or catchability; basin differs from tidal Virginia.
- Surrogate evidence: false
### E9. extreme flow and feeding condition - context-only
- Exact condition/range: 629 fish sampled across years including a record-flood year.
- Observed effect: Stomach fullness and fish condition differed among flow years, indicating that extreme flow can alter diet and energetic context.
- Measured: Stomach fullness, diet composition and condition
- Population/location: Large river, Nebraska
- Life stage: adult
- Evidence type: field comparative diet study, abstract-level
- NOVA applicability: direct feeding context but insufficient portable direction without full text
- Confidence: low-medium
- Source: S6 (section: Abstract)
- Limitations: Year, prey community, temperature and sampling differences confound causal flow effects; exact flow thresholds were not verified.
- Surrogate evidence: false
### E10. habitat-specific feeding - context-only
- Exact condition/range: Floodplain lake, side channel and main-channel habitats in the lower Mississippi River.
- Observed effect: Feeding ecology and energetic relationships varied among habitat types.
- Measured: Diet and energetic indices
- Population/location: Lower Mississippi River
- Life stage: adult
- Evidence type: field habitat/diet study, abstract-level
- NOVA applicability: context only
- Confidence: medium
- Source: S7 (section: Abstract)
- Limitations: Habitat occupancy and prey availability co-vary; no portable bite multiplier.
- Surrogate evidence: false
### E11. seasonal movement - zero-weight
- Exact condition/range: Telemetry across seasons in the lower St. Joseph River.
- Observed effect: Home range and movement were greatest during warm seasons and minimal in winter.
- Measured: Movement and home range
- Population/location: Michigan river
- Life stage: adult
- Evidence type: field telemetry
- NOVA applicability: location context, wrong endpoint
- Confidence: medium-high
- Source: S8 (section: Abstract)
- Limitations: Movement is not feeding or catchability; colder northern system.
- Surrogate evidence: false
### E12. diel movement - zero-weight
- Exact condition/range: Seasonal diel telemetry in the lower St. Joseph River.
- Observed effect: Diel movement varied by season and was often greater at night during warmer periods.
- Measured: Movement timing and habitat use
- Population/location: Michigan river
- Life stage: adult
- Evidence type: field telemetry
- NOVA applicability: context only
- Confidence: medium
- Source: S9 (section: Abstract)
- Limitations: No feeding or hook-and-line endpoint; cannot justify a generic nighttime bonus.
- Surrogate evidence: false
### E13. spawning movement and flow - context-only
- Exact condition/range: Two annual cycles in the lower Missouri River.
- Observed effect: Tributary use and movement increased during putative spawning periods and differed between years; flood conditions may have influenced access.
- Measured: Movement and migration
- Population/location: Lower Missouri River
- Life stage: adult
- Evidence type: field telemetry
- NOVA applicability: context only
- Confidence: medium
- Source: S10 (section: Abstract and Results)
- Limitations: No feeding/catchability measurement and no isolated discharge threshold.
- Surrogate evidence: false
### E14. weather folklore variables - unavailable
- Exact condition/range: Broad source search for direct species-specific pressure, front, moon, wind or cloud-cover experiments.
- Observed effect: No qualifying direct feeding or hook-and-line evidence was verified.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: multiple
- Evidence type: evidence-gap record
- NOVA applicability: high
- Confidence: high
- Source: S12 (page: 1-16; section: Review and cited-literature screening)
- Limitations: Absence of evidence is not proof of no effect; it supports zero weight.
- Surrogate evidence: false

## Remaining research gaps
- Adult Mid-Atlantic field feeding and standardized hook-and-line trials across temperature.
- Direct dissolved-oxygen, turbidity, underwater-light and short-term flow-change effects on feeding/catchability.
- Local size-specific angler recapture and pressure/learning studies.
- Replicated flood/discharge studies that separate prey access, temperature and habitat inundation.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (n.d.)
**Flathead Catfish**. Virginia Department of Wildlife Resources.
https://dwr.virginia.gov/wildlife/information/flathead-catfish/
Scope: Virginia. Access: agency-web-page. Verification: AI-reviewed-unverified.
### S2. Samuel L. Bourret, Ralph W. Tingley III, Yoichiro Kanno, and Jason C. Vokoun (2008)
**Maximum Daily Consumption and Specific Daily Metabolic Demand of Juvenile Flathead Catfish (Pylodictis olivaris)**. Journal of Freshwater Ecology 23(3):413-419. DOI: 10.1080/02705060.2008.9664218.
https://www.tandfonline.com/doi/abs/10.1080/02705060.2008.9664218
Scope: Laboratory experiment. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S3. Kyle Robert Winders and Joseph A. McMullen (2021)
**Size-Specific Exploitation of Flathead Catfish and Blue Catfish by Recreational and Commercial Fishers in the Missouri and Mississippi Rivers, Missouri**. North American Journal of Fisheries Management 41(S1):S247-S254. DOI: 10.1002/nafm.10619.
https://academic.oup.com/najfm/article/41/S1/S247/7749315
Scope: Missouri and Mississippi rivers, Missouri. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S4. Joseph D. Schmitt, Jason A. Emmel, Aaron J. Bunch, Corbin D. Hilling, and Donald J. Orth (2019)
**Feeding Ecology and Distribution of an Invasive Apex Predator: Flathead Catfish in Subestuaries of the Chesapeake Bay, Virginia**. North American Journal of Fisheries Management 39(2):390-402. DOI: 10.1002/nafm.10279.
https://units.fisheries.org/sdafscatfishcommittee/wp-content/uploads/sites/22/2019/06/Schmitt_et_al-2019-Feeding-ecology-and-Distribution-of-FCF.pdf
Scope: James, Pamunkey, Mattaponi, and Rappahannock subestuaries, Virginia. Access: accepted-manuscript-pdf-full-text. Verification: AI-reviewed-unverified.
### S5. Sydney Stark, Megan K. Schall, Geoffrey D. Smith, Aaron Maloy, Jason A. Coombs, Tyler Wagner, and Julian Avery (2024)
**Feeding Habits and Ecological Implications of the Invasive Flathead Catfish in the Susquehanna River Basin, Pennsylvania**. Transactions of the American Fisheries Society 153(5):591-607. DOI: 10.1002/tafs.10480.
https://academic.oup.com/tafs/article/153/5/591/7814514
Scope: Susquehanna River basin, Pennsylvania. Access: publisher-full-text. Verification: AI-reviewed-unverified.
### S6. Nick P. Hogberg and Mark A. Pegg (2016)
**Flathead Catfish Pylodictis olivaris Diet Composition during Extreme Flow Events in a Large River**. Journal of Freshwater Ecology 31(3):431-441. DOI: 10.1080/02705060.2016.1172523.
https://www.tandfonline.com/doi/abs/10.1080/02705060.2016.1172523
Scope: Large river, Nebraska. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S7. Michael A. Eggleton and Harold L. Schramm Jr. (2004)
**Feeding Ecology and Energetic Relationships with Habitat of Blue Catfish, Ictalurus furcatus, and Flathead Catfish, Pylodictis olivaris, in the Lower Mississippi River, U.S.A.**. Environmental Biology of Fishes 70(2):107-121. DOI: 10.1023/B:EBFI.0000029341.45030.94.
https://pubs.usgs.gov/publication/70026651
Scope: Lower Mississippi River. Access: agency-bibliographic-record-and-abstract. Verification: AI-reviewed-unverified.
### S8. Daniel J. Daugherty and Trent M. Sutton (2005)
**Seasonal Movement Patterns, Habitat Use, and Home Range of Flathead Catfish in the Lower St. Joseph River, Michigan**. North American Journal of Fisheries Management 25(1):256-269. DOI: 10.1577/M03-252.2.
https://academic.oup.com/najfm/article/25/1/256/7848083
Scope: Lower St. Joseph River, Michigan. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S9. Daniel J. Daugherty and Trent M. Sutton (2005)
**Diel Movement Patterns and Habitat Use of Flathead Catfish in the Lower St. Joseph River, Michigan**. Journal of Freshwater Ecology 20(1):1-8. DOI: 10.1080/02705060.2005.9664930.
https://www.tandfonline.com/doi/abs/10.1080/02705060.2005.9664930
Scope: Lower St. Joseph River, Michigan. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S10. D. L. Garrett and C. F. Rabeni (2011)
**Intra-annual Movement and Migration of Flathead Catfish and Blue Catfish in the Lower Missouri River and Tributaries**. American Fisheries Society Symposium 77:495-510.
https://units.fisheries.org/sdafscatfishcommittee/wp-content/uploads/sites/22/2019/07/Garrett-and-Rabeni-2011-Intra-annual-movement-and-migration-of-flathead-catfish-and-blue-catfish-in-the-lower-Missouri-River-and-tribuatrie.pdf
Scope: Lower Missouri River and tributaries. Access: proceedings-pdf-full-text. Verification: AI-reviewed-unverified.
### S11. Jason C. Vokoun and Charles F. Rabeni (2005)
**Home Range and Space Use Patterns of Flathead Catfish during the Summer-Fall Period in Two Missouri Streams**. Transactions of the American Fisheries Society 134(2):509-517. DOI: 10.1577/T04-064.1.
https://pubs.usgs.gov/publication/70029392
Scope: Two Missouri streams. Access: agency-bibliographic-record-and-abstract. Verification: AI-reviewed-unverified.
### S12. Geoffrey F. Montague and Daniel E. Shoup (2021)
**Two Decades of Advancement in Flathead Catfish Research**. North American Journal of Fisheries Management 41(S1):S48-S68. DOI: 10.1002/nafm.10654.
https://agriculture.okstate.edu/site-files/departments-programs/natural-resource/research/natural-resource-labs/shoup-fisheries-management-and-fisheries-ecology-lab/montague_and_shoup_2021.pdf
Scope: North America. Access: author-repository-pdf-full-text. Verification: AI-reviewed-unverified.
