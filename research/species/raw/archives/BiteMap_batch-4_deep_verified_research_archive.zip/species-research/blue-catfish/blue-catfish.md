# Blue Catfish
*Ictalurus furcatus*

- Species ID: `blue-catfish`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Bite-scored**

## Executive conclusion
Blue catfish are a major, intentionally targeted Virginia and Potomac-region sportfish. Direct consumption and size-specific exploitation evidence support Bite-scored status, but only bounded temperature and size candidates survive.

### Model-ready findings
- **score**: Maximum daily ration at 5 C was lower than at 15 C in a controlled trial; 15 and 25 C did not differ, so only a bounded cold reduction is supportable. Evidence: E2.
- **score**: Missouri/Mississippi reward-tag data showed size-specific recreational exploitation peaks, supporting a low-portability biological size candidate. Evidence: E10.

### Context-only findings
- Virginia field ration varied by river and August feeding chronology did not yield a universal time-of-day rule. Evidence: E5, E6.
- Tide, salinity zone, prey type and ontogenetic diet are valuable context but not portable independent multipliers. Evidence: E3, E7, E8, E9.
- Telemetry and abundance studies improve location context but measure neither feeding nor hook vulnerability. Evidence: E11, E12.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- moon phase or solunar tables
- wind or ordinary rainfall as an independent multiplier
- cloud cover without measured underwater light
- growth or survival limits used as bite optima
- movement or habitat occupancy used as feeding
- spawning movement used as appetite
- monthly curves derived from fishing seasons, regulations, stocking calendars, or folklore

## Contradictions and limitations
- The laboratory temperature result is maximum ration after starvation, not field angler catchability.
- The apparent 500-600 mm feeding peak is weakly replicated and is not implemented.
- Field diel and tidal patterns differ among rivers and cannot support universal clocks or tide bonuses.
- Exploitation peaks reflect human size selection and fishery structure as well as fish vulnerability.

## Targetability assessment
Blue catfish are a major, intentionally targeted Virginia and Potomac-region sportfish. Direct consumption and size-specific exploitation evidence support Bite-scored status, but only bounded temperature and size candidates survive.

## Candidate model rules
### R1. waterTemperatureC - score
- Condition: Approximately 5 C versus 15-25 C under the Schmitt laboratory design
- Direction: decrease below 15 C relative to tested warmer treatments
- Strength: moderate
- Confidence: medium-high
- Mechanism: Cold water reduced maximum daily ration; 15 and 25 C were not significantly different.
- Evidence: E2
- Double-counting risk: Do not declare 15 C an optimum, interpolate a smooth curve, or double count season.
### R2. fishTotalLengthMm - score
- Condition: 840-890 mm in sampled Missouri River reaches or 891-1,015 mm in sampled Mississippi River reaches
- Direction: increase in observed exploitation relative to other sampled sizes
- Strength: moderate
- Confidence: medium-low
- Mechanism: Angler selectivity and vulnerability produced size-specific return patterns.
- Evidence: E10
- Double-counting risk: Highly fishery-specific; avoid treating as innate appetite or transferring exact bins to NOVA without local tagging/creel data.
### R3. preyType - context-only
- Condition: Gizzard shad versus blue crab under laboratory maximum-ration trials
- Direction: higher consumption of gizzard shad
- Strength: moderate
- Confidence: medium
- Mechanism: Prey form and handling affected intake.
- Evidence: E3
- Double-counting risk: Fish Guide/forage context; do not double count prey abundance and fish size.
### R4. tidalPhase - context-only
- Condition: Near end of outgoing tide in three sampled rivers, but incoming tide in the Mattaponi
- Direction: river-specific/uncertain
- Strength: weak
- Confidence: low
- Mechanism: Tidal transport and prey access may affect feeding chronology.
- Evidence: E7
- Double-counting risk: Contradictory river result; no universal outgoing-tide bonus.
### R5. dielPeriod - zero-weight
- Condition: Clock hour alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Peak times differed among rivers despite an overall 0900-1500 fullness window.
- Evidence: E6
- Double-counting risk: Avoid double counting tide, prey, temperature and sampling schedule.
### R6. salinityZone - context-only
- Condition: Tidal fresh, oligohaline or mesohaline zone
- Direction: context-dependent prey composition only
- Strength: unknown
- Confidence: medium
- Mechanism: Salinity co-varied with prey community and habitat.
- Evidence: E9, E11
- Double-counting risk: Do not infer feeding intensity or catchability from occupancy.
### R7. spawningMovementOrFlood - zero-weight
- Condition: Tributary use or flood-associated movement
- Direction: none as a bite rule
- Strength: zero
- Confidence: high
- Mechanism: Telemetry measured movement and access, not feeding.
- Evidence: E12
- Double-counting risk: Avoid double counting flow, season and reproduction.
### R8. barometricPressureFrontsMoon - zero-weight
- Condition: Any category
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: No qualifying direct species-specific evidence.
- Evidence: E14
- Double-counting risk: Folklore is not evidence.
### R9. monthlyActivity - zero-weight
- Condition: Calendar month alone
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Seasonal diet and habitat shifts do not establish intrinsic monthly catchability.
- Evidence: E5, E8, E9
- Double-counting risk: Avoid double counting temperature, prey, salinity, access and effort.

## Evidence ledger
### E1. regional recreational targetability - context-only
- Exact condition/range: Virginia and Maryland agency accounts identify established blue-catfish fisheries and intentional hook-and-line targeting.
- Observed effect: Confirms practical, intentional regional targeting.
- Measured: Fishery status and fishing methods
- Population/location: Virginia and Maryland
- Life stage: adult
- Evidence type: agency fishery guidance
- NOVA applicability: high for targetability only
- Confidence: high
- Source: S1 (section: Species account)
- Limitations: Agency guidance does not validate weather or feeding thresholds.
- Surrogate evidence: false
### E2. absolute water temperature - score
- Exact condition/range: Laboratory trials at 5, 15, and 25 C; fish 332-878 mm TL; salinity near 3.0 per mille; 14-day acclimation; 72-hour pretrial starvation.
- Observed effect: Mean maximum 24-hour consumption increased from 7.53% body weight at 5 C to 10.66% at 15 C; 15 and 25 C did not differ significantly (25 C mean 10.55%).
- Measured: Maximum daily ration (% body weight per 24 h)
- Population/location: Laboratory fish associated with Virginia tidal-river research
- Life stage: subadult/adult sizes
- Evidence type: controlled feeding experiment
- NOVA applicability: mechanistically relevant; exact laboratory conditions must be preserved
- Confidence: high
- Source: S2 (page: 5-6; section: Results - Laboratory Estimates of Consumption; table: Table 1; figure: Figure 2)
- Limitations: Maximum-ration, starved-fish laboratory result is not a natural catch-rate curve; only three temperatures were tested.
- Surrogate evidence: false
### E3. prey type - context-only
- Exact condition/range: Gizzard shad versus blue crab in 24-hour laboratory feeding trials at tested temperatures and fish sizes.
- Observed effect: Blue catfish consumed significantly more gizzard shad than blue crab.
- Measured: Maximum 24-hour consumption
- Population/location: Laboratory
- Life stage: subadult/adult sizes
- Evidence type: controlled feeding experiment
- NOVA applicability: useful prey-context and Fish Guide evidence
- Confidence: medium-high
- Source: S2 (page: 5-6; section: Results - Laboratory Estimates of Consumption; table: Table 1; figure: Figure 2)
- Limitations: Prey availability, handling and energetic density differ; not an environmental multiplier.
- Surrogate evidence: false
### E4. fish size and feeding - context-only
- Exact condition/range: Fish grouped in 100-mm length bins from roughly 300 to 800 mm TL.
- Observed effect: The 500-600 mm groups had the highest laboratory maximum-consumption estimates.
- Measured: Maximum 24-hour consumption
- Population/location: Laboratory
- Life stage: subadult/adult sizes
- Evidence type: controlled feeding experiment
- NOVA applicability: possible biological calibration context
- Confidence: medium
- Source: S2 (page: 5-7; section: Results and Discussion; figure: Figure 3)
- Limitations: Only one representative fish was used in each length class above 500 mm; authors caution that individual behavior may explain the pattern.
- Surrogate evidence: false
### E5. field feeding rate - context-only
- Exact condition/range: 1,226 stomachs sampled in August at 22.3-29.6 C from four Virginia tidal rivers.
- Observed effect: Estimated daily ration varied by river from 2.27% to 5.22% body weight per 24 h.
- Measured: Diet-based daily ration
- Population/location: James, Pamunkey, Mattaponi, and Rappahannock rivers, Virginia
- Life stage: wild multiple sizes
- Evidence type: field diet chronology and modeling
- NOVA applicability: high regional relevance; August only
- Confidence: medium-high
- Source: S2 (page: 5-6; section: Results - Field Estimates of Consumption; table: Table 2; figure: Figure 4)
- Limitations: Estimates depend on evacuation/chronology modeling, prey identification, summer temperature and sampled times.
- Surrogate evidence: false
### E6. time of day - zero-weight
- Exact condition/range: August diet chronologies across four Virginia tidal rivers.
- Observed effect: Peak stomach fullness occurred between 0900 and 1500 overall, but peak feeding time differed among rivers and the authors found no consistent universal diel pattern.
- Measured: Stomach fullness and modeled feeding chronology
- Population/location: Virginia tidal rivers
- Life stage: wild multiple sizes
- Evidence type: field diet chronology
- NOVA applicability: high for rejecting a universal hourly bonus
- Confidence: medium-high
- Source: S2 (page: 5-8; section: Field Estimates and Discussion; figure: Figure 4)
- Limitations: August-only sampling; stomach evacuation and tidal movement can shift apparent peaks.
- Surrogate evidence: false
### E7. tidal stage/current - context-only
- Exact condition/range: Field feeding chronologies in four tidal rivers.
- Observed effect: Peak feeding appeared near the end of outgoing tide in the James, Pamunkey, and Rappahannock, but near the end of incoming tide in the Mattaponi; authors called for more research.
- Measured: Modeled feeding chronology relative to tide
- Population/location: Virginia tidal rivers
- Life stage: wild multiple sizes
- Evidence type: field observational
- NOVA applicability: directly regional but inconsistent
- Confidence: low-medium
- Source: S2 (page: 8; section: Discussion; figure: Figure 4)
- Limitations: Four-river inconsistency and one August sampling window prevent a portable tide rule.
- Surrogate evidence: false
### E8. ontogenetic diet shift - context-only
- Exact condition/range: 16,110 stomachs across four Virginia tidal rivers.
- Observed effect: Diet shifted from omnivory toward piscivory, with transition size varying by river roughly within 500-900 mm TL.
- Measured: Diet composition, trophic level and prey occurrence
- Population/location: Virginia Chesapeake Bay tributaries
- Life stage: juvenile through adult
- Evidence type: large field diet study
- NOVA applicability: high regional prey-selection relevance
- Confidence: high
- Source: S3 (page: 443-465; section: Results and Discussion; figure: size/diet figures)
- Limitations: Diet composition is not feeding intensity or angling vulnerability; thresholds vary by river.
- Surrogate evidence: false
### E9. season and salinity - context-only
- Exact condition/range: Tidal fresh, oligohaline and mesohaline reaches sampled across seasons.
- Observed effect: Prey composition varied by season, salinity zone, fish size and river.
- Measured: Diet composition
- Population/location: Virginia Chesapeake Bay tributaries
- Life stage: juvenile through adult
- Evidence type: field diet study
- NOVA applicability: high habitat/forage context
- Confidence: medium-high
- Source: S3 (page: 443-465; section: Results and Discussion; table: diet tables; figure: diet figures)
- Limitations: Does not isolate salinity as a causal feeding-rate effect; prey fields co-vary.
- Surrogate evidence: false
### E10. fish size and exploitation - score
- Exact condition/range: Reward-tag study beginning at 381 mm TL in Missouri and Mississippi river reaches.
- Observed effect: Recreational blue-catfish exploitation was highest at 840-890 mm in the Missouri River (0.34-0.43) and 891-1,015 mm in the Mississippi River (0.24-0.28).
- Measured: Size-specific reported harvest/catch-and-release corrected for reporting
- Population/location: Missouri and Mississippi rivers, Missouri
- Life stage: adult
- Evidence type: field tagging and fisher returns
- NOVA applicability: direct catchability/exploitation endpoint but low geographic portability
- Confidence: medium
- Source: S4 (section: Abstract)
- Limitations: Exploitation includes angler selectivity, abundance, regulations, gear and harvest decisions; not an intrinsic smooth size curve.
- Surrogate evidence: false
### E11. habitat occupancy - context-only
- Exact condition/range: Stratified sampling across a Chesapeake Bay subestuary.
- Observed effect: Large numbers occupied tidal freshwater and oligohaline habitats, with abundance patterns tied to habitat and season.
- Measured: Abundance and distribution
- Population/location: James River subestuary, Virginia
- Life stage: multiple
- Evidence type: field population sampling
- NOVA applicability: high location context
- Confidence: medium-high
- Source: S5 (section: Abstract and Results)
- Limitations: Occupancy and electrofishing abundance do not establish feeding or hook-and-line catchability.
- Surrogate evidence: false
### E12. movement, tributary use and flooding - context-only
- Exact condition/range: Two annual telemetry cycles in a 97-km lower Missouri River reach.
- Observed effect: Intra-annual movement and tributary use varied; tributary use during putative spawning was 10% in 2006 and 18% in 2007, and a May 2007 flood was a possible contributor.
- Measured: Movement and tributary use
- Population/location: Lower Missouri River
- Life stage: adult
- Evidence type: telemetry
- NOVA applicability: context only; different basin
- Confidence: medium
- Source: S7 (section: Abstract and Results)
- Limitations: Movement/spawning access is not feeding; flood attribution was not isolated experimentally.
- Surrogate evidence: false
### E13. prey selectivity during migration - context-only
- Exact condition/range: Spring sampling of nonnative catfish and migrating alosines in the James River.
- Observed effect: Catfish consumed alosines, but prey use depended on species, predator size, prey availability and season.
- Measured: Stomach contents and prey selectivity
- Population/location: James River, Virginia
- Life stage: multiple
- Evidence type: field diet/selectivity study
- NOVA applicability: high regional prey context
- Confidence: medium-high
- Source: S8 (page: 108-125; section: Results and Discussion; table: diet/selectivity tables)
- Limitations: Seasonal prey occurrence cannot be converted into a general spring bite bonus.
- Surrogate evidence: false
### E14. weather folklore variables - unavailable
- Exact condition/range: Broad search for species-specific direct feeding or hook-and-line experiments isolating pressure, fronts, wind, moon or cloud cover.
- Observed effect: No qualifying direct evidence was verified.
- Measured: Evidence availability
- Population/location: multiple
- Life stage: multiple
- Evidence type: systematic evidence-gap record
- NOVA applicability: high
- Confidence: high
- Source: S2 (page: 1-12; section: Article and reference screening)
- Limitations: Absence of verified evidence is not proof of no biological effect; it supports zero model weight.
- Surrogate evidence: false

## Remaining research gaps
- Adult Mid-Atlantic feeding/catchability trials across ordinary winter-to-summer temperatures rather than maximum-ration laboratory conditions.
- Local size-specific tagging or standardized catch-per-effort data for Virginia/Potomac fisheries.
- Replicated tidal-stage feeding studies across seasons with underwater light, prey and current measured.
- Direct dissolved-oxygen, turbidity, short-term temperature-trend and hook-avoidance experiments.

## Adversarial review outcome
Every candidate rule was challenged against the endpoint actually measured. Movement, habitat occupancy, growth, physiology, survival, spawning, diet composition and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are retained; no final production multiplier or invented smooth response curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (n.d.)
**Blue Catfish**. Virginia Department of Wildlife Resources.
https://dwr.virginia.gov/wildlife/information/blue-catfish/
Scope: Virginia. Access: agency-web-page. Verification: AI-reviewed-unverified.
### S2. Joseph D. Schmitt, Corbin D. Hilling, and Donald J. Orth (2021)
**Estimates of Food Consumption Rates for Invasive Blue Catfish**. Transactions of the American Fisheries Society 150(4):465-476. DOI: 10.1002/tafs.10300.
https://vtechworks.lib.vt.edu/bitstreams/0a0bf12b-c487-46d4-b63c-88a3a2353eb0/download
Scope: Virginia tidal James, Pamunkey, Mattaponi, and Rappahannock rivers plus laboratory trials. Access: repository-pdf-full-text. Verification: AI-reviewed-unverified.
### S3. Joseph D. Schmitt, Brandon K. Peoples, Leandro Castello, and Donald J. Orth (2019)
**Feeding ecology of generalist consumers: a case study of invasive blue catfish Ictalurus furcatus in Chesapeake Bay, Virginia, USA**. Environmental Biology of Fishes 102(3):443-465. DOI: 10.1007/s10641-018-0783-6.
https://leandrocastello.org/wp-content/uploads/2019/04/2018-Schmitt-et-al.-catfish-diet.pdf
Scope: Virginia tidal James, Pamunkey, Mattaponi, and Rappahannock rivers. Access: author-repository-pdf-full-text. Verification: AI-reviewed-unverified.
### S4. Kyle Robert Winders and Joseph A. McMullen (2021)
**Size-Specific Exploitation of Flathead Catfish and Blue Catfish by Recreational and Commercial Fishers in the Missouri and Mississippi Rivers, Missouri**. North American Journal of Fisheries Management 41(S1):S247-S254. DOI: 10.1002/nafm.10619.
https://academic.oup.com/najfm/article/41/S1/S247/7749315
Scope: Missouri and Mississippi rivers, Missouri. Access: publisher-abstract. Verification: AI-reviewed-unverified.
### S5. Mary C. Fabrizio, Troy D. Tuckey, Robert J. Latour, Gary C. White, and Alicia J. Norris (2018)
**Tidal Habitats Support Large Numbers of Invasive Blue Catfish in a Chesapeake Bay Subestuary**. Estuaries and Coasts 41(3):827-840. DOI: 10.1007/s12237-017-0307-1.
https://link.springer.com/article/10.1007/s12237-017-0307-1
Scope: James River subestuary, Virginia. Access: publisher-full-text. Verification: AI-reviewed-unverified.
### S6. Michael A. Eggleton and Harold L. Schramm Jr. (2004)
**Feeding Ecology and Energetic Relationships with Habitat of Blue Catfish, Ictalurus furcatus, and Flathead Catfish, Pylodictis olivaris, in the Lower Mississippi River, U.S.A.**. Environmental Biology of Fishes 70(2):107-121. DOI: 10.1023/B:EBFI.0000029341.45030.94.
https://pubs.usgs.gov/publication/70026651
Scope: Lower Mississippi River. Access: agency-bibliographic-record-and-abstract. Verification: AI-reviewed-unverified.
### S7. D. L. Garrett and C. F. Rabeni (2011)
**Intra-annual Movement and Migration of Flathead Catfish and Blue Catfish in the Lower Missouri River and Tributaries**. American Fisheries Society Symposium 77:495-510.
https://units.fisheries.org/sdafscatfishcommittee/wp-content/uploads/sites/22/2019/07/Garrett-and-Rabeni-2011-Intra-annual-movement-and-migration-of-flathead-catfish-and-blue-catfish-in-the-lower-Missouri-River-and-tribuatrie.pdf
Scope: Lower Missouri River and tributaries. Access: proceedings-pdf-full-text. Verification: AI-reviewed-unverified.
### S8. Joseph D. Schmitt, Eric M. Hallerman, Aaron Bunch, Zachary Moran, Jason A. Emmel, and Donald J. Orth (2017)
**Predation and Prey Selectivity by Nonnative Catfish on Migrating Alosines in an Atlantic Slope Estuary**. Marine and Coastal Fisheries 9:108-125. DOI: 10.1080/19425120.2016.1271844.
https://doi.org/10.1080/19425120.2016.1271844
Scope: James River, Virginia. Access: publisher-full-text. Verification: AI-reviewed-unverified.
### S9. Robert S. Greenlee and Christopher N. Lim (2011)
**Searching for Equilibrium: Population Parameters and Variable Recruitment in Introduced Blue Catfish Populations in Four Virginia Tidal River Systems**. American Fisheries Society Symposium 77:349-367.
https://fisheries.org/docs/books/54077C/16.pdf
Scope: Four Virginia tidal river systems. Access: proceedings-record. Verification: AI-reviewed-unverified.
### S10. Maryland Department of Natural Resources (n.d.)
**Blue Catfish**. Maryland Department of Natural Resources.
https://dnr.maryland.gov/fisheries/Pages/blue-catfish/bcat_fishing.aspx
Scope: Maryland Chesapeake Bay tributaries. Access: agency-web-page. Verification: AI-reviewed-unverified.
### S11. Corbin D. Hilling, Aaron J. Bunch, Donald J. Orth, and Yan Jiao (2018)
**Natural Mortality and Size Structure of Introduced Blue Catfish in Virginia Tidal Rivers**. Journal of the Southeastern Association of Fish and Wildlife Agencies 5:30-38.
https://seafwa.org/journal/2018/natural-mortality-and-size-structure-introduced-blue-catfish-virginia-tidal-rivers
Scope: Virginia tidal rivers. Access: publisher-full-text. Verification: AI-reviewed-unverified.
