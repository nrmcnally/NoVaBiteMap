# BiteMap NOVA Fisheries-Science Evidence Review

## Species 1 of 37 - Largemouth bass

| Field | Value |
|---|---|
| Priority | 1 |
| BiteMap status | current |
| BiteMap speciesId | `largemouth-bass` |
| Supplied scientific name | *Micropterus salmoides* |
| Accepted scientific name | *Micropterus nigricans* |
| Research status | PARTIAL |

Machine-readable JSON supplied separately in the research archive.

## Taxonomy check

The currently accepted name for Largemouth Bass is **_Micropterus nigricans_ (Cuvier, 1828)**. Eschmeyer's Catalog lists the name as valid and records **_Huro nigricans_** as the original combination. The 2022 phylogenomic revision retained **_Micropterus salmoides_** for Florida Bass and restored **_M. nigricans_** for Largemouth Bass. [S1](https://www.nature.com/articles/s41598-022-11743-2) [S2](https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatget.asp?spid=19779)

Relevant aliases and historical usages:

- *Huro nigricans* Cuvier, 1828 - original combination.
- *Micropterus salmoides* - historically and widely applied to Largemouth Bass; now accepted for Florida Bass.
- *Micropterus salmoides salmoides* - former subspecies usage for northern Largemouth Bass.
- *Micropterus floridanus* is a junior synonym of Florida Bass *M. salmoides* and is **not** an alias for the Northern Virginia target species.

### Northern Virginia applicability warning

The 2022 genomic study documented admixed *M. nigricans* and *M. salmoides* individuals in rivers draining Chesapeake Bay in eastern Virginia where both species had been introduced. Older studies labeled *M. salmoides* must therefore be screened by geography and population history. Results from Florida, Atlantic Coastal Plain Florida Bass populations, stocked trophy systems, or known hybrid populations should not automatically be transferred to Northern Virginia. Continue using the stable BiteMap ID `largemouth-bass`.

## 1. Executive conclusion

### Strongest supported predictors

- **Sustained recent fishing pressure can reduce per-fish hook-and-line catchability through learned lure avoidance.** Model use: **score**. Evidence: E9.
- **Progressive cold-season cooling reduces movement and swimming performance, although no universal feeding shutoff is supported.** Model use: **score**. Evidence: E2.
- **Prolonged water near 95 F produced very low feed intake and thermal stress in captive northern largemouth bass.** Model use: **score**. Evidence: E4.
- **Winter habitat below approximately 2 mg/L dissolved oxygen is avoided and induces behavioral responses.** Model use: **score**. Evidence: E5.
- **Nest-guarding males can be highly vulnerable to angling because of brood defense, not feeding.** Model use: **score**. Evidence: E8.

### Context only

- Dawn and seasonal acceleration patterns reflect movement rather than demonstrated feeding or catchability. Model use: **context-only**. Evidence: E6.
- Flow, turbidity, salinity, tidal migration, habitat cover, and regional reproductive timing can alter location or presentation but lack portable catchability functions. Model use: **context-only**. Evidence: E1, E10, E11, E12, E13.
- Acute prey-capture kinematics at 25 C are mechanistic context, not a bite optimum. Model use: **context-only**. Evidence: E3.

### Unsupported popular claims - zero weight

- barometric pressure
- pressure trend
- generic storm-front rules
- wind as a direct biological multiplier
- ordinary rain as a direct biological multiplier
- cloud cover as an independent multiplier
- moon phase or solunar tables
- generic stained-water bonus
- fixed tide-stage bonus

### Most important evidence gaps

- Direct Mid-Atlantic hook-and-line catchability across temperature and oxygen
- Adult feeding or catchability responses to measured turbidity
- Potomac-specific tide and current-speed effects
- Northern Virginia population genetics
- Controlled weather-variable studies after aquatic mediators are accounted for

## 2. Evidence ledger

| Evidence ID | Variable | Exact condition or range | Observed effect | What was measured | Population/location | Life stage | Evidence type | Applicability to Northern Virginia | Confidence | Model use | Source ID and locator | Limitations |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E1 | Regional habitat, diel feeding context, and reproduction | Virginia; spawning typically March-May; low-light periods described as especially active feeding periods | Agency account describes use of slow or calm water and submerged cover, feeding throughout the day with stronger low-light feeding, and spring nesting with male brood guarding. | expert/agency synthesis | Virginia | Mixed; reproduction concerns adults | government species account | Direct regional relevance | medium | context-only | [S3](https://dwr.virginia.gov/wildlife/information/largemouth-bass/); Habitat; Diet; Reproduction | Agency synthesis does not quantify catchability, underwater light, spawning temperature, or waterbody-specific timing. |
| E2 | Water temperature | Laboratory acclimation at 25.0, 14.0, and 7.5-8.5 C; seasonal field observations | Critical swimming speed was 2.17, 1.69, and 1.17 body lengths per second at the three acclimation temperatures. Early-winter field activity metrics were 63.3%-75.6% below summer values. | movement/activity | Warner Lake and Lake Opinicon, Ontario | Adult | peer-reviewed primary study | Strong taxonomic relevance but colder climate than Northern Virginia | high | score | [S4](https://calebthasler.wordpress.com/wp-content/uploads/2014/06/9cjz-hasler-et-al-2009.pdf); p. 589 and 593; Abstract; Results - Direct laboratory and field comparisons; Swim-tunnel experiments; Table 1; Figure 2 | Movement and swimming performance are not feeding or hook-and-line catchability. The paper uses 7.5 C in the abstract but 8.5 C for the early-spring swim-tunnel group in the results. |
| E3 | Acute temperature change | Five fish acclimated to 22 C and acutely tested at 15, 20, 25, and 30 C | Mean fastest times to peak gape were 23.3, 22.4, 18.2, and 22.0 ms, respectively; the fastest mouth-opening kinematics occurred at 25 C. | feeding rate | Laboratory population; lineage not genetically verified | 157-190 mm fish | peer-reviewed primary study | Mechanistically relevant but weak as a field forecast threshold | medium | context-only | [S5](https://fishlab.ucdavis.edu/wp-content/uploads/sites/397/2020/05/Devries-Wainwright-2006.pdf); p. 437 and 440; Abstract; Results; Table 2; Figure 1 | Only five fish; acute exposure; mouth-opening speed is not appetite, prey consumption, or angling catchability. It cannot establish a 77 F bite optimum. |
| E4 | Extreme high temperature | 35 C (95 F) for 28 days | All size groups consumed less than 0.21% of body weight per day and showed little biologically meaningful growth; authors interpreted prolonged exposure as thermal stress. | feeding rate | Captive northern largemouth bass in recirculating tanks | 80 g, 105 g, and 137 g size classes | peer-reviewed primary study | Lineage relevant, but aquaculture conditions and commercial feed differ from wild fish | medium | score | [S6](https://www.sciencedirect.com/science/article/pii/S2352513421002611); Abstract | Only the abstract was accessible. The study does not establish when feeding first declines, a field catchability threshold, or a cooler control within the reviewed text. |
| E5 | Dissolved oxygen | Winter habitat below approximately 2.0 mg/L; juvenile laboratory exposures at 1.99 and 1.42 mg/L at 5 C | Telemetered adults avoided water below about 2.0 mg/L. Juveniles began yawning and vertical movement at 1.99 mg/L, with stronger responses at 1.42 mg/L. | habitat selection | Warner Lake, Ontario, plus laboratory experiments | Adults in field; juveniles in laboratory | peer-reviewed primary study | Strong for winter avoidance; warm-season transfer is uncertain | high | score | [S7](https://fishlab.nres.illinois.edu/wp-content/uploads/2025/05/Hasler_et_al_PBZ_2009.pdf); p. 143, 148-150; Abstract; Laboratory Study; Discussion; Conclusion; Figures 4 and 5 | Not a universal feeding-cessation threshold. Fish sometimes used intermediate oxygen and briefly entered lower-oxygen water; temperature and other habitat variables interacted. |
| E6 | Season and diel period | Toronto Harbour year-round; dawn, day, dusk, and night | Mean acceleration was lower in winter (0.172 m/s2) and fall (0.277 m/s2) than spring (0.572 m/s2) and summer (0.642 m/s2). Dawn acceleration was 0.521 m/s2 and night was 0.278 m/s2. | movement/activity | Toronto Harbour, Lake Ontario | Adult | peer-reviewed primary study | Taxonomically relevant but colder, urban Great Lakes setting | high | context-only | [S8](https://link.springer.com/article/10.1186/s40317-026-00444-6); Results - Largemouth bass; Discussion; Table 1; Figures 3 and 4 | Acceleration averaged over 20-minute intervals primarily reflects sustained movement or transit and may miss short feeding bursts. It is not angling catchability. |
| E7 | Moon phase | Six complete lunar cycles across winter, spring, and summer | Lunar phase related to depth or movement in some cycles, but patterns were inconsistent across the year and not repeatable. Authors concluded solunar tables may have little predictive value for peak fishing time. | movement/activity | Warner Lake, Ontario | Adult | peer-reviewed primary study | Moderate biological applicability; no direct angling test | medium | zero-weight | [S9](https://calebthasler.wordpress.com/wp-content/uploads/2014/06/6fme-hanson-et-al-2008.pdf); p. 357-358; Abstract; Introduction | No hook-and-line catchability outcome. Moon phase is an incomplete proxy for actual underwater illumination and can be confounded with season. |
| E8 | Reproductive phase - nest guarding | Nesting males guarding newly spawned eggs; six-cast experimental angling trials | 54% of nesting male largemouth bass were hooked; vulnerability was associated with brood size and aggressive brood defense. | angling catchability | Seven southeastern Ontario lakes | Adult nesting males | peer-reviewed primary study | Strong mechanism; Virginia timing must be determined regionally | high | score | [S10](https://academic.oup.com/tafs/article-abstract/133/5/1100/7887981); p. 1100; Abstract | Only the abstract was accessible. The response is territorial aggression and nest defense, not increased feeding; it does not apply to females or all spawning fish. |
| E9 | Recent fishing pressure | Two May-October fishing seasons in six small impoundments, including a two-month closure | Catch rate and catchability declined with sustained effort, increased after the closure, and then declined again; results supported learned angler avoidance. | angling catchability | Six small southeastern U.S. impoundments | Catchable juveniles and adults | peer-reviewed primary study | Strong qualitative applicability to pressured ponds and reservoirs | high | score | [S11](https://pubs.usgs.gov/publication/70193170); p. 66-76; Abstract | Only the abstract was accessible. Magnitude depends on effort, lures, prior capture, population structure, and waterbody openness. |
| E10 | River discharge | Lower Neuse River; discharge below versus above 85 m3/s, with a steep CPUE change between 60 and 100 m3/s | Boat-electrofishing CPUE was usually lower above 85 m3/s and frequently higher below it. | expert/agency synthesis | Lower Neuse River tributaries, North Carolina | Mixed sizes | government technical report | Qualitative coastal-river context only; numerical threshold is not portable | medium | context-only | [S12](https://seafwa.org/sites/default/files/journal-articles/31%252520Homan%252520_%252520Barwick%252520184-189.pdf); p. 184 and 186; Abstract; Results; Table 1; Figure 2 | Electrofishing CPUE confounds abundance, fish relocation, conductivity, visibility, inundated habitat, boat access, and gear efficiency. It is not hook-and-line catchability. |
| E11 | Turbidity and visibility | 50 NTU | Maryland DNR's synthesis reports that foraging by age-1 largemouth bass was reduced by at least 33% at 50 NTU. | feeding rate | Primary experiment synthesized in a Chesapeake tidal-bass plan | Age 1 | government technical report | Relevant to regional juveniles; uncertain for adult lure capture | medium | context-only | [S13](https://dnrweb.dnr.state.md.us/fisheries/calendar/events/628/Draft_Tidal_Bass_Fishery_Management_Plan_08232013.pdf); p. 13; Population structure and dynamics - juvenile growth and foraging | Secondary reporting of the primary experiment. Does not establish an adult optimum, a beneficial moderate-turbidity band, or hook-and-line catchability. |
| E12 | Salinity and submerged cover | High salinity above 5 ppt or absence of submerged cover following displacement | Maryland DNR's synthesis reports movement away from release areas; freshwater and brackish-adapted adults differ in salinity tolerance and condition. | habitat selection | Chesapeake and other tidal populations synthesized by Maryland DNR | Adult | government technical report | Relevant to lower tidal Potomac and Chesapeake tributaries | medium | context-only | [S13](https://dnrweb.dnr.state.md.us/fisheries/calendar/events/628/Draft_Tidal_Bass_Fishery_Management_Plan_08232013.pdf); p. 11; 3.4 Species Movement and Home Range | This is not a universal salinity maximum, feeding threshold, or direct catchability effect. Local acclimation and genetics matter. |
| E13 | Tidal movement and seasonal migration | 38 radio-tagged adults; four migratory fish crossed the upper Chesapeake Bay during spring | The four migrants had a mean home range of 2,140 ha and returned to the Northeast River area two to three months later; migration was suspected to be spawning-related. | movement/activity | Tidal upper Chesapeake Bay, Maryland | Adult | government technical report | High regional relevance to tidal Chesapeake tributaries | medium | context-only | [S14](https://seafwa.org/sites/default/files/journal-articles/Heft-17-25.pdf); p. 17 and 21; Abstract; Results; Discussion; Table 1 | Only four fish showed this migration. No ebb/flood comparison, current-speed effect, feeding rate, or hook-and-line catchability was measured. |

## 3. Variable-by-variable synthesis

### A. Water temperature

Cold-season evidence supports a gradual reduction in movement and locomotor capacity rather than a universal shutdown. Adult bass in Ontario had lower field activity at cooler temperatures, and swim-tunnel performance declined across acclimation treatments. This is safe for a continuous, acclimation-aware temperature effect, but not for a hard feeding threshold. Evidence E2. Model use: **score**.

The acute prey-capture experiment found the fastest mouth-opening event at 25 C (77 F), but it measured kinematics in five fish, not appetite, prey consumption, or angling. It must not become a 77 F optimum-bite rule. Evidence E3. Model use: **context-only**.

At 35 C (95 F) for 28 days, captive northern largemouth bass consumed less than 0.21% body weight per day and showed little biologically meaningful growth. This supports an extreme-heat penalty, but not the onset temperature for feeding decline. Evidence E4. Model use: **score**.

No defensible active-feeding minimum, optimum range, decline point, cessation point, or lethal limit was found for a Northern Virginia forecast. Those JSON fields remain null.

### B. Dissolved oxygen

Winter adults avoided habitat below approximately 2.0 mg/L, and winter-acclimated juveniles began yawning and vertical movement at 1.99 mg/L. This can support a winter habitat-availability penalty. It is not a universal feeding-cessation value, and warm-season oxygen demand may differ. Evidence E5. Model use: **score**.

### C. Time and underwater light

Virginia DWR describes stronger feeding during low-light periods, while Toronto Harbour telemetry found higher acceleration at dawn and lower acceleration at night. The telemetry authors cautioned that sustained acceleration may reflect transit rather than short feeding bursts. A biological crepuscular classification is reasonable, but a universal dawn/dusk score multiplier is not. Evidence E1 and E6. Model use: **context-only**.

Moon-phase associations were inconsistent and did not demonstrate angling catchability. Evidence E7. Model use: **zero-weight**.

### D. Reproductive phase

Virginia DWR places spawning primarily from March through May. Direct experimental angling evidence shows elevated vulnerability of nest-guarding males. The mechanism is brood defense and territorial aggression, never increased feeding. Apply only when an actively guarded nest is plausible, not as a general spring bonus or to females. Evidence E1 and E8. Nesting model use: **score**; other reproductive phases: **context-only or unavailable**.

### E. Flow and water level

The lower Neuse River study found a steep change in boat-electrofishing CPUE near 85 m3/s, but this was a sampling and relative-abundance study. Fish relocation, flooded habitat, conductivity, visibility, boat access, and electrofishing efficiency were confounded. Never transfer 85 m3/s to the Potomac, Shenandoah, Rappahannock, or Occoquan. Evidence E10. Model use: **context-only**.

### F. Turbidity and visibility

Maryland DNR reported at least a 33% reduction in age-1 foraging at 50 NTU. This supports displaying severe turbidity as juvenile-foraging context. It does not establish an adult optimum, a beneficial stained-water band, or hook-and-line capture effect. Evidence E11. Model use: **context-only**.

### G. Tidal, current, and salinity effects

Some upper Chesapeake adults made large spring movements and occupied much larger tidal home ranges than typical lake populations. Maryland DNR also reports movement away from release areas when salinity exceeds about 5 ppt for freshwater-adapted fish or submerged cover is absent. Neither finding supports an ebb, flood, high-tide, low-tide, or slack-water multiplier. Evidence E12 and E13. Model use: **context-only**.

### H. Weather variables

No qualifying species-specific evidence isolated a direct catchability effect for barometric pressure, pressure trend, wind, ordinary rain, cloud cover, or storm fronts after aquatic mediators were controlled. These variables should receive **zero weight**. Rain and storms may still matter indirectly through measured water temperature, flow, turbidity, oxygen, salinity, or current.

### I. Seasonality

The monthly classifications below are categorical context, not decimal scores. Temperature, photoperiod, and spawning are not added as independent bonuses when they describe the same mechanism.

| Month | Level | Mechanisms | Evidence | Model use |
|---:|---|---|---|---|
| 1 | low | cold-reduced movement and swimming capacity; winter oxygen refuge or habitat exclusion may matter | E2, E5, E6 | context-only |
| 2 | low | cold-reduced movement; short warming events can create waterbody-specific variability | E2, E5, E6 | context-only |
| 3 | variable | rapid seasonal warming; pre-spawn shoreline movement may begin; early spawning is possible in warmer waters | E1, E2 | context-only |
| 4 | variable | pre-spawn and spawning movement; nest construction and male territorial behavior | E1, E8 | context-only |
| 5 | variable | spawning and brood defense; post-spawn transition; seasonal movement is generally elevated | E1, E6, E8 | context-only |
| 6 | variable | post-spawn recovery; high seasonal movement; developing vegetation and thermal structure | E1, E6 | context-only |
| 7 | variable | high temperature can increase physiological demand; diel and oxygen-mediated habitat use may shift | E4, E5, E6 | context-only |
| 8 | variable | possible heat and oxygen constraints; accumulated fishing-pressure effects | E4, E5, E9 | context-only |
| 9 | variable | cooling water and changing prey distribution; fishing-pressure effects may persist | E2, E9 | context-only |
| 10 | variable | seasonal cooling; continued but declining movement | E2, E6 | context-only |
| 11 | low | cold-reduced swimming and movement; transition toward winter habitat | E2, E6 | context-only |
| 12 | low | winter movement reduction; oxygen and depth refuge selection may matter | E2, E5, E6 | context-only |

### J. Habitat and presentation

Largemouth bass use calm or slow water, submerged vegetation, logs, rootwads, and other structure. Those features can change fish location and presentation efficiency but do not automatically increase feeding motivation. Tidal movement, salinity, flow, oxygen, and temperature can shift the likely depth or habitat. Model use: **context-only** unless a waterbody-specific catchability relationship is later validated.

## 4. Conflict and uncertainty report

- The accepted scientific name changed, but most older literature uses *Micropterus salmoides*. Geography and lineage must be checked before transfer.
- Chesapeake-drainage admixture creates uncertainty for some eastern Virginia populations.
- The temperature-performance paper uses 7.5 C in its abstract and 8.5 C for the early-spring swim-tunnel group in the results.
- Movement, acceleration, habitat use, and electrofishing CPUE are not equivalent to feeding or hook-and-line catchability.
- The 25 C prey-capture result is a kinematic optimum in a five-fish acute experiment, not an activity or bite optimum.
- The approximately 2 mg/L dissolved-oxygen response is winter-specific and should not be generalized to all temperatures.
- The 50 NTU result concerns age-1 foraging and cannot be applied directly to adult angling.
- The Neuse River 85 m3/s value is system-specific and strongly confounded.
- Tidal migration evidence does not identify a preferred tide stage or current speed.
- Barometer, fronts, wind, rain, cloud, and moon claims remain unsupported for direct scoring.

## 5. Candidate model rules

| Input | Condition | Direction | Strength | Confidence | Model use | Mechanism | Evidence | Double-counting risk |
|---|---|---|---|---|---|---|---|---|
| recentFishingPressure | Sustained recent hook-and-line effort at the same waterbody or area | decrease | strong | high | score | Learned lure avoidance reduces per-fish catchability. | E9 | Do not substitute month, fish abundance, or general waterbody popularity for measured recent effort. |
| waterTemperature | Progressive cooling relative to recent acclimation | decrease | moderate | medium | score | Cold water reduces locomotor performance and voluntary movement without proving complete feeding cessation. | E2 | Do not add a separate winter penalty if temperature already represents the seasonal mechanism. |
| waterTemperature | Prolonged water near 95 F (35 C) | decrease | strong | medium | score | Chronic extreme heat was associated with very low feed intake and thermal stress. | E4 | Avoid separately stacking summer, thermal stress, and low-oxygen penalties without distinct measurements. |
| dissolvedOxygen | Below approximately 2.0 mg/L in winter habitat | decrease | strong | high | score | Bass avoid severe winter hypoxia and exhibit behavioral responses near this concentration. | E5 | Apply to habitat availability or refuge selection, not as proof that all fish in the waterbody stop feeding. |
| timeOfDay | Dawn or twilight | context-only | moderate | medium | context-only | Acceleration can peak around crepuscular periods, but the study measured movement rather than feeding or catchability. | E1, E6 | Do not stack dawn, cloud, moon, and visibility bonuses without measured underwater light. |
| reproductivePhase | Male actively guarding eggs or fry | increase | moderate | high | score | Territorial aggression and brood defense increase vulnerability near the nest. | E1, E8 | Do not label this feeding, apply it to females, or stack it with a generic spring bonus. |
| turbidity | Approximately 50 NTU | context-only | moderate | low | context-only | Age-1 foraging was reduced in the agency-summarized evidence. | E11 | Do not transfer a juvenile feeding response directly to adult hook-and-line catchability. |
| riverDischarge | High enough to expand inundated habitat or reduce shoreline sampling efficiency | context-only | moderate | low | context-only | Fish location, accessible habitat, and capture efficiency can change with discharge. | E10 | Never transfer the Neuse River 85 m3/s value to Virginia waters. |
| salinity | Above approximately 5 ppt for freshwater-adapted fish | context-only | moderate | low | context-only | Freshwater-adapted adults may move from unsuitable saline habitat. | E12 | Local brackish adaptation varies; this is not a lethal or feeding threshold. |
| moonPhase | Any nominal solunar phase | neutral | weak | medium | zero-weight | Observed depth and movement associations were not repeatable and angling catchability was not measured. | E7 | Moon phase is an inadequate proxy for actual underwater light and overlaps with season and tides. |
| tidalStage | Ebb, flood, high, low, or slack tide | context-only | unknown | low | context-only | Regional fish can migrate and use large tidal home ranges, but stage-specific catchability was not measured. | E13 | Do not use tide stage without waterbody-specific current, depth, cover access, and salinity data. |

## 6. Sources

- **S1 - Phylogenomics and species delimitation of the economically important Black Basses (Micropterus)**. Daemin Kim, Andrew T. Taylor, and Thomas J. Near (2022). Scientific Reports 12:9113. DOI: 10.1038/s41598-022-11743-2. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Range-wide North American Micropterus sampling, including eastern Virginia Chesapeake drainages. [Source link](https://www.nature.com/articles/s41598-022-11743-2)
- **S2 - Eschmeyer's Catalog of Fishes: Huro nigricans / Micropterus nigricans record**. California Academy of Sciences (2026). Eschmeyer's Catalog of Fishes, online version updated 7 July 2026. Type: taxonomic catalog. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Global taxonomic catalog; target record concerns eastern North America. [Source link](https://researcharchive.calacademy.org/research/ichthyology/catalog/fishcatget.asp?spid=19779)
- **S3 - Largemouth Bass**. Virginia Department of Wildlife Resources (2024). Virginia DWR Species Profile Database. Type: government species account. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Virginia. [Source link](https://dwr.virginia.gov/wildlife/information/largemouth-bass/)
- **S4 - Effect of water temperature on laboratory swimming performance and natural activity levels of adult largemouth bass**. Caleb T. Hasler, Cory D. Suski, Kyle C. Hanson, Steven J. Cooke, David P. Philipp, and Bruce L. Tufts (2009). Canadian Journal of Zoology 87:589-596. DOI: 10.1139/Z09-044. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Warner Lake and Lake Opinicon, Ontario, Canada. [Source link](https://calebthasler.wordpress.com/wp-content/uploads/2014/06/9cjz-hasler-et-al-2009.pdf)
- **S5 - The Effects of Acute Temperature Change on Prey Capture Kinematics in Largemouth Bass, Micropterus salmoides**. Maya S. DeVries and Peter C. Wainwright (2006). Copeia 2006(3):437-444. DOI: 10.1643/0045-8511(2006)2006[437:TEOATC]2.0.CO;2. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Laboratory population; lineage not genetically verified. [Source link](https://fishlab.ucdavis.edu/wp-content/uploads/sites/397/2020/05/Devries-Wainwright-2006.pdf)
- **S6 - Growth parameters in northern largemouth bass Micropterus salmoides salmoides raised near their upper thermal tolerance for 28 days**. Leticia E. Fantini, Matthew A. Smith, Michele Jones, Luke A. Roy, Rebecca Lochmann, and Anita M. Kelly (2021). Aquaculture Reports 21:100845. DOI: 10.1016/j.aqrep.2021.100845. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Captive northern-lineage largemouth bass. [Source link](https://www.sciencedirect.com/science/article/pii/S2352513421002611)
- **S7 - The Influence of Dissolved Oxygen on Winter Habitat Selection by Largemouth Bass: An Integration of Field Biotelemetry Studies and Laboratory Experiments**. Caleb T. Hasler, Cory D. Suski, Kyle C. Hanson, Steven J. Cooke, and Bruce L. Tufts (2009). Physiological and Biochemical Zoology 82(2):143-152. DOI: 10.1086/591806. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Warner Lake, Ontario, and winter-temperature laboratory experiments. [Source link](https://fishlab.nres.illinois.edu/wp-content/uploads/2025/05/Hasler_et_al_PBZ_2009.pdf)
- **S8 - Seasonal effects on the acceleration of largemouth bass and Northern Pike in Toronto harbour**. Benjamin L. Hlina et al. (2026). Animal Biotelemetry 14:5. DOI: 10.1186/s40317-026-00444-6. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Toronto Harbour, Lake Ontario. [Source link](https://link.springer.com/article/10.1186/s40317-026-00444-6)
- **S9 - Effects of lunar cycles on the activity patterns and depth use of a temperate sport fish, the largemouth bass, Micropterus salmoides**. Kyle C. Hanson, S. Arrosa, Caleb T. Hasler, Cory D. Suski, David P. Philipp, G. Niezgoda, and Steven J. Cooke (2008). Fisheries Management and Ecology 15:357-364. DOI: 10.1111/j.1365-2400.2008.00634.x. Type: peer-reviewed primary study. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Warner Lake, Ontario, Canada. [Source link](https://calebthasler.wordpress.com/wp-content/uploads/2014/06/6fme-hanson-et-al-2008.pdf)
- **S10 - Factors Affecting the Vulnerability to Angling of Nesting Male Largemouth and Smallmouth Bass**. Cory D. Suski and David P. Philipp (2004). Transactions of the American Fisheries Society 133:1100-1106. DOI: 10.1577/T03-079.1. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Seven southeastern Ontario lakes. [Source link](https://academic.oup.com/tafs/article-abstract/133/5/1100/7887981)
- **S11 - Effect of fishing effort on catch rate and catchability of largemouth bass in small impoundments**. M. G. Wegener, Harold Schramm, J. W. Neal, and P. D. Gerard (2018). Fisheries Management and Ecology 25(1):66-76. DOI: 10.1111/fme.12268. Type: peer-reviewed primary study. Access: abstract-only. Verification: AI-reviewed-unverified. Geographic scope: Six small southeastern United States impoundments. [Source link](https://pubs.usgs.gov/publication/70193170)
- **S12 - Relationship between Discharge and Electrofishing Catch-per-unit-effort of Largemouth Bass in the Neuse River, North Carolina**. Justin M. Homan and Robert D. Barwick, North Carolina Wildlife Resources Commission (2010). Proceedings of the Annual Conference of the Southeastern Association of Fish and Wildlife Agencies 64:184-189. Type: government technical report. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Lower Neuse River tributaries, North Carolina. [Source link](https://seafwa.org/sites/default/files/journal-articles/31%252520Homan%252520_%252520Barwick%252520184-189.pdf)
- **S13 - Draft Tidal Bass Fishery Management Plan**. Maryland Department of Natural Resources (2013). Maryland DNR. Type: government technical report. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Maryland Chesapeake Bay tributaries and tidal Potomac context. [Source link](https://dnrweb.dnr.state.md.us/fisheries/calendar/events/628/Draft_Tidal_Bass_Fishery_Management_Plan_08232013.pdf)
- **S14 - Home Range of Largemouth Bass in the Tidal Upper Chesapeake Bay**. Alan A. Heft and Carol A. Richardson-Heft, Maryland Department of Natural Resources (2002). Proceedings of the Annual Conference of the Southeastern Association of Fish and Wildlife Agencies 56:17-25. Type: government technical report. Access: full-text. Verification: AI-reviewed-unverified. Geographic scope: Tidal upper Chesapeake Bay, Maryland. [Source link](https://seafwa.org/sites/default/files/journal-articles/Heft-17-25.pdf)

## 7. Final verdict

**RESEARCH STATUS: PARTIAL**

### SAFE TO IMPLEMENT
- Use Micropterus nigricans as the accepted name while retaining speciesId largemouth-bass and the supplied name as a search alias. Model use: **unavailable**. Evidence: None.
- Recent measured fishing pressure decreases catchability. Model use: **score**. Evidence: E9.
- Use an acclimation-aware cold-temperature reduction rather than a hard feeding shutoff. Model use: **score**. Evidence: E2.
- Treat prolonged water near 95 F as a strong heat-stress and low-feeding condition. Model use: **score**. Evidence: E4.
- Treat winter habitat below about 2 mg/L dissolved oxygen as strongly avoided or unavailable. Model use: **score**. Evidence: E5.
- Allow a nest-defense vulnerability modifier only for actively guarding males and label the mechanism correctly. Model use: **score**. Evidence: E8.

### CONTEXT ONLY
- Dawn and twilight movement patterns Evidence: E1, E6.
- Pre-spawn and seasonal movement Evidence: E1, E6, E13.
- Turbidity, salinity, flow, tide, habitat cover, and current Evidence: E10, E11, E12, E13.
- Acute prey-capture kinematics at 25 C Evidence: E3.

### DO NOT IMPLEMENT
- Universal best-bite or feeding-cessation temperatures Evidence: E2, E3, E4.
- Barometer, fronts, cloud, rain, wind, or moon-phase multipliers Evidence: E7.
- Transfer of the Neuse River discharge threshold to Virginia Evidence: E10.
- Generic stained-water, rising-water, falling-water, or fixed-tide bonuses Evidence: E10, E11, E13.
- Treating movement, growth, electrofishing CPUE, habitat occupancy, or nest defense as feeding Evidence: E2, E4, E6, E8, E10, E13.

### MISSING
- Northern Virginia catchability experiments
- Defensible adult feeding-temperature limits
- Warm-season oxygen thresholds
- Adult turbidity thresholds
- Potomac current and tide response
- Direct weather-variable evidence
- Regional genetic surveys

Machine-readable JSON supplied separately in the research archive.
