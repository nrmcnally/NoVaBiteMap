# BiteMap NOVA research resume packet

- Completed species before this batch: largemouth-bass, smallmouth-bass, channel-catfish, black-crappie, white-crappie, bluegill.
- Completed in Batch 2: redbreast-sunfish, pumpkinseed, green-sunfish, rock-bass.
- Pending species: rainbow-trout, brown-trout, brook-trout, blue-catfish, flathead-catfish, white-catfish, striped-bass, white-perch, yellow-perch, walleye, muskellunge, northern-snakehead, spotted-bass, common-carp, american-eel, fallfish, creek-chub, white-sucker, yellow-bullhead, brown-bullhead, northern-hogsucker, shorthead-redhorse, blacknose-dace, longnose-dace, mottled-sculpin, tessellated-darter, gizzard-shad.
- Next recommended batch: Batch 3 - rainbow trout, brown trout, and brook trout.
- Schema version: 1.1.
- Verification status: AI-reviewed-unverified.
- Known correction: the channel-catfish structural reference source S13 must list Kenneth O. Allen and James W. Avault Jr.
- Batch 2 outcome: redbreast sunfish and pumpkinseed have narrow parental-care feeding-suppression candidates; rock bass is proposed for scoring but currently context-only; green sunfish is Fish Guide only pending direct catchability evidence.
- Unresolved questions: see validation-report.json and correction-and-conflict-log.json.
- Files a new chat should receive: BiteMap_complete_37_species_research_archive(2).zip; BiteMap_channel-catfish_deep_verified_research_archive(2).zip; BiteMap_batch-1_deep_verified_research_archive.zip; BiteMap_batch-2_deep_verified_research_archive.zip; master prompt with ACTIVE BATCH changed to BATCH 3.
