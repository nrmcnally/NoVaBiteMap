# Rock Bass
*Ambloplites rupestris*

- Species ID: `rock-bass`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Proposed for bite scoring**

## Executive conclusion
Rock bass are a practical Mid-Atlantic target and have direct predation and angling experiments, but depth/cover effects were prey-specific and gear effects belong in the Fish Guide. Current environmental variables remain context-only pending field catchability validation.

### Model-ready findings
- No current score candidate survived adversarial review.

### Context-only findings
- In experimental channels, deeper water increased predation on several stream-fish prey but not pumpkinseed prey. Evidence: E2, E3.
- Hook type altered capture efficiency and injury; this is gear guidance rather than a weather score. Evidence: E4.
- New River catches and Pennsylvania management confirm intentional regional targetability. Evidence: E9, E10.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- wind or ordinary rainfall as an independent direct multiplier
- cloud cover without measured underwater light
- moon phase or solunar tables
- growth optimum used as bite optimum
- movement used as feeding
- habitat occupancy used as catchability
- spawning aggregation or nest defense labeled as feeding
- monthly curves derived from seasons, regulations, or folklore

## Contradictions and limitations
- Depth effects were prey-specific and came from artificial channels with only two depth levels.
- Spawning aggregation and nest defense do not demonstrate feeding; comparative attack probability was not especially strong.
- Retinal anatomy cannot validate a cloud, moon, or low-light bite multiplier.

## Targetability assessment
Rock bass are a practical Mid-Atlantic target and have direct predation and angling experiments, but depth/cover effects were prey-specific and gear effects belong in the Fish Guide. Current environmental variables remain context-only pending field catchability validation.

## Candidate model rules
### R1. depth - context-only
- Condition: Deep 35-38 cm versus shallow 7-10 cm in experimental channels
- Direction: prey-specific increase
- Strength: weak
- Confidence: medium
- Mechanism: Adult rock bass consumed more of several stream-fish prey in the deeper treatment.
- Evidence: E2
- Double-counting risk: Only two artificial depths and selected prey; no smooth curve or angling endpoint.
### R2. cover - context-only
- Condition: Cover present versus absent
- Direction: prey-specific/variable
- Strength: unknown
- Confidence: medium
- Mechanism: Cover and depth effects depended on prey species.
- Evidence: E3
- Double-counting risk: Do not add generic cover and depth bonuses from the same experiment.
### R3. preyCommunity - context-only
- Condition: Stream fishes versus pumpkinseed prey
- Direction: different predation response
- Strength: moderate
- Confidence: medium
- Mechanism: The depth effect did not generalize to pumpkinseed prey.
- Evidence: E2, E3
- Double-counting risk: Prey identity must be explicit; no forage-blind score.
### R4. hookType - context-only
- Condition: Hook designs tested in southeastern Ontario
- Direction: capture-efficiency and injury differences
- Strength: moderate
- Confidence: medium
- Mechanism: Gear changed capture efficiency and injury.
- Evidence: E4
- Double-counting risk: Fish Guide rule only; not environmental score.
### R5. macrophyteHabitat - context-only
- Condition: Submersed vegetation in Lake St. Clair
- Direction: resource-partitioning shift
- Strength: moderate
- Confidence: medium
- Mechanism: Vegetation altered food and habitat partitioning of yearlings.
- Evidence: E11
- Double-counting risk: Yearling and Great Lakes context; occupancy is not bite.
### R6. spawningHabitat - context-only
- Condition: Shallow coarse-substrate nest areas
- Direction: occupancy increase
- Strength: moderate
- Confidence: medium
- Mechanism: Adults aggregated and males defended nest territories.
- Evidence: E7
- Double-counting risk: Do not label aggregation or defense as feeding.
### R7. nestDefense - zero-weight
- Condition: Parental male near nest
- Direction: no generic feeding bonus
- Strength: zero
- Confidence: medium
- Mechanism: Comparative attack behavior was not especially strong and measured defense, not feeding.
- Evidence: E12
- Double-counting risk: Do not double-count spawning aggression and habitat.
### R8. temperature - unavailable
- Condition: Any optimum or short-term trend
- Direction: unknown
- Strength: unknown
- Confidence: medium
- Mechanism: No direct adult feeding/catchability curve.
- Evidence: E13
- Double-counting risk: Do not substitute spawn or growth temperatures.
### R9. dissolvedOxygen - unavailable
- Condition: Any mg/L threshold
- Direction: unknown
- Strength: unknown
- Confidence: medium
- Mechanism: No direct feeding/catchability oxygen function.
- Evidence: E14
- Double-counting risk: Do not substitute tolerance or occupancy.
### R10. barometricPressureFrontsMoon - zero-weight
- Condition: Any pressure, front, wind, rain, cloud, or moon category
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: No direct species-specific evidence.
- Evidence: E15
- Double-counting risk: Retinal morphology does not validate weather or solunar rules.
### R11. movement - context-only
- Condition: Tributary movement or seasonal aggregation
- Direction: encounter context
- Strength: weak
- Confidence: medium
- Mechanism: Movement changes availability but does not establish appetite.
- Evidence: E6, E10
- Double-counting risk: Avoid using catch composition as intrinsic bite probability.

## Evidence ledger
### E1. Regional occurrence and targetability - context-only
- Exact condition/range: Virginia rivers, streams, and reservoirs.
- Observed effect: Rock bass are an established and intentionally targeted Mid-Atlantic sportfish, especially in flowing waters.
- Measured: Agency occurrence and fishing context
- Population/location: Virginia
- Life stage: Mixed
- Evidence type: government synthesis
- NOVA applicability: High regional targetability relevance
- Confidence: high
- Source: S1 (section: Species account and fishing)
- Limitations: Not a direct environmental bite function.
- Surrogate evidence: false
### E2. Depth and predation - context-only
- Exact condition/range: Experimental stream channels with shallow 7-10 cm and deep 35-38 cm treatments.
- Observed effect: Predation by adult rock bass was greater in deep treatment for fantail darters and two sizes of central stonerollers.
- Measured: Prey loss/predation after 72 hours
- Population/location: Experimental stream
- Life stage: Adult predators
- Evidence type: controlled predation experiment
- NOVA applicability: Direct feeding endpoint but highly conditional
- Confidence: medium
- Source: S2 (section: Abstract)
- Limitations: Only two depths, artificial channels, and specific prey; do not create a smooth depth curve.
- Surrogate evidence: false
### E3. Cover and prey-specific response - zero-weight
- Exact condition/range: Cover absent versus present crossed with depth.
- Observed effect: Depth and cover effects varied by prey species; pumpkinseed prey did not show the same depth response as stream fishes.
- Measured: Prey-specific predation rates
- Population/location: Experimental stream
- Life stage: Adult predators
- Evidence type: controlled predation experiment
- NOVA applicability: Shows interaction and contradiction
- Confidence: medium
- Source: S2 (section: Abstract)
- Limitations: Cannot generalize a single cover or depth bonus across prey communities.
- Surrogate evidence: false
### E4. Hook type and capture efficiency - context-only
- Exact condition/range: Rock bass angled with different hook types.
- Observed effect: Hook type affected capture efficiency and injury, supporting gear-specific Fish Guide guidance.
- Measured: Capture efficiency and hooking injury
- Population/location: Southeastern Ontario
- Life stage: Adult/subadult
- Evidence type: field angling experiment
- NOVA applicability: Direct angling endpoint, but gear rather than environment
- Confidence: medium
- Source: S3 (section: Abstract)
- Limitations: Does not support weather, temperature, or habitat scoring.
- Surrogate evidence: false
### E5. Summer diet - context-only
- Exact condition/range: Summer samples from a Big South Fork stream.
- Observed effect: Rock bass consumed aquatic insects, crayfish, and fish, with diet varying by size and availability.
- Measured: Stomach contents and growth
- Population/location: Big South Fork, Tennessee-Kentucky
- Life stage: Mixed
- Evidence type: field diet study
- NOVA applicability: Appalachian/Mid-Atlantic contextual relevance
- Confidence: medium
- Source: S4 (page: 23-28; section: Food habits; Results)
- Limitations: Seasonal diet composition is not a daily catchability function.
- Surrogate evidence: false
### E6. Movement - context-only
- Exact condition/range: Telemetry/tag observations in Lake Ontario and tributaries.
- Observed effect: Rock bass movement and tributary use varied through time and habitat.
- Measured: Movement and behavior
- Population/location: Lake Ontario and tributaries
- Life stage: Adult
- Evidence type: field movement study
- NOVA applicability: Habitat-access context only
- Confidence: medium
- Source: S5 (section: Abstract)
- Limitations: Movement is not feeding, and Great Lakes context differs from NOVA streams.
- Surrogate evidence: false
### E7. Spawning habitat and aggregation - context-only
- Exact condition/range: Lake Opinicon spawning season.
- Observed effect: Adults moved inshore, densities increased, and males established shallow nest territories on coarse substrate.
- Measured: Movement, nest density, depth, and substrate
- Population/location: Lake Opinicon, Ontario
- Life stage: Adult
- Evidence type: field reproductive study
- NOVA applicability: Location context only
- Confidence: medium
- Source: S6 (section: Abstract)
- Limitations: Aggregation and territoriality do not demonstrate increased feeding.
- Surrogate evidence: false
### E8. Visual morphology - zero-weight
- Exact condition/range: Comparative retinal structure of rock bass and bluegill.
- Observed effect: Retinal morphology was interpreted relative to feeding ecology and visual environment.
- Measured: Retinal anatomy and inferred visual function
- Population/location: Ontario/laboratory material
- Life stage: Mixed
- Evidence type: comparative morphology study
- NOVA applicability: Mechanistic context only
- Confidence: low
- Source: S7 (section: Abstract)
- Limitations: Morphology cannot be translated into a direct low-light or cloud multiplier.
- Surrogate evidence: false
### E9. Regional management and intentional fishing - context-only
- Exact condition/range: Pennsylvania fisheries.
- Observed effect: Management material documents deliberate recreational fishing and population management.
- Measured: Agency fishery synthesis
- Population/location: Pennsylvania
- Life stage: Mixed
- Evidence type: government management report
- NOVA applicability: High Mid-Atlantic targetability relevance
- Confidence: medium
- Source: S8 (section: Fishing and management)
- Limitations: Catch trends combine effort, abundance, regulations, and access.
- Surrogate evidence: false
### E10. Angler catch in the New River - context-only
- Exact condition/range: Standardized creel/angler-catch work in Virginia and West Virginia.
- Observed effect: Rock bass were among the commonly caught species, confirming practical targetability in a regional river fishery.
- Measured: Angler catch composition and effort
- Population/location: New River, Virginia and West Virginia
- Life stage: Adult/subadult
- Evidence type: field creel/angler study
- NOVA applicability: Very high geographic relevance
- Confidence: medium
- Source: S9 (page: 526; section: Results; Discussion; table: Table 4)
- Limitations: Species catch proportion is confounded by abundance, gear, effort, and retention.
- Surrogate evidence: false
### E11. Macrophytes and resource partitioning - context-only
- Exact condition/range: Yearling rock bass and pumpkinseed in Lake St. Clair macrophyte habitats.
- Observed effect: Submersed vegetation altered habitat and food partitioning between the species.
- Measured: Diet and habitat use across macrophyte conditions
- Population/location: Lake St. Clair
- Life stage: Yearling
- Evidence type: field ecology study
- NOVA applicability: Habitat/prey context only
- Confidence: medium
- Source: S10 (page: 291-299; section: Results; Discussion)
- Limitations: Yearling stage and Great Lakes vegetation limit transfer; not hook-and-line catchability.
- Surrogate evidence: false
### E12. Nest defense aggression - zero-weight
- Exact condition/range: Comparative tests of male centrarchid nest defense.
- Observed effect: Rock bass males showed relatively short attack distance and among the lower attack probabilities in the compared species.
- Measured: Approach/attack behavior near nests
- Population/location: Ontario
- Life stage: Adult parental males
- Evidence type: field behavioral study
- NOVA applicability: Supports rejecting a generic spawning aggression bonus
- Confidence: medium
- Source: S11 (section: Abstract)
- Limitations: Nest-defense tests are not feeding and may not resemble angling lures.
- Surrogate evidence: false
### E13. Absolute temperature and feeding - unavailable
- Exact condition/range: Adult natural-water feeding or standardized catchability across temperatures.
- Observed effect: No qualifying portable temperature-response curve was identified.
- Measured: Documented evidence gap
- Population/location: Range-wide
- Life stage: Adult
- Evidence type: broad evidence review
- NOVA applicability: Direct reason to withhold a temperature rule
- Confidence: medium
- Source: S1 (section: Reference review)
- Limitations: Growth, spawning, and habitat temperatures cannot substitute for feeding.
- Surrogate evidence: false
### E14. Dissolved oxygen - unavailable
- Exact condition/range: Species-specific feeding or angling response in mg/L or saturation.
- Observed effect: No qualifying direct rock-bass feeding/catchability oxygen threshold was identified.
- Measured: Documented evidence gap
- Population/location: Range-wide
- Life stage: Mixed
- Evidence type: broad evidence review
- NOVA applicability: Model exclusion pending research
- Confidence: medium
- Source: S1 (section: Reference review)
- Limitations: Habitat tolerance is not bite probability.
- Surrogate evidence: false
### E15. Weather and lunar variables - zero-weight
- Exact condition/range: Barometric pressure, fronts, wind, rainfall, cloud cover, and moon phase.
- Observed effect: No qualifying rock-bass study directly isolated these variables for feeding or hook-and-line catchability.
- Measured: Documented evidence gap
- Population/location: Range-wide
- Life stage: Mixed
- Evidence type: broad evidence review
- NOVA applicability: Direct model-exclusion relevance
- Confidence: medium
- Source: S1 (section: Reference review)
- Limitations: Retinal morphology is not evidence for solunar or cloud scoring.
- Surrogate evidence: false
### E16. Population and life-stage transfer - context-only
- Exact condition/range: Comparisons among yearlings, adults, lake populations, streams, and experimental channels.
- Observed effect: Responses differed by prey, size, habitat, and study system, requiring explicit transfer limits.
- Measured: Cross-study synthesis
- Population/location: Range-wide
- Life stage: Mixed
- Evidence type: adversarial evidence synthesis
- NOVA applicability: High importance for uncertainty handling
- Confidence: high
- Source: S2 (section: Abstract and cross-study comparison)
- Limitations: This is a synthesis conclusion rather than an independent experiment.
- Surrogate evidence: false

## Remaining research gaps
- Wild Mid-Atlantic standardized catchability studies across depth, current, temperature, oxygen, clarity, and time of day.
- Replication of depth-cover predation effects with natural prey fields and angling endpoints.
- Short-term angling-pressure and hook-avoidance studies.

## Adversarial review outcome
Every candidate rule was tested against the actual endpoint. Movement, habitat occupancy, growth, physiology, survival, spawning, and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are preserved, exact values remain bounded to studied conditions, and no final production multiplier or invented smooth curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2024)
**Rock Bass**. Virginia Department of Wildlife Resources.
https://dwr.virginia.gov/wildlife/information/rock-bass/
Scope: Virginia. Access: agency-web-full-text. Verification: AI-reviewed-unverified.
### S2. Paul L. Angermeier (1992)
**Predation by Rock Bass on Other Stream Fishes: Experimental Effects of Depth and Cover**. Environmental Biology of Fishes 34:171-180. DOI: 10.1007/BF00002392.
https://doi.org/10.1007/BF00002392
Scope: Experimental stream channels; southeastern United States species. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S3. Steven J. Cooke, Brandon L. Barthel, and Cory D. Suski (2003)
**Effects of Hook Type on Injury and Capture Efficiency of Rock Bass, Ambloplites rupestris, Angled in South-Eastern Ontario**. Fisheries Management and Ecology 10:269-271. DOI: 10.1046/j.1365-2400.2003.00329.x.
https://doi.org/10.1046/j.1365-2400.2003.00329.x
Scope: Southeastern Ontario, Canada. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S4. D. L. Swann, L. E. Rider, and F. J. Bulow (1991)
**Age, Growth, and Summer Foods of Four Centrarchid Species in a Big South Fork National River and Recreation Area Stream**. Journal of the Tennessee Academy of Science 66(1):23-28.
https://trace.tennessee.edu/utk_natspubs/136/
Scope: Big South Fork, Tennessee-Kentucky. Access: university-repository-full-text. Verification: AI-reviewed-unverified.
### S5. G. P. Gerber and J. M. Haynes (1988)
**Movements and Behavior of Smallmouth Bass, Micropterus dolomieui, and Rock Bass, Ambloplites rupestris, in Southcentral Lake Ontario and Two Tributaries**. Journal of Freshwater Ecology 4(4):425-440. DOI: 10.1080/02705060.1988.9665191.
https://doi.org/10.1080/02705060.1988.9665191
Scope: Southcentral Lake Ontario and tributaries. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S6. Mart R. Gross and William A. Nowell (1980)
**The Reproductive Biology of Rock Bass, Ambloplites rupestris (Centrarchidae), in Lake Opinicon, Ontario**. Copeia 1980(3):482-494. DOI: 10.2307/1444526.
https://doi.org/10.2307/1444526
Scope: Lake Opinicon, Ontario. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S7. M. Williamson and A. Keast (1988)
**Retinal Structure Relative to Feeding in the Rock Bass (Ambloplites rupestris) and Bluegill (Lepomis macrochirus)**. Canadian Journal of Zoology 66(12):2840-2846. DOI: 10.1139/z88-411.
https://doi.org/10.1139/z88-411
Scope: Laboratory/morphological comparison, Ontario. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S8. Pennsylvania Fish and Boat Commission (2018)
**Rock Bass Management and Fishing in Pennsylvania**. Pennsylvania Fish and Boat Commission.
https://www.pa.gov/content/dam/copapwp-pagov/en/fishandboat/documents/about-us/agencyoverview/species-mgmt-plans/rockbassmanagement.pdf
Scope: Pennsylvania. Access: agency-report-full-text. Verification: AI-reviewed-unverified.
### S9. Douglas J. Austen and Donald J. Orth (1984)
**Angler Catches from New River, Virginia and West Virginia, in Relation to Minimum Length Limit Regulations**. Proceedings of the Annual Conference of the Southeastern Association of Fish and Wildlife Agencies 38:520-531.
https://seafwa.org/sites/default/files/journal-articles/AUSTEN-520-531.pdf
Scope: New River, Virginia and West Virginia. Access: original-pdf-full-text. Verification: AI-reviewed-unverified.
### S10. John R. P. French III (1988)
**Effect of Submersed Aquatic Macrophytes on Resource Partitioning in Yearling Rock Bass (Ambloplites rupestris) and Pumpkinseeds (Lepomis gibbosus) in Lake St. Clair**. Journal of Great Lakes Research 14(3):291-300. DOI: 10.1016/S0380-1330(88)71559-2.
https://doi.org/10.1016/S0380-1330(88)71559-2
Scope: Lake St. Clair. Access: publisher-pdf-full-text. Verification: AI-reviewed-unverified.
### S11. Patrick W. Colgan and Joseph A. Brown (1988)
**Dynamics of Nest Defense by Male Centrarchid Fish**. Behavioural Processes 17(1):17-26. DOI: 10.1016/0376-6357(88)90047-2.
https://doi.org/10.1016/0376-6357(88)90047-2
Scope: Ontario lake populations. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
