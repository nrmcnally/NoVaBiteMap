# Green Sunfish
*Lepomis cyanellus*

- Species ID: `green-sunfish`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Fish Guide only**

## Executive conclusion
Green sunfish are deliberately catchable and ecologically adaptable, but the reviewed evidence mostly measures habitat suitability, juvenile growth, physiology, or activity. No honest environmental bite-score rule met the endpoint and portability standard.

### Model-ready findings
- No current score candidate survived adversarial review.

### Context-only findings
- Juvenile growth depends jointly on food ration and temperature, but growth is not adult bite probability. Evidence: E5.
- Competition, acclimation, and habitat suitability change occupancy and physiology. Evidence: E2, E8, E9.
- Available turbidity evidence is either noncausal abundance correlation or a nonsignificant juvenile activity response. Evidence: E4, E6.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- wind or ordinary rainfall as an independent direct multiplier
- cloud cover without measured underwater light
- moon phase or solunar tables
- growth optimum used as bite optimum
- movement used as feeding
- habitat occupancy used as catchability
- spawning aggregation or nest defense labeled as feeding
- monthly curves derived from seasons, regulations, or folklore

## Contradictions and limitations
- The HSI oxygen component partly used related-species information and cannot be scored.
- Moderate-turbidity abundance association does not show feeding or catchability and uses JTU.
- Thermal acclimation and juvenile growth endpoints cannot become adult bite curves.

## Targetability assessment
Green sunfish are deliberately catchable and ecologically adaptable, but the reviewed evidence mostly measures habitat suitability, juvenile growth, physiology, or activity. No honest environmental bite-score rule met the endpoint and portability standard.

## Candidate model rules
### R1. foodRationTemperature - context-only
- Condition: Juvenile ration x temperature combinations
- Direction: growth response only
- Strength: moderate
- Confidence: high
- Mechanism: Food and temperature interacted to determine juvenile growth.
- Evidence: E5
- Double-counting risk: Growth is not adult bite; do not derive optimum.
### R2. turbidity - zero-weight
- Condition: Approximately 25-100 JTU
- Direction: no bite inference
- Strength: zero
- Confidence: low
- Mechanism: HSI abundance association lacked demonstrated causality and used obsolete units.
- Evidence: E4
- Double-counting risk: Do not convert JTU to NTU or abundance to feeding.
### R3. siltTurbidity - zero-weight
- Condition: 4-6 or 14-16 JTU in juvenile aquaria
- Direction: no reliable activity effect
- Strength: zero
- Confidence: medium
- Mechanism: Activity reduction was not statistically significant.
- Evidence: E6
- Double-counting risk: Activity is not feeding and juvenile aquaria limit transfer.
### R4. dissolvedOxygen - zero-weight
- Condition: Any oxygen threshold from HSI
- Direction: none
- Strength: zero
- Confidence: high
- Mechanism: Key HSI oxygen assumptions were partly surrogate centrarchid evidence.
- Evidence: E3
- Double-counting risk: Related-species evidence cannot score green sunfish.
### R5. thermalAcclimation - context-only
- Condition: Recent acclimation temperature
- Direction: physiology context
- Strength: moderate
- Confidence: medium
- Mechanism: Thermal limits and mitochondrial performance changed with acclimation.
- Evidence: E9
- Double-counting risk: Preprint physiology endpoint, not catchability.
### R6. communityCompetition - context-only
- Condition: Bluegill or other competitors present
- Direction: habitat shift
- Strength: moderate
- Confidence: medium
- Mechanism: Competition changed habitat occupancy.
- Evidence: E8
- Double-counting risk: Do not treat habitat presence as feeding.
### R7. preyAvailability - context-only
- Condition: Mixed shoreline prey including crayfish
- Direction: diet context
- Strength: weak
- Confidence: low
- Mechanism: Reservoir diet indicates opportunistic feeding.
- Evidence: E11
- Double-counting risk: Original full text not recovered and no rate/catch endpoint.
### R8. recentAnglingPressure - unavailable
- Condition: Short-term hook avoidance or depletion
- Direction: unknown
- Strength: unknown
- Confidence: medium
- Mechanism: No direct study isolated the effect.
- Evidence: E13
- Double-counting risk: Do not infer from electrofishing disturbance.
### R9. barometricPressureFronts - zero-weight
- Condition: Any pressure or weather-front category
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: No direct species-specific evidence.
- Evidence: E14
- Double-counting risk: Avoid centrarchid folklore.
### R10. moonPhase - zero-weight
- Condition: Any lunar phase
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: No direct species-specific evidence.
- Evidence: E14
- Double-counting risk: Do not infer from generalized light sensitivity.

## Evidence ledger
### E1. Regional occurrence and targetability - context-only
- Exact condition/range: Virginia native and introduced range.
- Observed effect: Green sunfish occur in Virginia and can be intentionally caught, but they are often a secondary target and local abundance is variable.
- Measured: Agency occurrence and fishing context
- Population/location: Virginia
- Life stage: Mixed
- Evidence type: government synthesis
- NOVA applicability: High regional applicability for guide status
- Confidence: medium
- Source: S1 (section: Species account)
- Limitations: Targetability does not prove a predictive environmental rule.
- Surrogate evidence: false
### E2. Habitat tolerance and current - context-only
- Exact condition/range: HSI synthesis across life stages.
- Observed effect: Green sunfish were modeled as habitat generalists favoring warm, low-gradient habitats with cover; suitability variables describe carrying capacity rather than bite probability.
- Measured: Habitat suitability model
- Population/location: United States synthesis
- Life stage: Mixed
- Evidence type: government technical synthesis
- NOVA applicability: Context only
- Confidence: medium
- Source: S2 (page: 1-24; section: Model description and variables)
- Limitations: Model assumptions combine literature, expert judgment, and surrogate information.
- Surrogate evidence: false
### E3. Dissolved oxygen - zero-weight
- Exact condition/range: HSI oxygen component.
- Observed effect: The report explicitly relied partly on bluegill or generalized centrarchid information because green-sunfish-specific oxygen data were limited.
- Measured: Habitat suitability assumptions
- Population/location: United States synthesis
- Life stage: Mixed
- Evidence type: government technical synthesis
- NOVA applicability: Not direct evidence for green sunfish scoring
- Confidence: low
- Source: S2 (page: 10-17; section: Water quality variables)
- Limitations: Related-species surrogate evidence cannot support a green-sunfish score rule.
- Surrogate evidence: true
### E4. Turbidity and abundance - zero-weight
- Exact condition/range: Moderate turbidity range in the HSI synthesis, approximately 25-100 JTU.
- Observed effect: The synthesis reported an abundance association with moderate turbidity, but also warned that cause and effect were not established.
- Measured: Field abundance correlations summarized in HSI
- Population/location: United States synthesis
- Life stage: Mixed
- Evidence type: government technical synthesis
- NOVA applicability: Habitat context only
- Confidence: low
- Source: S2 (page: 14-18; section: Turbidity variable)
- Limitations: JTU is not directly interchangeable with NTU; abundance is not feeding or catchability.
- Surrogate evidence: false
### E5. Temperature and growth - context-only
- Exact condition/range: Juveniles assigned combinations of food ration and water temperature.
- Observed effect: Food ration and temperature were similarly important to juvenile growth; abundant food at a suboptimal temperature could produce growth similar to scarce food near an optimum.
- Measured: Juvenile growth under controlled ration-temperature treatments
- Population/location: Laboratory
- Life stage: Juvenile
- Evidence type: controlled experiment
- NOVA applicability: Physiological context only
- Confidence: high
- Source: S3 (page: 263-269; section: Methods; Results; Discussion)
- Limitations: Growth does not establish an adult feeding optimum or hook-and-line response.
- Surrogate evidence: false
### E6. Silt turbidity and activity - zero-weight
- Exact condition/range: Clear, 4-6 JTU, and 14-16 JTU aquaria for 30 days.
- Observed effect: Juvenile green-sunfish activity declined numerically with turbidity, but the reported reduction was not statistically significant.
- Measured: Observed activity
- Population/location: Controlled aquaria
- Life stage: Juvenile
- Evidence type: controlled behavioral study
- NOVA applicability: Direct null/weak activity evidence, not feeding
- Confidence: medium
- Source: S4 (page: 3-9; section: Methods; Results)
- Limitations: Small aquaria, juvenile stage, and JTU units limit transfer.
- Surrogate evidence: false
### E7. Repeated electrofishing disturbance - zero-weight
- Exact condition/range: Repeated electroshocking in a warmwater stream study.
- Observed effect: Green sunfish showed no significant effect on measured growth or movement in the reported comparisons.
- Measured: Condition, growth, and movement
- Population/location: Warmwater stream
- Life stage: Mixed
- Evidence type: field disturbance experiment
- NOVA applicability: Null context only
- Confidence: medium
- Source: S5 (page: 792-797; section: Results; Discussion)
- Limitations: Electrofishing disturbance is not angling pressure or ordinary weather.
- Surrogate evidence: false
### E8. Competition and habitat shift - context-only
- Exact condition/range: Green sunfish and bluegill coexistence experiments/observations.
- Observed effect: Habitat use shifted in response to competition, demonstrating that occupancy is conditional on community composition.
- Measured: Habitat distribution and competition
- Population/location: Michigan systems
- Life stage: Juvenile/subadult
- Evidence type: field/experimental ecology study
- NOVA applicability: Context for habitat prediction
- Confidence: medium
- Source: S6 (section: Abstract)
- Limitations: Habitat shift is not feeding or hook-and-line catchability.
- Surrogate evidence: false
### E9. Thermal acclimation - context-only
- Exact condition/range: Controlled warm and cool acclimation treatments.
- Observed effect: Whole-organism thermal thresholds and mitochondrial bioenergetics changed rapidly with acclimation.
- Measured: Critical thermal limits and mitochondrial performance
- Population/location: Laboratory
- Life stage: Juvenile/adult laboratory fish
- Evidence type: controlled physiology preprint
- NOVA applicability: Context only; supports avoiding fixed universal thresholds
- Confidence: medium
- Source: S7 (section: Results; Discussion)
- Limitations: Preprint status and physiological endpoints preclude bite scoring.
- Surrogate evidence: false
### E10. Laboratory reproduction - context-only
- Exact condition/range: Laboratory breeding and culture conditions.
- Observed effect: Green sunfish could be bred and cultured under controlled conditions, documenting reproductive flexibility.
- Measured: Spawning and culture success
- Population/location: Laboratory
- Life stage: Adult and early life stages
- Evidence type: laboratory culture study
- NOVA applicability: Very limited transfer
- Confidence: low
- Source: S8 (section: Abstract)
- Limitations: Culture conditions are not natural-water feeding or catchability evidence.
- Surrogate evidence: false
### E11. Diet in reservoir shoreline habitat - context-only
- Exact condition/range: Bull Shoals shoreline centrarchid sampling.
- Observed effect: Green sunfish consumed a mixed diet including substantial crayfish volume in the cited shoreline study.
- Measured: Stomach contents and growth
- Population/location: Bull Shoals Reservoir
- Life stage: Mixed
- Evidence type: field diet study
- NOVA applicability: General prey context only
- Confidence: low
- Source: S9 (page: 469-482; section: Food habits)
- Limitations: Original full text was not recovered in this run; claim retained only at synthesis level.
- Surrogate evidence: false
### E12. Life-history synthesis - context-only
- Exact condition/range: Range-wide compiled evidence.
- Observed effect: The synthesis describes broad habitat, diet, and invasion traits but provides no validated short-term bite function.
- Measured: Authoritative species synthesis
- Population/location: Range-wide
- Life stage: Mixed
- Evidence type: authoritative catalog/synthesis
- NOVA applicability: Guide context only
- Confidence: medium
- Source: S10 (section: Biology and ecology)
- Limitations: Secondary synthesis cannot replace endpoint-specific primary research.
- Surrogate evidence: false
### E13. Direct hook-and-line catchability - unavailable
- Exact condition/range: Environmental variables separated from abundance, effort, gear, and access.
- Observed effect: No qualifying green-sunfish study directly estimated species-specific environmental effects on hook-and-line catchability.
- Measured: Documented evidence gap
- Population/location: Range-wide
- Life stage: Adult
- Evidence type: broad evidence review
- NOVA applicability: Direct reason to withhold scoring
- Confidence: medium
- Source: S1 (section: Reference review)
- Limitations: Lack of direct research does not mean the fish cannot be intentionally targeted.
- Surrogate evidence: false
### E14. Weather and lunar variables - zero-weight
- Exact condition/range: Barometric pressure, fronts, wind, rainfall, cloud cover, and moon phase.
- Observed effect: No qualifying green-sunfish feeding or angling study isolated these variables.
- Measured: Documented evidence gap
- Population/location: Range-wide
- Life stage: Mixed
- Evidence type: broad evidence review
- NOVA applicability: Direct model-exclusion relevance
- Confidence: medium
- Source: S1 (section: Reference review)
- Limitations: Do not substitute centrarchid folklore or related-species evidence.
- Surrogate evidence: false

## Remaining research gaps
- Any direct green-sunfish hook-and-line catchability experiment with environmental covariates.
- Adult feeding-rate studies across temperature, oxygen, turbidity, light, and flow.
- Mid-Atlantic population-specific targetability and pressure studies.

## Adversarial review outcome
Every candidate rule was tested against the actual endpoint. Movement, habitat occupancy, growth, physiology, survival, spawning, and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are preserved, exact values remain bounded to studied conditions, and no final production multiplier or invented smooth curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2024)
**Green Sunfish**. Virginia Department of Wildlife Resources.
https://dwr.virginia.gov/wildlife/information/green-sunfish/
Scope: Virginia. Access: agency-web-full-text. Verification: AI-reviewed-unverified.
### S2. Robert J. Stuber, Glen Gebhart, and O. Eugene Maughan (1982)
**Habitat Suitability Index Models: Green Sunfish**. U.S. Fish and Wildlife Service FWS/OBS-82/10.15.
https://apps.dtic.mil/sti/pdfs/ADA323471.pdf
Scope: United States; synthesis model. Access: agency-report-full-text. Verification: AI-reviewed-unverified.
### S3. Christopher J. Chizinski and Kevin L. Pope (2003)
**Importance of Food Ration and Water Temperature on Growth of Juvenile Green Sunfish (Lepomis cyanellus)**. Texas Journal of Science 55(3):263-270.
https://digitalcommons.unl.edu/natrespapers/112/
Scope: Controlled laboratory study, Nebraska. Access: university-repository-full-text. Verification: AI-reviewed-unverified.
### S4. N. W. Heimstra, D. K. Damkot, and N. G. Benson (1969)
**Some Effects of Silt Turbidity on Behavior of Juvenile Largemouth Bass and Green Sunfish**. U.S. Bureau of Sport Fisheries and Wildlife Technical Paper 20:3-9.
https://spo.nmfs.noaa.gov/sites/default/files/legacy-pdfs/SSRF20.pdf
Scope: Controlled aquaria. Access: agency-report-full-text. Verification: AI-reviewed-unverified.
### S5. A. John Gatz and R. Scott Linder (2008)
**Effects of Repeated Electroshocking on Condition, Growth, and Movement of Selected Warmwater Stream Fishes**. North American Journal of Fisheries Management 28(3):792-798. DOI: 10.1577/M07-031.1.
https://doi.org/10.1577/M07-031.1
Scope: Warmwater stream population. Access: author-upload-full-text. Verification: AI-reviewed-unverified.
### S6. Earl E. Werner and Donald J. Hall (1977)
**Competition and Habitat Shift in Two Sunfishes (Centrarchidae)**. Ecology 58:869-876. DOI: 10.2307/1936222.
https://doi.org/10.2307/1936222
Scope: Michigan lakes/experimental systems. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S7. Noah Wright, Remington G. Morrison, and Eloy Martinez (2022)
**Thermal Acclimation of the Green Sunfish, Lepomis cyanellus, Induces Rapid Changes in Whole-Organism Thermal Thresholds and Mitochondrial Bioenergetics**. Research preprint. DOI: 10.13140/RG.2.2.12155.80167.
https://doi.org/10.13140/RG.2.2.12155.80167
Scope: Controlled laboratory acclimation. Access: author-preprint-full-text. Verification: AI-reviewed-unverified.
### S8. Wesley E. Smith (1975)
**Breeding and Culture of Two Sunfish, Lepomis cyanellus and L. megalotis, in the Laboratory**. The Progressive Fish-Culturist 37(4):227-229. DOI: 10.1577/1548-8659(1975)37[227:BACOTS]2.0.CO;2.
https://doi.org/10.1577/1548-8659(1975)37%5B227:BACOTS%5D2.0.CO;2
Scope: Controlled laboratory culture. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S9. Richard L. Applegate, James W. Mullan, and David I. Morais (1967)
**Food and Growth of Six Centrarchids from Shoreline Areas of Bull Shoals Reservoir**. Proceedings of the 20th Annual Conference of the Southeastern Association of Game and Fish Commissioners:469-482.
https://seafwa.org/journal/1966/food-and-growth-six-centrarchids-shoreline-areas-bull-shoals-reservoir
Scope: Bull Shoals Reservoir, Arkansas-Missouri. Access: proceedings-metadata-and-citations. Verification: AI-reviewed-unverified.
### S10. Jeanine Velez-Gavilan (2024)
**Green Sunfish (Lepomis cyanellus) Species Account**. CABI Compendium. DOI: 10.1079/cabicompendium.77079.
https://www.cabidigitallibrary.org/doi/full/10.1079/cabicompendium.77079
Scope: Range-wide synthesis. Access: publisher-full-text. Verification: AI-reviewed-unverified.
