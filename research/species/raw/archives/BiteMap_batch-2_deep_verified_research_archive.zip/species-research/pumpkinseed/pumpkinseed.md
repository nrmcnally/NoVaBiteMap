# Pumpkinseed
*Lepomis gibbosus*

- Species ID: `pumpkinseed`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Proposed for bite scoring**

## Executive conclusion
Pumpkinseed have direct feeding evidence for parental-care suppression and direct angling evidence for low-light/deep-hooking risk. The environmental bite score should remain narrow and reproductive-state-specific.

### Model-ready findings
- **score**: Parental males carried less food and fewer chironomids than comparison groups during active care; treat as a negative reproductive-state candidate only. Evidence: E2, E3, E6.

### Context-only findings
- Dawn/dusk fullness peaks occurred during one reproductive-season study, not as a universal daily curve. Evidence: E4.
- Dark or passive angling increased deep-hooking risk and belongs mainly in Fish Guide handling advice. Evidence: E7, E8.
- Size, age, behavioral phenotype, and sustained removal affect ecology or vulnerability but lack portable environmental triggers. Evidence: E10, E14, E15.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- wind or ordinary rainfall as an independent direct multiplier
- cloud cover without measured underwater light
- moon phase or solunar tables
- growth optimum used as bite optimum
- movement used as feeding
- habitat occupancy used as catchability
- spawning aggregation or nest defense labeled as feeding
- monthly curves derived from seasons, regulations, or folklore

## Contradictions and limitations
- Low-light evidence concerns hooking depth with few nighttime pumpkinseed, not a night bite bonus.
- European thermal studies measure spawning/life history in introduced populations, not North American feeding.
- Nesting may suppress feeding while defensive responses or egg consumption still occur.

## Targetability assessment
Pumpkinseed have direct feeding evidence for parental-care suppression and direct angling evidence for low-light/deep-hooking risk. The environmental bite score should remain narrow and reproductive-state-specific.

## Candidate model rules
### R1. reproductiveState - score
- Condition: Confirmed parental male actively guarding a nest
- Direction: decrease
- Strength: moderate
- Confidence: high
- Mechanism: Parental care reduced stomach food weight and chironomid consumption.
- Evidence: E2, E3, E6
- Double-counting risk: Do not double-count with spawn season, shallow habitat, or dawn/dusk; do not apply to cuckolders or females.
### R2. timeOfDay - context-only
- Condition: Dawn or dusk during the studied reproductive period
- Direction: possible feeding peak
- Strength: weak
- Confidence: medium
- Mechanism: Stomach fullness peaked around dawn/dusk, especially in parental males.
- Evidence: E4
- Double-counting risk: Single population and reproductive season; overlaps with parental-care rule.
### R3. ambientLight - context-only
- Condition: Dark or low-light angling
- Direction: greater deep/foul-hooking risk
- Strength: moderate
- Confidence: medium
- Mechanism: Pumpkinseed hooked in darker periods were more likely to be deeply or foul hooked.
- Evidence: E7
- Double-counting risk: Handling-risk rule, not a positive bite score; low night sample.
### R4. presentationMode - context-only
- Condition: Passive bait rather than active presentation
- Direction: greater deep-hooking risk
- Strength: moderate
- Confidence: high
- Mechanism: Passive methods increased hooking depth.
- Evidence: E8, E16
- Double-counting risk: Fish Guide gear rule, not environmental scoring.
### R5. night - zero-weight
- Condition: Nighttime
- Direction: no supported catch bonus
- Strength: zero
- Confidence: medium
- Mechanism: Few pumpkinseed were caught at night in the direct diel-angling study.
- Evidence: E9
- Double-counting risk: Study was not optimized for standardized catch-rate inference.
### R6. fishSizeAge - context-only
- Condition: Larger/older parental males early in nesting season
- Direction: nesting-timing context
- Strength: moderate
- Confidence: medium
- Mechanism: Size and age altered seasonal nesting timing.
- Evidence: E15
- Double-counting risk: Do not treat size or early nesting as higher feeding.
### R7. temperature - context-only
- Condition: Elevated temperature causing earlier spawning
- Direction: earlier reproduction only
- Strength: moderate
- Confidence: medium
- Mechanism: Warm conditions shifted spawning phenology in introduced populations.
- Evidence: E12, E13
- Double-counting risk: Do not translate to bite optimum; Europe transfer limits.
### R8. behavioralPhenotype - context-only
- Condition: Shy-bold individual differences
- Direction: variable vulnerability
- Strength: unknown
- Confidence: medium
- Mechanism: Behavioral phenotype covaried with diet and risk.
- Evidence: E14
- Double-counting risk: No operational environmental trigger or portable effect size.
### R9. sustainedRemovalPressure - context-only
- Condition: Long-term angling removal
- Direction: population restructuring
- Strength: moderate
- Confidence: medium
- Mechanism: Removal changed size structure and juvenile growth.
- Evidence: E10
- Double-counting risk: Long-term population effect, not same-day bite decay.
### R10. barometricPressureFrontsMoon - zero-weight
- Condition: Any pressure, front, or moon category
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: No direct species-specific feeding/catchability evidence.
- Evidence: E17
- Double-counting risk: Do not infer from artificial/diel light studies.
### R11. dissolvedOxygen - unavailable
- Condition: Any mg/L or saturation threshold
- Direction: unknown
- Strength: unknown
- Confidence: medium
- Mechanism: No qualifying direct feeding or angling threshold was found.
- Evidence: none
- Double-counting risk: Do not substitute habitat or survival thresholds.

## Evidence ledger
### E1. Regional occurrence and targetability - context-only
- Exact condition/range: Virginia ponds, lakes, and slow waters.
- Observed effect: Pumpkinseed are present and intentionally catchable in Virginia, although local abundance and angler targeting vary.
- Measured: Agency occurrence and fishing context
- Population/location: Virginia
- Life stage: Mixed
- Evidence type: government synthesis
- NOVA applicability: High regional occurrence relevance
- Confidence: medium
- Source: S1 (section: Species account)
- Limitations: Agency account is not direct catchability experimentation.
- Surrogate evidence: false
### E2. Parental care and feeding quantity - score
- Exact condition/range: Whole-diel stomach sampling during the breeding season.
- Observed effect: Parental males had lower total food weight than females; cuckolder males did not show the same reduction.
- Measured: Stomach content mass by reproductive tactic and sex
- Population/location: Polish reservoir
- Life stage: Adult parental males, cuckolder males, and females
- Evidence type: field feeding study
- NOVA applicability: Direct feeding endpoint; state-specific
- Confidence: high
- Source: S2 (section: Results; table: Diet metrics by reproductive group)
- Limitations: Introduced European population; do not apply to all adults or all spawning periods.
- Surrogate evidence: false
### E3. Parental care and prey type - score
- Exact condition/range: Breeding-season stomach samples.
- Observed effect: Parental males contained lower numbers and weight of chironomids than comparison groups.
- Measured: Prey number and mass by taxon
- Population/location: Polish reservoir
- Life stage: Adult
- Evidence type: field feeding study
- NOVA applicability: Direct mechanism but population-specific
- Confidence: high
- Source: S2 (section: Results; Discussion)
- Limitations: Reduced chironomids may reflect nest-site foraging constraints rather than overall appetite alone.
- Surrogate evidence: false
### E4. Diel feeding during reproduction - context-only
- Exact condition/range: Repeated sampling across a 24-hour cycle.
- Observed effect: Stomach fullness peaked near dawn and dusk, most clearly in parental males.
- Measured: Stomach fullness across time of day
- Population/location: Polish reservoir
- Life stage: Adult
- Evidence type: field feeding study
- NOVA applicability: Potential context; not a universal hourly bite curve
- Confidence: medium
- Source: S2 (section: Results; figure: Diel stomach fullness)
- Limitations: Single reproductive season and population; light, prey, and temperature covary.
- Surrogate evidence: false
### E5. Egg consumption during reproduction - context-only
- Exact condition/range: Breeding-season stomach contents.
- Observed effect: Parental males were more likely to contain conspecific eggs, showing reproductive-state-specific prey use.
- Measured: Occurrence of conspecific eggs in stomachs
- Population/location: Polish reservoir
- Life stage: Adult parental males
- Evidence type: field feeding study
- NOVA applicability: Mechanistic context only
- Confidence: medium
- Source: S2 (section: Results; Discussion)
- Limitations: May include filial cannibalism or egg removal; not an angling predictor.
- Surrogate evidence: false
### E6. Nesting versus nonnesting feeding - score
- Exact condition/range: Nesting and nonnesting pumpkinseed sampled at dawn and dusk.
- Observed effect: Nesting reduced prey quantity and diversity relative to nonnesting fish.
- Measured: Gut contents by nesting status
- Population/location: Natural lake population
- Life stage: Adult
- Evidence type: field feeding study
- NOVA applicability: Direct feeding corroboration
- Confidence: medium
- Source: S3 (section: Abstract)
- Limitations: Abstract-level access; exact magnitude and covariates require full-text recheck.
- Surrogate evidence: false
### E7. Light level and hooking depth - context-only
- Exact condition/range: Active and passive angling during bright, low-light, and dark periods.
- Observed effect: Pumpkinseed caught in dark or low light were more often deeply or foul hooked than those caught in bright conditions.
- Measured: Hooking depth and hooking location
- Population/location: Eastern Ontario
- Life stage: Adult/subadult
- Evidence type: field angling experiment
- NOVA applicability: Direct angling handling evidence; limited as bite-score input
- Confidence: medium
- Source: S4 (page: 507-515; section: Results; Discussion)
- Limitations: Few pumpkinseed were caught at night; result concerns injury risk, not higher catch probability.
- Surrogate evidence: false
### E8. Angling method and hooking depth - context-only
- Exact condition/range: Active lure presentation versus passive bait presentation.
- Observed effect: Passive angling produced deeper hooking for the study fishes, including pumpkinseed.
- Measured: Hooking depth by angling method
- Population/location: Eastern Ontario
- Life stage: Adult/subadult
- Evidence type: field angling experiment
- NOVA applicability: Fish Guide/handling relevance
- Confidence: high
- Source: S4 (page: 511-515; section: Results; Discussion)
- Limitations: Gear effect, not environmental bite scoring.
- Surrogate evidence: false
### E9. Night catch sample - zero-weight
- Exact condition/range: Nighttime angling periods in the diel study.
- Observed effect: Few pumpkinseed were captured at night, preventing a strong night catch-rate conclusion.
- Measured: Number caught by diel period
- Population/location: Eastern Ontario
- Life stage: Adult/subadult
- Evidence type: field angling experiment
- NOVA applicability: Supports rejection of a generic night bonus
- Confidence: medium
- Source: S4 (page: 511-513; section: Results)
- Limitations: Sampling design targeted hooking-depth questions, not standardized population catchability.
- Surrogate evidence: false
### E10. Sustained angling removal and population response - context-only
- Exact condition/range: Repeated removal through angling in ten artificial lakes.
- Observed effect: Angling removal altered population size structure, maximum mass, and juvenile growth patterns over time.
- Measured: Population characteristics and juvenile growth under removal
- Population/location: Southern France artificial lakes
- Life stage: Mixed
- Evidence type: multi-lake field study
- NOVA applicability: Pressure/depletion context only
- Confidence: medium
- Source: S5 (section: Results; Discussion)
- Limitations: Long-term removal effects do not yield a short-term hook-avoidance or bite-decay function.
- Surrogate evidence: false
### E11. Ontogenetic diet shift - context-only
- Exact condition/range: 2,435 pumpkinseed stomachs across age groups and seasons.
- Observed effect: Diet and habitat use changed with size and age; younger and older fish exploited different prey and spaces.
- Measured: Stomach contents and habitat by age group
- Population/location: Lake Opinicon, Ontario
- Life stage: Juvenile through adult
- Evidence type: field diet study
- NOVA applicability: Important size/life-stage context
- Confidence: medium
- Source: S6 (section: Abstract)
- Limitations: No real-time environmental catchability function.
- Surrogate evidence: false
### E12. Elevated temperature and spawning timing - context-only
- Exact condition/range: Introduced European populations exposed to warmer conditions.
- Observed effect: Elevated temperature advanced spawning timing.
- Measured: Spawning phenology
- Population/location: Europe
- Life stage: Adult
- Evidence type: field comparative study
- NOVA applicability: Reproduction context only
- Confidence: medium
- Source: S7 (section: Abstract)
- Limitations: Introduced populations and climate differ; earlier spawning is not a feeding optimum.
- Surrogate evidence: false
### E13. Elevated temperature and life history - context-only
- Exact condition/range: Warm-water introduced population comparisons.
- Observed effect: Temperature affected growth, maturation, and other life-history traits.
- Measured: Growth and reproductive traits
- Population/location: Europe
- Life stage: Mixed
- Evidence type: field life-history study
- NOVA applicability: Context only
- Confidence: medium
- Source: S8 (section: Abstract)
- Limitations: Growth and life history are not bite endpoints.
- Surrogate evidence: false
### E14. Behavioral phenotype - context-only
- Exact condition/range: Shy-bold continuum measured in juvenile pumpkinseed.
- Observed effect: Behavioral type covaried with ecological traits including diet and risk exposure.
- Measured: Behavioral assays and ecological traits
- Population/location: New York
- Life stage: Juvenile
- Evidence type: field/behavioral study
- NOVA applicability: Individual-vulnerability context only
- Confidence: medium
- Source: S9 (section: Abstract)
- Limitations: No operational weather or habitat trigger; phenotype effects may be plastic.
- Surrogate evidence: false
### E15. Size and seasonal nesting timing - context-only
- Exact condition/range: Parental males observed across a nesting season.
- Observed effect: Larger and older males nested earlier; later nests were dominated by younger/smaller males.
- Measured: Nest timing, male size, and age
- Population/location: Lake Opinicon, Ontario
- Life stage: Adult males
- Evidence type: field reproductive study
- NOVA applicability: Size/season context only
- Confidence: medium
- Source: S10 (section: Abstract)
- Limitations: Nesting timing is not feeding or catchability.
- Surrogate evidence: false
### E16. Hook type, injury, and mortality - context-only
- Exact condition/range: Four hook types used for bluegill and pumpkinseed angling.
- Observed effect: Hook type influenced injury patterns and capture outcomes; findings inform catch-and-release handling.
- Measured: Capture efficiency, injury, and short-term mortality
- Population/location: Ontario
- Life stage: Adult/subadult
- Evidence type: controlled field angling study
- NOVA applicability: Fish Guide relevance, not environmental score
- Confidence: high
- Source: S11 (page: 883-891; section: Methods; Results; Discussion)
- Limitations: Gear-specific and not a weather/environmental predictor.
- Surrogate evidence: false
### E17. Weather, moon, and pressure - zero-weight
- Exact condition/range: Barometric pressure, fronts, wind, rainfall, cloud cover, and natural moon phase.
- Observed effect: No qualifying pumpkinseed study isolated these variables for feeding or hook-and-line catchability.
- Measured: Documented evidence gap
- Population/location: Range-wide
- Life stage: Mixed
- Evidence type: broad evidence review
- NOVA applicability: Direct model-exclusion relevance
- Confidence: medium
- Source: S1 (section: Reference review)
- Limitations: Artificial or categorical light studies cannot be translated into solunar weights.
- Surrogate evidence: false

## Remaining research gaps
- Adult Mid-Atlantic temperature, oxygen, turbidity, flow, and standardized catch-rate experiments.
- Replication of parental-care feeding effects in native North American populations.
- Natural underwater-light measurements separating catch rate from hooking injury.

## Adversarial review outcome
Every candidate rule was tested against the actual endpoint. Movement, habitat occupancy, growth, physiology, survival, spawning, and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are preserved, exact values remain bounded to studied conditions, and no final production multiplier or invented smooth curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2024)
**Pumpkinseed**. Virginia Department of Wildlife Resources.
https://dwr.virginia.gov/wildlife/information/pumpkinseed/
Scope: Virginia. Access: agency-web-full-text. Verification: AI-reviewed-unverified.
### S2. Grzegorz Zieba, Malgorzata Dukowska, Miroslaw Przybylski, Michael G. Fox, and Carl Smith (2018)
**Parental Care Compromises Feeding in the Pumpkinseed (Lepomis gibbosus)**. The Science of Nature 105:26. DOI: 10.1007/s00114-018-1554-0.
https://pmc.ncbi.nlm.nih.gov/articles/PMC5869894/
Scope: Polish reservoir population. Access: publisher-open-full-text. Verification: AI-reviewed-unverified.
### S3. J. H. Thorp, L. D. Goldsmith, J. A. Polgreen, and L. M. Mayer (1989)
**Foraging Patterns of Nesting and Nonnesting Sunfish (Centrarchidae: Lepomis auritus and L. gibbosus)**. Canadian Journal of Fisheries and Aquatic Sciences 46:1342-1346. DOI: 10.1139/f89-172.
https://doi.org/10.1139/f89-172
Scope: Natural lake population; North America. Access: publisher-abstract-and-metadata. Verification: AI-reviewed-unverified.
### S4. Shannon D. Bower, Himrat Kooner, Hannah Ludwig, Scott Lumb, Jagmeet Raina, Jenna Webb, Zoe Zrini, Constance M. O'Connor, and Steven J. Cooke (2017)
**Diel Patterns of Hooking Depth for Active and Passive Angling Methods for Two Freshwater Teleost Fishes**. Bulletin of Marine Science 93(2):507-517. DOI: 10.5343/bms.2015.1104.
https://doi.org/10.5343/bms.2015.1104
Scope: Eastern Ontario, Canada. Access: publisher-pdf-full-text. Verification: AI-reviewed-unverified.
### S5. Charlotte Evangelista, Robert J. Britton, and Julien Cucherousset (2015)
**Impacts of Invasive Fish Removal through Angling on Population Characteristics and Juvenile Growth Rate**. Ecology and Evolution 5(11):2193-2202. DOI: 10.1002/ece3.1471.
https://pmc.ncbi.nlm.nih.gov/articles/PMC4461421/
Scope: Ten artificial lakes in southern France. Access: publisher-open-full-text. Verification: AI-reviewed-unverified.
### S6. Allen Keast (1978)
**Feeding Interrelations between Age-Groups of Pumpkinseed (Lepomis gibbosus) and Comparisons with Bluegill (L. macrochirus)**. Journal of the Fisheries Research Board of Canada 35(1):12-27. DOI: 10.1139/f78-003.
https://doi.org/10.1139/f78-003
Scope: Lake Opinicon, Ontario. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S7. Grzegorz Zieba, Michael G. Fox, and Gordon H. Copp (2010)
**The Effect of Elevated Temperature on Spawning of Introduced Pumpkinseed Lepomis gibbosus in Europe**. Journal of Fish Biology 77(8):1850-1855. DOI: 10.1111/j.1095-8649.2010.02778.x.
https://doi.org/10.1111/j.1095-8649.2010.02778.x
Scope: Introduced European populations. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S8. S. Dembski, G. Masson, D. Monnier, P. Wagner, and J. C. Pihan (2006)
**Consequences of Elevated Temperatures on Life-History Traits of an Introduced Fish, Pumpkinseed Lepomis gibbosus**. Journal of Fish Biology 69(2):331-346. DOI: 10.1111/j.1095-8649.2006.01087.x.
https://doi.org/10.1111/j.1095-8649.2006.01087.x
Scope: Introduced European population. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S9. David Sloan Wilson, Kristine Coleman, Anne B. Clark, and Leslie Biederman (1993)
**Shy-Bold Continuum in Pumpkinseed Sunfish (Lepomis gibbosus): An Ecological Study of a Psychological Trait**. Journal of Comparative Psychology 107(3):250-260. DOI: 10.1037/0735-7036.107.3.250.
https://doi.org/10.1037/0735-7036.107.3.250
Scope: New York lake population. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S10. Andy J. Danylchuk and Michael G. Fox (1996)
**Size- and Age-Related Variation in the Seasonal Timing of Nesting Activity, Nest Characteristics, and Female Choice of Parental Male Pumpkinseed Sunfish**. Canadian Journal of Zoology 74(10):1834-1840. DOI: 10.1139/z96-206.
https://doi.org/10.1139/z96-206
Scope: Lake Opinicon, Ontario. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S11. Steven J. Cooke, Cory D. Suski, Brandon L. Barthel, Kevin G. Ostrand, Bruce L. Tufts, and David P. Philipp (2003)
**Injury and Mortality Induced by Four Hook Types on Bluegill and Pumpkinseed**. North American Journal of Fisheries Management 23(3):883-893. DOI: 10.1577/M02-096.
https://doi.org/10.1577/M02-096
Scope: Ontario, Canada. Access: publisher-and-author-full-text. Verification: AI-reviewed-unverified.
