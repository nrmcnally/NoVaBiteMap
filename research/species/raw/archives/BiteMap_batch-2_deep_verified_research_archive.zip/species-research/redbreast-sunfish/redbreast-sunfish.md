# Redbreast Sunfish
*Lepomis auritus*

- Species ID: `redbreast-sunfish`
- Schema: `1.1`
- Verification: `AI-reviewed-unverified`
- Research status: `PARTIAL`
- Targetability recommendation: **Proposed for bite scoring**

## Executive conclusion
A direct field feeding study supports one narrow reproductive-state rule, while Virginia-specific reproductive habitat and several Piedmont studies supply useful context. Most public weather and water-quality variables remain unsupported.

### Model-ready findings
- **score**: Confirmed nest-guarding parental males showed reduced prey quantity/diversity relative to nonnesting fish; use only as a bounded negative feeding-state candidate. Evidence: E11.

### Context-only findings
- North Anna River nest habitat and temperature observations can locate reproductive fish but are not bite optima. Evidence: E13.
- Prey use is opportunistic and can shift between aquatic and terrestrial sources. Evidence: E2, E7.
- Flow-growth and drought-recruitment results conflict with any universal flow direction. Evidence: E8, E9.

### Rejected or zero-weight assumptions
- barometric pressure or pressure trend
- generic weather-front category
- wind or ordinary rainfall as an independent direct multiplier
- cloud cover without measured underwater light
- moon phase or solunar tables
- growth optimum used as bite optimum
- movement used as feeding
- habitat occupancy used as catchability
- spawning aggregation or nest defense labeled as feeding
- monthly curves derived from seasons, regulations, or folklore

## Contradictions and limitations
- Nesting feeding suppression applies to parental males, while defensive capture may remain possible.
- Georgia wet-year growth and Edisto drought recruitment point in different directions and neither measures biting.
- Florida and South Carolina spawning calendars cannot be transferred exactly to Virginia.

## Targetability assessment
A direct field feeding study supports one narrow reproductive-state rule, while Virginia-specific reproductive habitat and several Piedmont studies supply useful context. Most public weather and water-quality variables remain unsupported.

## Candidate model rules
### R1. reproductiveState - score
- Condition: Confirmed nest-guarding parental male
- Direction: decrease
- Strength: moderate
- Confidence: medium
- Mechanism: Parental care constrains foraging and reduces prey quantity/diversity.
- Evidence: E11
- Double-counting risk: Do not double-count with season, shallow habitat, or spawn; do not apply to females or nonnesting fish.
### R2. timeOfDay - context-only
- Condition: Dawn versus dusk during nesting
- Direction: prey-composition shift
- Strength: weak
- Confidence: low
- Mechanism: Benthic prey proportion differed by time while reproductive state altered total diet.
- Evidence: E12
- Double-counting risk: Avoid separate dawn and spawn modifiers from the same study.
### R3. preyAvailability - context-only
- Condition: Aquatic prey scarcity with terrestrial prey available
- Direction: substitution
- Strength: moderate
- Confidence: medium
- Mechanism: Redbreast sunfish can switch prey sources rather than simply cease feeding.
- Evidence: E2, E7
- Double-counting risk: Prey inputs and land cover overlap; do not infer higher total feeding.
### R4. streamHabitat - context-only
- Condition: Pool depth >0.5 m and velocity <0.10 m/s during North Anna nesting
- Direction: occupancy increase
- Strength: moderate
- Confidence: high
- Mechanism: These conditions described nest placement in a Virginia stream.
- Evidence: E13
- Double-counting risk: This is spawn habitat, not feeding; overlaps with reproductive state.
### R5. springFlow - zero-weight
- Condition: Higher/variable April-June discharge
- Direction: unknown for bite
- Strength: unknown
- Confidence: medium
- Mechanism: Growth correlation may reflect productivity or habitat.
- Evidence: E8, E9
- Double-counting risk: Do not double-count flow with season or growth.
### R6. temperature - context-only
- Condition: Water above 20 C or near 23 C during observed spawning
- Direction: unknown for bite
- Strength: unknown
- Confidence: medium
- Mechanism: Temperature marked reproductive timing, not feeding optimum.
- Evidence: E6, E13
- Double-counting risk: Do not convert spawn cues into a bite curve.
### R7. movement - context-only
- Condition: Upstream movement or local aggregation
- Direction: encounter context
- Strength: weak
- Confidence: medium
- Mechanism: Movement can change fish availability without changing appetite.
- Evidence: E4
- Double-counting risk: Do not score movement as feeding.
### R8. barometricPressure - zero-weight
- Condition: Any level or trend
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: No direct species-specific feeding or catchability evidence.
- Evidence: E15
- Double-counting risk: Avoid folklore and weather-front double counting.
### R9. moonPhase - zero-weight
- Condition: Any lunar phase or solunar period
- Direction: none
- Strength: zero
- Confidence: medium
- Mechanism: No direct species-specific evidence.
- Evidence: E15
- Double-counting risk: Do not infer from diel observations.
### R10. recentAnglingPressure - unavailable
- Condition: Short-term pressure or hook avoidance
- Direction: unknown
- Strength: unknown
- Confidence: medium
- Mechanism: Tag/harvest evidence did not isolate learning from depletion and effort.
- Evidence: E4, E14
- Double-counting risk: Do not infer behavioral learning from lower catches alone.

## Evidence ledger
### E1. Regional occurrence and targetability - context-only
- Exact condition/range: Virginia and adjoining Mid-Atlantic waters.
- Observed effect: Agency and management records identify redbreast sunfish as an established, intentionally fished river and stream panfish.
- Measured: Regional occurrence, fishing use, and management context
- Population/location: Virginia and Pennsylvania
- Life stage: Mixed
- Evidence type: government synthesis
- NOVA applicability: High regional applicability; not a short-term bite predictor
- Confidence: high
- Source: S1 (section: Species account and fishing information)
- Limitations: Agency synthesis does not isolate intrinsic catchability from abundance or angler effort.
- Surrogate evidence: false
### E2. Diet and prey availability - context-only
- Exact condition/range: Bimonthly sampling from January 1972 through June 1973 in two Florida rivers.
- Observed effect: Aquatic and terrestrial insects formed the bulk of the diet; feeding was opportunistic and reflected available prey.
- Measured: Stomach contents and prey composition
- Population/location: Suwannee and Santa Fe rivers, Florida
- Life stage: Juvenile and adult
- Evidence type: field diet study
- NOVA applicability: Mechanistically relevant but geographically warmer than NOVA
- Confidence: medium
- Source: S2 (page: 296-304; section: Methods; Food habits; Discussion)
- Limitations: Diet composition is not a direct hourly catchability measure.
- Surrogate evidence: false
### E3. Seasonal reproduction - context-only
- Exact condition/range: Florida river samples; prolonged warm-season spawning.
- Observed effect: Spawning extended from spring into fall, with greatest activity in late spring and summer.
- Measured: Gonadal condition and reproductive timing
- Population/location: Florida rivers
- Life stage: Adult
- Evidence type: field life-history study
- NOVA applicability: Timing is not transferable as an exact NOVA calendar
- Confidence: medium
- Source: S2 (page: 302-305; section: Reproduction)
- Limitations: Warm Florida climate and long season limit transfer.
- Surrogate evidence: false
### E4. Movement and exploitation - context-only
- Exact condition/range: 481 tagged fish; 189 recaptures within 60 days.
- Observed effect: Most fish showed moderate mobility, upstream movements predominated, and annual sport harvest was estimated near 14.7%.
- Measured: Tag recaptures, movement direction, and harvest
- Population/location: Little River, North Carolina
- Life stage: Adult
- Evidence type: field tagging study
- NOVA applicability: Regional stream context; movement is not feeding
- Confidence: medium
- Source: S3 (page: 325-329; section: Abstract; Results; Discussion)
- Limitations: Tag returns depend on reporting, effort, and access.
- Surrogate evidence: false
### E5. Food consumption and diet - context-only
- Exact condition/range: Thirty-six South Carolina Piedmont beaver ponds.
- Observed effect: Food occurred in 96.6% of examined stomachs; aquatic insects dominated, with fish contributing substantial volume.
- Measured: Stomach occurrence and volumetric diet
- Population/location: South Carolina Piedmont beaver ponds
- Life stage: Mixed
- Evidence type: field diet study
- NOVA applicability: Piedmont relevance, but pond habitat differs from NOVA rivers
- Confidence: medium
- Source: S4 (page: 216-224; section: Food habits)
- Limitations: Presence of food in stomachs does not establish environmental bite multipliers.
- Surrogate evidence: false
### E6. Spawning temperature and season - context-only
- Exact condition/range: Beaver ponds; water reached approximately 23 C during the spawning period.
- Observed effect: Spawning occurred mainly May-August after water warmed to the reported level.
- Measured: Gonadal condition, nests, and water temperature
- Population/location: South Carolina Piedmont beaver ponds
- Life stage: Adult
- Evidence type: field life-history study
- NOVA applicability: Context only; exact threshold is population- and habitat-specific
- Confidence: medium
- Source: S4 (page: 222-224; section: Reproduction)
- Limitations: Do not convert a spawning observation into a feeding optimum.
- Surrogate evidence: false
### E7. Land cover and prey availability - context-only
- Exact condition/range: Three lower-Piedmont streams spanning forested, suburban, and urban land cover.
- Observed effect: Chironomids were major prey; fish shifted toward terrestrial prey where aquatic prey were less available.
- Measured: Stomach contents, prey availability, growth, and stable isotopes
- Population/location: Georgia lower Piedmont
- Life stage: Mixed
- Evidence type: comparative field study
- NOVA applicability: Moderate regional transfer for prey context
- Confidence: medium
- Source: S5 (page: 107-115; section: Results; Discussion)
- Limitations: Only three streams and limited sample sizes; land cover bundles multiple mechanisms.
- Surrogate evidence: false
### E8. Flow and growth - context-only
- Exact condition/range: Nine Georgia rivers; April-June flow metrics compared with annual growth.
- Observed effect: Higher or more variable spring flow was associated with greater growth in most rivers; reported wet-year growth increments exceeded dry-year increments by age.
- Measured: Back-calculated growth versus discharge
- Population/location: Georgia rivers
- Life stage: Ages 1-3
- Evidence type: multi-river observational study
- NOVA applicability: Regional river context only
- Confidence: medium
- Source: S7 (section: Abstract)
- Limitations: Growth is not feeding rate or catchability; correlations may reflect productivity and habitat.
- Surrogate evidence: false
### E9. Drought, flooding, and recruitment - zero-weight
- Exact condition/range: Edisto River cohorts spanning drought and flood years.
- Observed effect: A drought cohort dominated recruitment, and some growth intervals were greater during drought than flood conditions.
- Measured: Age structure, cohort strength, and growth
- Population/location: Edisto River, South Carolina
- Life stage: Juvenile to adult
- Evidence type: agency field study
- NOVA applicability: Useful contradiction to generic flood-benefit rules
- Confidence: medium
- Source: S6 (page: 6-19; section: Results; Discussion)
- Limitations: Recruitment and growth are not short-term bite endpoints.
- Surrogate evidence: false
### E10. Population variation in growth and survival - context-only
- Exact condition/range: 5,664 bluegill and redbreast sunfish from 13 Georgia river sections.
- Observed effect: Growth and annual survival varied substantially among river sections; redbreast survival estimates ranged broadly.
- Measured: Age, growth, and survival
- Population/location: Georgia rivers
- Life stage: Mixed
- Evidence type: comparative field study
- NOVA applicability: Supports population-specific uncertainty
- Confidence: medium
- Source: S8 (section: Abstract)
- Limitations: No feeding or angling endpoint was measured.
- Surrogate evidence: false
### E11. Parental care and feeding - score
- Exact condition/range: Nesting and nonnesting redbreast sunfish sampled at dawn and dusk.
- Observed effect: Nesting was associated with a slight-to-major reduction in prey quantity and diversity compared with nonnesting fish.
- Measured: Gut contents by nesting state and time of day
- Population/location: Natural lake population
- Life stage: Adult parental males and nonnesting adults
- Evidence type: field feeding study
- NOVA applicability: Direct feeding endpoint; transfer limited by sex, state, and single system
- Confidence: medium
- Source: S9 (section: Abstract)
- Limitations: Defensive strikes may still occur; reduced feeding does not equal zero catchability.
- Surrogate evidence: false
### E12. Diel prey selection during nesting - context-only
- Exact condition/range: Dawn versus dusk samples of nesting and nonnesting fish.
- Observed effect: Benthic prey formed a greater dietary proportion at dawn than dusk, while nesting status altered total diet.
- Measured: Gut contents and prey categories
- Population/location: Natural lake population
- Life stage: Adult
- Evidence type: field feeding study
- NOVA applicability: Mechanistic context only
- Confidence: low
- Source: S9 (section: Abstract)
- Limitations: No hook-and-line endpoint and no full environmental light record.
- Surrogate evidence: false
### E13. Virginia reproductive habitat - context-only
- Exact condition/range: North Anna River; spawning began in late May after water exceeded 20 C.
- Observed effect: Nests occurred in pool habitat with low current velocity below 0.10 m/s and depths above 0.5 m; degree-days helped explain nest density.
- Measured: Nest timing, density, depth, and velocity
- Population/location: North Anna River, Virginia
- Life stage: Adult males
- Evidence type: regional field study
- NOVA applicability: High geographic relevance for location context
- Confidence: high
- Source: S10 (page: 235-242; section: Results; Discussion)
- Limitations: Habitat occupancy and nest density are not feeding or catchability.
- Surrogate evidence: false
### E14. Fish Guide gear and regional management - context-only
- Exact condition/range: Pennsylvania river fisheries.
- Observed effect: Management guidance documents intentional angling, distribution, and fishery context.
- Measured: Agency fishery synthesis
- Population/location: Pennsylvania
- Life stage: Mixed
- Evidence type: government management report
- NOVA applicability: High Mid-Atlantic targetability relevance
- Confidence: medium
- Source: S11 (section: Fishing and management sections)
- Limitations: Not an experimental bite-predictor source.
- Surrogate evidence: false
### E15. Weather and lunar variables - zero-weight
- Exact condition/range: Barometric pressure, fronts, wind, ordinary rain, cloud cover, and moon phase.
- Observed effect: No qualifying species-specific study directly isolated these variables for feeding, foraging, or hook-and-line catchability.
- Measured: Documented evidence gap
- Population/location: Range-wide
- Life stage: Mixed
- Evidence type: broad evidence review
- NOVA applicability: Directly relevant to excluding unsupported weights
- Confidence: medium
- Source: S1 (section: Reference review)
- Limitations: Absence of evidence does not prove no effect; it does preclude a defensible production rule.
- Surrogate evidence: false

## Remaining research gaps
- Direct adult Mid-Atlantic hook-and-line tests of temperature, temperature trend, oxygen, light, turbidity, and flow.
- A replicated estimate of the magnitude and duration of parental-care feeding suppression.
- Short-term angling-pressure and hook-avoidance experiments.

## Adversarial review outcome
Every candidate rule was tested against the actual endpoint. Movement, habitat occupancy, growth, physiology, survival, spawning, and creel seasonality were not converted into bite rules unless feeding or hook-and-line catchability was directly measured. Contradictory and null findings are preserved, exact values remain bounded to studied conditions, and no final production multiplier or invented smooth curve is supplied.

## Complete bibliography
### S1. Virginia Department of Wildlife Resources (2024)
**Redbreast Sunfish**. Virginia Department of Wildlife Resources.
https://dwr.virginia.gov/wildlife/information/redbreast-sunfish/
Scope: Virginia. Access: agency-web-full-text. Verification: AI-reviewed-unverified.
### S2. D. Gray Bass Jr. and Vinard G. Hitt (1974)
**Ecological Aspects of the Redbreast Sunfish, Lepomis auritus, in Florida**. Proceedings of the Annual Conference of the Southeastern Association of Game and Fish Commissioners 28:296-307.
https://seafwa.org/sites/default/files/journal-articles/BASS-296.pdf
Scope: Suwannee and Santa Fe rivers, Florida. Access: original-pdf-full-text. Verification: AI-reviewed-unverified.
### S3. Robert G. Hudson and F. Eugene Hester (1976)
**Movements of the Redbreast Sunfish in Little River, Near Raleigh, North Carolina**. Proceedings of the Annual Conference of the Southeastern Association of Fish and Wildlife Agencies 30:325-329.
https://seafwa.org/sites/default/files/journal-articles/HUDSON-325.pdf
Scope: Little River, North Carolina. Access: original-pdf-full-text. Verification: AI-reviewed-unverified.
### S4. Daniel S. Levine, Arnold G. Eversole, and Harold A. Loyacano Jr. (1986)
**Biology of Redbreast Sunfish in Beaver Ponds**. Proceedings of the Annual Conference of the Southeastern Association of Fish and Wildlife Agencies 40:216-226.
https://seafwa.org/sites/default/files/journal-articles/LEVINE-216-226.pdf
Scope: South Carolina Piedmont beaver ponds. Access: original-pdf-full-text. Verification: AI-reviewed-unverified.
### S5. Brian S. Helms, Nate A. Bickford, Nathan W. Tubbs, and Jack W. Feminella (2018)
**Feeding, growth, and trophic position of redbreast sunfish (Lepomis auritus) in watersheds of differing land cover in the lower Piedmont, USA**. Urban Ecosystems 21:107-117. DOI: 10.1007/s11252-017-0696-8.
https://doi.org/10.1007/s11252-017-0696-8
Scope: Three lower-Piedmont Georgia streams. Access: publisher-and-author-full-text. Verification: AI-reviewed-unverified.
### S6. David B. Carmichael (2005)
**Recruitment and Growth of Edisto River Redbreast Sunfish**. South Carolina Department of Natural Resources completion report.
https://www.dnr.sc.gov/fish/fwfi/files/EdistoRedbreastCompletionReport2005.pdf
Scope: Edisto River, South Carolina. Access: agency-report-full-text. Verification: AI-reviewed-unverified.
### S7. Steven M. Sammons and Michael J. Maceina (2009)
**Effects of River Flows on Growth of Redbreast Sunfish Lepomis auritus (Centrarchidae) in Georgia Rivers**. Journal of Fish Biology 74(7):1580-1593. DOI: 10.1111/j.1095-8649.2009.02231.x.
https://doi.org/10.1111/j.1095-8649.2009.02231.x
Scope: Nine Georgia rivers. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S8. Steven M. Sammons and Michael J. Maceina (2009)
**Variation in Growth and Survival of Bluegills and Redbreast Sunfish in Georgia Rivers**. North American Journal of Fisheries Management 29(1):101-108. DOI: 10.1577/M07-140.1.
https://doi.org/10.1577/M07-140.1
Scope: Thirteen sections of Georgia rivers. Access: publisher-abstract-only. Verification: AI-reviewed-unverified.
### S9. J. H. Thorp, L. D. Goldsmith, J. A. Polgreen, and L. M. Mayer (1989)
**Foraging Patterns of Nesting and Nonnesting Sunfish (Centrarchidae: Lepomis auritus and L. gibbosus)**. Canadian Journal of Fisheries and Aquatic Sciences 46:1342-1346. DOI: 10.1139/f89-172.
https://doi.org/10.1139/f89-172
Scope: Natural lake population; North America. Access: publisher-abstract-and-metadata. Verification: AI-reviewed-unverified.
### S10. Joseph A. Lukas and Donald J. Orth (1993)
**Reproductive Ecology of Redbreast Sunfish Lepomis auritus in a Virginia Stream**. Journal of Freshwater Ecology 8(3):235-244. DOI: 10.1080/02705060.1993.9664859.
https://doi.org/10.1080/02705060.1993.9664859
Scope: North Anna River, Virginia. Access: author-repository-full-text. Verification: AI-reviewed-unverified.
### S11. R. Lorantas and B. Frick (2018)
**Redbreast Sunfish Management and Fishing in Pennsylvania**. Pennsylvania Fish and Boat Commission.
https://www.pa.gov/content/dam/copapwp-pagov/en/fishandboat/documents/about-us/agencyoverview/species-mgmt-plans/redbreastsunfishmanagement.pdf
Scope: Pennsylvania. Access: agency-report-full-text. Verification: AI-reviewed-unverified.
